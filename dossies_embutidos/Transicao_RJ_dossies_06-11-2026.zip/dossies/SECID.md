# Dossiê reduzido — Secretaria de Estado das Cidades (SECID)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SECID.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SECID_pesquisa.md`.

## Resumo executivo
- O TCE-RJ concedeu tutela provisória relativa a contratos da Secretaria das Cidades derivados do Pregão Eletrônico nº 002/2024, apontando indícios de falhas de planejamento, diagnósticos estruturais posteriores às autorizações e aditivos elevados; a decisão impôs restrições à execução e a novos aditivos. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- Há duas apurações que devem ser acompanhadas separadamente: uma fiscalização do TCE-RJ sobre contratos de pavimentação e investigações do MPRJ sobre suspeitas relacionadas a contratos da gestão anterior; os apontamentos não equivalem a comprovação de ilícitos. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/) [G1: auditorias de R$ 2,6 bilhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/09/18/governo-do-rj-mp-auditorias-suspeitas-de-irregularidades.ghtml) [G1: investigação sobre patrimônio](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/01/mprj-investiga-crescimento-patrimonial-de-empresas-ligadas-a-douglas-ruas.ghtml)
- As fontes não esclarecem o estágio atual de execução dos contratos, a situação dos serviços, os pagamentos pendentes ou a continuidade das restrições do TCE-RJ em 06/11/2026; esses dados devem ser obtidos antes da posse. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/) [O Globo: suspensão por 30 dias](https://oglobo.globo.com/rio/noticia/2026/04/17/governador-em-exercicio-suspende-licitacoes-e-contratos-das-secretarias-de-cidades-obras-e-do-der-por-30-dias-no-rio.ghtml)

## 1. Missão e competências
- Atuar na recuperação de pavimentação asfáltica, calçadas e sinalização viária, conforme os contratos citados.
- Promover intervenções de mobilidade urbana, incluindo corredor seletivo para ônibus.
- Atuar no desenvolvimento da Região Metropolitana do Rio de Janeiro, conforme a unidade vinculada indicada.

## 2. Estrutura essencial
- Titular: a confirmar.
- FDRM-RJ - Fundo de Desenv. da Região Metropolitana do RJ.
- RIO METRÓPOLE - Instituto Rio Metrópole.
- SECID - SECRETARIA DE ESTADO DAS CIDADES.

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 56 contratos, R$ 1,98 bi (+1 'Ativo' sem data de fim válida, R$ 0,0 mi) |
| Vencem em até 30 dias | 6 contratos, R$ 45,6 mi |
| Vencem em até 90 dias | 19 contratos, R$ 628,0 mi (16 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 42 contratos, R$ 1,41 bi |
| Emergenciais vigentes ou sem data de fim | 5 contratos, R$ 13,2 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 1,5 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2023000622 | UNIÃO NORTE FLUMINENSE ENGENHARIA E COMÉRCIO… | IMPLANTAÇÃO DE CORREDOR SELETIVO PARA ÔNIBUS - TIPO MUVI (M… | R$ 287.270.164,81 | 08/12/2026 (DOERJ) |
| 2025005644 | F P VIEIRA ENGENHARIA LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA ELABORAÇÃO DE PRO… | R$ 174.740.216,76 | 02/02/2027 |
| 2026000098 | FABMIX CONCRETOS LTDA | Serviços contínuos de conservação, manutenção e restauração… | R$ 61.695.367,59 | 10/01/2027 (PNCP) |
| 2025005434 | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | CONTRATAÇÃO DE EMPRESAESPECIALIZADA PARA EXECUÇÃO DE SERVIÇ… | R$ 22.232.496,64 | 07/11/2026 (PNCP) |
| 2025006853 | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | REGISTRO DE PREÇOS para eventual e futura contratação de em… | R$ 15.361.022,81 | 16/12/2026 (PNCP) |
| 2025005678 | MEGA ENGENHARIA EIRELI | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NO RAMO DE ENGENHARIA … | R$ 9.595.316,52 | 24/12/2026 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 47 (R$ 806,5 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 19 (R$ 628,0 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 2 | 0 | Alerta |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2023001703 | F P VIEIRA ENGENHARIA LTDA | R$ 252.225.720,44 | 21/05/2026 |
| 2022009355 | CONSTRUTORA METROPOLITANA S.A. | R$ 248.749.950,11 | 25/05/2026 |
| 2024006725 | F P VIEIRA ENGENHARIA LTDA | R$ 130.105.162,67 | 21/08/2025 |

## 5. Alertas vermelhos
- 6 contrato(s) vencem em até 30 dias (R$ 45,6 mi).
- 5 contratação(ões) emergencial(is) vigente(s) ou sem data de fim (R$ 13,2 mi): verificar limite de 1 ano (Lei 14.133, art. 75, VIII).
- 2 contrato(s) com fornecedor em recuperação judicial.
- O TCE-RJ apontou aumento agregado de R$ 520,1 milhões para R$ 744,9 milhões em 13 contratos aditados e concedeu tutela provisória. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- A fiscalização relatou diagnósticos estruturais posteriores às autorizações em 119 trechos e serviços em sete trechos sem ordem de serviço prévia. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- A pesquisa relata acréscimos acima de 25% em diversos contratos e inclusão de serviços que o TCE-RJ considerou estranhos ao objeto original. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- Há investigação do MPRJ sobre suspeitas relacionadas a contratos da gestão anterior; a pesquisa ressalva que não são ilícitos comprovados. [G1: investigação sobre patrimônio](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/01/mprj-investiga-crescimento-patrimonial-de-empresas-ligadas-a-douglas-ruas.ghtml)
- Auditorias estaduais sobre contratos de pelo menos R$ 2,6 bilhões foram encaminhadas ao MPRJ; o total não é exclusivo da SECID. [G1: auditorias de R$ 2,6 bilhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/09/18/governo-do-rj-mp-auditorias-suspeitas-de-irregularidades.ghtml)

## 6. Riscos prioritários
- Risco de descumprimento das restrições da tutela do TCE-RJ ou de novas ordens e aditivos sem verificar sua vigência e as condições impostas. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- Fragilidade de planejamento, diagnóstico e autorização pode comprometer a regularidade da execução e das medições dos contratos. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- O SIGA aponta 19 contratos, no total de R$ 627.969.876,81, com término em até 90 dias; a pesquisa não esclarece a situação operacional nem a continuidade dos serviços.
- A pesquisa não confirma paralisações, mas também não informa o estágio de execução, pagamentos pendentes e serviços em andamento, dificultando avaliar risco de descontinuidade.
- A SECID registra cinco contratos emergenciais, somando R$ 13.220.871,43; verificar objeto, vigência, fundamento e execução para identificar obrigações ou lacunas na transição.

## 7. Perguntas-chave para IA externa
1. Qual é a íntegra da decisão do TCE-RJ de 14/10/2026, ela segue vigente e que informações há sobre o cumprimento das restrições pela SECID? [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
2. Quais contratos decorrem do Pregão Eletrônico nº 002/2024, com valores originais e atualizados, aditivos, medições, pagamentos, ordens de serviço e situação atual? [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
3. Quais documentos justificam os aditivos e os itens novos apontados pelo TCE-RJ, inclusive nos contratos nº 023/2025, nº 031/2025 e nº 032/2025? [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
4. Quais diagnósticos, laudos, ordens de serviço e medições existem para os 119 trechos com diagnósticos posteriores e os sete trechos executados sem ordem prévia, e que esclarecimentos foram apresentados sobre os apontamentos da fiscalização? [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
5. Qual é a situação de encerramento, saldo, medições e pagamentos do contrato 2023000622, de R$ 287.270.164,81, com término informado em 08/12/2026?
6. Qual é o cronograma, saldo contratual e previsão de continuidade do contrato 2025005644, de R$ 174.740.216,76, com término informado em 02/02/2027?
7. O contrato 2026000098, de R$ 61.695.367,59, tinha término informado em 10/01/2027: quais serviços, saldo, medições e providências de continuidade estão previstos?
8. Os contratos 2025005434, de R$ 22.232.496,64, e 2025006853, de R$ 15.361.022,81, com a mesma fornecedora, têm objetos, locais ou serviços coincidentes? Quais são os saldos e as medições de cada um?
9. Quais contratos compõem os R$ 627.969.876,81 com término em até 90 dias, e quais têm continuidade autorizada, nova contratação necessária ou risco de interrupção?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SECID | Secretaria de Estado das Cidades | 56 | R$ 1,98 bi | 19 | R$ 628,0 mi | 0 | Tutela do TCE-RJ e situação de cumprimento dos contratos ainda não confirmadas. | Obter a íntegra da decisão do TCE-RJ, confirmar sua vigência e alcance e verificar o cump… |

## Fontes da pesquisa
1. [Governo do RJ envia auditorias ao TCE e aponta irregularidades em diversas áreas do estado](https://cbn.globo.com/politica/analise/2026/09/18/governo-do-rj-envia-auditorias-ao-tce-e-aponta-irregularidades-em-diversas-areas-do-estado.ghtml) — 2026-09-18
2. [TCE-RJ aponta irregularidades em contratos de R$ 663 milhões da ...](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/) — 2026-10-14
3. [Contratos do Governo do RJ: auditorias de R$ 2,6 bi vão ao MP   G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/09/18/governo-do-rj-mp-auditorias-suspeitas-de-irregularidades.ghtml) — 2026-09-18
4. [ACÓRDÃO Nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026) — 2026-07-06
5. [Douglas Ruas: MPRJ investiga patrimônio de empresas do ... - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/01/mprj-investiga-crescimento-patrimonial-de-empresas-ligadas-a-douglas-ruas.ghtml) — 2026-10-01
6. [Governador em exercício suspende licitações e contratos das ...](https://oglobo.globo.com/rio/noticia/2026/04/17/governador-em-exercicio-suspende-licitacoes-e-contratos-das-secretarias-de-cidades-obras-e-do-der-por-30-dias-no-rio.ghtml) — 2026-04-17

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
