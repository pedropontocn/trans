# Dossiê reduzido — Secretaria de Estado de Agricultura, Pecuária, Abastecimento e Pesca (SEAPA)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEAPA.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEAPA_pesquisa.md`.

## Resumo executivo
- Em 27/10/2026, a Polícia Federal deflagrou a segunda fase da Operação Castratio para apurar suspeitas de irregularidades em contratos ligados à Secretaria, cujo valor total informado pela imprensa é de R$ 200 milhões. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/) [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- A PF investiga suspeitas de direcionamento, superfaturamento e fraude à licitação, sem que as fontes fornecidas relatem condenação ou conclusão definitiva sobre esses fatos. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/) [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- O governo informou que os serviços da Consuvet no programa RJ PET estavam extintos desde 2024, após auditoria da Secretaria de Saúde; as fontes não relatam risco atual de interrupção desses serviços. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- Em junho de 2026, a Secretaria informava planos de revisão contratual e economia, mas as fontes não esclarecem se as metas foram implementadas até 06/11/2026. [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/) [O Globo — corte nos contratos vigentes](https://oglobo.globo.com/blogs/ancelmo-gois/post/2026/06/governo-do-rio-preve-corte-de-12percent-nos-contratos-vigentes-da-secretaria-de-agricultura.ghtml)

## 1. Missão e competências
- Atuação nas áreas de agricultura e pecuária, conforme a denominação da Secretaria.
- Atuação em pesca e abastecimento, conforme a denominação da Secretaria.
- Apoio a ações voltadas ao produtor rural, mencionado nas notícias sobre a revisão contratual.

## 2. Estrutura essencial
- Titular: Felipe Brasil, citado como titular em junho de 2026; confirmar a situação atual e em 01/01/2027.
- CASERJ - COMPANHIA DE ARMAZÉNS E SILOS DO EST DO RJ
- CEASA-RJ - CENTRAIS DE ABASTECIMENTO DO ESTADO DO RJ
- EMATER-RIO - EMPR DE ASSIST TÉCN E EXT RURAL DO EST DO RJ
- FIPERJ - FUNDACAO INSTITUTO DE PESCA DO ESTADO DO RJ
- FUNDEAGRO  - Fundo Estadual de Defesa Agropecuária
- FUNDEAGRO - FUNDO ESTADUAL DE DEFESA AGROPECUÁRIA
- PESAGRO-RIO - EMPR DE PESQUISA AGROPECUÁRIA DO EST DO RJ
- SEAPPA - GES/SP - SEAAPI-PROJETO RIO RURAL/GES-SEP
- SEAPPA - Secretaria de Estado de Agricultura, Pecuária, Pesca e Abastastecimento
- SEDRAP - SEC EST DESEN REG  ABASTEC E PESCA

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 142 contratos, R$ 398,4 mi (+13 'Ativo' sem data de fim válida, R$ 46,1 mi) |
| Vencem em até 30 dias | 6 contratos, R$ 19,3 mi |
| Vencem em até 90 dias | 36 contratos, R$ 195,3 mi (2 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 83 contratos, R$ 242,0 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 35,2 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2024000734 | JRF MANUTENCAO E SERVICOS EIRELI ME | Contratação de empresa especialiada em serviços de coleta d… | R$ 69.234.774,90 | 01/01/2027 |
| 2024000556 | PLIMA VIGILANCIA E SEGURANCA PRIVADA LTDA ME | Contratação de empresa especialiada em serviços de vigilânc… | R$ 47.971.311,01 | 28/12/2026 |
| 2024000555 | EMSIMEM MANUTENÇÃO E CONSERVAÇÃO LTDA ME | Contratação de empresa especialiada em serviços de engenhar… | R$ 11.553.390,00 | 01/01/2027 |
| 2025005321 | RESBRITEC CONSTRUÇÕES COMÉRCIO E SERVIÇOS LT… | Contratação de Empresa Especializada para Execução de Obras… | R$ 9.890.000,00 | 30/11/2026 |
| 2025010209 | MULTIPLAR ENGENHARIA E LOCACOES LTDA | contratação de empresa para a prestação de serviços de loca… | R$ 8.339.110,63 | 10/12/2026 (PNCP) |
| 2021007622 | ASSOCIAÇÃO NITEROIENSE DOS DEFICIENTES FISIC… | Contratação de mão de obra terceirizada. | R$ 7.586.811,96 | 21/12/2026 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 343 (R$ 612,9 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 36 (R$ 195,3 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2022007182 | CONPLAN EMPREENDIMENTOS E SERVIÇOS LTDA-ME | R$ 60.282.000,00 | 22/09/2025 |
| 2022006734 | ABBM BRAGA COMERCIO E SERVIÇOS LTDA ME | R$ 29.391.675,99 | 09/09/2025 |
| 2022006957 | G S GOUVEA DISTRIBUIDORA E SERVIÇOS EIRELI | R$ 26.102.699,25 | 18/09/2025 |

## 5. Alertas vermelhos
- 6 contrato(s) vencem em até 30 dias (R$ 19,3 mi).
- A PF investiga suspeitas de direcionamento, superfaturamento e fraude à licitação; não há conclusão definitiva informada. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/)
- A imprensa atribui à primeira fase da operação investigação sobre contratos da Consuvet que totalizariam R$ 200 milhões. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- O G1 relata indícios sobre capacidade da empresa, registro profissional e possível relação entre agente público e Consuvet; são alegações investigadas, não fatos julgados. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- Em 27/10/2026, a PF cumpriu cinco mandados de busca e apreensão expedidos pelo STF. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/)
- A Secretaria anunciou metas de redução de custos em junho de 2026, mas as fontes não confirmam sua implementação ou os resultados. [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/)

## 6. Riscos prioritários
- O SIGA/PNCP registra 36 contratos no recorte de 90 dias, somando R$ 195.310.521,37, e 83 no de 180 dias, somando R$ 241.980.720,31; confirmar vencimentos, renovações e continuidade dos serviços antes da posse.
- Contratos de alto valor listados incluem coleta de lixo, R$ 69.234.774,90, com fim em 01/01/2027, e vigilância, R$ 47.971.311,01, com fim em 28/12/2026; verificar cobertura e transição para evitar interrupções.
- O painel informa R$ 35.229.972,06 a pagar; sem detalhamento de credores, vencimentos ou atrasos, há risco de passivos não mapeados na transição.
- Há investigação criminal sobre contratos ligados à Secretaria, enquanto a documentação fornecida não detalha os contratos individuais da Consuvet, pagamentos ou entregas. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/)
- As metas anunciadas de redução contratual e economia de R$ 33,7 milhões em 12 meses não têm resultado atualizado nas fontes; mudanças sem verificação de execução e impacto podem afetar serviços e apoio ao produtor rural. [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/)

## 7. Perguntas-chave para IA externa
1. Quais dos 36 contratos do recorte de 90 dias, no total de R$ 195.310.521,37, vencem antes ou próximo de 01/01/2027, e qual o plano para cada serviço?
2. O contrato SIGA 2024000734, de R$ 69.234.774,90, com fim informado em 01/01/2027, será prorrogado, substituído ou encerrado? Qual a cobertura do serviço na transição?
3. Qual é o status do contrato SIGA 2024000556, de R$ 47.971.311,01, com fim informado em 28/12/2026, e como será garantida a continuidade da vigilância?
4. Qual é a situação dos contratos SIGA 2024000555, de R$ 11.553.390,00, e SIGA 2025005321, de R$ 9.890.000,00, ambos com término informado em 2026, incluindo medições, pagamentos e entregas pendentes?
5. Quais contratos relacionados à Consuvet e ao programa RJ PET tiveram números, valores individuais, aditivos, pagamentos, entregas e responsáveis? Quais documentos da auditoria da Secretaria de Saúde sustentam a informação de encerramento dos serviços em 2024? [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
6. Qual foi a economia efetivamente realizada com a revisão contratual anunciada em junho de 2026, incluindo contratos alterados e impactos sobre os serviços? [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/)
7. Como se compõem os R$ 35.229.972,06 informados como a pagar, por credor, contrato, vencimento e eventual atraso?
8. Quais são os contratos SIGA 2022007182, de R$ 60.282.000,00, 2022006734, de R$ 29.391.675,99, e 2022006957, de R$ 26.102.699,25, com términos informados em setembro de 2025, e qual o status de encerramento, liquidação e pagamento?
9. Qual é o status atualizado das apurações da PF, do MPRJ e da Polícia Civil, e existem decisões ou determinações do STF, TCE-RJ ou Controladoria que exijam providências da Secretaria? [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/)

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEAPA | Secretaria de Estado de Agricultura, Pecuária, Abastecimento e Pesca | 142 | R$ 398,4 mi | 36 | R$ 195,3 mi | 0 | Vencimentos contratuais próximos à posse sem plano de continuidade confirmado. | Validar vencimentos, pagamentos e planos de continuidade dos contratos críticos. |

## Fontes da pesquisa
1. [PF apura irregularidades em contratos no Rio de Janeiro](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/) — 2026-10-27
2. [PF apura suspeita de fraudes em licitações no Rio de Janeiro](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/05/pf-combate-organizacao-criminosa-suspeita-de-fraudes-em-licitacoes-no-rio-de-janeiro) — 2026-05-12
3. [Marcelo Queiroz é alvo da PF em operação sobre castração de animais   G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml) — 2026-10-27
4. [Secretaria de Agricultura do estado anuncia redução no valor dos contratos; governo espera diminuir em até 20%](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/) — 2026-06-08
5. [Governo do Rio prevê corte de 12% nos contratos vigentes ...](https://oglobo.globo.com/blogs/ancelmo-gois/post/2026/06/governo-do-rio-preve-corte-de-12percent-nos-contratos-vigentes-da-secretaria-de-agricultura.ghtml) — 2026-06-08

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
