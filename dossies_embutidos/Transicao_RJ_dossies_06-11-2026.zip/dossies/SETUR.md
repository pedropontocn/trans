# Dossiê reduzido — Secretaria de Estado de Turismo (SETUR)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SETUR.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SETUR_pesquisa.md`.

## Resumo executivo
- A Setur-RJ destinou R$ 10.998.000 a patrocínios e apoio financeiro para 18 eventos realizados entre 28 de julho e 27 de agosto de 2026; a reportagem também registra reconhecimento de dívida de R$ 349.326,56 referente a evento de 2025. [Patrocínios de agosto](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/)
- Há uma informação de controle a verificar com prioridade: o TCE-RJ deu 15 dias ao ex-secretário Gustavo Tutuca para apresentar defesa sobre patrocínio de R$ 5 milhões ligado à Universal, mas a fonte não informa o resultado nem o andamento posterior. [Prazo do TCE-RJ](https://temporealrj.com/category/transparencia/page/9/)
- Em maio, a imprensa apontou R$ 12.449.000 em extratos de investimentos e repasses publicados após anúncio de contenção de gastos; a Secretaria afirmou que os eventos citados decorriam de contratos anteriores e que 25 eventos deixaram de receber apoio, com economia superior a R$ 26.000.000. [Patrocínios e contenção de gastos](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)
- A troca de comando de Gustavo Tutuca para Lucas Alves foi descrita como planejada e sem ruptura, mas as fontes não detalham medidas administrativas para a transição de governo em 01/01/2027. [Transição na Setur-RJ](https://brasilturis.com.br/2026/03/20/tutuca-deixa-setur-rj-apos-cinco-anos-e-lucas-alves-assume-comando/)

## 1. Missão e competências
- Promover o turismo do Estado do Rio de Janeiro e atrair negócios para o setor.
- Apoiar eventos por meio de patrocínios e outras formas de apoio financeiro.
- Estimular a interiorização da promoção turística e a divulgação de destinos fluminenses.

## 2. Estrutura essencial
- Titular: Lucas Alves, citado como sucessor de Gustavo Tutuca em março de 2026; permanência no cargo a confirmar.
- Unidade: SETUR - SECRETARIA DE TURISMO.
- Unidade vinculada: TURISRIO - COMPANHIA DE TURISMO DO EST RJ.

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 1 contratos, R$ 0,2 mi (+2 'Ativo' sem data de fim válida, R$ 0,4 mi) |
| Vencem em até 30 dias | 0 contratos, R$ 0,0 mi |
| Vencem em até 90 dias | 0 contratos, R$ 0,0 mi (0 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 0 contratos, R$ 0,0 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 1,6 mi |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 3 (R$ 0,6 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 0 (R$ 0,0 mi) | Renovação/licitação definida | OK |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2024002474 | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | R$ 481.600,00 | 04/04/2025 |
| 2024004344 | RIOPAR PARTICIPAÇÕES S/A | R$ 81.000,00 | 12/06/2025 |
| 2025005664 | CBD BOLHETE DIGITAL S/A | R$ 34.020,15 | 30/07/2026 |

## 5. Alertas vermelhos
- TCE-RJ concedeu prazo de 15 dias para defesa sobre patrocínio de R$ 5 milhões ligado à Universal; resultado e andamento posterior não constam das fontes. [Prazo do TCE-RJ](https://temporealrj.com/category/transparencia/page/9/)
- A reportagem informa que extratos da Setur somaram R$ 12.449.000 e que, segundo a Secretaria, 25 eventos deixaram de receber apoio financeiro do Estado, gerando economia superior a R$ 26 milhões. A página não apresenta a lista desses eventos nem a memória de cálculo e afirma que os contratos mencionados na reportagem foram firmados e executados antes das medidas de contenção. [Patrocínios e contenção de gastos](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)
- Foram informados R$ 6.522.034,26 em 15 patrocínios de outubro; faltam, nas fontes, dados completos sobre instrumentos, execução e pagamentos. [Patrocínios de outubro](https://temporealrj.com/turismo-6-milhoes-15-patrocinios-outubro/)
- A pesquisa não apresenta plano de transição para 01/01/2027 nem inventário de contratos continuados e planos de continuidade.

## 6. Riscos prioritários
- Pendência de controle externo: situação, defesa e decisões do TCE-RJ sobre o patrocínio de R$ 5 milhões ligado à Universal precisam ser confirmadas. [Prazo do TCE-RJ](https://temporealrj.com/category/transparencia/page/9/)
- Conciliação financeira prioritária: SIGA informa R$ 1.633.433,68 a pagar e um registro vigente de R$ 195.218,136; os dados fornecidos não identificam os instrumentos nem explicam a diferença.
- A pesquisa registra patrocínios recentes de R$ 10.998.000 em agosto e R$ 6.522.034,26 em outubro, sem detalhamento suficiente nas fontes sobre empenhos, pagamentos e comprovação das entregas. [Patrocínios de agosto](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/) [Patrocínios de outubro](https://temporealrj.com/turismo-6-milhoes-15-patrocinios-outubro/)
- As fontes registram reconhecimentos de dívida de R$ 349.326,56 relativos ao Fenacam e de R$ 1 milhão destinado ao Flamengo por débitos relacionados a um evento em Orlando; não informam a situação atual desses reconhecimentos. [Dívida do Fenacam](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/) [Reconhecimento de dívida do Flamengo](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)
- Risco de lacuna de continuidade: não há nas fontes inventário de serviços continuados, fornecedores, vigências ou plano de transição para 01/01/2027.
- A compatibilidade entre os R$ 12.449.000 em extratos, a contenção de gastos anunciada e a economia declarada superior a R$ 26.000.000 não está demonstrada. [Patrocínios e contenção de gastos](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)

## 7. Perguntas-chave para IA externa
1. Qual é o número do processo no TCE-RJ sobre o patrocínio de R$ 5 milhões ligado à Universal, e qual o status da defesa, das decisões e das providências pendentes?
2. Quais registros SIGA compõem os 174 ativos e qual instrumento corresponde ao único registro vigente de R$ 195.218,136? Informar números SIGA/PNCP, partes, vigência e objeto.
3. A que obrigações correspondem os R$ 1.633.433,68 a pagar? Apresentar números SIGA/PNCP, credores, vencimentos e valores empenhados, liquidados e pagos.
4. Quais são os três registros SIGA classificados como nv24, associados a R$ 596.620,15, e qual a situação atual de cada um, incluindo saldos e pagamentos?
5. Quais instrumentos e números SIGA/PNCP correspondem aos 15 patrocínios de outubro, no total de R$ 6.522.034,26, incluindo o Roadshow BBG Brasil — Europa 2026, de R$ 1.194.000?
6. Quais processos e registros financeiros correspondem aos R$ 10.998.000 em patrocínios de agosto e ao reconhecimento de dívida de R$ 349.326,56? Quais valores foram pagos e quais permanecem em aberto?
7. Qual é o status contábil e de pagamento do reconhecimento de dívida de R$ 1.000.000 relacionado a evento em Orlando, e qual o respectivo número do processo ou registro SIGA/PNCP?
8. A Secretaria pode fornecer a relação dos 25 eventos que deixaram de receber apoio, os documentos de cancelamento e a memória de cálculo da economia superior a R$ 26.000.000, conciliados com os R$ 12.449.000 em extratos?
9. A Setur possui contratos de serviços continuados? Em caso afirmativo, informar números SIGA/PNCP, fornecedores, vigências, fiscais e planos de continuidade. Existe plano de transição para 01/01/2027 e, em caso afirmativo, quem responde por ele?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SETUR | Secretaria de Estado de Turismo | 1 | R$ 0,2 mi | 0 | R$ 0,0 mi | 0 | Pendências financeiras e de controle sem conciliação documental para a transição. | Conciliar obrigações e patrocínios, e atualizar o status do processo no TCE-RJ. |

## Fontes da pesquisa
1. [Arquivo de Transparência - Página 11 de 74 - Tempo Real](https://temporealrj.com/category/transparencia/page/11/) — 2026-11-05
2. [Arquivo de Transparência - Página 9 de 74 - Tempo Real](https://temporealrj.com/category/transparencia/page/9/) — 2026-11-03
3. [roadshow começa com foco em negócios e na força do turismo ...](https://www.rj.gov.br/secturismo/node/391) — 2026-06-17
4. [Turismo do Estado destina R$ 6,52 milhões a 15 patrocínios em outubro; capital e Região do Médio Paraíba levam](https://temporealrj.com/turismo-6-milhoes-15-patrocinios-outubro/) — 2026-10-31
5. [Tutuca deixa Setur-RJ após cinco anos e Lucas Alves assume ...](https://brasilturis.com.br/2026/03/20/tutuca-deixa-setur-rj-apos-cinco-anos-e-lucas-alves-assume-comando/) — 2026-03-20
6. [Turismo do estado publica R$ 12,4 milhões em patrocínios ...](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/) — 2026-05-31
7. [A fa(r)tura de agosto: Secretaria de Turismo do estado distribui R$ 11 ...](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/) — 2026-08-29

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
