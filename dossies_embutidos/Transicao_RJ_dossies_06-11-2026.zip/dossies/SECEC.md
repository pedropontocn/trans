# Dossiê reduzido — Secretaria de Estado de Cultura e Economia Criativa (SECEC)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SECEC.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SECEC_pesquisa.md`.

## Resumo executivo
A prioridade imediata é acompanhar a reestruturação do quadro da SECEC e o concurso público: a notícia do STF publicada em 19/10/2026 informa que foram suspensos os efeitos da decisão do TJRJ pelo tempo necessário às providências, limitado a 12 meses, e que há risco de continuidade dos serviços se houver exonerações sem substituição por efetivos. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)
O MPRJ ajuizou ação civil pública questionando a composição do quadro, descrita como 16 servidores efetivos e 336 cargos em comissão; essa é uma alegação no processo, não uma conclusão definitiva aqui documentada. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)
Há uma janela iminente do programa Cultura em Dia, de 9 a 23/11/2026, para regularização de pendências de proponentes de projetos culturais; as fontes não atribuem essas dívidas à Secretaria. [Programa Cultura em Dia](https://cultura.rj.gov.br/governo-do-estado-lanca-programa-cultura-em-dia-para-regularizacao-de-pendencias-de-projetos-culturais/)
As fontes consultadas não detalham contratos, decisões do TCE-RJ ou resultados/conclusões das auditorias listadas, limitando a avaliação de riscos financeiros e de controle. [Auditorias da SECEC](https://cultura.rj.gov.br/auditorias/)

## 1. Missão e competências
- Atuação em cultura e economia criativa, conforme a denominação da Secretaria.
- Acompanhamento de mecanismos de fomento e projetos culturais.
- Atuação relacionada a equipamentos culturais e unidades vinculadas.

## 2. Estrutura essencial
- Titular: a confirmar
- FCFB - FUNDAÇÃO CASA FRANÇA BRASIL
- FEC - Fundo Estadual da Cultura
- FMIS - FUNDAÇÃO MUSEU DA IMAGEM E DO SOM
- FTMRJ - FUNDAÇÃO TEATRO MUNICIPAL DO RIO DE JANEIRO
- FUNARJ - FUND ANITA MANTUANO DE ARTES DO EST DO RJ
- SECEC - Sec de Estado de Cultura e Econ Criativa

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 426 contratos, R$ 99,6 mi (+22 'Ativo' sem data de fim válida, R$ 2,1 mi) |
| Vencem em até 30 dias | 82 contratos, R$ 16,5 mi |
| Vencem em até 90 dias | 214 contratos, R$ 31,0 mi (6 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 277 contratos, R$ 42,3 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 4,9 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2024009026 | FUNDAÇÃO GETULIO VARGAS | Contratação direta de instituição para prestação de serviço… | R$ 8.000.000,00 | 17/11/2026 (PNCP) |
| 2025008827 | VIGILIA BRASIL SERVIÇOS LTDA | Destina-se a contratação de empresa especializada em presta… | R$ 4.245.944,84 | 03/02/2027 (PNCP) |
| 2026004492 | FP AUDIO EIRELI | Contratação de empresa especializada para prestação de serv… | R$ 1.250.000,00 | 10/11/2026 (PNCP) |
| 2025003396 | CIG PRODUCOES E EVENTOS LTDA - ME | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIC… | R$ 985.537,50 | 22/11/2026 (PNCP) |
| 2024009404 | TOKIO MARINE SEGURADORA SA | Destina-se a contratação de empresa especializada em presta… | R$ 699.185,09 | 26/11/2026 (PNCP) |
| 2026006907 | YDREAMS ENTERTAINMENT LTDA | Contratação da produção, execução, montagem, manutenção, su… | R$ 592.000,00 | 28/12/2026 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 1320 (R$ 306,3 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 214 (R$ 31,0 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2025000464 | LIGA INDEPENDENTE DAS ESCOLAS DE SAMBA DO RIO DE … | R$ 40.000.000,00 | 04/12/2025 |
| 2026000347 | LIGA INDEPENDENTE DAS ESCOLAS DE SAMBA DO RIO DE … | R$ 40.000.000,00 | 28/07/2026 |
| 2025001353 | LIGA INDEPENDENTE DO GRUPO A - RIO DE JANEIRO | R$ 16.000.000,00 | 06/08/2025 |

## 5. Alertas vermelhos
- 82 contrato(s) vencem em até 30 dias (R$ 16,5 mi).
- O STF informou a suspensão temporária dos efeitos da decisão estadual, limitada a 12 meses, para permitir a reestruturação do quadro. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)
- O MPRJ questiona a composição do quadro; os números de efetivos e comissionados são alegações noticiadas, não conclusões definitivas. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)
- O STJ manteve a decisão de exoneração de 20% dos cargos comissionados; a notícia posterior do STF relata suspensão temporária dos efeitos da decisão estadual. [STJ mantém exoneração de 20%](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx) [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)
- A adesão ao Cultura em Dia está prevista de 9 a 23/11/2026; a pesquisa não quantifica casos nem valores das pendências. [Programa Cultura em Dia](https://cultura.rj.gov.br/governo-do-estado-lanca-programa-cultura-em-dia-para-regularizacao-de-pendencias-de-projetos-culturais/)
- A página consultada lista auditorias, mas a pesquisa não detalha achados, recomendações ou providências corretivas. [Auditorias da SECEC](https://cultura.rj.gov.br/auditorias/)

## 6. Riscos prioritários
- Continuidade administrativa e cultural durante a reestruturação do quadro: a pesquisa relata risco reconhecido pelo STF caso haja exonerações sem substituição por efetivos. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)
- Transição de contratos: as estatísticas registram 214 contratações no recorte de 90 dias, no valor de R$ 31.013.695,29; confirmar vencimentos, execução e continuidade dos serviços.
- Contrato 2024009026, de R$ 8.000.000,00, tem término indicado em 17/11/2026; verificar execução, entregas e providências de continuidade antes da posse.
- Contrato 2025008827, de R$ 4.245.944,84, tem término indicado em 03/02/2027; o vencimento ocorre após a posse e requer confirmação de cobertura contratual e serviço.
- As estatísticas registram R$ 4.887.326,17 a pagar e uma contratação emergencial de R$ 2.491.999,92; reconciliar obrigações, documentação e situação de execução.
- A pesquisa não detalha achados de auditoria nem processos do TCE-RJ, e não informa valores ou volume das pendências de proponentes; a ausência de dados limita a avaliação de controle e de exposição financeira. [Auditorias da SECEC](https://cultura.rj.gov.br/auditorias/) [Programa Cultura em Dia](https://cultura.rj.gov.br/governo-do-estado-lanca-programa-cultura-em-dia-para-regularizacao-de-pendencias-de-projetos-culturais/)

## 7. Perguntas-chave para IA externa
1. Qual é a situação processual e o cronograma de cumprimento da decisão sobre o quadro, incluindo a data que inicia a contagem do prazo de até 12 meses? [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)
2. Qual é o quadro atualizado de efetivos e comissionados, o plano de reestruturação e o cronograma do concurso?
3. No contrato 2024009026, de R$ 8.000.000,00, com término indicado em 17/11/2026, quais entregas foram concluídas e qual é a situação de encerramento ou continuidade?
4. No contrato 2025008827, de R$ 4.245.944,84, com término indicado em 03/02/2027, há saldo, aditivos ou risco de interrupção após a posse?
5. Qual é a situação dos contratos 2026004492, de R$ 1.250.000,00, e 2025003396, de R$ 985.537,50, com términos indicados em 10/11/2026 e 22/11/2026, respectivamente?
6. Qual é a execução e a situação de continuidade dos contratos 2024009404, de R$ 699.185,09, e 2026006907, de R$ 592.000,00, com términos indicados em 26/11/2026 e 28/12/2026?
7. A que se referem os R$ 4.887.326,17 a pagar e qual é o cronograma de liquidação, por unidade e contrato?
8. Qual é a situação de execução e prestação de contas dos contratos 2025000464, de R$ 40.000.000,00, 2026000347, de R$ 40.000.000,00, e 2025001353, de R$ 16.000.000,00, associados a projetos de Carnaval?
9. Quais são, se disponíveis, os valores e a quantidade de pendências abrangidas pelo Cultura em Dia? Há auditorias, determinações do TCE-RJ ou planos de ação ainda pendentes? [Programa Cultura em Dia](https://cultura.rj.gov.br/governo-do-estado-lanca-programa-cultura-em-dia-para-regularizacao-de-pendencias-de-projetos-culturais/) [Auditorias da SECEC](https://cultura.rj.gov.br/auditorias/)

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SECEC | Secretaria de Estado de Cultura e Economia Criativa | 426 | R$ 99,6 mi | 214 | R$ 31,0 mi | 0 | Risco de descontinuidade de serviços caso ocorram exonerações imediatas sem substituição … | Obter plano de reestruturação e mapa de contratos críticos antes da posse. |

## Fontes da pesquisa
1. [Auditorias](https://cultura.rj.gov.br/auditorias/) — 2026-10-20
2. [STF dá prazo para que Secretaria de Cultura do RJ reestruture ...](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/) — 2026-11-05
3. [...](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx) — 2026-10-31
4. [Concurso Secec RJ: comissão formada; edital previsto](https://concursos.estrategia.com/portal/concurso-secec-rj/) — 2026-10-19
5. [Governo do Estado lança programa Cultura em Dia para regularização de pendências de projetos culturais](https://cultura.rj.gov.br/governo-do-estado-lanca-programa-cultura-em-dia-para-regularizacao-de-pendencias-de-projetos-culturais/) — 2026-11-04
6. [STJ nega pedido do Rio e mantém 67 exonerações na Secretaria de Cultura](https://noticias.r7.com/brasilia/stj-nega-pedido-do-rio-e-mantem-67-exoneracoes-na-secretaria-de-cultura-15102026/) — 2026-10-15

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
