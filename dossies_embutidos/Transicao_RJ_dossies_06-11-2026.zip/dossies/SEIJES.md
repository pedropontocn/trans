# Dossiê reduzido — Secretaria de Estado Internacional de Juventude e Envelhecimento Saudável (SEIJES)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEIJES.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEIJES_pesquisa.md`.

## Resumo executivo
A auditoria da Casa Civil apontou indícios de irregularidades na execução do “60+ Reabilita”, programa vinculado à Secretaria Intergeracional de Juventude e Envelhecimento Saudável (Seijes), e o governo suspendeu os repasses em agosto de 2026. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml)

As parcerias do programa com o Instituto NATA e a ONG Contato somaram R$ 115 milhões entre 2023 e 2026; as fontes consultadas não discriminam os valores de cada parceria. O Globo informa o Termo de Colaboração nº 001/2024 para o Reabilita II, administrado pelo Instituto NATA. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml) [Metrópoles — irmã do dono do NATA](https://www.metropoles.com/colunas/tacio-lorran/dono-de-os-contratada-no-governo-do-rj-contratou-irma-por-r-12-milhao)

A Seijes foi extinta por decreto, com incorporação de suas atribuições à Secretaria de Desenvolvimento Social e Direitos Humanos e exoneração de 35 servidores, incluindo a secretária Isabela Alves. [Veja](https://veja.abril.com.br/politica/couto-extingue-mais-uma-secretaria-por-irregularidades-em-contratos-r-115-milhoes/)

A sindicância instaurada em 24 de setembro conta com participação da CGE-RJ e do TCE-RJ, mas a fonte não relata decisão específica do Tribunal, ação do MPRJ ou ação judicial relacionada ao caso. [Metrópoles — polos em igreja](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario)

## 1. Missão e competências
- Atuação relacionada a juventude e envelhecimento saudável, conforme a denominação da secretaria.
- Atuação intergeracional, voltada à juventude e ao envelhecimento saudável, conforme a denominação da secretaria.
- O programa 60+ Reabilita era vinculado à Seijes, segundo a pesquisa.

## 2. Estrutura essencial
- Titular: a confirmar. Isabela Alves foi citada como secretária exonerada em agosto de 2026.
- Unidades listadas no SIGA: SEESQV - SEC EST ENVELHECIMTO SAUDÁVEL QUAL VIDA; SEIJES - Secretaria de Estado Intergeracional de Juventude e Envelhecimento Saudável.
- A pesquisa informa que as atribuições da Seijes foram transferidas à Secretaria de Estado de Desenvolvimento Social e Direitos Humanos.

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 0 contratos, R$ 0,0 mi (+0 'Ativo' sem data de fim válida, R$ 0,0 mi) |
| Vencem em até 30 dias | 0 contratos, R$ 0,0 mi |
| Vencem em até 90 dias | 0 contratos, R$ 0,0 mi (0 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 0 contratos, R$ 0,0 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 0,0 mi |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 1 (R$ 0,0 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 0 (R$ 0,0 mi) | Renovação/licitação definida | OK |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2025002957 | NP TECNOLOGIA E GESTAO DE DADOS LTDA | R$ 24.600,00 | 07/05/2026 |

## 5. Alertas vermelhos
- Auditoria apontou pagamentos ao NATA superiores ao que a implantação dos polos justificaria; em novembro de 2025, o excesso sem comprovação ultrapassava R$ 3,4 milhões. [Tempo Real](https://temporealrj.com/couto-extingue-secretaria-auditoria-governo-estado/)
- Em fevereiro de 2025, haviam sido pagos R$ 6 milhões ao NATA, embora o relatório citado registrasse que nenhum polo funcionava naquele momento. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml)
- A auditoria apontou suspeitas de direcionamento, superfaturamento, conflito de interesses e desvio de dinheiro; não são fatos comprovados por decisão final nas fontes consultadas. [Veja](https://veja.abril.com.br/politica/couto-extingue-mais-uma-secretaria-por-irregularidades-em-contratos-r-115-milhoes/)
- O NATA contratou por R$ 1,2 milhão uma empresa pertencente à irmã de seu dono para aluguel de veículos; a contratação teria ocorrido antes da implantação de qualquer unidade. [Metrópoles — irmã do dono do NATA](https://www.metropoles.com/colunas/tacio-lorran/dono-de-os-contratada-no-governo-do-rj-contratou-irma-por-r-12-milhao)
- A pesquisa registra suspensão dos repasses, mas não confirma a situação atual dos atendimentos nem o resultado da análise técnica anunciada. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml)

## 6. Riscos prioritários
- Os repasses ao programa foram suspensos, e as atividades deveriam continuar até o fim da análise técnica, prevista para 30 dias; a fonte não informa o estado dos polos, do custeio e das equipes após esse prazo. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml)
- Risco de pagamentos sem comprovação suficiente de entregas, diante dos achados da auditoria sobre o NATA e a ONG Contato. [Tempo Real](https://temporealrj.com/couto-extingue-secretaria-auditoria-governo-estado/)
- Apuração e responsabilização ainda incertas: a pesquisa informa sindicância e tomada de contas, mas não apresenta resultados nem decisão específica do TCE-RJ; também não encontrou ação ou manifestação do MPRJ nas fontes consultadas. [Metrópoles — polos em igreja](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario)
- Risco de perda de continuidade administrativa na transferência de atribuições, pois a pesquisa não detalha a migração de pessoal, processos, arquivos ou sistemas após a exoneração de 35 servidores. [Veja](https://veja.abril.com.br/politica/couto-extingue-mais-uma-secretaria-por-irregularidades-em-contratos-r-115-milhoes/)
- Os dados SIGA fornecidos registram 57 ativos e nenhum vigente; há um registro indicado como nv24 no valor de R$ 24.600, mas não foram fornecidos número, objeto ou vínculo desse registro.

## 7. Perguntas-chave para IA externa
1. Quais são os números SIGA e os valores individualizados dos instrumentos com o Instituto NATA e a ONG Contato, que somariam R$ 115 milhões entre 2023 e 2026?
2. Quais números SIGA correspondem aos pagamentos e saldos das parcerias, incluindo os R$ 86,6 milhões informados para os dois anos mais recentes do período?
3. Qual é o número SIGA do registro nv24 de R$ 24.600, qual seu objeto e a que unidade ou contrato está vinculado?
4. Quais são os números SIGA dos 57 registros ativos e por que as estatísticas indicam zero vigentes?
5. Qual o andamento da sindicância instaurada em 24 de setembro de 2026 e da tomada de contas, e quais providências foram adotadas sobre os achados de auditoria?
6. A análise técnica anunciada após a suspensão dos repasses foi concluída? Em caso afirmativo, qual foi o resultado? Qual é hoje a situação dos polos, atendimentos, equipes e custeio?
7. Quais são os instrumentos, valores e números SIGA relacionados ao contrato de veículos de R$ 1,2 milhão com a RCOM, e qual foi o resultado da rescisão e devolução dos bens?
8. Como a secretaria esclarece a divergência entre a previsão de 225 polos e a referência a 100 polos por organização, e a distinção entre 60+ Reabilita I e II?
9. Que inventário de servidores, processos, documentos, sistemas, obrigações e saldos foi transferido à Secretaria de Desenvolvimento Social e Direitos Humanos?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEIJES | Secretaria de Estado Internacional de Juventude e Envelhecimento Saudável | 0 | R$ 0,0 mi | 0 | R$ 0,0 mi | 0 | Continuidade assistencial e administrativa sem situação operacional atualizada. | Confirmar serviços em funcionamento e obter contratos, auditoria e inventário da transiçã… |

## Fontes da pesquisa
1. [Couto extingue Secretaria de Juventude e Envelhecimento ...](https://temporealrj.com/couto-extingue-secretaria-auditoria-governo-estado/) — 2026-08-17
2. [Couto extingue mais uma secretaria por irregularidades em contratos de R$ 115 milhões](https://veja.abril.com.br/politica/couto-extingue-mais-uma-secretaria-por-irregularidades-em-contratos-r-115-milhoes/) — 2026-08-17
3. [Dono de OS contratada no governo do RJ contratou irmã por R$ 1,2 milhão](https://www.metropoles.com/colunas/tacio-lorran/dono-de-os-contratada-no-governo-do-rj-contratou-irma-por-r-12-milhao) — 2026-11-04
4. [Auditoria em programa para idosos do Estado do Rio leva a 35 ...](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml) — 2026-08-17
5. [Projeto para idosos do RJ tinha unidades em igreja ligada a ex-secretário](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario) — 2026-10-27

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
