# Dossiê reduzido — Secretaria de Estado de Desenvolvimento Econômico, Indústria, Comércio e Serviços (SEDEICS)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEDEICS.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEDEICS_pesquisa.md`.

## Resumo executivo
O Decreto nº 50.447, de 26 de agosto de 2026, renomeou a SEDEICSCTI como Secretaria de Estado de Desenvolvimento Econômico (SEDES) e consolidou sua estrutura, declarando que a reorganização não aumenta despesas. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf)

A pasta reúne competências antes distribuídas entre Desenvolvimento Econômico, Energia e Economia do Mar e Ciência, Tecnologia e Inovação, após incorporações formalizadas em atos de 2026. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf) [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/) [G1: extinção da Secretaria de Energia e Economia do Mar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml)

As fontes fornecidas não trazem inventário de contratos, valores orçamentários, interrupções de serviços, dívidas ou achados de controle relativos à pasta. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf) [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/) [G1: exonerações no Diário Oficial](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/27/exoneracoes-publicadas-diario-oficial-do-rj.ghtml)

A prioridade para a transição é confirmar a implementação da nova estrutura, a publicação do regimento interno, a situação atual do pessoal e a continuidade das atividades e dos recursos das unidades incorporadas. O decreto prevê a transferência de bens, acervo e servidores e determina a edição futura do regimento, mas não informa se essas medidas foram efetivadas. A matéria relata a exoneração dos ocupantes de cargos comissionados da extinta Secti e um pedido para manter os recursos orçamentários, sem esclarecer os desdobramentos. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf) [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/)

## 1. Missão e competências
- Promover o desenvolvimento econômico.
- Atuar nas áreas de indústria, comércio e serviços.
- Abranger energia e economia do mar.
- Abranger ciência, tecnologia e inovação.

## 2. Estrutura essencial
- Titular: Roberto Gomides foi citado como nomeado; permanência atual a confirmar. [Correio da Manhã: unificação das secretarias](https://www.correiodamanha.com.br/colunistas/correio-bastidores/2026/08/309036-couto-unifica-secretarias-de-desenvolvimento-economico-e-ciencia-tecnologia-e-inovacao-do-rj.html)
- CODIN - COMP DE DESENV INDUSTRIAL DO ESTADO DO RJ
- FEMPO-FUNDO EST FOMENTO MICROC  PROD EMPREEDEDOR - FUNDO UPP EMPREENDEDOR
- JUCERJA - JUNTA COMERCIAL DO ESTADO DO RIO DE JANEIRO
- SEDEERI - Sec de Est de Dse Econ Emp e Rel Int
- SEDEICS - SEC DE EST DE DESENV ECONÔM INDU COMERC E SERV

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 67 contratos, R$ 76,8 mi (+5 'Ativo' sem data de fim válida, R$ 32,0 mi) |
| Vencem em até 30 dias | 2 contratos, R$ 0,3 mi |
| Vencem em até 90 dias | 18 contratos, R$ 17,1 mi (6 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 33 contratos, R$ 42,8 mi |
| Emergenciais vigentes ou sem data de fim | 1 contratos, R$ 1,9 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 7,2 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2026000438 | OPEN BRASIL PROMOÇÔES E EVENTOS LTDA | O presente Termo de Referência tem por objeto a contratação… | R$ 8.616.000,00 | 02/02/2027 (PNCP) |
| 2025010983 | R8 SOLUÇÕES EIRELI | PRESTAÇÃO DE SERVIÇOS DE LIMPEZA, CONFORME TERMO DE REFERÊN… | R$ 2.000.000,23 | 27/01/2027 (PNCP) |
| 2025010332 | ESFERA BRASIL LTDA | O presente Termo de Referência tem por objeto a contratação… | R$ 2.000.000,00 | 08/12/2026 (PNCP) |
| 2026009275 | VEENT EMPREENDIMENTOS EMPRESARIAIS LTDA | Contratação emergencial de empresa especializada na prestaç… (emergencial) | R$ 1.879.823,94 | 03/02/2027 (PNCP) |
| 2026000440 | MULTIPLAR ENGENHARIA E LOCACOES LTDA | Contratação, por meio de patrocínio, da Cota Master do even… | R$ 1.000.000,00 | 29/01/2027 (PNCP) |
| 2025010994 | NORTESUL TRANSPORTES E SERVICOS LTDA | PRESTAÇÃO DE SERVIÇO DE COPEIRAGEM, CONFORME TERMO DE REFER… | R$ 590.000,00 | 27/01/2027 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 130 (R$ 85,6 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 18 (R$ 17,1 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 3 (R$ 24,3 mi) | 0 | Alerta |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2024008414 | INSTITUTO GLOBAL DE DESENVOLVIMENTO E SUSTENTABIL… | R$ 11.999.998,50 | 14/01/2026 |
| 2025006669 | JM MAIS CENOGRAFIA E EVENTOS LTDA | R$ 10.256.164,24 | 27/03/2026 |
| 2024008915 | VIGILIA BRASIL SERVIÇOS LTDA | R$ 5.982.996,12 | 17/03/2026 |

## 5. Alertas vermelhos
- 2 contrato(s) vencem em até 30 dias (R$ 0,3 mi).
- 1 contratação(ões) emergencial(is) vigente(s) ou sem data de fim (R$ 1,9 mi): verificar limite de 1 ano (Lei 14.133, art. 75, VIII).
- 3 contrato(s) com data de fim impossível no SIGA (R$ 24,3 mi): 2021003139 JABERPLAN CONSTRUTORA LTDA (fim 30/01/2124); 2021003140 ALZIRA GAIA DA SILVA (fim 12/07/2071); 2018005065 ANTONELA DO CARMO MENTA (fim 01/11/2123). Corrigir o cadastro e confirmar a vigência real no processo SEI.
- O regimento interno deveria ser editado em até 30 dias; as fontes não confirmam sua publicação. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf)
- A reorganização reuniu áreas distintas; a crítica parlamentar e o pedido de diálogo não comprovam falha operacional. [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/)

## 6. Riscos prioritários
- Transição administrativa: confirmar regimento, responsabilidades, equipes, processos e sistemas das unidades reorganizadas. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf)
- Continuidade de pessoal e programas das áreas incorporadas: a pesquisa registra preocupação com exonerações, sem comprovar interrupções. [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/)
- Contrato emergencial 2026009275, da VEENT, no valor de R$ 1.879.823,94 e com fim indicado em 03/02/2027: verificar cobertura e continuidade após a posse.
- Contrato 2026000438, da OPEN BRASIL, no valor de R$ 8.616.000,00 e com fim indicado em 02/02/2027: confirmar obrigações, entregas e decisão sobre continuidade.
- Conciliar os R$ 7.218.240,97 registrados como a pagar com contratos, medições, empenhos e cronograma de liquidação.
- Confirmar encerramento e eventuais saldos ou obrigações do contrato 2024008397, do IBAP, no valor de R$ 5.638.660,00, com fim indicado em 22/01/2026.

## 7. Perguntas-chave para IA externa
1. O regimento interno previsto no Decreto nº 50.447/2026 foi publicado? Qual é o organograma vigente e a distribuição de competências?
2. Quais equipes, processos, sistemas e recursos das áreas incorporadas foram transferidos, e quais atividades exigem providências imediatas para manter a continuidade?
3. Qual é a situação atual de cargos de direção, vacâncias, exonerações e funções acumuladas nas unidades relacionadas?
4. No contrato 2026009275, da VEENT, por R$ 1.879.823,94 e com fim indicado em 03/02/2027, quais serviços estão cobertos e qual é o plano de continuidade?
5. No contrato 2026000438, da OPEN BRASIL, por R$ 8.616.000,00 e com fim indicado em 02/02/2027, quais entregas e pagamentos permanecem pendentes?
6. Qual é a justificativa, a execução e a situação de encerramento do contrato 2025010332, da ESFERA BRASIL, no valor de R$ 2.000.000,00 e com fim indicado em 08/12/2026?
7. Como se compõem os R$ 7.218.240,97 registrados como a pagar, por fornecedor e contrato, incluindo as datas de liquidação e o status ou a previsão de pagamento?
8. Qual é o status de encerramento, pagamento e eventuais obrigações remanescentes do contrato 2024008397, do IBAP, no valor de R$ 5.638.660,00 e com fim indicado em 22/01/2026?
9. O contrato 2024008414, do Instituto Global de Desenvolvimento e Sustentabilidade - IGDS, no valor de R$ 11.999.998,50 e com fim indicado em 14/01/2026, foi concluído? Há saldos, pendências ou prestação de contas em aberto?
10. Quais processos administrativos, judiciais e de controle — inclusive demandas do TCE-RJ e do MPRJ — envolvem a pasta e suas unidades?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEDEICS | Secretaria de Estado de Desenvolvimento Econômico, Indústria, Comércio e Serviços | 67 | R$ 76,8 mi | 18 | R$ 17,1 mi | 0 | Risco a verificar de descontinuidade administrativa ou contratual durante a reorganização… | Validar regimento, pessoal, contratos próximos do fim e valores a pagar. |

## Fontes da pesquisa
1. [��Á���](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf) — 2026-08-29
2. [Deputada cobra revogação de decreto que extinguiu a ...](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/) — 2026-08-06
3. [Couto extingue Secretaria de Energia e Economia do Mar   G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) — 2026-07-22
4. [Exonerações no Diário Oficial do RJ: Depósito Público e ... - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/27/exoneracoes-publicadas-diario-oficial-do-rj.ghtml) — 2026-07-27
5. [Couto unifica secretarias de Desenvolvimento Econômico e Ciência, Tecnologia e Inovação do RJ](https://www.correiodamanha.com.br/colunistas/correio-bastidores/2026/08/309036-couto-unifica-secretarias-de-desenvolvimento-economico-e-ciencia-tecnologia-e-inovacao-do-rj.html) — 2026-08-07

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
