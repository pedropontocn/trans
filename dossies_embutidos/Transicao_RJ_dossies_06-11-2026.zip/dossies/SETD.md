# Dossiê reduzido — Secretaria de Estado de Transformação Digital (SETD)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SETD.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SETD_pesquisa.md`.

## Resumo executivo
- O TCE-RJ concluiu auditoria sobre o Programa RJ Digital e determinou que SETD e PRODERJ elaborem planos de ação para atender às medidas corretivas. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
- Há registros de procedimentos de contratação de tecnologia vinculados ao PRODERJ: uma licitação de firewall, divulgada por R$ 90,2 milhões, e a adjudicação do Lote 1 do pregão para registro de preços de soluções Qlik por R$ 32,4 milhões. As fontes não confirmam a execução atual desses objetos nem a vigência de eventuais contratos. [Licitação de firewall do PRODERJ](https://temporealrj.com/ta-em-crise-chama-o-proderj-empresa-finaliza-mais-uma-licitacao-desta-vez-de-r-902-milhoes/) [Homologação de pregão do PRODERJ](https://www.rj.gov.br/proderj/sites/default/files/arquivos-andamento/Publicacao%20ADJ%20e%20Homolog_APM_DOERJ.pdf)
- O achado de ausência de integração de serviços ao Portal RJ Digital e a ineficiência no pagamento de taxas são problemas apontados pela auditoria, mas as fontes não registram interrupção de serviços ou apagão administrativo. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
- A página do [Arquivo de Transparência — Tempo Real](https://temporealrj.com/category/transparencia/page/8/) exibe reportagem cujo título informa que dois pregões do PRODERJ custariam R$ 390 milhões. No conteúdo fornecido, não constam os pregões, fornecedores, valores individuais ou vigências.

## 1. Missão e competências
- Conduzir iniciativas de transformação digital e de digitalização de serviços estaduais, incluindo o Programa RJ Digital.
- Atuar na governança de tecnologia da informação estadual, em articulação com o PRODERJ, identificado como gestor estadual de TIC.

## 2. Estrutura essencial
- Titular: a confirmar. O material cita Fernando Braga Martins em documento de fevereiro de 2026, mas não confirma que permaneça no cargo em 06/11/2026.
- Unidades informadas no SIGA: PRODERJ - CENTRO DE TECN DE INFORMAÇÃO E COMUN DO ERJ; SETD - SECRETARIA DE ESTADO DE TRANSFORMACAO DIGITAL.

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 23 contratos, R$ 165,7 mi (+3 'Ativo' sem data de fim válida, R$ 4,7 mi) |
| Vencem em até 30 dias | 2 contratos, R$ 0,5 mi |
| Vencem em até 90 dias | 6 contratos, R$ 53,5 mi (4 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 9 contratos, R$ 55,4 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 0,5 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2025001499 | CIX CITIZEN EXPERIENCE S/A | Contratação de empresa especializada para implantação e dis… | R$ 25.183.304,56 | 15/01/2027 (PNCP) |
| 2025010822 | VERT ANALYTICS LTDA. | Aquisição de licença perpétua de Solução de Inteligência an… | R$ 16.222.050,00 | 26/12/2026 (PNCP) |
| 2025010858 | LGPDNOW TRATAMENTO E HOSPEDAGEM DE DADOS LTDA | Contratação de plataforma para Automação de Machine Learnin… | R$ 6.750.763,59 | 23/12/2026 (PNCP) |
| 2025010830 | BLUE EYE SOLUÇÕES EM TECNOLOGIA LTDA | Prestação de serviços de subscrições de Plataforma para Ger… | R$ 4.859.851,24 | 24/12/2026 (PNCP) |
| 2025009154 | CLAVIS BBR CONSULTORIA EM INFORMATICA S/A | Contratação de empresa de Tecnologia da Informação para o f… | R$ 321.406,25 | 19/11/2026 |
| 2025009610 | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada para a confecção de ca… | R$ 195.000,00 | 28/11/2026 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 4 (R$ 9,4 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 6 (R$ 53,5 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2025009521 | 3STRUCTURE IT LTDA | R$ 7.817.177,04 | 06/06/2026 |
| 2025008809 | XERTICA BRASIL LTDA | R$ 1.422.000,00 | 03/11/2026 |
| 2025007414 | INSTITUTO IBDO DE GESTÃO E PROJETOS | R$ 144.000,00 | 24/09/2026 |

## 5. Alertas vermelhos
- 2 contrato(s) vencem em até 30 dias (R$ 0,5 mi).
- O TCE-RJ determinou planos de ação à SETD e ao PRODERJ para atender recomendações sobre o RJ Digital; o cumprimento não está demonstrado no material. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
- A auditoria apontou a inexistência de integração de serviços ao Portal RJ Digital, a ausência de planos de digitalização em 28 órgãos estaduais e a ineficiência no processo de pagamento de taxas de serviços. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
- Uma reportagem cujo título menciona dois pregões do PRODERJ por R$ 390 milhões não detalha, no conteúdo fornecido, objetos, fornecedores ou vigências. [Arquivo de Transparência — Tempo Real](https://temporealrj.com/category/transparencia/page/8/)
- Duas comissões de sindicância foram instituídas em fevereiro de 2026; o material não informa os fatos apurados nem os resultados. [Publicação de resoluções e atos da SETD/PRODERJ](https://www.rj.gov.br/proderj/sites/default/files/arquivos-andamento/Publicacao%20ADJ%20e%20Homolog_APM_DOERJ.pdf)
- O PLANAT 2025 registrou espaço limitado e compartilhado com o PRODERJ e previa mudança de sede; a situação atual não consta do material. [PLANAT 2025 da SETD](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/PLANAT%202025.pdf)

## 6. Riscos prioritários
- Transição contratual imediata: seis contratos somam R$ 53.532.375,64 na faixa de 90 dias; entre os listados, quatro contratos de tecnologia, no total de R$ 53.015.969,39, têm término informado entre 23/12/2026 e 15/01/2027.
- Situação a confirmar de contratos com datas de término já passadas no registro: 2025009521, de R$ 7.817.177,04, com fim informado em 06/06/2026, e 2025008809, de R$ 1.422.000,00, com fim em 03/11/2026.
- Risco de lacunas na entrega digital e na integração de serviços; o TCE-RJ apontou problemas no RJ Digital, sem que o material comprove interrupção de serviços. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
- A reportagem [“A volta das licitações milionárias: dois pregões do Proderj custarão R$ 390 milhões aos cofres do estado”](https://temporealrj.com/category/transparencia/page/8/), publicada em 13/09/2026, afirma que os dois pregões custarão R$ 390 milhões aos cofres estaduais.
- Continuidade operacional e capacidade instalada a verificar: as fontes não informam inventário atualizado de sistemas críticos, contingência ou situação atual da sede. [PLANAT 2025 da SETD](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/PLANAT%202025.pdf)

## 7. Perguntas-chave para IA externa
1. Qual é o estado atual, a data de término contratual e o plano de continuidade para o contrato 2025001499, de R$ 25.183.304,56, com fim informado em 15/01/2027?
2. Qual é a situação de execução, vigência e necessidade de renovação do contrato 2025010822, de R$ 16.222.050,00, com fim informado em 26/12/2026?
3. Qual é o estado atual do contrato 2025010858, de R$ 6.750.763,59, com fim informado em 23/12/2026, e quais serviços dependem dele?
4. Qual é o estado atual do contrato 2025010830, de R$ 4.859.851,24, com fim informado em 24/12/2026, e como será mantida a gestão de identidades após o término?
5. Os registros dos contratos 2025009521, de R$ 7.817.177,04, e 2025008809, de R$ 1.422.000,00, indicam términos em 06/06/2026 e 03/11/2026: houve encerramento, prorrogação ou nova contratação?
6. Quais planos de ação a SETD e o PRODERJ apresentaram ao TCE-RJ para o RJ Digital, quais recomendações já foram cumpridas e quais evidências estão disponíveis? [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
7. Quais são os objetos, fornecedores, valores individuais, vigências e situação de execução dos dois pregões mencionados como totalizando R$ 390 milhões? [Arquivo de Transparência — Tempo Real](https://temporealrj.com/category/transparencia/page/8/)
8. Quais foram os resultados das sindicâncias dos processos SEI-430001/006268/2025 e SEI-430001/006854/2025, e onde estão disponíveis os relatórios conclusivos? [Publicação de resoluções e atos da SETD/PRODERJ](https://www.rj.gov.br/proderj/sites/default/files/arquivos-andamento/Publicacao%20ADJ%20e%20Homolog_APM_DOERJ.pdf)

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SETD | Secretaria de Estado de Transformação Digital | 23 | R$ 165,7 mi | 6 | R$ 53,5 mi | 0 | Risco a avaliar de descontinuidade de serviços digitais na transição, diante de contratos… | Confirmar vigências, planos de continuidade e cumprimento das recomendações do TCE-RJ. |

## Fontes da pesquisa
1. [TCE-RJ recomenda aprimoramentos na execução do Programa RJ ...](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital) — 2025-10-30
2. [Tá em crise? Chama o Proderj: empresa finaliza mais uma ...](https://temporealrj.com/ta-em-crise-chama-o-proderj-empresa-finaliza-mais-uma-licitacao-desta-vez-de-r-902-milhoes/) — 2024-12-28
3. [Arquivo de Transparência - Página 8 de 73 - Tempo Real](https://temporealrj.com/category/transparencia/page/8/) — 2026-10-26
4. [ PDF  Anexo 1 PEDTIC 2026 - Governo do Estado do Rio de Janeiro](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/PEDTIC_SETD_2026_Vers%C3%A3o_1.7.pdf) — 2026-02-20
5. [ PDF  Á - RJ Gov](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/RES_SETD_130-2026_Gest%C3%A3o_e_Fiscaliza%C3%A7%C3%A3o.pdf) — 2026-04-15
6. [23/02/2026 PI230226-S-01___24](https://www.rj.gov.br/proderj/sites/default/files/arquivos-andamento/Publicacao%20ADJ%20e%20Homolog_APM_DOERJ.pdf) — 2026-03-25
7. [PLANO ANUAL DE ATIVIDADES DA AUDITORIA INTERNA](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/PLANAT%202025.pdf) — 2026-01-09
8. [��Á���](https://www.rj.gov.br/seiop/sites/default/files/arquivos_pagina_basica/Anexo%20Publica%C3%A7%C3%A3o%20no%20D.O..pdf) — 2025-11-29

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
