# Dossiê reduzido — Secretaria de Estado do Ambiente e Sustentabilidade (SEAS)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEAS.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEAS_pesquisa.md`.

## Resumo executivo
- O TCE-RJ determinou a retenção de R$ 3.693.431,29 em parcelas do contrato nº 024/2024 do INEA, após auditoria apontar indícios de sobrepreço e divergência entre trabalhadores pagos e efetivamente disponibilizados; o estado atual do cumprimento da decisão não consta nas fontes. [TCE-RJ bloqueia R$ 3,6 milhões](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/)
- A parceria de R$ 23 milhões do projeto Conexão Ambiental foi alvo de suspensão pelo TCE-RJ por indícios de irregularidades; o G1 informa que a contratação não foi concluída e o convênio não foi firmado. [TCE-RJ suspende parceria](https://temporealrj.com/tce-rj-mira-parceria-de-r-23-milhoes/) [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml)
- A obra de macrodrenagem dos rios Registro e Viegas seguia em execução em novembro de 2026, embora a previsão original de conclusão fosse janeiro de 2024; o INEA aplicou multa de R$ 4.989.669,69 à contratada. [Inea pune a Construtora Metropolitana](https://clickpetroleoegas.com.br/quase-r-5-milhoes-de-multa-20-do-que-faltava-pagar-inea-pune-a-construtora-metropolitana-responsavel-por-obra-contra-enchentes-na-zona-oeste-do-rio-que-tinha-previsao-de-btl96-mhbb01/)
- A gestão recente inclui substituição de dirigentes do INEA por servidores de carreira e reestruturação da SEAS; as fontes não confirmam como essas mudanças afetaram a continuidade dos serviços. [O Dia: mudanças no Inea](https://odia.ig.com.br/rio-de-janeiro/2026/05/7245885-governador-interino-do-rio-substitui-toda-a-direcao-do-inea-por-servidores-de-carreira.html) [Decreto nº 50.330](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/06/9-DECRETO-No-50.329-DE-12-DE-JUNHO-DE-2026-SEPPEN.pdf)

## 1. Missão e competências
- Atuação em políticas ambientais e de sustentabilidade, incluindo a reformulação do sistema de licenciamento ambiental.
- Atuação relacionada à conservação da biodiversidade, à gestão ambiental e ao monitoramento de unidades de conservação.
- Supervisão e harmonização institucional entre a SEAS e o INEA.
- Atuação relacionada a recursos hídricos, conforme a vinculação do FUNDRHI à estrutura informada.

## 2. Estrutura essencial
- Titular: Rodrigo Mascarenhas.
- FUNDRHI - FUNDO ESTADUAL DE RECURSOS HÍDRICOS.
- INEA - INSTITUTO ESTADUAL DO AMBIENTE.
- SEAS - SEC DE EST DO AMBIENT E SUSTENTABILIDADE.
- UEPSAM - Unidade Executora do PSAM.

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 47 contratos, R$ 693,1 mi (+3 'Ativo' sem data de fim válida, R$ 1,1 mi) |
| Vencem em até 30 dias | 3 contratos, R$ 8,8 mi |
| Vencem em até 90 dias | 17 contratos, R$ 147,8 mi (12 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 24 contratos, R$ 155,8 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 29,6 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2026000232 | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | Licitação na modalidade Pregão Eletrônico para a contrataçã… | R$ 18.111.139,08 | 26/01/2027 (PNCP) |
| 2026000234 | NEVADADISTRIBUIDORA E TRANSPORTADORA LTDA | Licitação na modalidade Pregão Eletrônico para a contrataçã… | R$ 18.040.736,16 | 26/01/2027 (PNCP) |
| 2026000231 | JH SERVICOS E MANUTENCAO LTDA | Licitação na modalidade Pregão Eletrônico para a contrataçã… | R$ 18.008.516,64 | 27/01/2027 (PNCP) |
| 2022010302 | FUNDACAO PARQUES E JARDINS | Tratase de convênio celebrado entre o Estado do Rio de Jane… | R$ 15.000.000,00 | 31/12/2026 |
| 2026000229 | FXS ENGENHARIA LTDA | Licitação na modalidade Pregão Eletrônico para a contrataçã… | R$ 14.445.955,41 | 26/01/2027 (PNCP) |
| 2026000230 | MSL PRESTACAO DE SERVICOS LTDA | Licitação na modalidade Pregão Eletrônico para a contrataçã… | R$ 13.872.193,08 | 26/01/2027 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 63 (R$ 184,8 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 17 (R$ 147,8 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 1 | 0 | Alerta |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2023004812 | CONSTRUVERDE CONSTRUCOES E SERVICOS EIRELI | R$ 55.285.113,16 | 30/12/2024 |
| 2023002225 | VOLUME PARTICIPACOES, PRODUCOES E EVENTOS LTDA | R$ 37.008.423,50 | 16/03/2026 |
| 2024002818 | SERPEN SERVIÇOS E PROJETOS DE ENGENHARIA LTDA | R$ 26.445.000,00 | 20/09/2026 |

## 5. Alertas vermelhos
- 3 contrato(s) vencem em até 30 dias (R$ 8,8 mi).
- 1 contrato(s) com fornecedor em recuperação judicial.
- TCE-RJ determinou retenção de R$ 3.693.431,29 no contrato 024/2024 do INEA após apontar indícios de sobrepreço e divergências de pessoal; cumprimento atual não informado. [TCE-RJ bloqueia R$ 3,6 milhões](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/)
- TCE-RJ determinou à Secretaria do Ambiente que suspendesse a contratação do Instituto Chaya para a parceria prevista de R$ 23 milhões; segundo o ex-secretário e o instituto, o convênio não foi firmado, e a página não informa atualização posterior. [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml)
- Obra de macrodrenagem dos rios Registro e Viegas seguia em execução apesar da previsão original de conclusão em janeiro de 2024; multa aplicada foi de R$ 4.989.669,69. [Inea pune a Construtora Metropolitana](https://clickpetroleoegas.com.br/quase-r-5-milhoes-de-multa-20-do-que-faltava-pagar-inea-pune-a-construtora-metropolitana-responsavel-por-obra-contra-enchentes-na-zona-oeste-do-rio-que-tinha-previsao-de-btl96-mhbb01/)
- Investigação criminal noticiada envolve suspeitas de corrupção em licenciamentos e 11 pessoas; as fontes não informam denúncia ou desfecho. [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml)

## 6. Riscos prioritários
- No Contrato INEA nº 024/2024, estimado em R$ 80.908.294,56, o TCE-RJ determinou a retenção de R$ 3.693.431,29, a correção dos salários de referência nas futuras medições e a conferência do número de trabalhadores antes dos pagamentos. [TCE-RJ bloqueia R$ 3,6 milhões](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/)
- Macrodrenagem dos rios Registro e Viegas: atraso relevante, obra ainda registrada como “em execução” em novembro de 2026 e multa aplicada; o painel informa 77,81% do valor liquidado, mas não esclarece o avanço físico atualizado, o cronograma nem eventual recurso contra a multa. [Inea pune a Construtora Metropolitana](https://clickpetroleoegas.com.br/quase-r-5-milhoes-de-multa-20-do-que-faltava-pagar-inea-pune-a-construtora-metropolitana-responsavel-por-obra-contra-enchentes-na-zona-oeste-do-rio-que-tinha-previsao-de-btl96-mhbb01/)
- O Dia noticia mudanças em 12 cargos de liderança do Inea, que passarão a ser ocupados por profissionais de carreira e perfil técnico, e exonerações, incluindo 157 cargos em comissão da Secretaria de Governo. A matéria também menciona mudanças na Secretaria de Ambiente e Sustentabilidade, mas não informa dados sobre vacâncias, capacidade operacional ou efeitos nos serviços. [O Dia: mudanças no Inea](https://odia.ig.com.br/rio-de-janeiro/2026/05/7245885-governador-interino-do-rio-substitui-toda-a-direcao-do-inea-por-servidores-de-carreira.html)
- Risco de transição contratual: estatísticas apontam 3 contratos com término em até 30 dias (R$ 8.803.550), 17 em até 90 dias (R$ 147.827.603,61) e 24 em até 180 dias (R$ 155.760.912,44); identificar objetos e planos de continuidade.
- Pendências financeiras e de inventário: há R$ 29.554.836,26 registrados como a pagar, enquanto o levantamento informa 354 ativos e 47 vigentes no valor de R$ 693.121.003,86; faltam detalhamento e conciliação para a passagem.

## 7. Perguntas-chave para IA externa
1. Qual é a situação atual do contrato INEA 024/2024, estimado em R$ 80.908.294,56: quanto foi pago e retido, quais medições foram revistas e qual o status das manifestações ao TCE-RJ?
2. A parceria Conexão Ambiental, prevista em R$ 23 milhões, teve assinatura, repasse ou execução após a suspensão? Quais manifestações foram apresentadas ao TCE-RJ?
3. No contrato 41/2021-INEA, de valor atualizado informado de R$ 120.071.124,96 e saldo de R$ 24.948.348,43, qual o avanço físico-financeiro, o novo cronograma e a situação da multa de R$ 4.989.669,69?
4. Quais contratos compõem os grupos com vencimento em até 30, 90 e 180 dias — respectivamente R$ 8.803.550, R$ 147.827.603,61 e R$ 155.760.912,44 — e quais têm plano de continuidade ou nova contratação?
5. Qual é a situação do contrato SIGA 2022010302, de R$ 15.000.000, com término informado em 31/12/2026: saldo, pagamentos, entregas e providências para evitar descontinuidade?
6. Como se decompõem os R$ 29.554.836,26 registrados como a pagar, por contrato, unidade, vencimento e estágio do pagamento, considerando que são valores já liquidados e não pagos?
7. Qual é o plano de continuidade e contingência para o contrato PNCP 2026000232, de R$ 18.111.139,08, cujo fornecedor aparece identificado como em recuperação judicial?
8. Como se conciliam os 354 ativos, os 47 vigentes e o valor vigente de R$ 693.121.003,86 entre SIGA e PNCP, incluindo contratos encerrados, aditivos e registros duplicados?
9. Qual é a situação atual dos contratos SIGA 2023004812 (R$ 55.285.113,16), 2023002225 (R$ 37.008.423,50) e 2024002818 (R$ 26.445.000), cujas datas de término informadas já passaram?
10. Qual o quadro atualizado de pessoal, vacâncias e funções críticas nas unidades vinculadas, e quais indicadores demonstram continuidade dos serviços após a reestruturação?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEAS | Secretaria de Estado do Ambiente e Sustentabilidade | 47 | R$ 693,1 mi | 17 | R$ 147,8 mi | 0 | Continuidade contratual e controle insuficiente em contratos sob alertas do TCE-RJ. | Obter status documental, financeiro e operacional dos contratos críticos antes da posse. |

## Fontes da pesquisa
1. [TCE-RJ bloqueia R$ 3,6 milhões em contrato do INEA por encontrar indícios de superfaturamento](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/) — 2026-07-02
2. [TCE aponta falhas e suspende convênio de R$ 23 milhões - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml) — 2026-07-13
3. [Quase R$ 5 milhões de multa, 20% do que faltava pagar: Inea pune a Construtora Metropolitana, responsável por ](https://clickpetroleoegas.com.br/quase-r-5-milhoes-de-multa-20-do-que-faltava-pagar-inea-pune-a-construtora-metropolitana-responsavel-por-obra-contra-enchentes-na-zona-oeste-do-rio-que-tinha-previsao-de-btl96-mhbb01/) — 2026-11-03
4. [PARTE I PODER EXECUTIVO www.rj.gov.br S U M Á R I O ...](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/06/9-DECRETO-No-50.329-DE-12-DE-JUNHO-DE-2026-SEPPEN.pdf) — 2026-07-28
5. [ PDF  ANEXO II - Governo do Estado do Rio de Janeiro](https://www.rj.gov.br/seas/sites/default/files/arquivos_paginas/SEI_124137298_Anexo_2.pdf) — 2026-03-06
6. [Governador em exercício do Rio substitui toda a direção do Inea por ...](https://odia.ig.com.br/rio-de-janeiro/2026/05/7245885-governador-interino-do-rio-substitui-toda-a-direcao-do-inea-por-servidores-de-carreira.html) — 2026-05-05
7. [Rio busca virar página na área ambiental com gestão técnica ...](https://valor.globo.com/brasil/noticia/2026/10/08/rio-busca-virar-pagina-na-area-ambiental-com-gestao-tecnica-e-novos-regramentos.ghtml) — 2026-10-08
8. [TCE-RJ suspende parceria de R$ 23 milhões entre governo do estado e instituto para projeto ambiental](https://temporealrj.com/tce-rj-mira-parceria-de-r-23-milhoes/) — 2026-07-10

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
