# Dossiê reduzido — Secretaria de Estado de Saúde (SES)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SES.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SES_pesquisa.md`.

## Resumo executivo
- A Tomada de Contas Especial sobre pagamentos de serviços advocatícios com recursos do Contrato de Gestão nº 004/2017 foi considerada irregular pela comissão da SES; o voto do TCE-RJ julgou as contas irregulares e considerou configurados desvio de finalidade e dano ao erário, além de registrar indícios de superfaturamento e conluio. A decisão determinou o envio dos autos ao Ministério Público para avaliar eventual procedimento, não constituindo decisão judicial definitiva. [Acórdão TCE-RJ nº 000771/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/771/2026)
- A obra do Hospital Estadual de Oncologia de Nova Friburgo está sob questionamento no TCE-RJ por aditivos, aumento de custos e atrasos; o Tribunal determinou que a SES apresentasse esclarecimentos e documentos. [TCE-RJ cobra explicações sobre obra de hospital em Nova Friburgo](https://g1.globo.com/rj/regiao-serrana/noticia/2026/07/21/tce-rj-da-cinco-dias-para-estado-explicar-contratos-da-obra-do-hospital-de-oncologia-de-nova-friburgo.ghtml)
- A JP Serviços deixou cerca de 307 trabalhadores sem receber após o encerramento de contratos com a Fundação Saúde, enquanto mantinha contrato vigente desde setembro de 2025 para teleatendimento do SAMU 192; a Fundação informou apuração de possível descumprimento relativo ao FGTS. [Empresa contratada pela Saúde do RJ deixa 300 sem receber](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/14/empresa-com-r-45-milhoes-em-contratos-com-a-fundacao-saude-deixa-mais-de-300-trabalhadores-sem-receber.ghtml)
- Em 28/10/2026, o secretário estadual de Saúde informou ao CREMERJ que não haveria redução no valor do plantão médico de 12 horas nas UPAs estaduais; a fonte não identifica contratos ou empresas envolvidos. [CREMERJ atua e plantão de médicos das UPAs estaduais volta para valor inicial](https://news.cremerj.org.br/2026/10/30/cremerj-atua-e-plantao-de-medicos-das-upas-estaduais-volta-para-valor-inicial/)

## 1. Missão e competências
- Atuação estadual em serviços de saúde, incluindo hospitais, UPAs e teleatendimento do SAMU 192, conforme os casos citados.
- Coordenação e acompanhamento de contratos de assistência, serviços médicos, diagnóstico, apoio operacional e obras de saúde identificados nas estatísticas.
- Acompanhamento de unidades vinculadas e do Fundo Estadual de Saúde, conforme a estrutura informada.

## 2. Estrutura essencial
- Titular: a confirmar
- FES - FUNDO ESTADUAL DE SAÚDE
- FSERJ - FUNDAÇÃO SAÚDE DO EST. DO RIO DE JANEIRO
- IVB - INSTITUTO VITAL BRAZIL SA.
- SES - SECRET ESTADO  SAÚDE

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 1120 contratos, R$ 6,87 bi (+20 'Ativo' sem data de fim válida, R$ 19,6 mi) |
| Vencem em até 30 dias | 139 contratos, R$ 271,9 mi |
| Vencem em até 90 dias | 422 contratos, R$ 833,3 mi (84 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 833 contratos, R$ 3,51 bi |
| Emergenciais vigentes ou sem data de fim | 10 contratos, R$ 29,3 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 1,11 bi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2024000429 | TAPEVAS SOLUÇÕES INTEGRADAS EIRELI | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA PRESTAÇÃO DE SERV… | R$ 123.897.770,64 | 04/02/2027 |
| 2025009298 | APPA SERVIÇOS TEMPORARIOS E EFETIVOS LTDA | CONTRATAÇÃO DE SERVIÇOS DE PRESTAÇÃO DE SERVIÇOS DE APOIO O… | R$ 71.868.499,68 | 19/11/2026 (PNCP) |
| 2025004247 | LMG ENGENHARIA LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA EXECUÇÃO DE REFOR… | R$ 67.503.660,84 | 23/11/2026 (PNCP) |
| 2023000009 | CN GLOBAL PARTICIPAÇÃO E SERVIÇOS LTDA | ASSEIO E LIMPEZA, DESCRICAO: CONTRATACAO DE EMPRESA ESPECIA… | R$ 41.729.017,65 | 22/01/2027 |
| 2023008793 | BIOMETRIX DIAGNÓSTICA LTDA | Aquisição de ANALISADOR DE FLUXO CITÔMETRO DE FLUXO junto a… | R$ 40.416.799,64 | 04/12/2026 |
| 2026000352 | DAFLON ATENDIMENTOS MÉDICOS LTDA | Contratação de empresa especializada na prestação de serviç… | R$ 37.239.921,36 | 28/01/2027 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 1988 (R$ 8,81 bi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 422 (R$ 833,3 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 4 (R$ 15,8 mi) | 0 | Alerta |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2022002602 | FUNDAÇÃO SAÚDE DO ESTADO DO RIO DE JANEIRO | R$ 1.293.933.974,00 | 28/02/2025 |
| 2022000866 | INSTITUTO DE DESENVOLVIMENTO ENSINO E ASSISTÊNCIA… | R$ 664.528.288,68 | 31/07/2025 |
| 2024002523 | INSTITUTO DE DESENVOLVIMENTO ENSINO E ASSISTÊNCIA… | R$ 466.318.062,25 | 31/07/2025 |

## 5. Alertas vermelhos
- 139 contrato(s) vencem em até 30 dias (R$ 271,9 mi).
- 10 contratação(ões) emergencial(is) vigente(s) ou sem data de fim (R$ 29,3 mi): verificar limite de 1 ano (Lei 14.133, art. 75, VIII).
- 4 contrato(s) com data de fim impossível no SIGA (R$ 15,8 mi): 2015003720 HOPE RECURSOS HUMANOS EIRELI (fim 09/10/5015); 2015003734 NOVA RIO SERVIÇOS GERAIS LTDA (fim 09/10/5015); 2015003731 VP SERVIÇOS TERCEIRIZADOS LTDA (fim 09/10/5015); 2015003735 CNS NACIONAL DE SERVIÇOS LTDA (fim 09/10/5015). Corrigir o cadastro e confirmar a vigência real no processo SEI.
- Tomada de contas sobre pagamentos à Tharyk: dano apurado de R$ 3.593.225,20 à época dos fatos e valores atualizados em diferentes etapas, incluindo R$ 4.550.900,42 (referência de 2023), R$ 4.989.826,14 (instrução de 2025) e R$ 5.209.971,71 (valor indicado no item 18.4). [Acórdão TCE-RJ nº 000771/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/771/2026)
- Hospital de Oncologia de Nova Friburgo: aditivos, aumento de custos e prazo, com esclarecimentos exigidos pelo TCE-RJ. [TCE-RJ cobra explicações sobre obra de hospital em Nova Friburgo](https://g1.globo.com/rj/regiao-serrana/noticia/2026/07/21/tce-rj-da-cinco-dias-para-estado-explicar-contratos-da-obra-do-hospital-de-oncologia-de-nova-friburgo.ghtml)
- Cerca de 307 trabalhadores da JP Serviços ficaram sem receber valores devidos; a Fundação informou apuração sobre FGTS. [Empresa contratada pela Saúde do RJ deixa 300 sem receber](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/14/empresa-com-r-45-milhoes-em-contratos-com-a-fundacao-saude-deixa-mais-de-300-trabalhadores-sem-receber.ghtml)
- JP Serviços mantinha contrato de teleatendimento do SAMU 192 enquanto a Fundação apurava questões de FGTS; a fonte não relata interrupção do serviço. [Empresa contratada pela Saúde do RJ deixa 300 sem receber](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/14/empresa-com-r-45-milhoes-em-contratos-com-a-fundacao-saude-deixa-mais-de-300-trabalhadores-sem-receber.ghtml)
- A manutenção do valor dos plantões de 12 horas nas UPAs foi comunicada pelo secretário, mas a fonte não confirma formalização contratual ou implementação posterior. [CREMERJ atua e plantão de médicos das UPAs estaduais volta para valor inicial](https://news.cremerj.org.br/2026/10/30/cremerj-atua-e-plantao-de-medicos-das-upas-estaduais-volta-para-valor-inicial/)

## 6. Riscos prioritários
- Pressão de continuidade contratual: os indicadores registram 139 contratos e R$ 271,9 milhões no horizonte de 30 dias, 422 e R$ 833,3 milhões em 90 dias, e 833 e R$ 3,512 bilhões em 180 dias; validar vencimentos, serviços e planos de substituição.
- Exposição financeira e de caixa: a estatística informa R$ 1,112 bilhão a pagar; discriminar valores, vencimentos, credores e efeitos sobre a continuidade dos serviços.
- Contratos de gestão de grande valor com vigência encerrada no SIGA: 2022002602 (R$ 1,294 bilhão), 2022000866 (R$ 664,5 milhões) e 2024002523 (R$ 466,3 milhões); confirmar aditivos, execução e transição dos serviços. [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV)
- O acórdão reconheceu dano ao erário decorrente de pagamentos à Tharyk com recursos vinculados ao Contrato de Gestão nº 004/2017 e condenou solidariamente o Instituto dos Lagos Rio, Gustavo Pinto Ribeiro e Tharyk ao recolhimento de 1.050.312,82 UFIR-RJ, equivalentes, na data do acórdão, a R$ 5.209.971,71. Os valores em reais mencionados em etapas anteriores refletem atualizações em datas distintas. [Acórdão TCE-RJ nº 000771/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/771/2026)
- Risco de atraso e de pendências de controle na obra do Hospital de Oncologia de Nova Friburgo, incluindo os contratos nº 030/2022 e nº 018/2025. [TCE-RJ cobra explicações sobre obra de hospital em Nova Friburgo](https://g1.globo.com/rj/regiao-serrana/noticia/2026/07/21/tce-rj-da-cinco-dias-para-estado-explicar-contratos-da-obra-do-hospital-de-oncologia-de-nova-friburgo.ghtml)
- A reportagem relata pendências trabalhistas da JP Serviços com mais de 300 trabalhadores em contratos encerrados com a Fundação Saúde. À época, a empresa também mantinha contrato para o teleatendimento do SAMU 192, e a Fundação apurava descumprimentos relacionados ao FGTS. Verificar a situação atual das obrigações trabalhistas e do contrato, bem como a continuidade do serviço, sem que a reportagem registre interrupção do teleatendimento. [Fonte](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/14/empresa-com-r-45-milhoes-em-contratos-com-a-fundacao-saude-deixa-mais-de-300-trabalhadores-sem-receber.ghtml)

## 7. Perguntas-chave para IA externa
1. Quais contratos compõem os indicadores de vencimento em 30, 90 e 180 dias, quais serviços são essenciais e quais têm plano de continuidade para janeiro de 2027?
2. Como se distribuem os R$ 1.111.796.171,66 informados como valores a pagar, por credor, vencimento, unidade e serviço?
3. Qual é a vigência, execução física e financeira e plano de transição do contrato 2022002602, registrado em R$ 1.293.933.974,00?
4. Qual é a situação dos contratos 2022000866 (R$ 664.528.288,68) e 2024002523 (R$ 466.318.062,25), incluindo objeto detalhado, metas, pagamentos e vigência?
5. Qual é o estágio, cronograma, saldo, aditivos e situação das determinações do TCE-RJ para os contratos nº 030/2022 e nº 018/2025 do Hospital de Oncologia de Nova Friburgo?
6. Qual memória de cálculo explica os valores de R$ 4.550.900,42, R$ 4.989.826,14 e R$ 5.209.971,71 relacionados ao caso Tharyk, e qual é a situação atual de eventual cobrança?
7. Quais são os instrumentos e a situação atual do contrato de teleatendimento do SAMU 192 com a JP Serviços, e qual foi o resultado da apuração de FGTS e da regularização dos trabalhadores?
8. Quais são os 10 contratos classificados como emergenciais, que somam R$ 29.259.307,78, e quais serviços, prazos e alternativas de continuidade estão associados a eles?
9. Qual é a execução, vigência e necessidade de transição do contrato 2024000429 com a TAPEVAS SOLUÇÕES INTEGRADAS EIRELI, registrado em R$ 123.897.770,64?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SES | Secretaria de Estado de Saúde | 1120 | R$ 6,87 bi | 422 | R$ 833,3 mi | 0 | Descontinuidade de serviços essenciais em meio a vencimentos, passivos e pendências de co… | Consolidar contratos críticos, vencimentos, pagamentos e planos de continuidade para jane… |

## Fontes da pesquisa
1. [ PDF  ACÓRDÃO Nº 000771/2026-PLENV - TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/771/2026) — 2026-06-26
2. [Empresa contratada pela Saúde do RJ deixa 300 sem receber - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/14/empresa-com-r-45-milhoes-em-contratos-com-a-fundacao-saude-deixa-mais-de-300-trabalhadores-sem-receber.ghtml) — 2026-05-14
3. [TCE-RJ cobra explicações sobre obra de hospital em Nova ...](https://g1.globo.com/rj/regiao-serrana/noticia/2026/07/21/tce-rj-da-cinco-dias-para-estado-explicar-contratos-da-obra-do-hospital-de-oncologia-de-nova-friburgo.ghtml) — 2026-07-21
4. [Risco de paralisação na Saúde leva governador interino a liberar repasse urgente à Prefeitura do Rio](https://oglobo.globo.com/rio/noticia/2026/03/30/risco-de-paralisacao-na-saude-leva-governador-interino-a-liberar-repasse-urgente-a-prefeitura-do-rio.ghtml) — 2026-03-30
5. [CREMERJ atua e plantão de médicos das UPAs estaduais ...](https://news.cremerj.org.br/2026/10/30/cremerj-atua-e-plantao-de-medicos-das-upas-estaduais-volta-para-valor-inicial/) — 2026-10-30

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
