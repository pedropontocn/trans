# Dossiê reduzido — Secretaria de Estado de Desenvolvimento Regional do Interior, Pesca e Agricultura Familiar (SEDIPAF)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEDIPAF.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEDIPAF_pesquisa.md`.

## Resumo executivo
- O Decreto nº 50.380, datado de 13/07/2026, incorporou a SEDIPAF à SEAPA e criou a Secretaria de Estado de Agricultura, Pecuária, Pesca, Abastecimento e Desenvolvimento do Interior (SEAPPADI), sem aumento de despesa, conforme o texto do decreto. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- O decreto transferiu à nova secretaria contratos, convênios, instrumentos de contratação em curso, orçamentos, bens e obrigações da SEDIPAF, mas não discrimina valores nem identifica os instrumentos transferidos. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- As fontes consultadas não registram decisões do TCE-RJ, ações do MPRJ, processos judiciais ou interrupções de serviços associados à SEDIPAF. [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca) [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- Há divergência entre as fontes sobre a forma de reorganização e o nome do órgão resultante, o que recomenda confirmar a estrutura vigente e as competências na documentação administrativa atualizada. [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca) [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)

## 1. Missão e competências
- Atuar em agricultura, pecuária e agricultura familiar.
- Abranger pesca, aquicultura e abastecimento.
- Promover o desenvolvimento regional do interior.

## 2. Estrutura essencial
- Titular: Ricardo Augusto Rosa Mansur, citado por Agência Brasil e Brasil de Fato; confirmar nomeação e situação atual.
- Unidade SIGA: SEDIPAF - SEC. EST. DESENV. REGIONAL, INTERIOR, PESCA E AGRIC. FAMILIAR.
- O Decreto nº 50.380/2026 teria reorganizado a secretaria como SEAPPADI; confirmar denominação, estrutura e competências vigentes.

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 8 contratos, R$ 12,9 mi (+0 'Ativo' sem data de fim válida, R$ 0,0 mi) |
| Vencem em até 30 dias | 0 contratos, R$ 0,0 mi |
| Vencem em até 90 dias | 0 contratos, R$ 0,0 mi (0 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 3 contratos, R$ 11,7 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 0,0 mi |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 0 (R$ 0,0 mi) | 0 | OK |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 0 (R$ 0,0 mi) | Renovação/licitação definida | OK |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

## 5. Alertas vermelhos
- O decreto transfere contratos e obrigações, mas não identifica instrumentos, valores ou vencimentos. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- Reportagem relata exoneração de 173 comissionados e estima economia, sem detalhar efeitos sobre a continuidade dos serviços. [DOC PRESS](https://docpress.inf.br/2026/07/21/couto-unifica-secretarias-de-agro-e-interior/)
- Há divergência nas fontes sobre a configuração e o nome do órgão resultante da reorganização. [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca)
- Não foi localizada confirmação de que os encontros previstos para subsidiar a revisão do Pleapo ocorreram. [Folha de Italva](https://www.folhadeitalva.com.br/2026/07/emater-rio-sedia-encontro-sobre.html)

## 6. Riscos prioritários
- Concentração de vencimentos: 3 contratos, totalizando R$ 11.720.736,87, têm prazo indicado em até 180 dias; os números SIGA não foram fornecidos.
- O inventário dos contratos transferidos, com valores, saldos, obrigações e responsáveis pela fiscalização, não consta das fontes. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- A configuração institucional vigente precisa ser confirmada diante da divergência entre as descrições da reorganização. [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca) [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)

## 7. Perguntas-chave para IA externa
1. Quais são os números SIGA dos 8 contratos vigentes, com objeto, contratado, valor, saldo, vigência e fiscal responsável?
2. Quais são os 3 contratos com prazo em até 180 dias, que somam R$ 11.720.736,87, e quais providências de renovação, encerramento ou nova contratação estão previstas?
3. Como se compõe o valor vigente total de R$ 12.866.761,022 entre os 8 contratos, e há divergências entre os registros SIGA e os processos administrativos?
4. O SIGA registra zero contratos com prazo em até 30 ou 90 dias e zero valores a pagar: esses dados foram conferidos com as unidades gestoras e os processos de pagamento?
5. Quais contratos, convênios, saldos orçamentários, bens e obrigações da SEDIPAF foram transferidos, e qual documento formaliza cada transferência?
6. Qual é a denominação oficial, a estrutura e a autoridade responsável pela secretaria após o Decreto nº 50.380/2026 e eventuais atos posteriores?
7. Quem responde atualmente pela gestão e fiscalização de cada contrato, pela execução orçamentária, pelo patrimônio e pelos pagamentos transferidos?
8. Há plano de continuidade para serviços, sistemas, arquivos e atendimento ao público? Foram registrados atrasos ou interrupções após a reorganização?
9. Os encontros previstos para subsidiar a revisão do Pleapo foram realizados? Qual é a situação atual do programa e das demais ações transferidas?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEDIPAF | Secretaria de Estado de Desenvolvimento Regional do Interior, Pesca e Agricultura Familiar | 8 | R$ 12,9 mi | 0 | R$ 0,0 mi | 0 | Três contratos têm vencimento em até 180 dias, mas os dados apresentados não permitem afi… | Obter inventário SIGA e plano de tratamento dos três vencimentos em até 180 dias. |

## Fontes da pesquisa
1. [RJ funde secretarias de Agricultura e Desenvolvimento Regional - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) — 2026-07-14
2. [Rio de Janeiro funde secretarias de Agricultura e de Pesca](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca) — 2026-07-15
3. [Rio de Janeiro funde secretarias de Agricultura e de Pesca](https://www.brasildefato.com.br/2026/07/15/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca/) — 2026-07-15
4. [Combined PDF](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf) — 2026-07-16
5. [Desenvolvimento Regional do Interior](https://www.rj.gov.br/sedipaf/node/723) — 2026-06-08
6. [Emater-Rio sedia Encontro Sobre Agroecologia nesta quarta-feira em Italva](https://www.folhadeitalva.com.br/2026/07/emater-rio-sedia-encontro-sobre.html) — 2026-07-07
7. [Couto unifica secretarias de Agro e Interior - DOC PRESS](https://docpress.inf.br/2026/07/21/couto-unifica-secretarias-de-agro-e-interior/) — 2026-07-21

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
