# Dossiê reduzido — Secretaria de Estado de Fazenda (SEFAZ)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEFAZ.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEFAZ_pesquisa.md`.

## Resumo executivo
- A situação fiscal exige acompanhamento prioritário: a Secretaria informou dívida estadual de R$ 242,1 bilhões em julho de 2026, enquanto a LOA de 2026 projetou déficit de quase R$ 19 bilhões; o governo interino esperava reverter o resultado, mas não informou o valor de eventual superávit. [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- Há apurações disciplinares e de controle relevantes na SEFAZ, mas as fontes não permitem concluir que os processos recentes sobre servidores da área de petróleo estejam relacionados às apurações anteriores ou identificar os investigados e as infrações. [PADs na área de petróleo](https://www.ururau.com.br/noticias/estado-rj/corregedoria-da-fazenda-do-rj-abre-processos-contra-seis-servidores-da-area-de-petroleo/82795/) [Apuração sobre ordem judicial](https://veja.abril.com.br/brasil/fazenda-do-rio-investiga-servidores-que-teriam-omitido-ordem-judicial-sobre-auditor-alvo-da-pf/)
- O MPRJ recomendou medidas para identificar e acompanhar devedores contumazes, incluindo banco de dados compartilhado com o órgão, mas as fontes não informam se a SEFAZ iniciou ou concluiu essas providências. [Recomendação do MPRJ](https://valor.globo.com/brasil/noticia/2026/03/11/mp-rj-pede-que-estado-crie-banco-de-dados-para-identificar-devedores-contumazes.ghtml)
- As fontes não trazem inventário de contratos críticos nem indicam risco concreto de interrupção de serviços; essa ausência deve ser tratada como lacuna de informação para a transição. [Entrevista do secretário](https://cbn.globo.com/programas/cbn-rio/entrevista/2026/10/14/a-gente-vai-entregar-um-estado-saneado-mas-sem-duvida-nenhuma-os-desafios-ainda-sao-muito-grandes-diz-secretario-de-fazenda-do-rj.ghtml) [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)

## 1. Missão e competências
- Conduzir a gestão fiscal e acompanhar a situação financeira e orçamentária do Estado.
- Atuar na gestão de receitas e despesas públicas, inclusive no acompanhamento da dívida estadual.
- Exercer atividades de fiscalização tributária e apuração de incentivos fiscais.

## 2. Estrutura essencial
- Titular: Guilherme Mercês.
- FAF - Fundo Especial de Adm Fazendária.
- LOTERJ - LOTERIA DO ESTADO DO RIO DE JANEIRO.
- SEFAZ - SECRETARIA DE ESTADO DE FAZENDA.

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 102 contratos, R$ 248,8 mi (+10 'Ativo' sem data de fim válida, R$ 1,3 mi) |
| Vencem em até 30 dias | 12 contratos, R$ 25,6 mi |
| Vencem em até 90 dias | 18 contratos, R$ 41,7 mi (4 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 34 contratos, R$ 66,4 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 11,6 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2025009748 | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Trata-se da Adesão da Ata de Registro de Preços nº Nº 010/2… | R$ 15.861.602,00 | 26/11/2026 (PNCP) |
| 2021006496 | CLARO S/A (FILIAL) | Trata-se da adesão à Ata de registro de Preços nº 0001/2021… | R$ 7.922.703,60 | 29/11/2026 |
| 2025010995 | LGPDNOW TRATAMENTO E HOSPEDAGEM DE DADOS LTDA | Trata-se da Contratação de plataforma de Inteligência Artif… | R$ 6.119.682,55 | 30/12/2026 (PNCP) |
| 2026001001 | ASSOCIAÇÃO LIGA BRASILEIRA DE MMA | Patrocínio pela Loteria do Estado do Rio de Janeiro - LOTER… | R$ 6.000.000,00 | 03/01/2027 (PNCP) |
| 2025010811 | LGPDNOW TRATAMENTO E HOSPEDAGEM DE DADOS LTDA | Trata-se da Contratação de plataforma de voltada para prote… | R$ 3.386.358,89 | 20/12/2026 |
| 2025009746 | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada para a confecção, forn… | R$ 966.556,50 | 26/11/2026 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 89 (R$ 113,8 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 18 (R$ 41,7 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2022004816 | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES LTDA | R$ 21.098.000,00 | 12/07/2026 |
| 2024008526 | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES LTDA | R$ 15.742.260,00 | 30/10/2026 |
| 2025003017 | ONIX ORGANIZACAO E PRODUCAO DE EVENTOS LTDA | R$ 14.000.000,00 | 07/10/2026 |

## 5. Alertas vermelhos
- 12 contrato(s) vencem em até 30 dias (R$ 25,6 mi).
- Pressão fiscal: dívida estadual informada em R$ 242,1 bilhões e déficit projetado de quase R$ 19 bilhões. [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- A dependência de receitas não recorrentes e a redução da disponibilidade líquida de caixa exigem acompanhamento. [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- Dois PADs foram abertos contra seis servidores da área de petróleo e combustíveis; não há conclusão de responsabilidade. [PADs na área de petróleo](https://www.ururau.com.br/noticias/estado-rj/corregedoria-da-fazenda-do-rj-abre-processos-contra-seis-servidores-da-area-de-petroleo/82795/)
- A auditoria sobre incentivos fiscais à Refit não tinha conclusão informada na pesquisa. [Apuração sobre a Refit](https://www.brasildefato.com.br/2026/05/19/secretaria-de-fazenda-do-rj-apura-envolvimento-de-servidores-em-favorecimento-do-grupo-fit)

## 6. Riscos prioritários
- Pressão sobre o equilíbrio fiscal diante da dívida informada, do déficit projetado e da dependência de receitas extraordinárias. [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- Risco de descontinuidade ou renovação tardia: as estatísticas registram 12 contratos com vencimento em até 30 dias e 18 em até 90 dias; a pesquisa não identificou contratos críticos nem planos de contingência.
- Pendências de pagamento: há R$ 11.631.086,05 a pagar, sem detalhamento de credores, prazos ou impacto operacional nas informações fornecidas.
- A Sefaz abriu PADs para apurar a omissão de comunicação de ordem judicial; em outro caso, a Corregedoria abriu dois PADs contra seis servidores da área de petróleo. As fontes não informam o desfecho dos procedimentos. [Apuração sobre ordem judicial](https://veja.abril.com.br/brasil/fazenda-do-rio-investiga-servidores-que-teriam-omitido-ordem-judicial-sobre-auditor-alvo-da-pf/) [PADs na área de petróleo](https://www.ururau.com.br/noticias/estado-rj/corregedoria-da-fazenda-do-rj-abre-processos-contra-seis-servidores-da-area-de-petroleo/82795/)
- Os dados incluem contratos e patrocínios de unidades distintas, como LOTERJ; sem segregação por unidade, há risco de atribuir à SEFAZ obrigações ou vencimentos que podem pertencer a outra unidade.

## 7. Perguntas-chave para IA externa
1. Qual é a situação atual, o objeto completo e a unidade responsável pelo contrato SIGA 2022004816, no valor de R$ 21.098.000,00, cuja data de fim informada é 12/07/2026?
2. O contrato SIGA 2024008526, de R$ 15.742.260,00, com fim informado em 30/10/2026, foi encerrado, prorrogado ou substituído? Qual o plano de continuidade?
3. Qual é o estágio de execução e a data efetiva de término do contrato 2025009748, de R$ 15.861.602,00, com fim informado em 26/11/2026?
4. Qual unidade responde pelo contrato 2021006496 com a Claro, de R$ 7.922.703,60, e qual a situação da vigência informada até 29/11/2026?
5. Qual a justificativa, unidade demandante, estágio de implantação e plano de continuidade da plataforma de IA do contrato 2025010995, de R$ 6.119.682,55, com fim informado em 30/12/2026?
6. Os contratos 2025010811, de R$ 3.386.358,89, e 2025010995, ambos com a LGPDNOW, têm objetos complementares ou sobrepostos? Quais controles de execução e continuidade estão previstos?
7. Dos 12 contratos com vencimento em até 30 dias e dos 18 em até 90 dias, quais são os de maior criticidade, respectivos responsáveis, providências de renovação e contingências?
8. Como se compõe o valor de R$ 11.631.086,05 a pagar, quais obrigações estão vencidas e quais podem afetar serviços ou fornecedores essenciais?
9. Qual o andamento da recomendação do MPRJ sobre devedores contumazes e dos PADs relativos à área de petróleo e à comunicação judicial? Qual a situação da auditoria sobre incentivos fiscais à Refit?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEFAZ | Secretaria de Estado de Fazenda | 102 | R$ 248,8 mi | 18 | R$ 41,7 mi | 0 | Pressão fiscal combinada com lacunas sobre contratos, pagamentos e continuidade. | Validar vencimentos, pagamentos e continuidade dos serviços essenciais. |

## Fontes da pesquisa
1. [Corregedoria da Fazenda do RJ abre processos contra seis servidores da área de petróleo   Ururau Notícias](https://www.ururau.com.br/noticias/estado-rj/corregedoria-da-fazenda-do-rj-abre-processos-contra-seis-servidores-da-area-de-petroleo/82795/) — 2026-10-23
2. [Fazenda do Rio investiga servidores que teriam omitido ordem judicial sobre auditor alvo da PF](https://veja.abril.com.br/brasil/fazenda-do-rio-investiga-servidores-que-teriam-omitido-ordem-judicial-sobre-auditor-alvo-da-pf/) — 2026-08-18
3. [MP-RJ pede que Estado crie banco de dados para identificar ...](https://valor.globo.com/brasil/noticia/2026/03/11/mp-rj-pede-que-estado-crie-banco-de-dados-para-identificar-devedores-contumazes.ghtml) — 2026-03-11
4. [Secretaria de Fazenda do RJ apura envolvimento de servidores em favorecimento do Grupo Fit](https://www.brasildefato.com.br/2026/05/19/secretaria-de-fazenda-do-rj-apura-envolvimento-de-servidores-em-favorecimento-do-grupo-fit) — 2026-05-19
5. [Contas do RJ perdem fôlego após impulso de receita extraordinária, e interino tenta reverter déficit](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml) — 2026-09-06
6. ['A gente vai entregar um estado saneado, mas, sem dúvida nenhuma, os desafios ainda são muito grandes', diz se](https://cbn.globo.com/programas/cbn-rio/entrevista/2026/10/14/a-gente-vai-entregar-um-estado-saneado-mas-sem-duvida-nenhuma-os-desafios-ainda-sao-muito-grandes-diz-secretario-de-fazenda-do-rj.ghtml) — 2026-10-14

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
