# Dossiê reduzido — Secretaria de Estado de Infraestrutura e Obras Públicas (SEIOP)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEIOP.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEIOP_pesquisa.md`.

## Resumo executivo
- O TCE-RJ acompanha a implantação da nova sede do Museu da Imagem e do Som (MIS). Em decisão de 17 de março de 2025, determinou, entre outras medidas, a apuração de possíveis infrações relacionadas ao Contrato nº 012/2022 e estudos de planejamento para mitigar riscos de prazo nas novas contratações. Já em 16 de março de 2026, acolheu as defesas, determinou comunicações para ciência e arquivou os autos. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- Há um valor de **R$ 217.923,11** solicitado para Termo de Ajuste de Contas por serviços da Peri Formas e Escoamentos Ltda. cujo pagamento, segundo a informação reportada, não havia sido efetivado por falta de disponibilidade orçamentária. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- Em levantamento do TCE-RJ publicado em agosto de 2026, a Secretaria de Estado de Infraestrutura e Obras aparece com **11 contratos classificados como paralisados**, mas a matéria não identifica os contratos nem atribui especificamente ao órgão os efeitos gerais de atrasos e paralisações apontados pela auditoria. [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)
- Registros orçamentários com posição em **31/03/2026** mostram pagamentos em 2026 para a recuperação dos equipamentos do Teleférico do Alemão; as fontes não informam se o serviço está operando normalmente ou se há risco iminente de interrupção. [Investimento em Obras 2026 — CSV](https://www.rj.gov.br/transparencia/sites/default/files/arquivos_paginas/Investimento%20em%20Obras%202026%2003.csv)

## 1. Missão e competências
- Atuação em infraestrutura e obras públicas estaduais, inferida do nome da Secretaria e do conjunto de contratos.
- Execução de obras e serviços rodoviários, incluindo conservação/recapeamento da malha estadual e restauração e melhorias físico-operacionais da RJ-99, conforme objetos registrados no SIGA.
- Intervenções em equipamentos públicos, incluindo a nova sede do Museu da Imagem e do Som e a recuperação do Teleférico do Alemão.

## 2. Estrutura essencial
- Titular: a confirmar
- DER-RJ - FUND DEP ESTRADAS DE RODAGEM DO ESTADO DO RJ
- EMOP - EMPRESA DE OBRAS PÚBLICAS DO ESTADO DO RJ
- IEEA - INST ESTADUAL DE ENGENHARIA E ARQUITETURA
- SEINFRA - Secretaria de Estado de Infra e Obras
- SEIOP - SECRETARIA DE ESTADO DE INFRAESTRUTURA E OBRAS PUBLICAS - SEIOP

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 54 contratos, R$ 850,8 mi (+0 'Ativo' sem data de fim válida, R$ 0,0 mi) |
| Vencem em até 30 dias | 1 contratos, R$ 0,7 mi |
| Vencem em até 90 dias | 6 contratos, R$ 10,1 mi (0 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 25 contratos, R$ 386,5 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 47,5 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2024000033 | CS BRASIL FROTAS S.A. | O presente Termo de Referência tem por objetivo estabelecer… | R$ 9.029.240,28 | 22/01/2027 |
| 2023005053 | REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | Locação de veículos automotores categoria Representação RP0… | R$ 741.600,00 | 14/11/2026 |
| 2025010645 | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada paraconfecção, forneci… | R$ 173.387,50 | 19/12/2026 |
| 2026000064 | ELEVADORES ATLAS SCHINDLER LTDA. | Prestação de serviços de manutenção preventiva e corretiva … | R$ 118.474,68 | 06/01/2027 |
| 2026000073 | JSB COMERCIO E SERVIÇOS LTDA | SERVIÇOS DE LOCAÇÃO DE PURIFICADORES DE ÁGUA, com troca de … | R$ 43.080,00 | 06/01/2027 |
| 2025010020 | PORTAL TRANSPORTE E COMÉRCIO DE RESÍDUOS E L… | SERVIÇO DE COLETA DE RESÍDUOS SÓLIDOS, URBANOS, INDUSTRIAL … | R$ 4.000,00 | 10/12/2026 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 124 (R$ 2,32 bi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 6 (R$ 10,1 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2024008523 | OMEGA CONSTRUTORA E SERVIÇOS LTDA | R$ 165.184.182,50 | 21/10/2026 |
| 2021000714 | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | R$ 146.039.466,63 | 03/04/2026 |
| 2024005766 | OMEGA CONSTRUTORA E SERVIÇOS LTDA | R$ 121.209.193,39 | 17/01/2026 |

## 5. Alertas vermelhos
- 1 contrato(s) vencem em até 30 dias (R$ 0,7 mi).
- O levantamento do TCE-RJ atribuiu 11 contratos paralisados à Secretaria, sem identificar contratos, valores ou causas. [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)
- Em decisão plenária de 17/03/2025, o TCE-RJ determinou à SEIOP a apuração de possíveis infrações relacionadas ao Contrato nº 012/2022 do MIS; no Acórdão nº 009981/2026, considerou atendida essa determinação. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- Foi solicitada disponibilidade orçamentária para celebrar Termo de Ajuste de Contas de R$ 217.923,11 à Peri Formas e Escoamentos Ltda., mas não houve pagamento por falta de disponibilidade orçamentária; o TCE-RJ também apontou a necessidade de identificar corretamente o valor devido e evitar duplicidade. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- A matéria sobre o Asfalto na Porta 2 relata prejuízo de cerca de R$ 22,8 milhões em contratos atribuídos à antiga Seobras, sem estabelecer responsabilidade da SEIOP. [TCE-RJ aponta prejuízo no Asfalto na Porta 2](https://temporealrj.com/tce-rj-asfalto-na-porta-2-governo-estado/)
- O TCE-RJ apontou risco orçamentário sistêmico de atrasos e paralisações, mas a fonte não atribui esses efeitos especificamente à SEIOP. [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)

## 6. Riscos prioritários
- Transição de contratos: 6 contratos somam R$ 10.109.782,46 na janela de 90 dias; verificar prazos, renovações e continuidade dos serviços, inclusive o contrato 2024000033, de R$ 9.029.240,28.
- Pressão de pagamentos: as estatísticas registram R$ 47.460.743,95 a pagar; a composição, os vencimentos e a disponibilidade orçamentária precisam ser confirmados.
- A EMOP informou que solicitou disponibilidade orçamentária para celebrar Termo de Ajuste de Contas de R$ 217.923,11, mas o pagamento não foi realizado por falta de orçamento; a matéria segue sob acompanhamento da empresa. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- Risco de controle e responsabilização no MIS: o TCE-RJ determinou apuração relativa ao Contrato nº 012/2022 e registrou questões de planejamento e prazos em novas contratações. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- Continuidade do Teleférico do Alemão: há pagamentos registrados para recuperação de equipamentos, mas as fontes não confirmam condição operacional, cronograma atualizado ou risco de interrupção. [Investimento em Obras 2026 — CSV](https://www.rj.gov.br/transparencia/sites/default/files/arquivos_paginas/Investimento%20em%20Obras%202026%2003.csv)

## 7. Perguntas-chave para IA externa
1. Quais são os 11 contratos classificados como paralisados, com número, objeto, contratada, valor, causa, saldo, pagamentos e plano de retomada?
2. Qual a situação atual do Contrato nº 012/2022 do MIS, da apuração determinada pelo TCE-RJ e das providências sobre a garantia após o distrato de 24/06/2025?
3. O Termo de Ajuste de Contas de R$ 217.923,11 com a Peri Formas e Escoamentos Ltda. foi pago? Se não, qual a previsão e a situação orçamentária?
4. Quais são os valores, responsáveis, cronogramas e situação atual do Contrato nº 012/2024, do Contrato nº 031/2021 e da Concorrência Pública nº 015/2023 do MIS?
5. Qual a situação operacional do Teleférico do Alemão e o cronograma de conclusão das intervenções associadas às notas 2026NE00218, de R$ 4.823.492,73, e 2026NE00304, de R$ 2.069.211,53?
6. Quais contratos compõem os R$ 10.109.782,46 na janela de 90 dias e quais medidas de renovação ou substituição estão previstas, em especial para o contrato 2024000033, de R$ 9.029.240,28?
7. Qual a composição dos R$ 47.460.743,95 registrados como a pagar, com credores, vencimentos, fonte de recursos e eventuais valores contestados?
8. Qual o andamento e a responsabilidade institucional pelos contratos de obras rodoviárias de maior valor, incluindo 2024008523, de R$ 165.184.182,50, e 2021000714, de R$ 146.039.466,63?
9. Quais medidas de continuidade administrativa, responsáveis e prioridades para os primeiros 90 dias estão definidas para obras, contratos essenciais, pagamentos e sistemas?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEIOP | Secretaria de Estado de Infraestrutura e Obras Públicas | 54 | R$ 850,8 mi | 6 | R$ 10,1 mi | 0 | Risco a verificar de descontinuidade de obras e serviços: o levantamento do TCE-RJ classi… | Consolidar contratos paralisados, vencimentos próximos, pagamentos e planos de retomada. |

## Fontes da pesquisa
1. [ACÓRDÃO Nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026) — 2026-07-06
2. [TCE-RJ aponta prejuízo de R$ 22,8 milhões em obras do programa Asfalto na Porta 2, do governo do estado; multa](https://temporealrj.com/tce-rj-asfalto-na-porta-2-governo-estado/) — 2026-11-01
3. [https://www.rj.gov.br/transparencia/sites/default/...](https://www.rj.gov.br/transparencia/sites/default/files/arquivos_paginas/Investimento%20em%20Obras%202026%2003.csv) — 2026-04-09
4. [Bloqueios propositais de recursos atrasam obras em estradas ...](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/) — 2026-08-16

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
