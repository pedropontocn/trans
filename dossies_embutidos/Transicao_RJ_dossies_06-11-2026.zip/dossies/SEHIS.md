# Dossiê reduzido — Secretaria de Estado de Habitação de Interesse Social (SEHIS)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEHIS.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEHIS_pesquisa.md`.

## Resumo executivo
- A segunda etapa do Parque Ermitage, prevista para 500 apartamentos, teve a conclusão estimada para julho de 2027. O custo reportado passou de R$ 97 milhões para aproximadamente R$ 137 milhões após aditivos ao contrato. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- A licitação para quatro condomínios chegou a ser suspensa pelo TCE-RJ diante de indícios de direcionamento no edital, que deveria ser corrigido antes de o processo prosseguir. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- A documentação fornecida identifica o Contrato nº 051/2026, para projeto executivo e obras em 69 unidades habitacionais no Rio de Janeiro, mas não informa valor ou cronograma. [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf)
- As fontes não permitem confirmar dívida, risco iminente de interrupção de serviços ou ações judiciais. O texto do O Dia informa que foi encaminhado ao MPRJ e ao TCE-RJ um pedido para apurar os atrasos e o aumento dos valores, mas não esclarece se o MPRJ abriu ou concluiu uma apuração. Esses pontos precisam ser verificados com os órgãos competentes e, quando cabível, com a Secretaria. [Início — SEHIS](https://www.rj.gov.br/habitacao/) [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)

## 1. Missão e competências
- Atuar na área de habitação de interesse social.
- Promover obras de construção, reforma e requalificação de unidades habitacionais.
- Acompanhar iniciativas de urbanização e melhorias em áreas habitacionais.

## 2. Estrutura essencial
- Titular: a confirmar
- CEHAB - COMPANHIA ESTADUAL DE HABITAÇÃO DO RJ
- ITERJ - INSTIT DE TERRAS E CARTOGRAFIA DO EST DO RJ
- SEH - SECRETARIA DE ESTADO DE HABITAÇÃO
- SEHIS - Secretaria de Estado de Habitação de Interesse Social

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 73 contratos, R$ 286,7 mi (+1 'Ativo' sem data de fim válida, R$ 0,0 mi) |
| Vencem em até 30 dias | 3 contratos, R$ 0,8 mi |
| Vencem em até 90 dias | 14 contratos, R$ 50,7 mi (11 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 43 contratos, R$ 198,4 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 44,7 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2025010118 | FABMIX CONCRETOS LTDA | EXECUÇÃO DE SERVIÇOS DE URBANIZAÇÃO (EXECUÇÃO DE CONSTRUÇÃO… | R$ 12.000.000,00 | 23/12/2026 (PNCP) |
| 2025010245 | CONSTRUTORA AUGUSTO VELLOSO S.A. | EXECUÇÃO DE SERVIÇOS DE URBANIZAÇÃO(EXECUÇÃO DE CONSTRUÇÃO/… | R$ 10.018.085,44 | 08/12/2026 (PNCP) |
| 2026000506 | DIMENSIONAL ENGENHARIA LTDA | ADESÃO LOTE 02 ATA SRP Processo nº SEI-510001/000267/2024 -… | R$ 7.060.325,31 | 02/02/2027 (PNCP) |
| 2026000505 | DIMENSIONAL ENGENHARIA LTDA | ADESÃO LOTE 01 ATA SRP Processo nº SEI-510001/000267/2024 -… | R$ 6.668.085,06 | 30/01/2027 (PNCP) |
| 2026000512 | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | ADESÃO LOTE 09 ATA SRP Processo nº SEI-510001/000267/2024 -… | R$ 3.564.467,64 | 30/01/2027 (PNCP) |
| 2026000513 | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | ADESÃO LOTE 06 ATA SRP Processo nº SEI-510001/000267/2024 -… | R$ 3.564.467,64 | 30/01/2027 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 65 (R$ 228,9 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 14 (R$ 50,7 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2022000255 | DYNATEST ENGENHARIA LTDA | R$ 43.182.614,53 | 24/01/2025 |
| 2024010002 | TCE EMPREENDIMENTOS ESPORTIVOS LTDA | R$ 37.998.137,02 | 11/08/2026 |
| 2025003726 | CONSTRUTORA SUMARÉ LTDA | R$ 31.181.117,07 | 31/10/2026 |

## 5. Alertas vermelhos
- 3 contrato(s) vencem em até 30 dias (R$ 0,8 mi).
- Parque Ermitage: segunda etapa de 500 apartamentos adiada para julho de 2027; custo reportado passou de R$ 97 milhões para cerca de R$ 137 milhões. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- O TCE-RJ suspendeu licitação de quatro condomínios e exigiu correções após apontar indícios de direcionamento; situação atual não informada. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- Em fevereiro de 2026, havia 229 vínculos ativos e 1 servidor efetivo/concursado; o dado requer validação das funções críticas e da sucessão. [Caderno de RH — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Caderno_de_RH-Fevereiro%202026_v2.pdf)
- A publicação do Termo de Colaboração nº 001/2025 — CONVERJ nº 1437 foi tornada sem efeito; motivo e consequências não informados. [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf)
- Foi solicitado ao TCE-RJ e ao MPRJ apurar atrasos e aumento de valores; as fontes não informam desfecho ou providências subsequentes. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)

## 6. Riscos prioritários
- Atrasos e aumento reportado de custo no Parque Ermitage podem comprometer a entrega das 500 unidades; confirmar aditivos, medições e cronograma. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- A suspensão da licitação dos quatro condomínios pode atrasar a contratação e a execução; verificar decisão do TCE-RJ e estágio do certame. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- O SIGA/PNCP registra R$ 44.730.231,80 a pagar; é necessário reconciliar valores, disponibilidade financeira e calendário de pagamentos.
- O indicador informa 14 contratos e R$ 50.652.276,95 no horizonte de 90 dias; confirmar prazos, renovações e risco de descontinuidade.
- A base aponta 43 contratos e R$ 198.397.423,28 no horizonte de 180 dias; priorizar revisão de cronogramas, obrigações e necessidade de continuidade.
- O quadro divulgado — 229 vínculos ativos e 1 efetivo/concursado — pode indicar fragilidade de continuidade administrativa, mas requer detalhamento por área e função. [Caderno de RH — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Caderno_de_RH-Fevereiro%202026_v2.pdf)

## 7. Perguntas-chave para IA externa
1. Quais contratos compõem os 14 registros e R$ 50.652.276,95 do indicador de 90 dias, quais vencem nos 90 dias seguintes à data de referência (até 04/02/2027) e quais têm renovação ou substituição encaminhada?
2. Como se conciliam os 73 contratos vigentes com os 316 ativos da base, e qual é a situação dos 43 contratos e R$ 198.397.423,28 indicados no horizonte de 180 dias?
3. Qual a composição dos R$ 44.730.231,80 a pagar, por contrato, credor, vencimento, fonte orçamentária e disponibilidade financeira?
4. Qual a situação do contrato SIGA 2025010152, da ABRE CONSTRUÇÕES LTDA, no valor de R$ 49.211.636,93 e término indicado em 30/03/2027, inclusive quanto à classificação registrada como rescisão?
5. Quais são o cronograma, as medições, os pagamentos e a previsão de continuidade dos contratos 2025010118, de R$ 12.000.000,00, e 2025010245, de R$ 10.018.085,44?
6. Nos contratos 2026000506, de R$ 7.060.325,31, e 2026000505, de R$ 6.668.085,06, quais são o estágio de execução, os pagamentos e os controles da adesão às atas de registro de preços?
7. No Parque Ermitage, qual é o número do contrato, a identificação da empresa, a justificativa e o valor de cada aditivo, o cronograma atualizado e o plano de entrega das 500 unidades? [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
8. O TCE-RJ suspendeu a licitação dos quatro condomínios após identificar indícios de direcionamento no edital e determinar correções antes da continuidade do processo. A matéria informa que um pedido de investigação foi encaminhado ao MPRJ, mas não diz se o órgão instaurou procedimento ou se manifestou, nem qual é a situação atual da licitação. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
9. Qual o valor, prazo, cronograma e estágio do Contrato nº 051/2026, relativo a 69 unidades, e por que foi tornada sem efeito a publicação do Termo de Colaboração nº 001/2025 — CONVERJ nº 1437? [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf)

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEHIS | Secretaria de Estado de Habitação de Interesse Social | 73 | R$ 286,7 mi | 14 | R$ 50,7 mi | 0 | Atrasos e aumento de custos reportados no Parque Ermitage, além de suspensão de licitação… | Validar contratos, cronogramas, pagamentos e medidas corretivas antes da posse. |

## Fontes da pesquisa
1. [Atraso de obras mantém vítimas da tragédia de 2011 sem moradia em Teresópolis   Teresópolis   O Dia](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html) — 2026-07-11
2. [Foi](https://www.alerj.rj.gov.br/Visualizar/Noticia/81935) — 2026-10-27
3. [Início   Secretaria de Habitação de Interesse Social](https://www.rj.gov.br/habitacao/) — 2026-06-19
4. [ PDF  GESTÃO DOCUMENTAL - Governo do Estado do Rio de Janeiro](https://www.rj.gov.br/seiop/sites/default/files/arquivos_pagina_basica/PED%20N%C2%BA%2039365.pdf) — 2026-04-21
5. [��Á���](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf) — 2026-10-28
6. [Edição nº 146](https://www.rj.gov.br/gesperj/sites/default/files/Caderno_de_RH-Fevereiro%202026_v2.pdf) — 2026-03-15

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
