# Dossiê reduzido — Secretaria de Estado de Transporte e Mobilidade Urbana (SETRAM)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SETRAM.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SETRAM_pesquisa.md`.

## Resumo executivo
- Um risco financeiro-operacional recente é a cobrança, pela TrensRJ, de R$ 68 milhões até 28 de agosto de 2026; a empresa alertou que a falta do repasse suspenderia a folha salarial e que fornecedores ameaçavam cortar serviços essenciais, embora tenha afirmado que não haveria paralisação. [BandNews — TrensRJ cobra R$ 68 milhões](https://www.band.com.br/bandnews-fm/rio-de-janeiro/noticias/trensrj-cobra-r-68-milhoes-do-estado-e-fala-em-risco-de-paralisacao-202608281752)
- A continuidade dos repasses depende de contrato emergencial da Setram com a RioCard, válido por sete meses até março de 2027; a secretaria informou que ainda precisava de ajustes técnicos para assumir todas as atividades com segurança. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- O TCE-RJ manteve, em março de 2026, a decisão que declarou ilegais convênios do Estado com a RioCard e determinou o desenvolvimento de capacidade estatal autônoma para verificar os dados usados nos pagamentos. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- As fontes também registram riscos à operação ferroviária associados a dívidas com fornecedores, além de uma disputa judicial envolvendo valores devidos à SuperVia. [Veja Rio — operação dos trens ameaçada](https://vejario.abril.com.br/cidade/trens-rio-operacao-ameacada-divida-supervia-trensrj/) [Ônibus & Transporte — atrasos no BUI e na Tarifa Social](https://onibusetransporte.com/2026/01/06/atraso-bilhete-unico-intermunicipal-tarifa-social-repasses-rj/)

## 1. Missão e competências
- Atuar na área estadual de transportes e mobilidade urbana, incluindo serviços de transporte rodoviário e ferroviário.
- Acompanhar a operação dos sistemas de transporte e a continuidade de serviços essenciais.
- Administrar ou acompanhar a bilhetagem e os repasses relacionados ao Bilhete Único Intermunicipal e à Tarifa Social.

## 2. Estrutura essencial
- Titular: a confirmar
- CENTRAL - COMP EST DE ENGENH DE TRANSPORTES E LOGÍSTICA
- CODERTE - COMP DE DESENV RODOV E TERMINAIS DO EST DO RJ
- CTC - CIA TRANSP COLET DO EST RJ-EM LIQUIDAÇÃO
- DETRO-RJ - DEP DE TRANSPORTES RODOVIÁRIOS DO EST DO RJ
- FET - FUNDO ESTADUAL DE TRANSPORTES
- RIOTRILHOS - COMP DE TRANSP SOBRE TRILHOS DO EST DO RJ
- SETRANS - SECRETARIA DE ESTADO DE TRANSPORTES

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 95 contratos, R$ 2,25 bi (+13 'Ativo' sem data de fim válida, R$ 2,4 mi) |
| Vencem em até 30 dias | 6 contratos, R$ 3,2 mi |
| Vencem em até 90 dias | 25 contratos, R$ 87,9 mi (2 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 48 contratos, R$ 102,5 mi |
| Emergenciais vigentes ou sem data de fim | 2 contratos, R$ 0,2 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 22,5 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2025002339 | OMEGA CONSTRUTORA E SERVIÇOS LTDA | CONTRATAÇÃO SEMI-INTEGRADA DE EMPRESAESPECIALIZADA PARA EXE… | R$ 72.499.193,50 | 25/01/2027 (PNCP) |
| 2015000692 | LIGHT SERVICOS DE ELETRICIDADE SA | CONTRATAÇÃO SERVIÇO DE FORNECIMENTO DE ENERGIA ELÉTRICA, PA… | R$ 3.490.873,04 | 31/12/2026 |
| 2024003250 | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | Conversão Digital de documentos e serviços de Microfilme di… | R$ 3.200.000,00 | 25/12/2026 |
| 2021007547 | CONSTRUTORA INTERNACIONAL LTDA | Contratação de Serviço de Locação de Imóveis. | R$ 2.654.005,90 | 22/11/2026 |
| 2024000115 | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | Contratação de empresa especialiada no fornecimento de Créd… | R$ 1.956.240,00 | 24/01/2027 (DOERJ) |
| 2024002493 | TERMINAL GARAGEM MENEZES CÔRTES S/A | Locação do imóvel do Terminal Rodoviários de Passageiros, c… | R$ 1.272.000,00 | 31/12/2026 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 108 (R$ 179,7 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 25 (R$ 87,9 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 12 (R$ 2,2 mi) | 0 | Alerta |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2023009562 | MPE ENGENHARIA E SERVIÇOS S/A | R$ 69.800.000,00 | 21/01/2025 |
| 2022005329 | FUNDAÇÃO DE APOIO À BIODIVERSIDADE SÃO FRANCISCO … | R$ 25.898.234,35 | 13/12/2024 |
| 2018003087 | GRUPO HOSPITALAR DO RIO DE JANEIRO LTDA (MATRIZ) | R$ 19.972.848,00 | 08/02/2026 |

## 5. Alertas vermelhos
- 6 contrato(s) vencem em até 30 dias (R$ 3,2 mi).
- 2 contratação(ões) emergencial(is) vigente(s) ou sem data de fim (R$ 0,2 mi): verificar limite de 1 ano (Lei 14.133, art. 75, VIII).
- 12 contrato(s) com data de fim impossível no SIGA (R$ 2,2 mi): 2022002788 LOWNDES E SONS S A ADM CORRETAGENS E RE… (fim 31/03/8202); 2024000466 RIOPAR PARTICIPAÇÕES S/A (fim 20/10/2192); 2024000506 AMPLA ENERGIA E SERVIÇOS S/A (fim 20/10/2192); 2024000665 COMPANHIA ESTADUAL DE AGUAS E ESGOTOS-C… (fim 20/10/2192); 2024000510 LIGHT SERVICOS DE ELETRICIDADE SA (fim 20/10/2192). Corrigir o cadastro e confirmar a vigência real no processo SEI.
- TrensRJ cobrou R$ 68 milhões e apontou risco à folha e a serviços essenciais; situação do pagamento deve ser confirmada. [BandNews — TrensRJ cobra R$ 68 milhões](https://www.band.com.br/bandnews-fm/rio-de-janeiro/noticias/trensrj-cobra-r-68-milhoes-do-estado-e-fala-em-risco-de-paralisacao-202608281752)
- Contrato emergencial de bilhetagem com a RioCard foi noticiado até março de 2027, enquanto a Setram ainda precisava de ajustes técnicos para internalizar as atividades. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- O TCE-RJ manteve a declaração de ilegalidade dos convênios com a RioCard e determinou capacidade estatal autônoma de verificação e controle. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- Reportagem registrou atrasos de pagamentos a fornecedores ferroviários e risco à prestação de serviços essenciais. [Veja Rio — operação dos trens ameaçada](https://vejario.abril.com.br/cidade/trens-rio-operacao-ameacada-divida-supervia-trensrj/)

## 6. Riscos prioritários
- Em 28/8/2026, a TrensRJ cobrou R$ 68 milhões do Estado e alertou que a falta do repasse poderia afetar a folha e a operação. A notícia informava que o pagamento deveria ocorrer em 31/8, mas não esclarece se foi realizado; a empresa afirmou que não haveria paralisação. [BandNews — TrensRJ cobra R$ 68 milhões](https://www.band.com.br/bandnews-fm/rio-de-janeiro/noticias/trensrj-cobra-r-68-milhoes-do-estado-e-fala-em-risco-de-paralisacao-202608281752)
- Dependência operacional da RioCard e prontidão incerta da capacidade própria de bilhetagem, com contrato emergencial noticiado até março de 2027 e determinação de controle autônomo pelo TCE-RJ. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- Transição de contratos próxima à posse: o SIGA registra R$ 87.917.889,06 em 25 contratos com fim em até 90 dias; o contrato 2025002339, de R$ 72.499.193,50, tem fim indicado em 25/01/2027.
- Exposição financeira relevante a administrar: há 108 contratos vigentes no SIGA, no valor total indicado de R$ 2.255.699.026,04, e R$ 22.493.399,04 a pagar; é necessária conciliação por contrato, credor e vencimento.
- Possível inconsistência cadastral a validar: o contrato 2024004346, de R$ 1.688.767,47, consta com término em 26/06/2193.

## 7. Perguntas-chave para IA externa
1. Qual é a situação conciliada dos R$ 68 milhões cobrados pela TrensRJ, quanto foi pago, quanto permanece pendente e quais comprovantes e análises da Agetransp sustentam o saldo?
2. Qual é o plano, com responsáveis, prazos, testes e contingências, para a bilhetagem e os repasses após o término previsto do contrato emergencial com a RioCard em março de 2027?
3. Quais marcos de prontidão foram cumpridos no Contrato nº 005/2026 para a Setram verificar, validar e auditar autonomamente os dados de bilhetagem?
4. O contrato SIGA 2025002339, de R$ 72.499.193,50 e com fim indicado em 25/01/2027, será prorrogado, substituído ou encerrado? Qual é o plano para evitar interrupção?
5. Qual é a situação atual do contrato SIGA 2015000692 com a Light, cujo fim indicado é 31/12/2026, e quais obrigações ou pagamentos permanecem pendentes?
6. Como se compõem os R$ 22.493.399,04 registrados como valores a pagar, incluindo credores, vencimentos, serviços associados e parcelas já liquidadas?
7. Qual é o saldo atualizado das dívidas ferroviárias com fornecedores, quais serviços estão em risco e que medidas de continuidade foram adotadas? [Veja Rio — operação dos trens ameaçada](https://vejario.abril.com.br/cidade/trens-rio-operacao-ameacada-divida-supervia-trensrj/)
8. Qual foi o resultado da decisão do TCE-RJ no Processo nº 101.211-9/2026 e qual é a situação jurídica e contratual atual do processo competitivo relativo à SuperVia?
9. O SIGA registra o término do contrato 2024004346 em 11/05/2026 e o valor de R$ 1.688.767,47. Solicita-se confirmar a vigência e o objeto do contrato, que prevê serviços contínuos de apoio nas áreas de recepção, manutenção, limpeza, asseio, conservação e higienização predial para atender às necessidades da CODERTE.

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SETRAM | Secretaria de Estado de Transporte e Mobilidade Urbana | 95 | R$ 2,25 bi | 25 | R$ 87,9 mi | 0 | Interrupção ou fragilidade de repasses e operações de transporte na transição. | Conciliar passivos e assegurar plano de continuidade ferroviária e da bilhetagem. |

## Fontes da pesquisa
1. [PROCESSO: TCE-RJ Nº 101.211-9/2026 ...](https://www.tribunanf.com.br/wp-content/uploads/2026/02/TCE-RJ-leilao-Supervia.pdf) — 2026-02-13
2. [Estado faz contrato emergencial com RioCard para repassar ...](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml) — 2026-09-11
3. [Arquivo de destaque - Página 77 de 834 - Tempo Real](https://temporealrj.com/tag/destaque/page/77/) — 2026-11-05
4. [Atraso no Bilhete Único Intermunicipal e Tarifa Social ...](https://onibusetransporte.com/2026/01/06/atraso-bilhete-unico-intermunicipal-tarifa-social-repasses-rj/) — 2026-01-06
5. [TrensRJ cobra R$ 68 milhões do Estado e fala em risco de paralisação](https://www.band.com.br/bandnews-fm/rio-de-janeiro/noticias/trensrj-cobra-r-68-milhoes-do-estado-e-fala-em-risco-de-paralisacao-202608281752) — 2026-08-28
6. [Operação dos trens no Rio está ameaçada por dívida da ...](https://vejario.abril.com.br/cidade/trens-rio-operacao-ameacada-divida-supervia-trensrj/) — 2026-07-23

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
