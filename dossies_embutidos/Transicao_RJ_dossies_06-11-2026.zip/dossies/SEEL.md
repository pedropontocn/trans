# Dossiê reduzido — Secretaria de Estado de Esporte e Lazer (SEEL)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEEL.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEEL_pesquisa.md`.

## Resumo executivo
A apuração do TCE-RJ sobre a compra de materiais esportivos da WR Calçados Eireli tem dano potencial calculado em R$ 1.938.853,26 e ainda não foi julgada definitivamente. [Farra das bolas](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/)

Há parcerias e programas relevantes a confirmar quanto à execução e continuidade: o Projeto Esporte Ativo 02 prevê 600 núcleos e R$ 92.133.900,72, enquanto o Termo de Fomento nº 18/2025 prevê seis meses de execução da Casa do Torcedor. [Edital do Projeto Esporte Ativo 02](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/Edital%20de%20Chamamento%20P%C3%BAblico%2003%20de%202025.pdf) [Termo de Fomento nº 18/2025](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/SEI_121816818_Termo_de_Parceria.pdf)

Reportagem de outubro informa que estava em análise uma possível fusão das pastas de Turismo, Esportes e Eventos, sem registrar decisão final. [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)

As fontes consultadas não permitem confirmar a situação atual dos contratos, a continuidade dos serviços, nem a existência de ações do MPRJ ou processos judiciais ligados à Secretaria. [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml) [Diário Oficial — orçamento da SEEL](https://cj.estrategia.com/portal/wp-content/uploads/2026/05/18092944/diarioOficial-2.pdf)

## 1. Missão e competências
- Atuar nas áreas de esporte, lazer e juventude.
- Promover iniciativas esportivas, incluindo núcleos de atividades e projetos de esporte comunitário, conforme os programas citados.

## 2. Estrutura essencial
- Titular: a confirmar
- SEELJE - SEC DE EST  ESPORTE, LAZER E JUVENTUDE
- SUDERJ - SUPERINTENDÊNCIA DE DESPORTOS DO ESTADO DO RJ

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 24 contratos, R$ 20,8 mi (+1 'Ativo' sem data de fim válida, R$ 0,3 mi) |
| Vencem em até 30 dias | 1 contratos, R$ 0,2 mi |
| Vencem em até 90 dias | 1 contratos, R$ 0,2 mi (0 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 10 contratos, R$ 12,2 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 0,9 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2023003829 | BRS SUPRIMENTOS CORPORATIVOS S/A | Contratação de serviços continuados de OUTSOURCING para ope… | R$ 190.552,85 | 25/11/2026 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 30 (R$ 10,6 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 1 (R$ 0,2 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2023009002 | CONQUISTA VIGILANCIA E SEGURANCA PATRIMONIAL LTDA | R$ 2.587.227,22 | 23/10/2025 |
| 2021003057 | SUCESSO EMPREENDIMENTOS E PARTICIPAÇÕES LTDA | R$ 1.531.401,27 | 01/07/2025 |
| 2024002305 | TECHDOG SOLUÇÕES DE INTERNET LTDA | R$ 1.419.952,80 | 01/04/2026 |

## 5. Alertas vermelhos
- 1 contrato(s) vencem em até 30 dias (R$ 0,2 mi).
- TCE-RJ apura dano potencial de R$ 1.938.853,26 na compra de materiais esportivos; não há notícia de julgamento definitivo. [Farra das bolas](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/)
- O Projeto Esporte Ativo 02 prevê R$ 92.133.900,72 para os três lotes, mas a homologação não comprova a formalização da parceria nem o início das atividades. [Edital do Projeto Esporte Ativo 02](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/Edital%20de%20Chamamento%20P%C3%BAblico%2003%20de%202025.pdf)
- O Termo de Fomento nº 18/2025 prevê seis meses para a Casa do Torcedor; vigência atual e eventual prorrogação não foram confirmadas. [Termo de Fomento nº 18/2025](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/SEI_121816818_Termo_de_Parceria.pdf)
- A eventual fusão de Turismo, Esportes e Eventos estava em análise, sem decisão final informada. [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)

## 6. Riscos prioritários
- Apuração do TCE-RJ sobre a compra da WR Calçados Eireli, com dano potencial de R$ 1.938.853,26 e situação processual atual não confirmada. [Farra das bolas](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/)
- Continuidade da Casa do Torcedor incerta: o termo prevê seis meses, mas não há confirmação de início, prorrogação ou encerramento. [Termo de Fomento nº 18/2025](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/SEI_121816818_Termo_de_Parceria.pdf)
- Carteira contratual requer validação: os registros apontam 24 contratos vigentes, no valor de R$ 20.751.706,77, enquanto contratos destacados têm datas de término em 2025 e 2026; confirmar situação, aditivos e continuidade.
- Há R$ 907.907,51 registrados como a pagar; saldo atualizado, restos a pagar e projeção até 01/01/2027 não foram informados.
- Possível reorganização da Secretaria pode afetar competências, contratos e serviços; a reportagem registra apenas que a fusão estava em estudo. [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)

## 7. Perguntas-chave para IA externa
1. Qual é o andamento atualizado da apuração do TCE-RJ sobre a compra da WR Calçados Eireli? Enviar processo, contrato, entregas, pagamentos e decisões, considerando o dano potencial de R$ 1.938.853,26.
2. O Projeto Esporte Ativo 02 teve termos de colaboração formalizados para os três lotes? Informar repasses, cronograma, metas e núcleos efetivamente em operação, diante do valor previsto de R$ 92.133.900,72.
3. Qual é a situação do Termo de Fomento nº 18/2025 da Casa do Torcedor, no valor de R$ 326.802,00? Informar início e término da vigência, aditivos, pagamentos, execução e prestação de contas.
4. Qual é a situação atual do contrato SIGA 2023003829, de R$ 190.552,85, com término registrado em 25/11/2026? Houve prorrogação, substituição ou encerramento do serviço?
5. Qual é a situação dos contratos SIGA 2023009002, no valor de R$ 2.587.227,216, e 2021003057, no valor de R$ 1.531.401,27, ambos com término registrado em 2025? Informar vigência atual, aditivos e continuidade dos serviços.
6. Qual é a situação do contrato SIGA 2024002305, de R$ 1.419.952,80, com término registrado em 01/04/2026? O serviço permanece ativo e sob qual instrumento?
7. Enviar inventário atualizado dos 24 contratos vigentes, dos 315 ativos registrados e dos respectivos saldos, pagamentos, vigências, aditivos, gestores e fiscais.
8. A que obrigações correspondem os R$ 907.907,51 registrados como a pagar? Informar credores, vencimentos, fonte de recursos e previsão de liquidação.
9. Qual é o saldo orçamentário e financeiro atualizado, a execução por programa e fonte e a projeção até 01/01/2027? O orçamento publicado em maio de 2026 não confirma os valores atuais.
10. Há decisão ou estudo atualizado sobre eventual fusão de Turismo, Esportes e Eventos? Informar impactos previstos na estrutura, competências, contratos, pessoal e continuidade dos serviços.

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEEL | Secretaria de Estado de Esporte e Lazer | 24 | R$ 20,8 mi | 1 | R$ 0,2 mi | 0 | Apuração de controle e continuidade contratual sem situação atual consolidada. | Validar passivos, contratos e parcerias antes da posse. |

## Fontes da pesquisa
1. [Farra das bolas: TCE-RJ aponta superfaturamento de R$ 1,9 milhão ...](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/) — 2026-07-25
2. [Ruas começa transição de governo estudando mudanças na ...](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml) — 2026-10-14
3. [ PDF  Á - RJ Gov](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/IOERJTraceableFile698df88e6774d.pdf) — 2026-04-27
4. [Á](https://print.cge.rj.gov.br/uploads/short-url/fqy5QKyfg1tgQxFWx7Kj7QDzV4K.pdf) — 2026-06-10
5. [Diario Oficial](https://cj.estrategia.com/portal/wp-content/uploads/2026/05/18092944/diarioOficial-2.pdf) — 2026-08-20
6. [EDITAL DE CHAMAMENTO PÚBLICO Nº 03/2025](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/Edital%20de%20Chamamento%20P%C3%BAblico%2003%20de%202025.pdf) — 2026-01-15
7. [termo de fomento nº 18/2025](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/SEI_121816818_Termo_de_Parceria.pdf) — 2026-05-20

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
