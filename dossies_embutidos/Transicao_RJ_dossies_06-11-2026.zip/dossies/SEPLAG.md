# Dossiê reduzido — Secretaria de Estado de Planejamento e Gestão (SEPLAG)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEPLAG.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEPLAG_pesquisa.md`.

## Resumo executivo
- O futuro secretário anunciado para a Secretaria de Planejamento, Gestão e Inovação é Anderson Monteze, que integra a equipe de transição de Douglas Ruas; a equipe recebeu relatórios do governo atual, mas as fontes não confirmam se a SEPLAG entregou seu relatório específico nem detalham seu conteúdo. [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)
- A proposta orçamentária de 2027 deverá ser reavaliada, diante de déficit previsto de R$ 14 bilhões, e a futura pasta deverá participar da formulação de um teto de gastos; são planos anunciados, não medidas cuja implementação esteja confirmada. [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml)
- As fontes consultadas não relatam contratos problemáticos, decisões do TCE-RJ, ações do MPRJ ou do Judiciário, nem interrupções de serviços relacionadas à SEPLAG. [G1 — transição de governo no RJ](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/15/transicao-de-governo-no-rj-veja-quem-participa-prazos-e-proximos-passos.ghtml) [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)

## 1. Missão e competências
- Planejamento e gestão estadual, incluindo revisão da proposta orçamentária e análise de receitas e despesas.
- Gestão de logística e de serviços administrativos, conforme áreas representadas nas unidades vinculadas e nos contratos listados.
- Há evidência de contrato de conectividade e link de dados (SIGA 2021007413), mas as fontes consultadas não demonstram a gestão de sistemas e soluções de TI em geral.
- A futura pasta foi anunciada como responsável pela gestão do patrimônio imobiliário estadual, plano ainda não detalhado.

## 2. Estrutura essencial
- Rafael Ventura Abreu, então secretário estadual de Planejamento e Gestão, foi incluído na Comissão de Transição em 14/10/2026.
- Futuro titular anunciado: Anderson Monteze, para a futura Secretaria de Planejamento, Gestão e Inovação.
- CEPERJ - FUND CENTRO EST. ESTAT.  PESQ. SERV RJ
- IASERJ - INSTITUTO DE ASSIST DOS SERVID DO EST RJ
- RIOPREVIDÊNCIA - FUNDO UNICO DE PREVIDENCIA DO ERJ
- RIOPREVIDÊNCIA - FUNDO UNICO DE PREVIDENCIA SOCIAL DO ESTADO DO RIO DE JANEIRO
- RJPREV - Fundação de Previdência Complem do ERJ
- SEPLAG  - SUBSECRETARIA DE LOGÍSTICA
- SEPLAG - SEC DE EST DE PLANEJAMENTO E GESTÃO (Antiga SEPLAG)
- SEPLAG - Secretaria de Estado de Planejamento e Gestão

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 111 contratos, R$ 199,0 mi (+13 'Ativo' sem data de fim válida, R$ 1,1 mi) |
| Vencem em até 30 dias | 3 contratos, R$ 0,0 mi |
| Vencem em até 90 dias | 16 contratos, R$ 6,1 mi (2 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 28 contratos, R$ 31,3 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 4,8 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2025010444 | TAMANDARÉ INFORMATICA LTDA | Aquisição de equipamentos de informática, compreendendo mic… | R$ 2.230.950,00 | 15/12/2026 (PNCP) |
| 2026000333 | RIOPAR PARTICIPAÇÕES S/A | Fornecimento de vale-transporte para os servidores do Fundo… | R$ 1.200.000,00 | 03/02/2027 (PNCP) |
| 2023010803 | BRS SUPRIMENTOS CORPORATIVOS S/A | Este Termo de Referência TR versa sobre as condições de pre… | R$ 932.932,80 | 20/12/2026 |
| 2021007677 | EMPRESA DE TECNOLOGIA E INFORMACOES DA PREVI… | Custeio do novo sistema COMPREV | R$ 720.000,00 | 31/12/2026 |
| 2022009117 | LIZ SERVIÇOS ONLINE LTDA | Contratação de empresa especializada na prestação continuad… | R$ 379.980,00 | 12/12/2026 |
| 2021007413 | CLARO S/A (FILIAL) | Fornecimento de link de dados e conexão com a internet para… | R$ 178.596,00 | 28/12/2026 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 164 (R$ 87,6 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 16 (R$ 6,1 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 1 (R$ 0,0 mi) | 0 | Alerta |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2024008758 | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES LTDA | R$ 16.681.010,88 | 23/10/2025 |
| 2024009206 | FUNDAÇÃO DE APOIO A PESQUISA, ENSINO E ASSISTENCI… | R$ 14.960.000,00 | 31/12/2025 |
| 2025010826 | 3STRUCTURE IT LTDA | R$ 7.890.234,04 | 21/06/2026 |

## 5. Alertas vermelhos
- 3 contrato(s) vencem em até 30 dias (R$ 0,0 mi).
- 1 contrato(s) com data de fim impossível no SIGA (R$ 0,0 mi): 2012006999 DISTRIBUIDORA KARDU DE ALIMENTOS LTDA (fim 21/09/9201). Corrigir o cadastro e confirmar a vigência real no processo SEI.
- Déficit de R$ 14 bilhões previsto para 2027; confirmar premissas e memória de cálculo. [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml)
- O teto de gastos está em discussão, não implementado; eventual aprovação exigiria adequar a proposta orçamentária de 2027. [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)
- Estuda-se reduzir de 31 para 23 o número de pastas estaduais; confirmar impactos e desenho institucional para a SEPLAG. [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)

## 6. Riscos prioritários
- Risco fiscal e de replanejamento: a previsão de déficit de R$ 14 bilhões para 2027 leva a equipe a reavaliar as projeções de arrecadação e a proposta orçamentária, além de estudar limites para o crescimento das despesas. [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml)
- Risco de descontinuidade contratual: há 16 contratos na janela de 90 dias, somando R$ 6.123.645,63; confirmar cronogramas de renovação ou substituição.
- Risco de continuidade em serviços de TI e logística: contratos SIGA 2023010803 (R$ 932.932,80), 2021007677 (R$ 720.000,00), 2022009117 (R$ 379.980,00) e 2021007413 (R$ 178.596,00) têm término informado em dezembro de 2026.
- Risco de concentração de vencimentos: 28 contratos, no total de R$ 31.271.721,63, estão na janela de 180 dias; priorizar análise de criticidade e plano de continuidade.
- Há 2 contratos emergenciais, no total de R$ 516.165,24; verificar objeto, justificativa, prazo e estratégia de contratação subsequente.

## 7. Perguntas-chave para IA externa
1. O relatório de transição da SEPLAG foi entregue? Solicita-se cópia, com programas em andamento, decisões para os primeiros 100 dias, projetos pendentes ou interrompidos e situação das contas.
2. Quais são os 16 contratos com término previsto em até 90 dias, totalizando R$ 6.123.645,63, e quais têm plano de renovação, nova licitação ou transição?
3. Qual o plano de continuidade para o contrato SIGA 2023010803, de R$ 932.932,80, com término informado em 20/12/2026?
4. Qual o plano de continuidade do custeio do sistema COMPREV, contrato SIGA 2021007677, de R$ 720.000,00, com término informado em 31/12/2026?
5. Qual o status e o plano de contratação para os serviços administrativos do contrato SIGA 2022009117, de R$ 379.980,00, com término informado em 12/12/2026?
6. Como será mantido o link de dados e a conexão à internet após o término informado em 28/12/2026 do contrato SIGA 2021007413, de R$ 178.596,00?
7. Como se compõe o total acumulado de R$ 4.794.114,92 em valores liquidados e não pagos, e quais registros o compõem?
8. Qual a memória de cálculo do déficit previsto de R$ 14 bilhões para 2027 e qual o estágio da revisão orçamentária? [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml)
9. Quais imóveis estaduais seriam transferidos à futura pasta, qual o cronograma e quais estimativas de receitas e custos foram elaboradas? [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml)

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEPLAG | Secretaria de Estado de Planejamento e Gestão | 111 | R$ 199,0 mi | 16 | R$ 6,1 mi | 0 | Risco de pressão fiscal em 2027, diante da previsão divulgada de déficit de R$ 14 bilhões… | Obter relatório de transição e validar plano fiscal e continuidade dos contratos. |

## Fontes da pesquisa
1. [Transição de governo no RJ: o que acontece agora   G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/15/transicao-de-governo-no-rj-veja-quem-participa-prazos-e-proximos-passos.ghtml) — 2026-10-15
2. [Ricardo Couto oficializa transição para gestão de Douglas ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/14/governo-do-rj-inicia-transicao-para-gestao-2027.ghtml) — 2026-10-14
3. [Douglas Ruas anuncia primeiros secretários e prepara revisão do ...](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml) — 2026-11-03
4. [Ricardo Couto oficializa criação da Comissão de Transição para futura gestão de Douglas Ruas no RJ](https://cbn.globo.com/politica/noticia/2026/10/14/ricardo-couto-oficializa-criacao-da-comissao-de-transicao-para-futura-gestao-de-douglas-ruas-no-rj.ghtml) — 2026-10-14
5. [Douglas Ruas anuncia intenção de criar teto de gastos para o governo estadual](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos) — 2026-11-04

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
