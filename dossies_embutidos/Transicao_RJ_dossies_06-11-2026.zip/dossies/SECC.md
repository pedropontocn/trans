# Dossiê reduzido — Secretaria de Estado da Casa Civil (SECC)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SECC.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SECC_pesquisa.md`.

## 1. Missão e competências
- Coordenar a comissão de transição para a gestão estadual que assume em 01/01/2027.
- Conduzir, em conjunto com a CGE, a revisão de contratos estaduais.
- Realizar auditorias, como a do Programa Empoderadas, conforme descrito na pesquisa.

## 2. Estrutura essencial
- Titular: Flávio de Araújo Willeman, citado como secretário e presidente da comissão de transição.
- Unidades informadas: DETRAN - Departamento de Trânsito do Estado do RJ; SECC - Secretaria de Estado da Casa Civil; SSCS - Subsecretaria de Comunicação Social.

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 213 contratos, R$ 1,38 bi (+9 'Ativo' sem data de fim válida, R$ 0,3 mi) |
| Vencem em até 30 dias | 12 contratos, R$ 93,9 mi |
| Vencem em até 90 dias | 102 contratos, R$ 447,1 mi (5 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 126 contratos, R$ 491,1 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 111,9 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2021007521 | EMPLACA COMÉRCIO DE PLACAS E SERVIÇOS DE EMP… | Contratação ,via certame licitatório, de empresa especializ… | R$ 73.099.084,52 | 12/12/2026 |
| 2020005634 | INSTITUTO BRASILEIRO DE ADMINISTRAÇÃO PUBLIC… | Prestação de serviços de apoio administrativo, com vistas a… | R$ 54.282.568,44 | 07/12/2026 |
| 2022000020 | M.I. MONTREAL INFORMÁTICA S/A | SERVIÇO DE CERTIFICAÇÃO AUTOMATIZADA DE IDENTIFICAÇÃO DE PE… | R$ 46.456.324,68 | 31/01/2027 |
| 2020005968 | CIX CITIZEN EXPERIENCE S/A | Contratação de empresa especializada para prestação de serv… | R$ 35.026.223,03 | 27/12/2026 |
| 2024009164 | AGILE COMUNICAÇÃO LTDA | Contratação de empresa prestadora de serviços de comunicaçã… | R$ 30.406.950,00 | 21/11/2026 (PNCP) |
| 2024010613 | SOFTWARE AG BRASIL INFORMATICA E SERVIÇOS LT… | Contratação de serviços especializados de licenciamento de … | R$ 26.473.180,64 | 27/12/2026 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 177 (R$ 686,6 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 2 (R$ 25,8 mi) | 0 | Alerta |
| Vencimentos até 90 dias | 102 (R$ 447,1 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 1 (R$ 0,0 mi) | 0 | Alerta |
| Fornecedores em recuperação judicial | 1 | 0 | Alerta |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2025004440 | EMPRESA BRASILEIRA DE CORREIOS E TELÉGRAFOS | R$ 107.471.520,00 | 18/06/2026 |
| 2019007072 | FXX SEGURANCA E TRANSPORTE DE VALORES LTDA | R$ 54.811.926,25 | 19/12/2025 |
| 2025002218 | RAH COMÉRCIO E SERVIÇOS EDUCACIONAIS LTDA | R$ 35.994.769,80 | 04/04/2026 |

## 5. Alertas vermelhos
- 12 contrato(s) vencem em até 30 dias (R$ 93,9 mi).
- 2 contrato(s) com Termo de Rescisão crível no PNCP (publicado perto do fim, sem aditivo posterior) seguem 'Ativo' no SIGA: 2025010736 FXX SEGURANCA E TRANSPORTE DE VALORES L… (R$ 24,8 mi); 2025009178 ACADEMIA BRASILEIRA DE LETRAS (R$ 1,0 mi). Confirmar substituição do serviço.
- 1 contrato(s) com data de fim impossível no SIGA (R$ 0,0 mi): 2012009912 NOVACASA AMBIENTE & DECORAÇÃO LTDA (fim 13/12/2102). Corrigir o cadastro e confirmar a vigência real no processo SEI.
- 1 contrato(s) com fornecedor em recuperação judicial.
- A revisão anunciada abrange 6.754 contratos estaduais acima de R$ 1 milhão, mas não há balanço dos resultados nem discriminação dos contratos da SECC. [Choque de transparência](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)
- Foi noticiado contrato de agenciamento de viagens estimado em R$ 825 milhões, sem identificação de empresa, número, vigência ou resultado de auditoria. [Choque de transparência](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)
- Auditoria apontou cerca de R$ 4,45 milhões em despesas questionadas no Empoderadas; a equipe do programa e a Uerj contestaram os achados. [Auditoria do Empoderadas](https://www.folhape.com.br/noticias/auditoria-aponta-irregularidades-de-r-45-milhoes-em-programa-do/506496/) [Contestação do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/14/empoderadas-contesta-auditoria-do-governo-rj.ghtml)
- Denúncia ao TCE-RJ relata descontos consignados sem autorização ou mantidos após quitação ou cancelamento; as alegações não são conclusões comprovadas pelas fontes. [Denúncia sobre consignações](https://www.tribunanf.com.br/blogdoralfereis/wp-content/uploads/sites/11/2026/05/Denuncia-TCE-RJ-Banco-Master-contracheque-servidores.pdf)

## 6. Riscos prioritários
- Concentração de vencimentos: 12 contratos, no valor de R$ 93.942.628,42, constam na faixa de 30 dias; 102, no valor de R$ 447.149.752,98, na faixa de 90 dias. Confirmar renovações e planos para manter os serviços.
- O contrato SIGA 2021007521, de R$ 73.099.084,52, tem fim informado em 12/12/2026; o SIGA 2020005634, de R$ 54.282.568,44, em 07/12/2026. Verificar situação, saldo e continuidade na transição.
- A contratação emergencial de vigilância 2025010736, de R$ 24.806.748,42, tem fim informado em 20/06/2026, data já passada em relação ao dossiê. Confirmar vigência atual e cobertura do serviço.
- O resultado da revisão de contratos estaduais não foi divulgado nas fontes, e o contrato de viagens estimado em R$ 825 milhões carece de identificação e dados de execução. [Choque de transparência](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)
- A denúncia relata reclamações sobre descontos supostamente não autorizados e falhas em averbações. A fonte informa o bloqueio de novas operações e outras medidas administrativas e judiciais, mas não apresenta decisão final sobre a denúncia no TCE/RJ nem sobre cada ocorrência individual. [Denúncia sobre consignações](https://www.tribunanf.com.br/blogdoralfereis/wp-content/uploads/sites/11/2026/05/Denuncia-TCE-RJ-Banco-Master-contracheque-servidores.pdf)
- O Empoderadas foi informado como suspenso, com achados de auditoria contestados; as fontes não esclarecem retomada, contingência para beneficiárias ou resultado de apurações externas. [Auditoria do Empoderadas](https://www.folhape.com.br/noticias/auditoria-aponta-irregularidades-de-r-45-milhoes-em-programa-do/506496/) [Contestação do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/14/empoderadas-contesta-auditoria-do-governo-rj.ghtml)

## 7. Perguntas-chave para IA externa
1. Os relatórios de transição previstos para 30/10/2026 foram entregues? Quais pendências, projetos interrompidos e decisões dos primeiros 100 dias foram registrados?
2. Qual foi o resultado da revisão de contratos conduzida com a CGE? Quais contratos da SECC foram analisados e quais recomendações ou riscos de continuidade foram identificados?
3. Qual é o número, fornecedor, vigência, saldo, pagamentos e situação de auditoria do contrato de agenciamento de viagens estimado em R$ 825 milhões?
4. Dos 12 contratos no valor de R$ 93.942.628,42 com vencimento na faixa de 30 dias, quais serão renovados, substituídos ou encerrados? E qual o plano para os 102 contratos na faixa de 90 dias, que somam R$ 447.149.752,98?
5. Qual é a situação atual do SIGA 2021007521, de R$ 73.099.084,52, com fim informado em 12/12/2026, incluindo saldo, pagamentos, aditivos e plano de continuidade?
6. Qual é a situação do SIGA 2020005634, de R$ 54.282.568,44, com fim informado em 07/12/2026, e do SIGA 2022000020, de R$ 46.456.324,68, com fim informado em 31/01/2027?
7. A contratação emergencial 2025010736, de R$ 24.806.748,42, cujo fim informado é 20/06/2026, permanece vigente? Qual instrumento garante a continuidade da vigilância patrimonial?
8. Qual é a situação dos processos SEI-150001/001645/2025, SEI-150001/015550/2025 e SEI-150001/001069/2026, do Termo de Credenciamento SECC nº 26/2025 e da denúncia TCE-RJ nº 100.713-0/2026?
9. Qual é o estado da suspensão do Empoderadas, qual a resposta formal à auditoria e houve encaminhamento comprovado ao MPRJ, MPT e TCE-RJ?
10. Como se compõe o valor de R$ 111.868.857,44 informado como a pagar, e há pagamentos em atraso, passivos ou riscos para serviços essenciais?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SECC | Secretaria de Estado da Casa Civil | 213 | R$ 1,38 bi | 102 | R$ 447,1 mi | 2 | Risco potencial de descontinuidade de serviços associado a vencimentos contratuais próxim… | Confirmar vencimentos, vigências e planos de continuidade dos contratos críticos. |

## Fontes da pesquisa
1. [ACÓRDÃO Nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026) — 2026-07-06
2. [ PDF  PROCESSO: TCE-RJ Nº 100.713-0/2026 UNIDADE: SECRETARIA ...](https://www.tribunanf.com.br/blogdoralfereis/wp-content/uploads/sites/11/2026/05/Denuncia-TCE-RJ-Banco-Master-contracheque-servidores.pdf) — 2026-10-06
3. [Auditoria aponta irregularidades de R$ 4,5 milhões em programa do governo do Rio](https://www.folhape.com.br/noticias/auditoria-aponta-irregularidades-de-r-45-milhoes-em-programa-do/506496/) — 2026-08-13
4. [Choque de transparência no RJ prevê análise de 6,7 mil contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml) — 2026-04-16
5. [g1.globo.com › rj › rio-de-janeiroPrograma Empoderadas contesta auditoria do RJ; 14 são ... - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/14/empoderadas-contesta-auditoria-do-governo-rj.ghtml) — 2026-08-14
6. [Ricardo Couto oficializa transição para gestão de Douglas ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/14/governo-do-rj-inicia-transicao-para-gestao-2027.ghtml) — 2026-10-14

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
