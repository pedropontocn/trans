# Secretarias (sigla e nome)

Só os nomes, para ligar cada pesquisa à secretaria. Sem dados do SIGA/PNCP.

| Sigla | Secretaria |
|---|---|
| SES | Secretaria de Estado de Saúde |
| SEEDUC | Secretaria de Estado de Educação |
| SECID | Secretaria de Estado das Cidades |
| SECC | Secretaria de Estado da Casa Civil |
| SECTI | Secretaria de Estado de Ciência, Tecnologia e Inovação |
| SEPM | Secretaria de Estado de Polícia Militar |
| SEAPA | Secretaria de Estado de Agricultura, Pecuária, Abastecimento e Pesca |
| SEAS | Secretaria de Estado do Ambiente e Sustentabilidade |
| SETRAM | Secretaria de Estado de Transporte e Mobilidade Urbana |
| SEPOL | Secretaria de Estado de Polícia Civil |
| SEGOV | Secretaria de Estado de Governo |
| SEDEC | Secretaria de Estado de Defesa Civil |
| SETD | Secretaria de Estado de Transformação Digital |
| SEHIS | Secretaria de Estado de Habitação de Interesse Social |
| SEFAZ | Secretaria de Estado de Fazenda |
| SEDSODH | Secretaria de Estado de Desenvolvimento Social e Direitos Humanos |
| SEAP | Secretaria de Estado de Administração Penitenciária |
| SECEC | Secretaria de Estado de Cultura e Economia Criativa |
| SEDCON | Secretaria de Estado de Defesa do Consumidor |
| SEDEICS | Secretaria de Estado de Desenvolvimento Econômico, Indústria, Comércio e Serviços |
| SEIOP | Secretaria de Estado de Infraestrutura e Obras Públicas |
| SEENEMAR | Secretaria de Estado de Energia e Economia do Mar |
| SEPLAG | Secretaria de Estado de Planejamento e Gestão |
| SETRAB | Secretaria de Estado de Trabalho e Renda |
| SEGG | Secretaria de Estado do Gabinete do Governador |
| SEM | Secretaria de Estado da Mulher |
| SESP | Secretaria de Estado de Segurança Pública |
| SEEL | Secretaria de Estado de Esporte e Lazer |
| SEDIPAF | Secretaria de Estado de Desenvolvimento Regional do Interior, Pesca e Agricultura Familiar |
| SETUR | Secretaria de Estado de Turismo |
| SEIJES | Secretaria de Estado Internacional de Juventude e Envelhecimento Saudável |
