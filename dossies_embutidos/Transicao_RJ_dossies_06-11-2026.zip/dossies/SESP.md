# Dossiê reduzido — Secretaria de Estado de Segurança Pública (SESP)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SESP.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SESP_pesquisa.md`.

## Resumo executivo
- A Secretaria de Estado de Segurança Pública é apresentada como protagonista do planejamento estadual de reocupação territorial, com a Grande Jacarepaguá indicada como área-piloto; o plano prevê articulação entre segurança, justiça, políticas sociais e infraestrutura. [Ofício GPGJ nº 0610](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/Oficio_GPGJ_0610.pdf)
- Há uma pendência de acompanhamento: ofício da ENASP, de 07 de novembro de 2025, solicita regulamentação conjunta com a SESP sobre comunicação de ocorrências, mas as fontes não informam se a regulamentação foi editada. [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf)
- Em 28 de outubro de 2026, as investigações das mortes de 117 pessoas na Operação Contenção continuavam em andamento; segundo a Secretaria, haviam sido concluídas até então somente as investigações dos cinco policiais mortos. [Diário do Grande ABC — Operação Contenção](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao)
- O governador eleito confirmou que manterá uma Secretaria de Segurança e adotará comando unificado das polícias Civil e Militar, mas os nomes dos responsáveis ainda não haviam sido anunciados em 3 de novembro de 2026. [G1 — Secretariado de Douglas Ruas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml)

## 1. Missão e competências
- Articular o planejamento estadual de segurança e reocupação territorial com políticas de justiça, sociais e de infraestrutura, incluindo a área-piloto da Grande Jacarepaguá. [Ofício GPGJ nº 0610](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/Oficio_GPGJ_0610.pdf)
- Participar da discussão promovida pela SESP sobre a regulamentação da política de câmeras corporais e de reunião para alinhar melhorias no fluxo de comunicação de operações policiais ao MPRJ. O CNMP solicitou atualização sobre encaminhamentos relativos à regulamentação conjunta da comunicação de ocorrências, sem informar que ela foi concluída. [MPRJ — Reunião sobre câmeras corporais](https://www.mprj.mp.br/visualizar?noticiaId=243402) [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf)
- Acompanhar, por meio do GAESP, a implementação do Programa de Assistência à Saúde Mental para as Polícias Civil e Militar, regulamentado pela resolução conjunta citada na pesquisa. [Ofício GPGJ nº 0610](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/Oficio_GPGJ_0610.pdf)

## 2. Estrutura essencial
- Titular: a confirmar
- FISED - FUNDO EST INVEST AÇÕES SEG PUB DES SOC
- RIO SEGURANÇA - Instituto de Segurança Pública - ISP
- SESEG - SECRETARIA DE ESTADO DE SEGURANÇA
- SESP - SECRETARIA DE ESTADO DE SEGURANCA PUBLICA

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 35 contratos, R$ 85,0 mi (+8 'Ativo' sem data de fim válida, R$ 1,7 mi) |
| Vencem em até 30 dias | 1 contratos, R$ 0,0 mi |
| Vencem em até 90 dias | 13 contratos, R$ 1,7 mi (1 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 17 contratos, R$ 2,4 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 0,3 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2026007424 | CENTRO DE ESTUDOS E PESQUISA E DESENVOLVIMEN… | O objeto do processo é a contratação de serviço de consulto… | R$ 556.437,60 | 08/01/2027 (PNCP) |
| 2025011013 | ZOOM TECNOLOGIA LTDA | Aquisição de Servidores (Equipamentos de TIC) para atender … | R$ 421.752,41 | 30/12/2026 |
| 2025009741 | MICRO BIT INFORMATICA LTDA | Aquisição de equipamentos de informática, desntre os quais … | R$ 195.000,00 | 11/12/2026 |
| 2026008274 | INSPER INSTITUTO DE ENSINO E PESQUISA | O objeto do processo é a contratação de instituição especia… | R$ 185.000,00 | 16/01/2027 |
| 2025008353 | TAVELO COMÉRCIO E DISTRIBUIDORA LTDA | Fornecimento, instalação e comissionamento de sistema de ar… | R$ 79.338,00 | 26/12/2026 |
| 2026008432 | LIRA REFORMAS E CONSTRUÇÃO LTDA | contratação de empresa especializada para instalação de 07 … | R$ 51.275,35 | 08/01/2027 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 36 (R$ 12,4 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 13 (R$ 1,7 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2024008794 | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES LTDA | R$ 4.535.040,00 | 04/11/2025 |
| 2024005649 | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | R$ 2.301.535,00 | 04/08/2025 |
| 2025004568 | PBC ADMINISTRADORA DE BENS S/A | R$ 1.320.000,00 | 26/06/2026 |

## 5. Alertas vermelhos
- 1 contrato(s) vencem em até 30 dias (R$ 0,0 mi).
- Em 28/10/2026, as investigações das mortes de 117 pessoas na Operação Contenção continuavam em andamento; haviam sido concluídas as investigações dos cinco policiais mortos. [Diário do Grande ABC — Operação Contenção](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao)
- A ENASP solicitou ao MPRJ, até 15 de janeiro de 2026, uma atualização sobre os encaminhamentos relativos à decisão na ADPF 635, que prevê regulamentação conjunta para a comunicação imediata de ocorrências de letalidade e vitimização policiais. O ofício não informa se houve resposta ao pedido de atualização nem se a medida foi implementada. [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf)
- A política de câmeras corporais estava em discussão; as fontes não confirmam cronograma, contratos ou situação atual de implantação. [MPRJ — Reunião sobre câmeras corporais](https://www.mprj.mp.br/visualizar?noticiaId=243402)

## 6. Riscos prioritários
- Continuidade contratual: as estatísticas registram 1 contrato na faixa de 30 dias (R$ 32.264,44), 13 na faixa de 90 dias (R$ 1.702.502,36) e 17 na faixa de 180 dias (R$ 2.391.462,16); validar vencimentos e planos de continuidade.
- Verificar liquidação, vencimento e cronograma dos R$ 281.487,54 registrados como valores a pagar, sem presumir que estejam em atraso.
- Risco jurídico e de controle relacionado às investigações ainda abertas da Operação Contenção. [Diário do Grande ABC — Operação Contenção](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao)
- O [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf) solicita ao MPRJ atualização, até 15 de janeiro de 2026, sobre os encaminhamentos relativos à ADPF 635 e relaciona, entre as medidas previstas na decisão do STF, regulamentações conjuntas com a Secretaria de Segurança Pública do Rio de Janeiro sobre a comunicação imediata de ocorrências ao Ministério Público.
- Há indícios de lacunas na cobertura e na operação das câmeras corporais: na Polícia Civil, o uso está restrito à CORE e a poucos equipamentos, enquanto o ofício aponta limitações operacionais nas COPs e providências ainda em acompanhamento. Na saúde mental, embora a Resolução Conjunta nº 18/2026 preveja serviço permanente e contínuo, a execução do programa segue sob acompanhamento, e o ofício registra insuficiências na estrutura de atendimento. Assim, as fontes indicam medidas e normas, mas não confirmam a cobertura efetiva das câmeras nem a implementação contínua e suficiente do atendimento de saúde mental. [MPRJ — Reunião sobre câmeras corporais](https://www.mprj.mp.br/visualizar?noticiaId=243402) [Ofício GPGJ nº 0610](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/Oficio_GPGJ_0610.pdf)
- A transição pode começar sem responsáveis anunciados para a área de segurança; a notícia de 03/11/2026 informa que os nomes ainda seriam divulgados. [G1 — Secretariado de Douglas Ruas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml)

## 7. Perguntas-chave para IA externa
1. Quais contratos compõem as faixas de 30, 90 e 180 dias, com datas de término, objeto, unidade responsável, aditivos e plano para evitar descontinuidade?
2. Qual é a situação de execução, aceite, pagamento e continuidade do contrato SIGA 2026007424, de R$ 556.437,60, para consultoria técnica especializada?
3. O contrato SIGA 2025011013, de R$ 421.752,41, para aquisição de servidores, já foi entregue e está operacional? Há garantia, suporte ou etapa pendente?
4. Qual é a situação de entrega e aceite do contrato SIGA 2025009741, de R$ 195.000,00, para equipamentos de informática?
5. Qual é o escopo, cronograma, entregável e situação de pagamento do contrato SIGA 2026008274, de R$ 185.000,00, com o INSPER?
6. Os contratos SIGA 2025008353, de R$ 79.338,00, e 2026008432, de R$ 51.275,35, foram instalados, comissionados e recebidos? Há pendências que afetem unidades?
7. A que obrigações correspondem os R$ 281.487,54 a pagar, quais são os vencimentos e há valores pendentes de liquidação ou contestados?
8. Foi editada a regulamentação conjunta solicitada pela ENASP em 2025? Se sim, qual ato, fluxo de comunicação, responsáveis e data de início? [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf)
9. Qual é o status das investigações das 117 mortes da Operação Contenção e como a Polícia Civil e o MPRJ acompanham o caso? [Diário do Grande ABC — Operação Contenção](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao)
10. Qual é o estágio de implantação da política de câmeras corporais e do Pro-Saúde Mental, com cobertura, responsáveis, necessidades de contratação e plano de continuidade? [MPRJ — Reunião sobre câmeras corporais](https://www.mprj.mp.br/visualizar?noticiaId=243402) [Ofício GPGJ nº 0610](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/Oficio_GPGJ_0610.pdf)

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SESP | Secretaria de Estado de Segurança Pública | 35 | R$ 85,0 mi | 13 | R$ 1,7 mi | 0 | Risco a monitorar na transição: há contratos próximos do vencimento. As fontes consultada… | Validar vencimentos, pagamentos e responsáveis pelos serviços críticos nos primeiros dias. |

## Fontes da pesquisa
1. [ PDF  OFÍCIO - Conselho Nacional do Ministério Público](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/Oficio_GPGJ_0610.pdf) — 2026-09-15
2. [GAESP/MPRJ discute acesso direto a dados da Polícia Civil, comunicação de operações policiais e regras para câ](https://www.mprj.mp.br/visualizar?noticiaId=243402) — 2026-11-05
3. [ONG internacional aponta falhas na investigação da Operação Contenção - Diário do Grande ABC](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao) — 2026-11-05
4. [OFÍCIO n° 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf) — 2026-09-18
5. [Douglas Ruas apresenta primeiros nomes do secretariado no ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml) — 2026-11-03

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
