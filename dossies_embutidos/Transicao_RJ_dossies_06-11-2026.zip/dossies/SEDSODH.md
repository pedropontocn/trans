# Dossiê reduzido — Secretaria de Estado de Desenvolvimento Social e Direitos Humanos (SEDSODH)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEDSODH.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEDSODH_pesquisa.md`.

## Resumo executivo
- As fontes apontam dois temas prioritários para a SEDSODH: falhas em contratações emergenciais de alimentação para o Abrigo Cristo Redentor e instabilidade financeira e operacional do Programa Rio Sem LGBTIfobia. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/) [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao)
- O TCE-RJ multou três ex-gestores por irregularidades ligadas à contratação de alimentação, que incluíram sucessivas dispensas emergenciais por mais de 15 meses. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- No Rio Sem LGBTIfobia, trabalhadores denunciaram atrasos salariais e risco de interrupção dos serviços; o governo anunciou a regularização dos pagamentos e houve publicação de uma liberação orçamentária, mas as fontes não confirmam que os valores tenham sido efetivamente pagos. [Trabalhadores protestam por salários](https://oglobo.globo.com/rio/noticia/2026/07/02/sem-salarios-trabalhadores-do-rio-sem-lgbtfobia-protestam-no-centro.ghtml) [Governo promete pagar atrasados](https://www.poder360.com.br/poder-gente/governo-do-rj-promete-pagar-atrasados-do-programa-rio-sem-lgbtifobia/) [Assembleia e liberação de recursos](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html)
- A Secretaria informou que o modelo de contratação e gestão do programa está em revisão com a PGE, enquanto trabalhadores cobravam definições sobre sua continuidade e forma de execução. [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao) [Assembleia e liberação de recursos](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html)

## 1. Missão e competências
- Atuação em desenvolvimento social e direitos humanos, conforme a denominação da Secretaria.
- Execução, em parceria com a UERJ, do Programa Rio Sem LGBTIfobia, com acolhimento, orientação jurídica, atendimento psicossocial e encaminhamentos.
- Atendimento social a idosos no Centro de Promoção Social Abrigo Cristo Redentor, incluindo serviços de alimentação.

## 2. Estrutura essencial
- Titular: a confirmar
- FIA - FUNDAÇÃO PARA A INFÂNCIA E ADOLESCÊNCIA
- FLXIII - FUNDAÇÃO LEÃO XIII
- SEASDH - SECRETARIA DE ESTAD ASSIST SOC E DIR HUMANOS
- SEDHMI - SEC EST DIR HUM E POL PARA MUL E IDOSOS
- SEDSODH - SEC ESTADO DESEN SOCIAL E DE DIR HUM
- SEPREDEQ - SEC EST DE PREVENÇÃO A DEP QUÍMICA

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 121 contratos, R$ 227,3 mi (+1 'Ativo' sem data de fim válida, R$ 0,1 mi) |
| Vencem em até 30 dias | 12 contratos, R$ 19,3 mi |
| Vencem em até 90 dias | 32 contratos, R$ 35,2 mi (13 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 62 contratos, R$ 65,8 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 10,7 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2023010267 | CONTROL 361 TECNOLOGIA E SERVICOS LTDA | contratação de serviços terceiriados de instalação e operaç… | R$ 7.555.200,00 | 15/12/2026 |
| 2024009602 | A.C.F. DA SILVA LTDA | Contratação de empresa especializada na prestação de serviç… | R$ 6.828.287,50 | 27/11/2026 (PNCP) |
| 2024009601 | LOCASEM SERVIÇOS DE LIMPEZA, MANUTENÇÃO E AL… | Contratação de empresa especializada na prestação de serviç… | R$ 4.928.880,00 | 27/11/2026 (PNCP) |
| 2025008481 | NUTRIVITA ALIMENTAÇÃO E SERVIÇOS LTDA | Contratação de empresa especializada na prestação do serviç… | R$ 2.679.600,00 | 01/12/2026 (PNCP) |
| 2025010967 | TD DANTAS SOLUÇÕES LTDA | Tem por objeto a contratação, por meio de Adesão à Ata de R… | R$ 2.373.005,00 | 09/01/2027 (PNCP) |
| 2025010964 | TD DANTAS SOLUÇÕES LTDA | Tem por objeto a contratação, por meio de Adesão à Ata de R… | R$ 2.146.640,00 | 09/01/2027 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 81 (R$ 42,4 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 32 (R$ 35,2 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2025006907 | SANTA COMBA SERVICOS LTDA | R$ 13.859.780,00 | 03/10/2026 |
| 2024006492 | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | R$ 2.646.822,00 | 18/08/2025 |
| 2023009107 | CONQUISTA VIGILANCIA E SEGURANCA PATRIMONIAL LTDA | R$ 2.584.435,20 | 30/10/2025 |

## 5. Alertas vermelhos
- 12 contrato(s) vencem em até 30 dias (R$ 19,3 mi).
- TCE-RJ apontou dispensas sucessivas por mais de 15 meses e falhas na contratação de alimentação do Abrigo Cristo Redentor. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- Trabalhadores do Rio Sem LGBTIfobia relataram atrasos salariais e risco de paralisação dos atendimentos. [Trabalhadores protestam por salários](https://oglobo.globo.com/rio/noticia/2026/07/02/sem-salarios-trabalhadores-do-rio-sem-lgbtfobia-protestam-no-centro.ghtml)
- A liberação de R$ 3,35 milhões à UERJ tinha previsão de pagamento até 08/07/2026, mas as fontes não confirmam a quitação. [Assembleia e liberação de recursos](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html)
- A revisão do modelo de gestão do Rio Sem LGBTIfobia não tinha decisão final divulgada. [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao)

## 6. Riscos prioritários
- Continuidade do Rio Sem LGBTIfobia exposta a atrasos salariais, risco de paralisação e indefinição do modelo de gestão. [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao)
- Risco de repetição de contratações emergenciais e falhas de planejamento na alimentação do Abrigo Cristo Redentor, com decisão sancionatória do TCE-RJ. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- Confirmar a situação dos contratos SIGA/PNCP com término informado em 2026: 2024009602 (R$ 6.828.287,50; 27/11/2026), 2024009601 (R$ 4.928.880,00; 27/11/2026), 2025008481 (R$ 2.679.600,00; 01/12/2026) e 2023010267 (R$ 7.555.200,00; 15/12/2026), incluindo prorrogação, substituição ou encerramento.
- A contratação 2025010967 (R$ 2.373.005,00) e a 2025010964 (R$ 2.146.640,00), ambas com término informado em 09/01/2027, exigem confirmação de cobertura e providências para a transição.
- O montante estatístico a pagar é de R$ 10.717.512,03; a transição deve identificar credores, vencimentos, liquidações e eventual relação com os pagamentos do Rio Sem LGBTIfobia.

## 7. Perguntas-chave para IA externa
1. Qual é a situação atual do Contrato nº 18/2023 do Abrigo Cristo Redentor: empresa contratada, valor, vigência, pagamentos, aditivos e eventual licitação substituta?
2. Quais medidas foram adotadas após a decisão do TCE-RJ sobre o Contrato nº 18/2023, e as multas foram recolhidas ou encaminhadas para protesto ou dívida ativa? [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
3. Os salários atrasados do Rio Sem LGBTIfobia foram pagos? Como foram aplicados os R$ 3,35 milhões descentralizados à UERJ e que obrigações permanecem pendentes? [Assembleia e liberação de recursos](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html)
4. Qual foi a decisão final sobre o modelo de gestão do Rio Sem LGBTIfobia, e qual é o plano de continuidade dos 24 equipamentos?
5. Qual é a situação do contrato 2023010267, no valor de R$ 7.555.200,00, com término informado em 15/12/2026: foi encerrado, prorrogado ou substituído?
6. Qual é a situação dos contratos 2024009602 (R$ 6.828.287,50), 2024009601 (R$ 4.928.880,00) e 2025008481 (R$ 2.679.600,00), todos com término informado entre novembro e dezembro de 2026?
7. Há cobertura contratual e recursos para os serviços das contratações 2025010967 (R$ 2.373.005,00) e 2025010964 (R$ 2.146.640,00), com término informado em 09/01/2027?
8. Quais itens compõem os R$ 10.717.512,03 registrados como a pagar, e quais valores estão liquidados, vencidos ou sujeitos a disputa?
9. Qual é o status do contrato 2025006907, de R$ 13.859.780,00, descrito como emergencial para acolhimento institucional, com término informado em 03/10/2026?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEDSODH | Secretaria de Estado de Desenvolvimento Social e Direitos Humanos | 121 | R$ 227,3 mi | 32 | R$ 35,2 mi | 0 | Descontinuidade de serviços por pendências financeiras e contratos sem situação confirmad… | Validar pagamentos, vigências e planos de continuidade antes da posse. |

## Fontes da pesquisa
1. [‘Emergência fabricada’: ex-gestores da Assistência Social são multados pelo TCE-RJ por falhas em contrato de a](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/) — 2026-08-15
2. [Rio Sem LGBTIfobia: modelo de contrato e gestão está em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao) — 2026-07-02
3. [Governo do RJ promete pagar atrasados do programa Rio Sem LGBTIfobia](https://www.poder360.com.br/poder-gente/governo-do-rj-promete-pagar-atrasados-do-programa-rio-sem-lgbtifobia/) — 2026-07-11
4. [Sem salários, trabalhadores do Rio Sem LGBTfobia ...](https://oglobo.globo.com/rio/noticia/2026/07/02/sem-salarios-trabalhadores-do-rio-sem-lgbtfobia-protestam-no-centro.ghtml) — 2026-07-02
5. [Rio Sem LGBTIfobia: Trabalhadores marcam assembleia para avaliar greve  Rio de Janeiro](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html) — 2026-07-03

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
