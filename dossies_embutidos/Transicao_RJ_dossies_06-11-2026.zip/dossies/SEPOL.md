# Dossiê reduzido — Secretaria de Estado de Polícia Civil (SEPOL)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEPOL.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEPOL_pesquisa.md`.

## Resumo executivo
- A SEPOL abriu processo sancionador contra a FXX Segurança e Transporte de Valores para apurar indícios de atrasos salariais e de benefícios e falhas na cobertura de postos de vigilância, que podem comprometer a continuidade do serviço. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- A SEPOL também firmou contrato de R$ 6,36 milhões para comprar 60 viaturas descaracterizadas, com vigência de 12 meses. O contrato foi assinado em 27/10/2026; as fontes não informam o andamento da entrega. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- As fontes relatam operações contra extorsão e organizações criminosas, incluindo investigação de policiais civis suspeitos de extorquir comerciantes; essas informações são investigações e acusações, não conclusões judiciais. [Agentes suspeitos de extorsão](https://record.r7.com/balanco-geral-rj/video/agentes-usavam-a-estrutura-da-policia-para-extorquir-donos-de-ferros-velhos-no-rj-diz-mp-04092026/) [Operação Dominus](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/policia-civil-e-mprj-deflagram-a-operacao-dominus.ghtml)
- O governador eleito anunciou a intenção de reunir os comandos das polícias Civil e Militar sob uma Secretaria de Segurança Pública; a fonte informa que a transição transcorria com êxito, mas não detalha plano, cronograma ou impactos para a SEPOL. [Anúncio sobre a Secretaria de Segurança](https://www.cnnbrasil.com.br/blogs/cleber-rodrigues/nacional/sudeste/rj/douglas-ruas-vai-unir-policias-militar-e-civil-em-mesma-pasta-no-rj/)

## 1. Missão e competências
- Investigar crimes e conduzir operações policiais, conforme as ações atribuídas à Polícia Civil no texto.
- Atuar no enfrentamento a organizações criminosas e extorsões, conforme as operações mencionadas.
- Proteger unidades policiais por meio de serviços de vigilância patrimonial armada.

## 2. Estrutura essencial
- Titular: a confirmar
- PCERJ - POLÍCIA CIVIL DO ESTADO DO RIO DE JANEIRO
- SEPOL - Secretaria de Estado de Policia Civil

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 176 contratos, R$ 350,9 mi (+8 'Ativo' sem data de fim válida, R$ 2,8 mi) |
| Vencem em até 30 dias | 12 contratos, R$ 22,1 mi |
| Vencem em até 90 dias | 33 contratos, R$ 84,9 mi (19 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 50 contratos, R$ 135,1 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 2,8 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2025009743 | HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS… | Aquisição de SUV através de Consumo de ARP | R$ 19.187.500,00 | 09/12/2026 (PNCP) |
| 2025010652 | HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS… | AQUISIÇÃO DE VIATURAS - SUVs por meio de Consumo de Ata SRP… | R$ 12.024.166,67 | 26/12/2026 (PNCP) |
| 2025010897 | HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS… | Aquisição de SUV através de consumo da ARP 004/2025 | R$ 8.698.333,33 | 09/01/2027 (PNCP) |
| 2026003781 | 2R DATATEL TELEINFORMÁTICA LTDA | Participação na Ata de Registro de Preços nº 007/2024 do PR… | R$ 6.360.396,00 | 18/11/2026 (PNCP) |
| 2025008585 | NRTT - SOLUCOES E SERVICOS LTDA | O presente Termo de Referência tem por objetivo descrever a… | R$ 5.828.899,00 | 14/11/2026 (PNCP) |
| 2025008397 | GENERAL MOTORS DO BRASIL LTDA. | Participação na Ata de Registro de Preços nº 17/2025 da Sec… | R$ 5.455.500,00 | 14/11/2026 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 111 (R$ 86,8 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 33 (R$ 84,9 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2025002229 | 2R DATATEL TELEINFORMÁTICA LTDA | R$ 12.435.000,00 | 12/05/2026 |
| 2025008320 | LECARD ADMNISTRADORA DE CARTÕES LTDA | R$ 7.264.400,00 | 05/11/2026 |
| 2022001444 | CLARO S/A (FILIAL) | R$ 5.653.908,00 | 10/03/2025 |

## 5. Alertas vermelhos
- 12 contrato(s) vencem em até 30 dias (R$ 22,1 mi).
- A SEPOL apura possíveis atrasos de salários e benefícios e falhas na cobertura de postos de vigilância da FXX, com possível impacto na continuidade do serviço. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- O processo sancionador contra a FXX estava em fase de defesa; a fonte não informa decisão final nem regularização dos pagamentos ou postos. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- O governador eleito anunciou a intenção de reunir os comandos das polícias Civil e Militar sob uma Secretaria de Segurança; não há plano de implementação descrito. [Anúncio sobre a Secretaria de Segurança](https://www.cnnbrasil.com.br/blogs/cleber-rodrigues/nacional/sudeste/rj/douglas-ruas-vai-unir-policias-militar-e-civil-em-mesma-pasta-no-rj/)
- A pesquisa relata a prisão de policiais civis suspeitos de extorsão; são informações de investigação, sem desfecho judicial informado. [Agentes suspeitos de extorsão](https://record.r7.com/balanco-geral-rj/video/agentes-usavam-a-estrutura-da-policia-para-extorquir-donos-de-ferros-velhos-no-rj-diz-mp-04092026/)
- A Operação Dominus envolveu mandados, prisões e bloqueio de valores contra uma organização suspeita; as informações são investigativas, não condenações. [Operação Dominus](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/policia-civil-e-mprj-deflagram-a-operacao-dominus.ghtml)

## 6. Riscos prioritários
- A Polícia Civil do RJ apura falhas atribuídas à FXX, incluindo problemas recorrentes na reposição de vigilantes e postos sem cobertura em dois plantões; segundo a Sepol, essas falhas podem comprometer a regularidade e a continuidade da vigilância armada nas unidades. A reportagem não informa medidas de contingência. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- Pressão de execução e acompanhamento contratual: a estatística registra 33 contratações na janela de 90 dias, no valor de R$ 84.907.002,73, sem detalhar individualmente todas as obrigações ou entregas.
- Concentração relevante em aquisições de viaturas: três contratações de SUVs da Hyundai somam cerca de R$ 39,91 milhões; atraso ou falha de entrega pode afetar a renovação da frota.
- Divergência a esclarecer: a pesquisa atribui R$ 6,36 milhões ao contrato 105/SEPOL/2026 para 60 viaturas Nissan, enquanto a estatística identifica R$ 6.360.396,00 na contratação 2026003781 da 2R Datatel, para solução de tecnologia.
- A estatística registra R$ 2.758.035,38 a pagar; sem discriminação de credores, vencimentos e serviços associados, não é possível avaliar risco de atraso ou interrupção.

## 7. Perguntas-chave para IA externa
1. Qual é o valor, a vigência, a execução atual e o plano de contingência do contrato 022/SEPOL/2024 da FXX, e houve regularização de salários, benefícios e cobertura dos postos?
2. Qual é a situação e o desfecho do processo sancionador da FXX, incluindo defesa apresentada, decisão, sanções ou medidas corretivas?
3. Qual é o cronograma de entrega e a situação de execução da contratação 2026003781, no valor de R$ 6.360.396,00, com a 2R Datatel?
4. A contratação 2026003781 da 2R Datatel corresponde ao contrato 105/SEPOL/2026 da pesquisa, atribuído à Nissan por R$ 6,36 milhões? Se não, qual é o identificador SIGA do contrato Nissan?
5. Qual é o cronograma de entrega das viaturas das contratações 2025009743, de R$ 19.187.500,00, 2025010652, de R$ 12.024.166,67, e 2025010897, de R$ 8.698.333,33?
6. Quais são os pagamentos, vencimentos e serviços associados aos R$ 2.758.035,38 registrados como a pagar, e há risco de interrupção de serviços essenciais?
7. Qual é a situação da contratação 2025002229, de R$ 12.435.000,00, e da contratação 2025008320, de R$ 7.264.400,00, incluindo entregas, pagamentos e vigência?
8. A contratação 2022001444 da Claro, no valor de R$ 5.653.908,00 e com fim registrado em 10/03/2025, foi encerrada, prorrogada ou substituída?
9. Quais contratos, auditorias, determinações ou recomendações do TCE-RJ e procedimentos do MPRJ relacionados à SEPOL estão pendentes, e quais providências e prazos cabem à secretaria?
10. Existe plano formal para a eventual reorganização das polícias sob uma Secretaria de Segurança, com cronograma, responsáveis e garantias de continuidade administrativa?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEPOL | Secretaria de Estado de Polícia Civil | 176 | R$ 350,9 mi | 33 | R$ 84,9 mi | 0 | Descontinuidade da vigilância armada durante a apuração das falhas da FXX. | Confirmar cobertura dos postos e instituir contingência imediata para a vigilância. |

## Fontes da pesquisa
1. [Operação Dominus combate monopólio do gás do Comando Vermelho ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/policia-civil-e-mprj-deflagram-a-operacao-dominus.ghtml) — 2026-10-28
2. [Agentes usavam a estrutura da polícia para extorquir donos ...](https://record.r7.com/balanco-geral-rj/video/agentes-usavam-a-estrutura-da-policia-para-extorquir-donos-de-ferros-velhos-no-rj-diz-mp-04092026/) — 2026-09-04
3. [PCERJ](https://www.policiacivil.rj.gov.br/news/15104) — 2026-03-10
4. [Polícia faz operação contra facção que extorquia barqueiros em Paraty   G1](https://g1.globo.com/rj/sul-do-rio-costa-verde/noticia/2026/09/16/policia-civil-deflagra-operacao-contra-faccao-que-extorquia-barqueiros-em-paraty.ghtml) — 2026-09-16
5. [Polícia Civil do RJ abre processo contra empresa de ...](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/) — 2026-10-30
6. [Douglas Ruas vai unir polícias Militar e Civil em mesma pasta no RJ   Blogs   CNN Brasil](https://www.cnnbrasil.com.br/blogs/cleber-rodrigues/nacional/sudeste/rj/douglas-ruas-vai-unir-policias-militar-e-civil-em-mesma-pasta-no-rj/) — 2026-11-03

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
