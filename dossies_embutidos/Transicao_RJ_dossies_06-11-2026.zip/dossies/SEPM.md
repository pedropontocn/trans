# Dossiê reduzido — Secretaria de Estado de Polícia Militar (SEPM)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEPM.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEPM_pesquisa.md`.

## Resumo executivo
- Foi identificada cobrança solidária de R$ 2.580.758,63 contra um coronel da PM-RJ e outros envolvidos, mantida pelo TCE-RJ apesar de pedido de suspensão; o débito decorre de irregularidades apontadas em compras hospitalares de 2014. [Conta não fecha](https://temporealrj.com/coronel-pm-barrar-cobranca-milhoes-tce-pedido/)
- Há denúncias do MPRJ contra policiais por condutas na Megaoperação Contenção, incluindo invasões de domicílio, subtração de bens e obstrução de câmeras corporais; denúncias não equivalem a condenações. [MPRJ denunciou 28 PMs](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/megaoperacao-mprj-denuncia-pms-crimes.ghtml)
- Foram noticiados atraso contestado em pagamentos extraordinários do Segurança Presente e transferência de recursos, contratos e bens para a PMERJ, mas as fontes não detalham contratos nem indicam interrupção do serviço. [Pagamento do Segurança Presente](https://extra.globo.com/economia/servidor-publico/noticia/2026/07/pmerj-deposita-pagamento-atrasado-de-agentes-do-seguranca-presente.ghtml)
- O governador eleito anunciou a intenção de reunir as polícias Militar e Civil sob uma Secretaria de Segurança Pública, mas a mudança ainda é uma proposta e não há detalhes de implementação nas fontes consultadas. [Douglas Ruas e a segurança](https://www.cnnbrasil.com.br/blogs/cleber-rodrigues/nacional/sudeste/rj/douglas-ruas-vai-unir-policias-militar-e-civil-em-mesma-pasta-no-rj/)

## 1. Missão e competências
- Atuação da Polícia Militar do Estado do Rio de Janeiro, conforme a identificação da SEPM e da PMERJ no material fornecido.
- Gestão e continuidade do Segurança Presente, cuja transferência de gestão, recursos, contratos e bens para a PMERJ foi relatada na pesquisa.
- Sustentação operacional da corporação, com aquisições de viaturas e equipamentos de proteção, além de serviços de alimentação e apoio administrativo.

## 2. Estrutura essencial
- Titular: a confirmar.
- FUNESPOM - Fundo Esp. Polícia Militar RJ.
- PMERJ - Polícia Militar do Estado do Rio de Janeiro.
- SEPM - Secretaria de Estado de Polícia Militar.

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 968 contratos, R$ 981,9 mi (+1 'Ativo' sem data de fim válida, R$ 0,0 mi) |
| Vencem em até 30 dias | 65 contratos, R$ 37,9 mi |
| Vencem em até 90 dias | 369 contratos, R$ 203,0 mi (51 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 494 contratos, R$ 329,6 mi |
| Emergenciais vigentes ou sem data de fim | 5 contratos, R$ 15,9 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 73,0 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2025008496 | LECARD ADMNISTRADORA DE CARTÕES LTDA | contratação de empresa especializada para confecção, fornec… | R$ 27.366.852,50 | 18/11/2026 |
| 2025000324 | ECO RIO COMERCIO E SERVIÇOS GERAIS LTDA | Contratação do serviço continuado de apoio administrativo, … | R$ 14.695.887,12 | 03/02/2027 (PNCP) |
| 2023000097 | JP CONSTRUÇÕES REFORMAS E INSTALAÇÕES EM GER… | CONTRATAÇÃO DE PESSOA JURÍDICA PARA PRESTAÇÃO DE SERVIÇOS C… | R$ 14.349.643,95 | 31/01/2027 |
| 2025010993 | HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS… | AQUISIÇÃO DE VIATURAS TIPO SUV CARACTERIZADAS E COM BLINDAG… | R$ 10.745.000,00 | 30/12/2026 (PNCP) |
| 2025010944 | GENERAL MOTORS DO BRASIL LTDA. | AQUISIÇÃO DE VIATURAS CARACTERIZADAS DO TIPO SUV COM BLINDA… | R$ 9.092.500,00 | 05/01/2027 (PNCP) |
| 2025010871 | GLAGIO DO BRASIL LTDA | AQUISIÇÃO DE COLETES DE PROTEÇÃO BALÍSTICA NÍVEL III-A TAMA… | R$ 8.719.645,00 | 26/12/2026 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 861 (R$ 645,4 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 369 (R$ 203,0 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 2 | 0 | Alerta |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2024009597 | EMPORIUM COMERCIO DE VEICULOS E EQUIPAMENTOS E SE… | R$ 39.070.023,69 | 20/03/2026 |
| 2025000465 | NRTT - SOLUCOES E SERVICOS LTDA | R$ 34.559.140,91 | 20/03/2026 |
| 2025000671 | NRTT - SOLUCOES E SERVICOS LTDA | R$ 32.491.500,00 | 11/02/2026 |

## 5. Alertas vermelhos
- 65 contrato(s) vencem em até 30 dias (R$ 37,9 mi).
- 5 contratação(ões) emergencial(is) vigente(s) ou sem data de fim (R$ 15,9 mi): verificar limite de 1 ano (Lei 14.133, art. 75, VIII).
- 2 contrato(s) com fornecedor em recuperação judicial.
- O TCE-RJ manteve cobrança solidária de R$ 2.580.758,63 relacionada a irregularidades em compras hospitalares de 2014; o recurso ainda aguardava tramitação. [Conta não fecha](https://temporealrj.com/coronel-pm-barrar-cobranca-milhoes-tce-pedido/)
- Em decisão anterior, o TCE apontou pagamentos por produtos não entregues, recebimento de materiais diferentes dos descritos nas notas fiscais, compras em quantidades superiores às necessárias, falhas nos registros patrimoniais e armazenamento inadequado de insumos hospitalares. [Conta não fecha](https://temporealrj.com/coronel-pm-barrar-cobranca-milhoes-tce-pedido/)
- O MPRJ denunciou 28 policiais em 12 peças relacionadas à Megaoperação Contenção; denúncias não equivalem a condenações. [MPRJ denunciou 28 PMs](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/megaoperacao-mprj-denuncia-pms-crimes.ghtml)
- O comandante do 23º BPM foi alvo de busca e apreensão em investigação sigilosa; o objeto não foi esclarecido oficialmente nas fontes consultadas. [Operação no 23º BPM](https://oglobo.globo.com/rio/noticia/2026/11/05/comandante-do-23o-bpm-no-leblon-e-alvo-de-operacao-da-corregedoria-da-pm-e-do-mprj.ghtml)
- Agentes relataram atraso no pagamento extraordinário do Segurança Presente, enquanto a PMERJ contestou a existência de atraso. [Pagamento do Segurança Presente](https://extra.globo.com/economia/servidor-publico/noticia/2026/07/pmerj-deposita-pagamento-atrasado-de-agentes-do-seguranca-presente.ghtml)

## 6. Riscos prioritários
- Continuidade contratual: 65 contratos somam R$ 37.909.418,36 com término em até 30 dias, e 369 somam R$ 203.046.736,70 em até 90 dias. O contrato 2025008496, de R$ 27.366.852,50, termina em 18/11/2026.
- Após a transferência da gestão do Segurança Presente para a PMERJ, em maio, agentes relataram atraso no pagamento pelos serviços prestados em junho. A PMERJ contestou que houvesse atraso e informou que o pagamento foi depositado no dia 24. [Pagamento do Segurança Presente](https://extra.globo.com/economia/servidor-publico/noticia/2026/07/pmerj-deposita-pagamento-atrasado-de-agentes-do-seguranca-presente.ghtml)
- Risco de controle e responsabilização: a cobrança solidária de R$ 2.580.758,63 e os achados sobre compras hospitalares requerem apuração do estágio do recurso e das medidas corretivas, sem presumir que o débito seja da secretaria. [Conta não fecha](https://temporealrj.com/coronel-pm-barrar-cobranca-milhoes-tce-pedido/)
- O MPRJ denunciou 28 PMs por crimes cometidos durante a Megaoperação Contenção. Em caso separado, o comandante do 23º BPM foi alvo de uma operação do MPRJ e da Corregedoria da PM; o procedimento tramita sob sigilo e, segundo a TV Globo, investiga a atuação de uma milícia. Os casos podem exigir acompanhamento institucional, respeitados o devido processo e os sigilos legais. [MPRJ denunciou 28 PMs](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/megaoperacao-mprj-denuncia-pms-crimes.ghtml) [Operação no 23º BPM](https://oglobo.globo.com/rio/noticia/2026/11/05/comandante-do-23o-bpm-no-leblon-e-alvo-de-operacao-da-corregedoria-da-pm-e-do-mprj.ghtml)
- Risco de acompanhamento das contratações emergenciais: as estatísticas registram 7 contratos emergenciais, no total de R$ 40.472.022,10; faltam, no material fornecido, sua relação, vigências e situação de execução.

## 7. Perguntas-chave para IA externa
1. Quais são os 65 contratos com término em até 30 dias, quais serviços podem ser afetados e qual o plano de renovação ou substituição, especialmente para o contrato 2025008496, de R$ 27.366.852,50, com término em 18/11/2026?
2. Qual é a situação de execução, saldo, aditivos e plano de continuidade do contrato 2023000097, de R$ 14.349.643,95, com término em 31/01/2027, e do contrato 2025000324, de R$ 14.695.887,12, com término em 03/02/2027?
3. Como se compõem os R$ 73.020.441,53 registrados como a pagar, quais são os vencimentos, credores e fontes orçamentárias, e quais pagamentos são críticos para a operação?
4. Quais recursos, contratos, bens, efetivo e responsabilidades do Segurança Presente foram transferidos para a PMERJ, e qual é o calendário atualizado dos pagamentos extraordinários, com comprovantes e pendências?
5. Quais são os 5 contratos emergenciais vigentes ou sem data de fim, que totalizam R$ 15.942.060,23, com números, objetos, fornecedores, justificativas, vigências e situação de execução?
6. Qual é a situação atual da cobrança solidária de R$ 2.580.758,63, do recurso de revisão e de eventuais medidas de cobrança, distinguindo a responsabilidade individual da responsabilidade institucional?
7. Quais providências foram adotadas após os achados da auditoria sobre a adesão nº 25/13 e as compras hospitalares de 2014, e qual é a situação atual dos estoques e controles relacionados?
8. Qual é o quadro atualizado de procedimentos e medidas administrativas relacionados às denúncias da Megaoperação Contenção e à investigação no 23º BPM, respeitados os sigilos legais e a presunção de inocência?
9. Existe plano, cronograma e avaliação de impactos para a proposta de reunir as polícias Militar e Civil em uma Secretaria de Segurança Pública, incluindo transferência de contratos, orçamento, pessoal e sistemas?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEPM | Secretaria de Estado de Polícia Militar | 968 | R$ 981,9 mi | 369 | R$ 203,0 mi | 0 | Risco potencial de descontinuidade de contratos e serviços durante a transição e eventual… | Mapear vencimentos, pagamentos e responsáveis por cada serviço crítico. |

## Fontes da pesquisa
1. [Conta não fecha: coronel da PM tenta barrar cobrança de R$ 2,5 ...](https://temporealrj.com/coronel-pm-barrar-cobranca-milhoes-tce-pedido/) — 2026-09-07
2. [MPRJ denunciou 28 PMs um ano após Megaoperação Contenção   G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/megaoperacao-mprj-denuncia-pms-crimes.ghtml) — 2026-10-28
3. [Comandante do 23° BPM, no Leblon, é alvo de operação da Corregedoria da PM e do MPRJ](https://oglobo.globo.com/rio/noticia/2026/11/05/comandante-do-23o-bpm-no-leblon-e-alvo-de-operacao-da-corregedoria-da-pm-e-do-mprj.ghtml) — 2026-11-05
4. [MPRJ denuncia mais oito PMs que participaram da Operação ...](https://agenciabrasil.ebc.com.br/justica/noticia/2026-10/mprj-denuncia-mais-oito-pms-que-participaram-da-operacao-contencao) — 2026-10-09
5. [PMERJ deposita pagamento atrasado de agentes do Segurança Presente](https://extra.globo.com/economia/servidor-publico/noticia/2026/07/pmerj-deposita-pagamento-atrasado-de-agentes-do-seguranca-presente.ghtml) — 2026-07-24
6. [Douglas Ruas vai unir polícias Militar e Civil em mesma pasta no RJ   Blogs   CNN Brasil](https://www.cnnbrasil.com.br/blogs/cleber-rodrigues/nacional/sudeste/rj/douglas-ruas-vai-unir-policias-militar-e-civil-em-mesma-pasta-no-rj/) — 2026-11-03

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
