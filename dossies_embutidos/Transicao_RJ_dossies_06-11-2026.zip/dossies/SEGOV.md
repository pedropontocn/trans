# Dossiê reduzido — Secretaria de Estado de Governo (SEGOV)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEGOV.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEGOV_pesquisa.md`.

## Resumo executivo
- A apuração mais relevante envolve contrato de R$ 49,6 milhões com a Fundação Cesgranrio para avaliar o Programa Operação Segurança Presente: auditoria estadual apontou indícios de sobrepreço e problemas na comprovação dos serviços, e informou que os pagamentos foram suspensos após a gestão interina assumir o governo; as fontes não confirmam se a suspensão continua em 06/11/2026. [Auditoria sobre o Segurança Presente](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/)
- O TCE-RJ solicitou informações sobre licitação de aluguel de veículos de quase R$ 62 milhões, inclusive se houve anulação, contratos, empenhos ou pagamentos; a fonte não registra a resposta final nem decisão de mérito. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/)
- A Corregedoria da Segov instaurou cinco sindicâncias, mas a fonte não identifica os contratos ou fatos investigados nem informa os resultados. [Cinco sindicâncias na Segov](https://boletimrj.com.br/pente-fino-corregedoria-da-secretaria-de-governo-abre-cinco-sindicancias-e-substitui-comissoes-de-investigacoes-em-andamento/)
- Segurança Presente e Barricada Zero foram transferidos para a Polícia Militar em abril de 2026; as fontes não informam o estado atual da operação, dos contratos ou da continuidade dos serviços após a transferência. [Mudanças na Segov e no GSI](https://oglobo.globo.com/rio/noticia/2026/04/30/ricardo-couto-enxuga-segov-e-gsi-transferindo-seguranca-presente-e-barricada-zero-para-a-pm.ghtml)

## 1. Missão e competências
- Atuação ligada à coordenação de programas governamentais, conforme as áreas mencionadas no material.
- Gestão do programa Segurança Presente, transferido para a Polícia Militar em abril de 2026.
- Atuação relacionada ao Barricada Zero e à Lei Seca, cujas responsabilidades e situação atual precisam ser confirmadas.

## 2. Estrutura essencial
- Titular: a confirmar
- Unidade SIGA: SEGOV - Secretaria de Estado de Governo

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 64 contratos, R$ 212,9 mi (+3 'Ativo' sem data de fim válida, R$ 0,1 mi) |
| Vencem em até 30 dias | 2 contratos, R$ 0,5 mi |
| Vencem em até 90 dias | 10 contratos, R$ 79,2 mi (3 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 33 contratos, R$ 142,9 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 0,8 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2025010890 | FUNDAÇÃO CESGRANRIO | O presente Termo de Referência tem por objetivo estabelecer… | R$ 49.667.956,58 | 23/12/2026 (PNCP) |
| 2025009850 | STEM SOLUÇÕES E INTEGRAÇÕES EDUCACIONAIS LTDA | Aquisição de 100.000 (cem mil) kits de material educativo s… | R$ 25.662.000,00 | 10/12/2026 (PNCP) |
| 2025010264 | BICICLETARIA E LANCHONETE CARIOCA LTDA | Registro de preços para a aquisição eventual de até 400(qua… | R$ 2.840.000,00 | 10/12/2026 (PNCP) |
| 2021006205 | EMPRESA BRASILEIRA DE ENGENHARIA E COMÉRCIO … | Adesão à ATA DE REGISTRO DE PREÇOS para a locação de veícul… | R$ 435.140,64 | 02/12/2026 |
| 2021005229 | EMPRESA BRASILEIRA DE ENGENHARIA E COMÉRCIO … | : Trata-se de locação de veículos automotores novos, do tip… | R$ 348.359,76 | 13/01/2027 |
| 2025010810 | SHEMÁ SUPRIMENTOS E SERVIÇOS LTDA | Aquisição de uniformes operacionais para suprir o efetivo d… | R$ 162.594,00 | 19/12/2026 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 58 (R$ 190,7 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 10 (R$ 79,2 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2025003186 | GLOBALTEC TECNOLOGIAS EDUCACIONAIS LTDA | R$ 57.116.600,00 | 08/05/2026 |
| 2025001299 | BARRA BR COMÉRCIO E SERVIÇOS LTDA | R$ 25.656.000,00 | 26/02/2026 |
| 2024000651 | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL LTDA | R$ 24.994.813,96 | 10/09/2025 |

## 5. Alertas vermelhos
- 2 contrato(s) vencem em até 30 dias (R$ 0,5 mi).
- Auditoria apontou indícios de sobrepreço e fragilidades na comprovação e medição dos serviços do contrato Cesgranrio; não há decisão definitiva nem confirmação sobre a suspensão atual dos pagamentos. [Auditoria sobre o Segurança Presente](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/)
- O TCE-RJ pediu informações sobre licitação de veículos de quase R$ 62 milhões; a pesquisa não informa resposta final ou decisão de mérito. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/)
- A Corregedoria da Segov instaurou cinco sindicâncias para apurar possíveis irregularidades em contratos e processos administrativos. A fonte informa que três tiveram suas comissões substituídas e as apurações reiniciadas, mas não apresenta os resultados nem providências após as conclusões. [Cinco sindicâncias na Segov](https://boletimrj.com.br/pente-fino-corregedoria-da-secretaria-de-governo-abre-cinco-sindicancias-e-substitui-comissoes-de-investigacoes-em-andamento/)
- Segurança Presente e Barricada Zero foram transferidos para a Polícia Militar; as fontes não detalham custos, contratos ou continuidade operacional após a mudança. [Mudanças na Segov e no GSI](https://oglobo.globo.com/rio/noticia/2026/04/30/ricardo-couto-enxuga-segov-e-gsi-transferindo-seguranca-presente-e-barricada-zero-para-a-pm.ghtml)
- A pesquisa relata exoneração de 385 dos 487 cargos comissionados e redução da folha mensal de R$ 4,2 milhões para R$ 1,1 milhão; não informa o impacto sobre as funções essenciais. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/)

## 6. Riscos prioritários
- Auditoria identificou indícios de sobrepreço e superfaturamento em contrato de R$ 49,6 milhões entre a Segov e a Cesgranrio para avaliar o Segurança Presente. R$ 29,7 milhões já haviam sido pagos, e os pagamentos foram suspensos. Os auditores recomendaram avaliar a continuidade do contrato e abrir Tomada de Contas para apurar os fatos e eventual prejuízo. [Auditoria sobre o Segurança Presente](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/)
- Incerteza sobre a licitação de veículos de quase R$ 62 milhões, incluindo atas, contratos, empenhos e pagamentos; a pesquisa não confirma o desfecho. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/)
- Risco de descontinuidade ou indefinição de responsabilidades nos programas transferidos à Polícia Militar, sem evidência fornecida de interrupção dos serviços. [Mudanças na Segov e no GSI](https://oglobo.globo.com/rio/noticia/2026/04/30/ricardo-couto-enxuga-segov-e-gsi-transferindo-seguranca-presente-e-barricada-zero-para-a-pm.ghtml)
- Após a exoneração de 385 dos 487 cargos comissionados, o TCE-RJ deu ao secretário Roberto Lisandro Leão 15 dias para informar a situação da licitação, das atas de registro de preços e de eventuais contratos, empenhos ou pagamentos. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/)
- O SIGA/PNCP registra R$ 811.821,24 a pagar; é necessário conciliar esse valor com credores, liquidações, vencimentos e disponibilidade financeira.
- Há contratos do conjunto de maiores valores com datas de término já passadas ou próximas, como o nº 2025003186, de R$ 57.116.600,00, com término registrado em 08/05/2026; confirmar encerramento, saldo e obrigações remanescentes.

## 7. Perguntas-chave para IA externa
1. Qual é a situação atual do contrato nº 2025010890 com a Fundação Cesgranrio, no valor de R$ 49.667.956,58: vigência, entregáveis aceitos, pagamentos, saldo e decisão sobre continuidade ou encerramento?
2. Como a Segov apurou os R$ 29,7 milhões pagos à Cesgranrio até março de 2026, mencionados na pesquisa, e qual é a situação atual da suspensão de pagamentos?
3. Qual foi a resposta à diligência do TCE-RJ sobre a licitação de veículos de quase R$ 62 milhões, e quais atas, contratos, empenhos ou pagamentos decorreram do procedimento?
4. Os contratos nº 2021006205, de R$ 435.140,64, e nº 2021005229, de R$ 348.359,76, têm relação com a licitação de veículos questionada pelo TCE-RJ? Informar objeto, vigência, saldo e pagamentos.
5. Quais são os objetos, responsáveis atuais, prazos e resultados das cinco sindicâncias noticiadas, e quais relatórios ou providências seguem pendentes?
6. Qual órgão responde atualmente por cada contrato, equipe, dotação e obrigação dos programas Segurança Presente, Barricada Zero e Lei Seca após as mudanças de 2026?
7. Como está composto o quadro atual da SEGOV, quem responde por contratos e controle interno, e quais medidas asseguram a continuidade das funções essenciais após as exonerações noticiadas?
8. A que obrigações correspondem os R$ 811.821,24 registrados como a pagar no SIGA/PNCP, quais são os vencimentos e há valores em atraso?
9. Qual é a situação de encerramento, saldo, pagamentos e eventuais obrigações remanescentes do contrato nº 2025003186, de R$ 57.116.600,00, com término registrado em 08/05/2026?
10. No contrato nº 2025009850, de R$ 25.662.000,00, com término registrado em 10/12/2026, quais entregas foram recebidas, quais pagamentos foram realizados e há pendências para a transição?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEGOV | Secretaria de Estado de Governo | 64 | R$ 212,9 mi | 10 | R$ 79,2 mi | 0 | Pendências financeiras e de controle: confirmar os responsáveis atuais e a situação da co… | Obter processos integrais, saldos e responsáveis atuais pelos contratos e programas. |

## Fontes da pesquisa
1. [Secretaria de Estado de Governo](https://www.rj.gov.br/segov/) — 2026-06-18
2. [TCE cobra explicações sobre licitação de R$ 62 milhões para aluguel de veículos feita durante gestão de André ](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/) — 2026-07-19
3. [Ricardo Couto enxuga Segov e GSI transferindo Segurança Presente e Barricada Zero para a PM](https://oglobo.globo.com/rio/noticia/2026/04/30/ricardo-couto-enxuga-segov-e-gsi-transferindo-seguranca-presente-e-barricada-zero-para-a-pm.ghtml) — 2026-04-30
4. [Auditoria aponta indícios de sobrepreço em contrato de R$ ...](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/) — 2026-09-26
5. [Pente-fino: Corregedoria da Secretaria de Governo abre cinco sindicâncias e substitui comissões de investigaçõ](https://boletimrj.com.br/pente-fino-corregedoria-da-secretaria-de-governo-abre-cinco-sindicancias-e-substitui-comissoes-de-investigacoes-em-andamento/) — 2026-07-19
6. [Ruas começa transição de governo estudando mudanças na ...](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml) — 2026-10-14

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
