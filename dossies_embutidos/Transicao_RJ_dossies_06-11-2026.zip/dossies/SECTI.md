# Dossiê reduzido — Secretaria de Estado de Ciência, Tecnologia e Inovação (SECTI)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SECTI.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SECTI_pesquisa.md`.

## 1. Missão e competências
- Atuação nas áreas de ciência, tecnologia e inovação, conforme a denominação da Secretaria.
- Acompanhamento de entidades estaduais de ensino técnico e superior, pesquisa e educação a distância listadas entre as unidades vinculadas.

## 2. Estrutura essencial
- Titular: Antonio Claudio da Nóbrega, identificado como secretário em reportagem de 20/10/2026.
- CECIERJ - FUND CENTRO CIÊN EDUC SUP DISTÂN DO EST RJ
- FAETEC - CCF - FUND DE APOIO À ESCOLA TÉCNICA DO EST DO RJ
- FAPERJ - FUNDAÇÃO C.C.F. DE AMPARO À PESQUISA DO ERJ
- FENORTE - FUNDAÇÃO ESTADUAL DO NORTE-FLUMINENSE
- SECTI - SECRETARIA DE ESTADO DE CIÊNCIA TECNOLOGIA
- UENF - Univ Est do Norte Fluminense Darcy Rib
- UERJ - ADMINISTRACAO CENTRAL
- UERJ - HOSPITAL UNIVERSITÁRIO - HOSPITAL UNIVERSITARIO PEDRO ERNESTO
- UERJ-ZO - CAMPUS UERJ - ZONA OESTE
- UEZO - Centro Universitário Estadual Zona Oeste

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 1701 contratos, R$ 2,16 bi (+44 'Ativo' sem data de fim válida, R$ 2,7 mi) |
| Vencem em até 30 dias | 140 contratos, R$ 75,5 mi |
| Vencem em até 90 dias | 349 contratos, R$ 290,6 mi (43 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 746 contratos, R$ 566,8 mi |
| Emergenciais vigentes ou sem data de fim | 9 contratos, R$ 8,6 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 36,4 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2026000349 | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Processamento de despesa - Prestadores de serviço e estagiá… | R$ 54.500.000,00 | 03/02/2027 (PNCP) |
| 2025001516 | SGHN - HIGIENIZACAO TEXTIL E NUTRICAO HOSPIT… | A contratação de empresa especializada na prestação de serv… | R$ 36.140.990,84 | 27/11/2026 (PNCP) |
| 2023000345 | SCALLE CONSTRUCOES, REFORMAS E INSTALACOES L… | O presente Termo de Referência relativo ao Processo Adminis… | R$ 28.061.749,20 | 25/01/2027 |
| 2025009911 | MVT EDUCACAO LTDA | Aquisição de solução pedagógica de educação financeira, com… | R$ 25.283.699,00 | 09/12/2026 (PNCP) |
| 2024004219 | FOCO SERVICOS ESPECIALIZADOS LTDA | O presente Termo de Referência tem por objeto a Contratação… | R$ 17.330.379,74 | 31/01/2027 |
| 2026001775 | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto Atenção a Saúde do Homem | R$ 11.675.798,00 | 12/01/2027 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 3059 (R$ 856,8 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 2 (R$ 1,1 mi) | 0 | Alerta |
| Vencimentos até 90 dias | 349 (R$ 290,6 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 2 (R$ 0,0 mi) | 0 | Alerta |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2025001497 | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | R$ 29.348.417,30 | 11/03/2026 |
| 2021007476 | CNS NACIONAL DE SERVIÇOS LTDA | R$ 28.082.435,15 | 02/03/2025 |
| 2022002255 | HAWK SEGURANÇA E VIGILÂNCIA LTDA | R$ 26.817.159,91 | 06/04/2026 |

## 5. Alertas vermelhos
- 140 contrato(s) vencem em até 30 dias (R$ 75,5 mi).
- 2 contrato(s) com Termo de Rescisão crível no PNCP (publicado perto do fim, sem aditivo posterior) seguem 'Ativo' no SIGA: 2024005811 LIFETEX INDUSTRIA E COMERCIO LTDA (R$ 0,5 mi); 2024008825 RENAL TEC INDUSTRIA COMERCIO E SERVICOS… (R$ 0,6 mi). Confirmar substituição do serviço.
- 9 contratação(ões) emergencial(is) vigente(s) ou sem data de fim (R$ 8,6 mi): verificar limite de 1 ano (Lei 14.133, art. 75, VIII).
- 2 contrato(s) com data de fim impossível no SIGA (R$ 0,0 mi): 2020004629 AVANTE BRASIL COMERCIO EIRELI ME (fim 01/10/2121); 2018000163 LABORATÓRIOS B. BRAUN S.A (fim 31/12/2201). Corrigir o cadastro e confirmar a vigência real no processo SEI.
- Obras de oito unidades da FAETEC foram paralisadas e o contrato foi rescindido em março de 2026; Tamoios seguia sem previsão de conclusão. [Folha dos Lagos — obra da FAETEC em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/)
- O MPRJ recomendou regularizar repasses do Fundeb à FAETEC; a pesquisa não confirma cumprimento. [MPRJ — recomendação sobre repasses do Fundeb à FAETEC](https://mprjemnuvem.mprj.mp.br/web/guest/visualizar?noticiaId=218201)
- Reportagem menciona contrato de plataforma educacional suspenso pelo TCE-RJ, mas não identifica contrato, empresa, valor ou órgão gestor. [O Globo — projetos e estrutura da SECTI](https://oglobo.globo.com/rio/noticia/2026/10/20/vamos-entregar-uma-secretaria-pronta-para-novos-saltos-assegura-secretario-estadual-de-ciencia-e-tecnologia-do-rio-veja-seus-projetos.ghtml)
- Após a incorporação da SECTI à estrutura de Desenvolvimento Econômico, o governo se comprometeu a recriá-la em até dez dias; a fonte não detalha ato final, organograma ou distribuição de competências. [Tempo Real RJ — recriação da SECTI](https://temporealrj.com/governo-do-estado-recua-e-vai-recriar-secretaria-de-ciencia-tecnologia-e-inovacao-apos-reacao-da-comunidade-cientifica/)

## 6. Riscos prioritários
- O contrato das oito obras da FAETEC passou de R$ 154,6 milhões para R$ 191.649.941,68 e foi rescindido unilateralmente em março de 2026; as obras estavam paralisadas desde dezembro de 2024, e a situação posterior não foi esclarecida. [Folha dos Lagos — obra da FAETEC em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/)
- Risco de pressão sobre funcionamento da FAETEC por repasses do Fundeb, infraestrutura e falta de profissionais, sem confirmação de cumprimento da recomendação do MPRJ. [MPRJ — recomendação sobre repasses do Fundeb à FAETEC](https://mprjemnuvem.mprj.mp.br/web/guest/visualizar?noticiaId=218201)
- Exposição a vencimentos próximos: os dados registram 349 contratos, no valor de R$ 290,6 milhões, na janela de 90 dias; é necessário confirmar vencimentos, prorrogações e continuidade dos serviços.
- Risco de pressão de caixa: os dados apontam R$ 36,38 milhões a pagar, além de 140 contratos, no valor de R$ 75,53 milhões, na janela de 30 dias.
- Risco de interrupção ou passivo em contratações emergenciais e rescindidas: os dados registram 8 emergenciais somando R$ 8,59 milhões e 10 rescindidas somando R$ 15,93 milhões; a pesquisa não apresenta inventário atualizado desses casos.

## 7. Perguntas-chave para IA externa
1. Qual é o ato vigente de recriação da SECTI, seu organograma, a distribuição de competências e o plano de transição para 01/01/2027?
2. Qual é a situação atual do contrato das oito unidades da FAETEC: medições, pagamentos, multa, rescisão, estado de cada obra e plano de conclusão, considerando o valor reportado de R$ 191.649.941,68?
3. A SEEDUC respondeu à recomendação do MPRJ sobre os repasses do Fundeb à FAETEC? Quais valores, se houver, estão pendentes ou foram regularizados?
4. Qual contrato de plataforma educacional foi suspenso pelo TCE-RJ, qual órgão o gere e qual é a situação atual da decisão e da execução?
5. Qual é a situação e a continuidade prevista do contrato SIGA 2026000349, de R$ 54.500.000,00, com a UERJ? Há saldo a pagar?
6. O contrato SIGA 2025001516, de R$ 36.140.990,84, para serviços de lavanderia hospitalar, será mantido ou substituído, e como será assegurada a continuidade?
7. Qual é o andamento, o objeto atual e o cronograma do contrato SIGA 2023000345, de R$ 28.061.749,20, com a Scalle Construções?
8. O contrato SIGA 2025009911, de R$ 25.283.699,00, para solução pedagógica, tem relação com a plataforma educacional mencionada na reportagem sobre suspensão pelo TCE-RJ?
9. Qual foi a destinação e como foi assegurada a continuidade do serviço do contrato emergencial SIGA 2024004072, de R$ 6.457.548,00, cujo fim indicado é 04/06/2025?
10. Qual é a situação de encerramento, renovação ou substituição do contrato SIGA 2025001497, de R$ 29.348.417,30, relativo a pessoal de projeto, com fim indicado em 11/03/2026?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SECTI | Secretaria de Estado de Ciência, Tecnologia e Inovação | 1701 | R$ 2,16 bi | 349 | R$ 290,6 mi | 2 | Transição institucional sem estrutura e plano de continuidade confirmados. | Formalizar estrutura, responsabilidades e plano de continuidade antes da posse. |

## Fontes da pesquisa
1. [ PDF  ACÓRDÃO Nº 003919/2026-PLENV - TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/3919/2026) — 2026-06-26
2. [RELATÓRIO PARCIAL DE GESTÃO 2024-2025](https://www.uerj.br/wp-content/uploads/2026/10/Relatorio-de-Gestao-Documento-final.pdf) — 2026-10-13
3. [Notícia - Rio de Janeiro - MPRJ em Nuvem](https://mprjemnuvem.mprj.mp.br/web/guest/visualizar?noticiaId=218201) — 2026-09-24
4. ['Vamos entregar uma secretaria pronta para novos saltos', assegura secretário estadual de Ciência e Tecnologia](https://oglobo.globo.com/rio/noticia/2026/10/20/vamos-entregar-uma-secretaria-pronta-para-novos-saltos-assegura-secretario-estadual-de-ciencia-e-tecnologia-do-rio-veja-seus-projetos.ghtml) — 2026-10-20
5. [Douglas Ruas e Dra Gabriela mantém silêncio sobre paralisação da obra da Faetec em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/) — 2026-10-18
6. [Governo do estado recua e vai recriar Secretaria de Ciência, Tecnologia e Inovação após reação da comunidade c](https://temporealrj.com/governo-do-estado-recua-e-vai-recriar-secretaria-de-ciencia-tecnologia-e-inovacao-apos-reacao-da-comunidade-cientifica/) — 2026-08-07

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
