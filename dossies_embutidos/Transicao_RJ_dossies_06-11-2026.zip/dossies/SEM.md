# Dossiê reduzido — Secretaria de Estado da Mulher (SEM)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEM.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEM_pesquisa.md`.

## Resumo executivo
- Como proposta de prioridades para os primeiros 90 dias, podem ser considerados dois temas: a parceria para implantação das Salas Lilases e CEAMs, suspensa cautelarmente para apuração de possíveis irregularidades, e a formalização dos recursos de 2026 do Programa Empoderadas, enquanto mais de 200 profissionais relatam atraso nos salários. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/) [Empoderadas: recursos e salários](https://temporealrj.com/empoderadas-mulheres-sem-salario/)
- A auditoria citada sobre o Empoderadas apontou indícios de pagamentos indevidos e desvio de finalidade em 2025, mas a reportagem atribui os achados à auditoria do programa, não a irregularidades praticadas pela SEM. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml)
- As fontes não relatam decisão do TCE-RJ nem ação do MPRJ contra a SEM ou sobre os instrumentos aqui descritos; a auditoria do Empoderadas seria encaminhada a órgãos de controle, segundo informação do governo reproduzida pela reportagem. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml) [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- Para a futura estrutura, foi anunciado que a vice-governadora eleita Fernanda Louback comandará a Secretaria de Políticas Inclusivas e da Mulher, acumulando a função com a vice-governadoria. [Primeiros nomes do secretariado](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml)

## 1. Missão e competências
- Formular e executar políticas estaduais voltadas às mulheres, conforme a atuação indicada pelo nome da Secretaria.
- Promover serviços de atendimento às mulheres, incluindo a implantação de Salas Lilases e a modernização de CEAMs.
- Coordenar ações do Programa Empoderadas, cuja formalização para 2026 entre a SEM e a UERJ ainda estava pendente, segundo as fontes consultadas.
- Desenvolver capacitação e treinamento relacionados às políticas e aos serviços destinados às mulheres.

## 2. Estrutura essencial
- Titular: Bia Pacheco, também identificada como Bianca Pacheco nas reportagens; a pesquisa não esclarece a divergência.
- Unidade listada no SIGA: SEMPI - SECRETARIA DE ESTADO DA MULHER E POLITICAS INCLUSIVAS.

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 10 contratos, R$ 11,8 mi (+5 'Ativo' sem data de fim válida, R$ 0,6 mi) |
| Vencem em até 30 dias | 2 contratos, R$ 3,4 mi |
| Vencem em até 90 dias | 4 contratos, R$ 4,4 mi (3 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 5 contratos, R$ 4,5 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 0,0 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2024009216 | FUNDAÇÃO UNIVERSITÁRIA JOSE BONIFACIO | CONTRATAÇÃO DE CONSULTORIA TÉCNICAESPECIALIZADA PARA ELABOR… | R$ 2.470.517,33 | 24/11/2026 (PNCP) |
| 2024009538 | INSTITUTO MAPEAR (MASCULINIDADES, PATERNIDAD… | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA, COM NOTÓRIO SABER EM … | R$ 942.080,00 | 29/11/2026 (PNCP) |
| 2025010866 | LIVRE DE ASSÉDIO LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM CAPACITAÇÃO E TREIN… | R$ 600.000,00 | 26/12/2026 (PNCP) |
| 2023007991 | HADDAD RENT A CAR LOCADORA LTDA | Serviços de Locação Veículo Automotor Categoria Representaç… | R$ 388.800,00 | 04/02/2027 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 34 (R$ 12,7 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 4 (R$ 4,4 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2025002241 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 2.065.690,00 | 10/06/2026 |
| 2025005730 | INSTITUTO AQUILA DE GESTÃO LTDA. | R$ 1.385.000,00 | 18/08/2026 |
| 2025005118 | FUNDAÇÃO SANTA CABRINI | R$ 1.240.040,00 | 23/07/2026 |

## 5. Alertas vermelhos
- 2 contrato(s) vencem em até 30 dias (R$ 3,4 mi).
- Suspensão cautelar do Termo de Fomento nº 005/2026 com a AFIURJ: sem novos repasses, ordens de serviço, contratação de equipes ou obras enquanto durarem as apurações. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- Há divergência entre o valor de R$ 43 milhões e o de R$ 44.500.830,00, além de diferença na identificação do termo; as fontes não esclarecem a discrepância. [Repasse de R$ 44,5 milhões](https://temporealrj.com/secretaria-mulher-garante-44-milhoes/) [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- Mais de 200 profissionais do Empoderadas relataram salários em atraso, enquanto a formalização dos R$ 21,3 milhões previstos para 2026 não estava concluída. [Empoderadas: recursos e salários](https://temporealrj.com/empoderadas-mulheres-sem-salario/)
- Auditoria sobre o Empoderadas em 2025 apontou indícios de cerca de R$ 4,45 milhões em pagamentos indevidos e possível desvio de finalidade; a pesquisa não relata decisão final de órgão de controle ou judicial. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml)

## 6. Riscos prioritários
- A suspensão da parceria com a AFIURJ pode atrasar a implantação de 20 Salas Lilases e a modernização de três CEAMs; não há prazo informado para conclusão das apurações. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- A falta de formalização da parceria e de descentralização dos recursos previstos impediu o processamento financeiro e levou à suspensão de novas atividades do Empoderadas, enquanto trabalhadores relatam salários atrasados e a Uerj aponta riscos à continuidade do programa. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml)
- Os indícios apontados na auditoria do Empoderadas e a ausência de confirmação de encaminhamento ou desfecho perante órgãos de controle criam risco de pendências administrativas e de controle. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml)
- Os dados do SIGA/PNCP registram dois contratos no intervalo de 30 dias, somando R$ 3.412.597,33: 2024009216, com término informado em 24/11/2026, e 2024009538, em 29/11/2026. É necessário verificar encerramento, prorrogação e continuidade dos serviços.
- A carteira informa 52 registros ativos e 10 vigentes, com R$ 11.820.898,62 associados aos vigentes; a transição precisa validar obrigações, saldos e situação documental de cada instrumento.

## 7. Perguntas-chave para IA externa
1. Qual é o valor oficial, a identificação correta e a situação atual do Termo de Fomento nº 005/2026 com a AFIURJ, diante das referências a R$ 43 milhões e R$ 44.500.830,00?
2. Quanto já foi repassado à AFIURJ, qual é o saldo e qual o cronograma físico-financeiro da parceria suspensa para 20 Salas Lilases e três CEAMs?
3. Qual é o estágio e o prazo estimado das apurações administrativas da parceria com a AFIURJ, e quais medidas de continuidade dos atendimentos estão previstas?
4. A Resolução Conjunta SEM–UERJ do Empoderadas foi assinada e os R$ 21,3 milhões de 2026 foram descentralizados? Qual é o montante de salários pendentes e a situação dos polos?
5. Qual é o relatório integral da auditoria do Empoderadas e há comprovantes de encaminhamento de seus resultados ao MPRJ, ao MPT e ao TCE-RJ?
6. Qual é a situação do contrato 2024009216, de R$ 2.470.517,33, com término informado em 24/11/2026, e há plano para continuidade do objeto?
7. Qual é a situação do contrato 2024009538, de R$ 942.080,00, com término informado em 29/11/2026, incluindo execução, pagamentos e eventual prorrogação?
8. Qual é o plano para o contrato 2025010866, de R$ 600.000,00, com término informado em 26/12/2026, e para o contrato 2023007991, de R$ 388.800,00, com término informado em 04/02/2027?
9. Qual é a execução, o saldo e a previsão de encerramento dos contratos 2025002241, de R$ 2.065.690,00, 2025005730, de R$ 1.385.000,00, e 2025005118, de R$ 1.240.040,00?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEM | Secretaria de Estado da Mulher | 10 | R$ 11,8 mi | 4 | R$ 4,4 mi | 0 | Risco de interrupção ou atraso de serviços essenciais em razão da suspensão da parceria e… | Validar contratos, recursos pendentes e planos de continuidade antes da posse. |

## Fontes da pesquisa
1. [Secretaria da Mulher suspende contrato de R$ 43 milhões para ...](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/) — 2026-09-21
2. [Nem só de tesourada vive o Guanabara: Secretaria Estadual da Mulher garante R$ 44,5 milhões para megaprojeto d](https://temporealrj.com/secretaria-mulher-garante-44-milhoes/) — 2026-08-05
3. [Programa Empoderadas: Auditoria do RJ aponta desvio de R$ 4,5 ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml) — 2026-08-13
4. [Empoderadas: irregularidades no contrato R$ 21,3 milhões do programa estadual deixam mais de 200 mulheres sem ](https://temporealrj.com/empoderadas-mulheres-sem-salario/) — 2026-07-22
5. [Sem salário há sete meses, profissionais do Empoderadas ...](https://odia.ig.com.br/rio-de-janeiro/2026/07/7282807-sem-salario-ha-sete-meses-profissionais-do-empoderadas-fazem-protesto.html) — 2026-07-27
6. [Douglas Ruas apresenta primeiros nomes do secretariado no ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml) — 2026-11-03

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
