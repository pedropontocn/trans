# Dossiê reduzido — Secretaria de Estado de Trabalho e Renda (SETRAB)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SETRAB.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SETRAB_pesquisa.md`.

## 1. Missão e competências
- Atuação em trabalho e renda, conforme a denominação e as atividades descritas para a secretaria.
- Qualificação e capacitação profissional, incluindo cursos e convênios relacionados à formação para o trabalho.
- Acompanhamento de temas ligados ao piso salarial regional e à execução de recursos do FAT para qualificação.

## 2. Estrutura essencial
- Titular: a confirmar; a página institucional citada diverge entre Paulo Renato Marques e Daniel Martins.
- FTRJ - FUNDO DO TRABALHO DO ESTADO DO RIO DE JANEIRO - FT/RJ
- SETRAB - SECRETARIA DE ESTADO DO TRABALHO E RENDA

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 20 contratos, R$ 17,0 mi (+0 'Ativo' sem data de fim válida, R$ 0,0 mi) |
| Vencem em até 30 dias | 2 contratos, R$ 0,3 mi |
| Vencem em até 90 dias | 6 contratos, R$ 5,7 mi (2 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 9 contratos, R$ 12,8 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 0,1 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2025009400 | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | CONTRATACAO DE EMPRESA ESPECIALIZADA PARA CONFECCAO,FORNECI… | R$ 4.223.081,65 | 12/12/2026 (PNCP) |
| 2024010474 | INSTITUTO BRASILEIRO DE ADMINISTRAÇÃO PUBLIC… | Contratação de instituição especializada para ministrar Cur… | R$ 1.077.500,00 | 06/01/2027 (PNCP) |
| 2023008971 | BRS SUPRIMENTOS CORPORATIVOS S/A | A contratação de prestação dos serviços continuados de outs… | R$ 258.359,79 | 06/11/2026 |
| 2025009960 | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação dos Serviços de Hospedagem IaaS (VPS´s), Serviç… | R$ 88.524,24 | 06/01/2027 |
| 2024010199 | TERMINAL GARAGEM MENEZES CÔRTES S/A | A contratação de empresa especializada para locação de 10 (… | R$ 72.000,00 | 09/01/2027 |
| 2026008483 | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | Contratação direta de 02 vagas de servidores da SETRAB-RJ n… | R$ 13.000,00 | 12/11/2026 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 24 (R$ 10,0 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 6 (R$ 5,7 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2025006369 | FORTES SERVIÇOS LTDA | R$ 4.230.597,94 | 04/03/2026 |
| 2024006442 | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGERAÇÃO… | R$ 2.880.000,00 | 11/08/2025 |
| 2025000032 | SERVIÇO NACIONAL DE APRENDIZAGEM COMERCIAL - SENA… | R$ 1.568.351,36 | 23/01/2026 |

## 5. Alertas vermelhos
- 2 contrato(s) vencem em até 30 dias (R$ 0,3 mi).
- Auditoria da CGE apontou falhas na contratação e fiscalização do contrato HSOL; a sindicância preliminar não tem conclusão informada. [Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- Auditoria relatou pagamento integral do contrato HSOL antes do término previsto de um dos cursos e inconsistências nos registros de beneficiários. [Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- Reportagem informou que 80% dos cargos de confiança da Setrab eram ocupados por funcionários fantasmas; o valor mensal citado abrange o conjunto, sem discriminar a parcela da secretaria. [G1 — relatório sobre funcionários fantasmas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/26/relatorio-funcionarios-fantasmas-governo-rj.ghtml)
- Foi aberta sindicância preliminar sobre possíveis repasses de projeto social a parente da ex-chefe de gabinete; a fonte não informa valores nem desfecho. [Tempo Real — ex-chefe de gabinete](https://temporealrj.com/tag/destaque/page/36/)
- A pesquisa relata demora na tramitação do piso regional de 2026, mas não informa se o processo foi concluído até 06/11/2026. [Tempo Real — atraso do piso regional](https://temporealrj.com/piso-salarial-regional-rio-atraso-burocratico/)

## 6. Riscos prioritários
- O 2º Termo Aditivo ao Contrato nº 13/2024 com o IBAP-RJ prorrogou a vigência de 07/01/2026 a 06/01/2027. O extrato não detalha o objeto original do contrato nem menciona providências de continuidade. [Diário Oficial — 2º Termo Aditivo](https://www.rj.gov.br/planejamento/sites/default/files/arquivos_paginas/12.2%29%20II%20Termo%20Aditivo_0.pdf)
- Risco de pendências de controle e comprovação de execução no contrato HSOL de R$ 6.115.000; há sindicância preliminar e requisição de documentos pelo MPRJ, sem desfecho informado. [Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- Contrato 2025009400, de tickets, no valor de R$ 4.223.081,65, tem término indicado em 12/12/2026; confirmar execução, saldo e providências para evitar descontinuidade.
- Contrato 2025009960, de hospedagem IaaS e serviços relacionados, no valor de R$ 88.524,24, tem término indicado em 06/01/2027; confirmar necessidade e plano de continuidade.
- Há risco de atraso ou perda de oportunidade na política de qualificação: a pesquisa relata recursos do FAT acumulados e convênios buscados, sem informar valores ou situação atual. [Tempo Real — atraso do piso regional](https://temporealrj.com/piso-salarial-regional-rio-atraso-burocratico/)
- A estatística registra R$ 67.349,41 a pagar, sem detalhamento dos credores, contratos, vencimentos ou estágio de liquidação.

## 7. Perguntas-chave para IA externa
1. Qual é o objeto efetivo do Contrato nº 13/2024 com o IBAP-RJ, correspondente na listagem à contratação 2024010474, no valor de R$ 1.077.500,00, e quais são as entregas, medições, pagamentos e saldo pendentes?
2. Que providências estão previstas para o encerramento em 06/01/2027 do contrato IBAP-RJ e para a continuidade de eventual serviço ou entrega?
3. Qual é a situação atual do contrato HSOL de R$ 6.115.000: quantas das 2 mil vagas foram efetivamente entregues, quanto foi pago e qual é o estado da sindicância e da resposta ao MPRJ?
4. Para a contratação 2025009400 da Trivale, no valor de R$ 4.223.081,65 e com término indicado em 12/12/2026, qual é a execução, o saldo e o plano para manter o fornecimento de tickets?
5. Para a contratação 2025009960, de serviços de hospedagem IaaS, no valor de R$ 88.524,24 e com término indicado em 06/01/2027, há dependências operacionais, saldo ou medida de continuidade a providenciar?
6. Quais são os dois contratos que compõem os R$ 271.359,79 com vencimento nos próximos 30 dias, e quais medidas de renovação, encerramento ou substituição estão em andamento?
7. Qual é o detalhamento dos R$ 67.349,41 registrados como valores a pagar, incluindo credor, contrato, vencimento e etapa de processamento?
8. Qual é a situação da tramitação do piso regional de 2026 e da preparação do piso de 2027, e quais prazos ou decisões ainda dependem da secretaria?
9. Quais são os valores, prazos e situação de execução dos recursos do FAT para qualificação, e que convênios estão vigentes ou em preparação?
10. Quem é o titular da secretaria na data de transição e qual é o desfecho ou situação atual das sindicâncias mencionadas na pesquisa?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SETRAB | Secretaria de Estado de Trabalho e Renda | 20 | R$ 17,0 mi | 6 | R$ 5,7 mi | 0 | Pendências de controle e continuidade contratual na transição. | Confirmar contratos, apurações, saldos e planos de continuidade antes da posse. |

## Fontes da pesquisa
1. [g1.globo.com › rj › rio-de-janeiroSecretaria de Trabalho do RJ tinha 80% de funcionários ... - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/26/relatorio-funcionarios-fantasmas-governo-rj.ghtml) — 2026-06-26
2. [Arquivo de Transparência - Página 9 de 74 - Tempo Real](https://temporealrj.com/category/transparencia/page/9/) — 2026-11-03
3. [Atraso burocrático em secretaria e calendário eleitoral ameaçam ...](https://temporealrj.com/piso-salarial-regional-rio-atraso-burocratico/) — 2026-08-11
4. [Trabalho e Renda - Governo do Estado do Rio de Janeiro](https://www.rj.gov.br/trabalho/) — 2026-06-20
5. [Estado gera mais de 86 mil postos de trabalho no ano](https://www.correiodamanha.com.br/estado-do-rio/2026/11/332564-estado-gera-mais-de-86-mil-postos-de-trabalho-no-ano.html) — 2026-11-05
6. [Arquivo de destaque - Página 36 de 834 - Tempo Real](https://temporealrj.com/tag/destaque/page/36/) — 2026-11-03
7. [Notificada pelo MPRJ, Secretaria Estadual de Trabalho abre ...](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/) — 2026-09-06
8. [ PDF  DIÁRIO OFICIAl - Governo do Estado do Rio de Janeiro](https://www.rj.gov.br/planejamento/sites/default/files/arquivos_paginas/12.2%29%20II%20Termo%20Aditivo_0.pdf) — 2026-04-23

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
