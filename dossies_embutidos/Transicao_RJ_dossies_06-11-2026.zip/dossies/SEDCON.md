# Dossiê reduzido — Secretaria de Estado de Defesa do Consumidor (SEDCON)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEDCON.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEDCON_pesquisa.md`.

## Resumo executivo
- O principal risco financeiro e de controle identificado é a parceria de R$ 52 milhões para o Balcão do Consumidor: cerca de R$ 17 milhões já haviam sido pagos, e a segunda parcela foi suspensa cautelarmente diante de falhas documentais apontadas em auditorias. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- A fonte sobre essa parceria registra risco de execução e prestação de contas, mas não confirma interrupção dos postos ou dos serviços; a entidade afirma que as atividades e unidades estavam em funcionamento. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- Há uma representação do TCE-RJ sobre licitação do Procon-RJ para vale-refeição, estimada em R$ 880.200,00, julgada parcialmente procedente; o acórdão determinou ajustes caso o certame seja retomado ou republicado. [TCE-RJ — Acórdão nº 047887/2025-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025)
- As fontes também registram fiscalização de empresas de apostas, uma apuração de acidente envolvendo serviço de abastecimento e sindicâncias relativas a notícias sobre vazamento de informações de fiscalizações, sem demonstrar desfecho definitivo desses procedimentos. [BNLData — Procon-RJ e empresas de apostas](https://bnldata.com.br/en/procon-rj-multa-175-bets-por-infracoes-a-leis-do-consumidor-no-estado/) [O Globo — notificação à Águas do Rio](https://oglobo.globo.com/rio/noticia/2026/11/04/procon-rj-da-72-horas-para-aguas-do-rio-explicar-rompimento-de-tubulacao-que-destruiu-casas-em-iraja.ghtml) [O Brasilianista — reportagem sobre investigados e manifestação do governo](https://obrasilianista.com.br/2026/10/15/justica/biscoito-calcinha-e-tchetcheco-trindade-saiba-quem-sao-esses-e-outros-investigados-por-ligacao-com-a-mafia-dos-combustiveis/)

## 1. Missão e competências
- Atuar na proteção e defesa dos direitos dos consumidores.
- Fiscalizar e responder a práticas que possam prejudicar consumidores, inclusive nos setores de apostas e serviços essenciais.
- Promover atendimento e orientação ao consumidor por meio do Procon-RJ e de iniciativas como o Balcão do Consumidor.

## 2. Estrutura essencial
- Titular: a confirmar
- IPEM-RJ - INSTITUTO DE PESOS E MEDIDAS DO ESTADO DO RJ
- PROCON RJ - Proteção e Defesa do Consumidor
- SEDCON - SECRETARIA DE ESTADO DE DEFESA DO CONSUMIDOR

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 56 contratos, R$ 180,8 mi (+4 'Ativo' sem data de fim válida, R$ 1,1 mi) |
| Vencem em até 30 dias | 6 contratos, R$ 0,9 mi |
| Vencem em até 90 dias | 15 contratos, R$ 18,6 mi (3 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 20 contratos, R$ 22,8 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 3,0 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2022004831 | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Fornecimento de vale alimentação, na modalidade eletrônica,… | R$ 15.376.894,27 | 01/01/2027 |
| 2026000002 | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Contratação de empresa especializada naprestação de serviço… | R$ 1.303.799,51 | 02/01/2027 (PNCP) |
| 2025009005 | RIOPAR PARTICIPAÇÕES S/A | SERVICO DE FORNECIMENTO/RECARGA VALETRANSPORTE,DESCRIÇÃO: C… | R$ 615.783,17 | 11/12/2026 (PNCP) |
| 2025009004 | CBD BOLHETE DIGITAL S/A | SERVICO DE FORNECIMENTO/RECARGA VALE TRANSPORTE,DESCRIÇÃO: … | R$ 588.107,52 | 25/11/2026 (PNCP) |
| 2024009559 | NOVA VIDA LOCACOES LTDA | Veículo de Representação, tipo Sedan, com blindagem nível I… | R$ 264.113,28 | 27/11/2026 |
| 2025010873 | LECARD ADMNISTRADORA DE CARTÕES LTDA | contratação de empresa especializada para aconfecção, forne… | R$ 117.273,00 | 02/01/2027 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 78 (R$ 63,9 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 15 (R$ 18,6 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2021004801 | INVICTA SERVICE CLEAN LTDA | R$ 14.913.319,51 | 30/09/2026 |
| 2025006914 | SOS TECNOLOGIA E GESTÃO DA INFORMAÇÃO LTDA -EPP | R$ 8.000.435,84 | 07/10/2026 |
| 2025008687 | CENTRAL UNICA DAS FAVELAS DO RIO DE JANEIRO | R$ 7.056.000,00 | 22/01/2026 |

## 5. Alertas vermelhos
- 6 contrato(s) vencem em até 30 dias (R$ 0,9 mi).
- Parceria de R$ 52 milhões para o Balcão do Consumidor: a segunda parcela foi suspensa cautelarmente após apontamentos sobre documentação e prestação de contas. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- Auditorias apontaram fragilidades de controle e documentação na parceria do Balcão; a fonte não confirma interrupção dos postos ou serviços. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- O TCE-RJ julgou parcialmente procedente representação sobre o pregão de vale-refeição e determinou ajustes para eventual retomada ou republicação. [TCE-RJ — Acórdão nº 047887/2025-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025)
- Reportagem relata suspeita de vazamento de informações de fiscalizações; o governo informou que instaurou sindicâncias, sem desfecho informado. [O Brasilianista — reportagem sobre investigados e manifestação do governo](https://obrasilianista.com.br/2026/10/15/justica/biscoito-calcinha-e-tchetcheco-trindade-saiba-quem-sao-esses-e-outros-investigados-por-ligacao-com-a-mafia-dos-combustiveis/)
- O Procon-RJ aplicou multas a 175 empresas de apostas; a fonte não informa o total nem o estágio individual dos processos. [BNLData — Procon-RJ e empresas de apostas](https://bnldata.com.br/en/procon-rj-multa-175-bets-por-infracoes-a-leis-do-consumidor-no-estado/)
- Após rompimento de tubulação em Irajá, a concessionária foi notificada; a reportagem não afirma que falhas de manutenção foram comprovadas. [O Globo — notificação à Águas do Rio](https://oglobo.globo.com/rio/noticia/2026/11/04/procon-rj-da-72-horas-para-aguas-do-rio-explicar-rompimento-de-tubulacao-que-destruiu-casas-em-iraja.ghtml)

## 6. Riscos prioritários
- Continuidade e controle da parceria do Balcão do Consumidor: confirmar situação dos repasses, prestação de contas e funcionamento dos postos; a suspensão não comprova interrupção do serviço. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- Risco de transição contratual na posse: há 15 contratos com término em até 90 dias, no valor informado de R$ 18.614.351,97; entre os listados, o contrato 2022004831, de R$ 15.376.894,27, termina em 01/01/2027.
- Continuidade dos benefícios de transporte e alimentação: contratos 2025009005, de R$ 615.783,17, e 2025009004, de R$ 588.107,52, têm términos informados em 11/12/2026 e 25/11/2026; confirmar situação atual e cobertura na posse.
- Situação do vale-refeição permanece incerta: a pesquisa não informa se o pregão suspenso foi retomado ou republicado, nem se houve contratação posterior. [TCE-RJ — Acórdão nº 047887/2025-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025)
- Risco de controle de acesso a informações de fiscalização: há sindicâncias mencionadas sem números, resultados ou protocolos atuais informados. [O Brasilianista — reportagem sobre investigados e manifestação do governo](https://obrasilianista.com.br/2026/10/15/justica/biscoito-calcinha-e-tchetcheco-trindade-saiba-quem-sao-esses-e-outros-investigados-por-ligacao-com-a-mafia-dos-combustiveis/)
- Há R$ 3.024.183,59 informados como a pagar; sem discriminação por credor, vencimento ou contrato, não é possível avaliar o risco de atraso ou de interrupção de serviços.

## 7. Perguntas-chave para IA externa
1. Qual é a situação atual do contrato do Balcão do Consumidor, de R$ 52 milhões: número, vigência, saldo, repasses suspensos, documentos recebidos e conclusão da análise da CGE, AGE, SEDCON e Procon-RJ?
2. Os postos do Balcão do Consumidor estão funcionando e com equipes completas? Quais indicadores atuais de atendimento e quais medidas de continuidade existem caso os repasses permaneçam suspensos?
3. Qual é a situação do contrato 2022004831, de R$ 15.376.894,27, com término informado em 01/01/2027: haverá prorrogação, nova contratação ou plano de transição para o fornecimento de vale-alimentação?
4. Qual é a situação do contrato 2026000002, de R$ 1.303.799,51, com término informado em 02/01/2027, e que serviço de implementação e gerenciamento ele cobre?
5. Qual é a situação dos contratos de vale-transporte 2025009005, de R$ 615.783,17, e 2025009004, de R$ 588.107,52, cujos términos informados são 11/12/2026 e 25/11/2026? Os serviços estão cobertos até a posse e depois dela?
6. Qual é a situação do pregão de vale-refeição do Procon-RJ após o Acórdão nº 047887/2025-PLENV: houve retomada ou republicação, foram cumpridas as determinações do TCE-RJ e o benefício está garantido?
7. Como se compõem os R$ 3.024.183,59 a pagar: quais credores, contratos, vencimentos e valores estão pendentes, e há pagamentos em atraso que afetem serviços?
8. Qual é a situação processual atual do caso da CPASC relativo aos cerca de R$ 27 milhões mencionados na pesquisa, e quais são os autos, decisões e recursos existentes?
9. Quais são os números, responsáveis, prazos e resultados das sindicâncias sobre possível vazamento de informações de fiscalização, e quais controles de acesso estão em vigor?
10. Qual foi o resultado da notificação à Águas do Rio após o rompimento em Irajá, e qual é o estágio dos processos das multas aplicadas às 175 empresas de apostas, incluindo valores e pendências?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEDCON | Secretaria de Estado de Defesa do Consumidor | 56 | R$ 180,8 mi | 15 | R$ 18,6 mi | 0 | Risco de descontinuidade de serviços durante a transição, a verificar diante do venciment… | Validar imediatamente contratos críticos, repasses suspensos e serviços ativos na posse. |

## Fontes da pesquisa
1. [RJ suspende repasses a projeto de R$ 52 milhões por suspeita ... - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml) — 2026-06-17
2. [Procon-RJ fines 175 betting companies for violating consumer laws in the state - BNLData](https://bnldata.com.br/en/procon-rj-multa-175-bets-por-infracoes-a-leis-do-consumidor-no-estado/) — 2026-09-24
3. [Procuradoria Geral do Estado](https://cj.estrategia.com/portal/wp-content/uploads/2025/12/03083918/comissao.pdf) — 2026-02-13
4. [Procon-RJ dá 72 horas para Águas do Rio explicar rompimento de tubulação que destruiu casas em Irajá](https://oglobo.globo.com/rio/noticia/2026/11/04/procon-rj-da-72-horas-para-aguas-do-rio-explicar-rompimento-de-tubulacao-que-destruiu-casas-em-iraja.ghtml) — 2026-11-04
5. [Biscoito, Calcinha e Tchetcheco Trindade; saiba quem os investigados por ligação com a Máfia dos Combustíveis](https://obrasilianista.com.br/2026/10/15/justica/biscoito-calcinha-e-tchetcheco-trindade-saiba-quem-sao-esses-e-outros-investigados-por-ligacao-com-a-mafia-dos-combustiveis/) — 2026-10-15
6. [ PDF  ACÓRDÃO Nº 047887/2025-PLENV - TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025) — 2026-06-30

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
