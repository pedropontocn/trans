# Dossiê reduzido — Secretaria de Estado do Gabinete do Governador (SEGG)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEGG.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEGG_pesquisa.md`.

## Resumo executivo
- As fontes consultadas não identificam contratos, valores, vigências ou serviços críticos atribuídos especificamente à SEGG, nem relatam riscos de interrupção de serviços do Gabinete. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) [G1 — análise de contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)
- Há uma auditoria geral estadual anunciada em abril de 2026, com revisão de despesas, contratos e estrutura administrativa; as fontes não atribuem irregularidades à SEGG. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml)
- Um decreto de transição previu informações das secretarias até 30 de outubro sobre programas, contas públicas e prioridades, mas a fonte não informa o ano dessa data nem se a SEGG entregou os dados. [Governo do RJ — regras da transição](http://www.rj.gov.br/radioroquettepinto/node/21550)
- A principal prioridade documental para os primeiros 90 dias é obter da SEGG inventário de contratos, situação da auditoria e da transição, quadro de pessoal e eventuais pendências legais ou de controle, não detalhados nas fontes. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) [Governo do RJ — regras da transição](http://www.rj.gov.br/radioroquettepinto/node/21550)

## 1. Missão e competências
- Apoiar o Gabinete do Governador e a atuação institucional da Vice-Governadoria.
- Abranger áreas de segurança institucional e apoio militar, conforme as unidades listadas.
- Manter representação do Governo do Estado em Brasília, conforme a unidade SERGB.

## 2. Estrutura essencial
- Titular: Marco Antônio Rodrigues Simões; identificado em relação publicada em junho de 2026, sem confirmação de permanência em 6 de novembro de 2026.
- GSI - Gabinete de Segurança Institucional do Governo do Estado do Rio de Janeiro
- SERGB - SECRET EXTR DE REPRES DO GOV EM BSB
- SMGSI - Subsecretaria Militar do Gab de Seg Inst
- VICE-GOV - VICE-GOVERNADORIA

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 61 contratos, R$ 57,8 mi (+2 'Ativo' sem data de fim válida, R$ 0,2 mi) |
| Vencem em até 30 dias | 6 contratos, R$ 0,1 mi |
| Vencem em até 90 dias | 16 contratos, R$ 4,6 mi (0 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 24 contratos, R$ 24,8 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 5,4 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2022010107 | RENTCON LOCAÇÃO E COMERCIO DE EQUIPAMENTOS  … | O presente procedimento administrativo tem como objeto o pr… | R$ 2.796.900,00 | 01/01/2027 |
| 2024000039 | CS BRASIL FROTAS S.A. | Contratação de serviço para a locação de veículos automotor… | R$ 1.611.720,00 | 16/01/2027 |
| 2025005024 | FUNDAÇÃO GETULIO VARGAS | Inscrição de servidor no Curso de Pós-Graduação LLM Direito… | R$ 38.035,00 | 10/01/2027 |
| 2026006934 | INSTITUTO BRASILEIRO DE DIREITO ADMINISTRATI… | Trata-se de contratação de 10 (dez) vagas para participação… | R$ 22.500,00 | 24/12/2026 |
| 2026007676 | ALTHVA TECNOLOGIA VENDAS E SERVIÇOS LTDA | 10 unidades de Controlador Facial05 unidades de Fonte de Al… | R$ 20.099,00 | 09/11/2026 |
| 2025009864 | MAPFRE SEGUROS GERAIS S/A | Contratação de serviço de Seguro na modalidade R.E.T.A. (Re… | R$ 11.191,27 | 03/12/2026 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 81 (R$ 72,3 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 16 (R$ 4,6 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2024007579 | INSTITUTO NTC DO BRASIL LTDA | R$ 8.061.300,00 | 17/03/2025 |
| 2025006257 | INSTITUTO NTC DO BRASIL LTDA | R$ 7.660.800,00 | 15/11/2025 |
| 2025003697 | INSTITUTO NTC DO BRASIL LTDA | R$ 7.552.768,00 | 28/07/2025 |

## 5. Alertas vermelhos
- 6 contrato(s) vencem em até 30 dias (R$ 0,1 mi).
- Auditoria geral estadual anunciada; as fontes não atribuem irregularidades à SEGG. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml)
- O prazo de transição até 30 de outubro não tem ano informado, e não há confirmação de entrega pela SEGG. [Governo do RJ — regras da transição](http://www.rj.gov.br/radioroquettepinto/node/21550)
- O Decreto nº 50.162/2026 alterou, sem aumento de despesa, a estrutura da SEGG, mas outros detalhes não constam no material. [Boletim GESPERJ — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Boletim%20GESPERJ%20-%20FEVEREIRO%2026.pdf)
- A saída do secretário-chefe de Gabinete foi noticiada em abril de 2026; a fonte não aponta irregularidade específica da SEGG. [G1 — análise de contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)

## 6. Riscos prioritários
- A estatística registra R$ 5.409.494,78 a pagar, sem detalhar vencimentos ou atrasos; é necessário conciliar obrigações e fluxo de caixa.
- Há 24 contratos, somando R$ 24.844.897,06, com término indicado no horizonte de 180 dias; mapear serviços essenciais, decisões de renovação e risco de descontinuidade.
- No horizonte de 90 dias, são 16 contratos e R$ 4.560.122,86. Entre os maiores listados estão 2022010107, de R$ 2.796.900,00, e 2024000039, de R$ 1.611.720,00; confirmar vigência, execução e plano de continuidade.
- A auditoria estadual prevê revisão de despesas, contratos e estrutura, mas as fontes não esclarecem se a SEGG foi incluída especificamente nem apresentam resultados da Secretaria. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml)
- O boletim informa que o Decreto nº 50.162, de 26 de fevereiro de 2026, altera a estrutura da SEGG, mas não detalha as mudanças nem apresenta organograma; o trecho não permite concluir se há lacunas de atribuições ou continuidade na transição. [Boletim GESPERJ — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Boletim%20GESPERJ%20-%20FEVEREIRO%2026.pdf)
- Três contratações recentes listadas para o Instituto NTC do Brasil somam R$ 23.274.868,00; verificar objeto, entregas, pagamentos e justificativa das contratações, sem presumir irregularidade.

## 7. Perguntas-chave para IA externa
1. Quais dos 444 ativos são essenciais à continuidade da SEGG e quais têm responsáveis, plano de contingência e fonte orçamentária identificados?
2. Qual a composição dos R$ 5.409.494,78 registrados como a pagar, com vencimentos, credores, valores liquidados e eventuais parcelas em atraso?
3. No contrato SIGA 2022010107, de R$ 2.796.900,00, qual serviço está contratado, qual a execução atual e qual o plano para o término indicado em 01/01/2027?
4. No contrato SIGA 2024000039, de R$ 1.611.720,00, quantos veículos estão em uso, quais unidades são atendidas e como será garantida a continuidade após 16/01/2027?
5. Qual a execução, entrega e avaliação das contratações com o Instituto NTC do Brasil: 2024007579 (R$ 8.061.300,00), 2025006257 (R$ 7.660.800,00) e 2025003697 (R$ 7.552.768,00)?
6. A SEGG foi incluída entre os órgãos obrigados a apresentar informações no âmbito da auditoria geral estadual? Em caso afirmativo, entregou-as e quais apontamentos, recomendações ou providências foram registrados? [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml)
7. A SEGG comprovou a entrega dos documentos de transição sobre programas, contas e prioridades? Qual é o ano aplicável ao prazo de 30 de outubro? [Governo do RJ — regras da transição](http://www.rj.gov.br/radioroquettepinto/node/21550)
8. Quais mudanças o Decreto nº 50.162/2026 estabeleceu para o organograma, as atribuições, os cargos e as equipes da SEGG, e quais delas foram efetivamente implementadas? [Boletim GESPERJ — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Boletim%20GESPERJ%20-%20FEVEREIRO%2026.pdf)
9. Qual é o titular atual, quais são os responsáveis pelas unidades listadas e quais certidões ou relações atualizadas existem sobre pendências no TCE-RJ, MPRJ e Judiciário?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEGG | Secretaria de Estado do Gabinete do Governador | 61 | R$ 57,8 mi | 16 | R$ 4,6 mi | 0 | Lacunas de informação sobre contratos e governança durante a transição, a verificar; as f… | Validar contratos, pagamentos, auditoria e entregas de transição com a SEGG. |

## Fontes da pesquisa
1. [Governador em exercício do RJ impõe auditoria geral nas ...](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) — 2026-04-15
2. [Choque de transparência no RJ prevê análise de 6,7 mil contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml) — 2026-04-16
3. [Governo do Estado publica decreto com as regras para a transição governamental](http://www.rj.gov.br/radioroquettepinto/node/21550) — 2026-10-14
4. [ PDF  FEVEREIRO/2026 - Governo do Estado do Rio de Janeiro](https://www.rj.gov.br/gesperj/sites/default/files/Boletim%20GESPERJ%20-%20FEVEREIRO%2026.pdf) — 2026-05-16
5. [parte i poder executivo](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/05/Decreto-Estadual-no-49.736-Membos-Comite-LGPD.pdf) — 2026-07-19
6. [16/06/2026 PI160626-S-01___1](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/22-Decreto-Estadual-no-50.332-de-15.06.2026-CGE.pdf) — 2026-08-29
7. [ESTA PARTE É EDITADA](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/05/16-Decreto-de-49989-de-17-de-Novembro-de-2025-SEAPA.pdf) — 2026-07-05

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
