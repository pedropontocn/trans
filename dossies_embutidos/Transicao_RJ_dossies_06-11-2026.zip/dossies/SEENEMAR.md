# Dossiê reduzido — Secretaria de Estado de Energia e Economia do Mar (SEENEMAR)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEENEMAR.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEENEMAR_pesquisa.md`.

## Resumo executivo
- A Seenemar deixou de existir como secretaria independente e foi incorporada à Secretaria de Estado de Desenvolvimento Econômico, Indústria, Comércio e Serviços, conforme incorporação formalizada pelo Decreto nº 50.391, de 21 de julho de 2026. [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62)
- A área de Energia e Economia do Mar permaneceu na estrutura como subsecretaria, com atribuições relativas a petróleo e gás, energia elétrica, transição energética, portos, indústria naval e economia do mar. [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/)
- As fontes não apresentam dados suficientes para avaliar contratos específicos, continuidade de serviços, passivos, processos ou apontamentos de órgãos de controle; esses itens devem ser solicitados à Secretaria antes da posse. [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/)

## 1. Missão e competências
- Atuar nas cadeias de petróleo, gás e biocombustíveis.
- Abranger energia elétrica, eficiência e transição energética.
- Atuar em portos, indústria naval e economia do mar.

## 2. Estrutura essencial
- Titular: a confirmar.
- A pesquisa informa que a Seenemar foi incorporada à Secretaria de Estado de Desenvolvimento Econômico, Indústria, Comércio e Serviços; a área permaneceu como Subsecretaria de Energia e Economia do Mar. [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62)
- Unidades listadas no SIGA: DRM - DEPART RECURSOS MINERAIS ESTADO RJ; SEENEMAR - SECRETARIA DE ESTADO DE ENERGIA E ECONOMIA DO MAR. A situação atual dessas unidades deve ser confirmada.

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 24 contratos, R$ 13,0 mi (+2 'Ativo' sem data de fim válida, R$ 0,0 mi) |
| Vencem em até 30 dias | 2 contratos, R$ 4,7 mi |
| Vencem em até 90 dias | 9 contratos, R$ 6,1 mi (2 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 11 contratos, R$ 8,4 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 0,4 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2026004063 | METTA INDUSTRIA EM SOLUÇÕES AMBIENTAIS LTDA | Contratação de empresa especializada, para o serviço de des… | R$ 4.449.000,00 | 27/11/2026 (PNCP) |
| 2025010823 | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | empresa especializada na prestação de serviços de emissão e… | R$ 1.279.803,20 | 22/12/2026 (PNCP) |
| 2025008388 | AMAZONIA BR SERVICOS ALIMENTACAO LTDA | Contratação de empresa especializada em serviços de aliment… | R$ 242.395,60 | 26/11/2026 |
| 2025009297 | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada para a prestação de se… | R$ 76.050,00 | 10/12/2026 |
| 2025005638 | AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA L… | A presente contratação centralizada tem como objeto a prest… | R$ 33.259,18 | 22/12/2026 |
| 2025005640 | AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA L… | A presente contratação centralizada tem como objeto a prest… | R$ 19.933,55 | 22/12/2026 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 51 (R$ 68,6 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 9 (R$ 6,1 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2024002560 | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL LTDA | R$ 25.398.000,00 | 12/12/2025 |
| 2026000892 | AMBIENTECH SOLUÇÕES EM TECNOLOGIA AMBIENTAL E CON… | R$ 15.193.813,23 | 07/06/2026 |
| 2024010644 | AMBIENTECH SOLUÇÕES EM TECNOLOGIA AMBIENTAL E CON… | R$ 6.992.804,72 | 12/06/2026 |

## 5. Alertas vermelhos
- 2 contrato(s) vencem em até 30 dias (R$ 4,7 mi).
- A Seenemar deixou de existir como secretaria independente e foi incorporada à estrutura de Desenvolvimento Econômico; confirmar a sucessão formal. [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62)
- Há divergência de redação entre a publicação governamental e o decreto sobre a direção da integração; confirmar a estrutura vigente. [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940) [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62)
- A revisão contratual anunciada prevê economia de R$ 715 mil por mês, mas não identifica contratos, empresas ou valores individuais. [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940)
- A pesquisa não informa quem passou a ocupar a titularidade nem como ficaram as delegações após o acúmulo temporário anunciado em julho. [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml)

## 6. Riscos prioritários
- O decreto apresenta a estrutura básica e as subordinações resultantes, mas não identifica titulares nem detalha delegações ou a transição de processos. [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62)
- Continuidade contratual a verificar: contrato 2026004063, de R$ 4.449.000,00, tem término informado em 27/11/2026; objeto de desmantelamento e descomissionamento.
- Contratos com término informado antes da posse podem exigir substituição ou prorrogação: 2025008388, R$ 242.395,60, em 26/11/2026; 2025009297, R$ 76.050,00, em 10/12/2026; 2025005638, R$ 33.259,18, e 2025005640, R$ 19.933,55, ambos em 22/12/2026.
- O SIGA informa R$ 425.509,05 a pagar; sem detalhamento fornecido, há risco de pendências não conciliadas na transferência.
- Revisão e economia contratual anunciadas sem discriminação dos contratos ou valores podem dificultar a validação de cortes, obrigações e continuidade dos serviços. [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940)

## 7. Perguntas-chave para IA externa
1. Qual ato formaliza a sucessão da Seenemar, e quais competências, processos, bens, obrigações e responsabilidades foram transferidos à Secretaria de Desenvolvimento Econômico?
2. Qual é a estrutura institucional vigente, quem é o titular atual e quais delegações e responsáveis foram formalizados após o acúmulo temporário anunciado em julho? [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml)
3. Quais contratos foram abrangidos pela revisão que anunciou economia de R$ 715 mil mensais, e como se chega a esse valor? [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940)
4. Qual é o plano de continuidade, encerramento ou nova contratação para o contrato 2026004063, de R$ 4.449.000,00, com término informado em 27/11/2026?
5. O contrato 2025010823, de R$ 1.279.803,20, com término informado em 22/12/2026, exige prorrogação ou substituição para manter a emissão e entrega de cartões?
6. Qual é a situação do contrato SIGA 2025008388, de R$ 242.395,60, com término informado em 26/11/2026, e como será assegurada a continuidade do serviço de alimentação?
7. Qual é a situação do contrato SIGA 2025009297, de R$ 76.050,00, com término informado em 10/12/2026, e há dependência de serviço compartilhado com outro contrato de cartões?
8. Os contratos SIGA 2025005638, de R$ 33.259,18, e 2025005640, de R$ 19.933,55, com términos informados em 22/12/2026, serão renovados, substituídos ou encerrados?
9. A que contratos, credores e períodos correspondem os R$ 425.509,05 indicados como a pagar, e quais pagamentos ou obrigações serão transferidos?
10. Qual é a relação atualizada de processos no TCE-RJ, procedimentos no MPRJ, ações judiciais, auditorias, recomendações e providências pendentes? [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62)

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEENEMAR | Secretaria de Estado de Energia e Economia do Mar | 24 | R$ 13,0 mi | 9 | R$ 6,1 mi | 0 | Verificar a titularidade, a distribuição de responsabilidades e a reconciliação dos contr… | Formalizar sucessão, designar responsáveis e validar contratos e pagamentos. |

## Fontes da pesquisa
1. [Couto extingue Secretaria de Energia e Economia do Mar   G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) — 2026-07-22
2. [DOERJ 27/08/2026 - Diario Oficial do Estado do RJ - Dia Oficial](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) — 2026-08-27
3. [Secretaria Estadual de Desenvolvimento Econômico publica Regimento Interno e estabelece modelo de governança](https://temporealrj.com/desenvolvimento-economico-regimento-interno/) — 2026-10-27
4. [Post](https://x.com/GovRJ/status/2092968770272669940) — 2026-08-27
5. [Arquivo de destaque - Página 253 de 834 - Tempo Real](https://temporealrj.com/tag/destaque/page/253/) — 2026-11-03

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
