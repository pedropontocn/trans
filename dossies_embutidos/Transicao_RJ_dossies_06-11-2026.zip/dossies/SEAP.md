# Dossiê reduzido — Secretaria de Estado de Administração Penitenciária (SEAP)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEAP.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEAP_pesquisa.md`.

## 1. Missão e competências
- Administrar a política penitenciária e a Polícia Penal no âmbito estadual.
- Garantir a prestação contínua de alimentação e nutrição nas unidades prisionais.
- Gerir serviços e estruturas de segurança e apoio às unidades penitenciárias.

## 2. Estrutura essencial
- Titular: a confirmar; a pesquisa informa nomeação de Alessandra Rosa Odawara em maio de 2026, mas não confirma quem ocupa o cargo atualmente.
- FSCABRINI - FUNDAÇÃO SANTA CABRINI
- FUESP - FUNDO ESPECIAL PENITENCIÁRIO
- SEPPENRJ - SECRETARIA DE ESTADO DE POLICIA PENAL

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 47 contratos, R$ 163,8 mi (+1 'Ativo' sem data de fim válida, R$ 0,3 mi) |
| Vencem em até 30 dias | 10 contratos, R$ 32,0 mi |
| Vencem em até 90 dias | 10 contratos, R$ 32,0 mi (4 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 14 contratos, R$ 32,2 mi |
| Emergenciais vigentes ou sem data de fim | 1 contratos, R$ 19,3 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 60,7 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2025009168 | COMISSARIA AEREA RIO DE JANEIRO LTDA | CONTRATAÇÃO EMERGENCIAL DE EMPRESAS ESPECIALIZADAS NA PREST… (emergencial) | R$ 19.296.236,88 | 07/11/2026 (PNCP) |
| 2025009616 | INDUSTRIA E COMERCIO DE COLCHOES POLAR LTDA | O objeto da presente licitação é o Registro de Preços para … | R$ 5.878.950,00 | 26/11/2026 (PNCP) |
| 2025009058 | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada na prestação de serviç… | R$ 4.063.572,50 | 24/11/2026 (PNCP) |
| 2022007522 | DECISION TEAM LTDA EPP | CONTRATAÇÃO DE EMPRESA PARA PRESTAÇÃO DE SERVIÇOS DE MANUTE… | R$ 1.299.000,00 | 21/11/2026 (DOERJ) |
| 2023009349 | CS BRASIL FROTAS S.A. | Contratação de serviços de locação de veículos de serviço e… | R$ 819.720,00 | 06/12/2026 |
| 2025005950 | X CAR VEICULOS LTDA | Aquisição de veículos especiais novos tipo pick up 4x4 cabi… | R$ 465.800,00 | 19/11/2026 |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 142 (R$ 350,5 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 10 (R$ 32,0 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 0 (R$ 0,0 mi) | 0 | OK |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2021003307 | SPACECOMM MONITORAMENTO S/A | R$ 26.834.731,00 | 04/08/2026 |
| 2019006174 | QUALYBEM FOOD E SERVICE S.A | R$ 25.452.460,44 | 09/10/2025 |
| 2023000381 | APARECIDA REGINA CASSAROTTI | R$ 17.779.980,00 | 31/01/2026 |

## 5. Alertas vermelhos
- 10 contrato(s) vencem em até 30 dias (R$ 32,0 mi).
- 1 contratação(ões) emergencial(is) vigente(s) ou sem data de fim (R$ 19,3 mi): verificar limite de 1 ano (Lei 14.133, art. 75, VIII).
- Contrato emergencial 2025009168 (Comissaria Aérea Rio de Janeiro, refeições para internos custodiados e servidores, R$ 19.296.236,88) tem fim em 07/11/2026 conforme o PNCP, sem termo aditivo publicado, enquanto a licitação de alimentação prisional de R$ 1,3 bilhão foi suspensa pelo TCE-RJ; confirmar imediatamente a cobertura contratual da alimentação a partir de 08/11/2026. [PNCP — contrato 2025/5489](https://pncp.gov.br/app/contratos/42498600000171/2025/5489) [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)
- O TCE-RJ suspendeu a licitação de alimentação prisional estimada em R$ 1,3 bilhão; a pesquisa não confirma contratação substituta nem interrupção do serviço. [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)
- O MPRJ denunciou 22 pessoas por suposta organização criminosa ligada às cantinas; as alegações e o pedido de reparação de R$ 25 milhões não são decisão judicial de mérito. [MPRJ — denúncia sobre cantinas](https://www.mprj.mp.br/visualizar?noticiaId=237301)
- Persistem dúvidas sobre o cumprimento das determinações do TCE-RJ relativas a bens patrimoniais, incluindo bens doados pelo GIFRJ. [Acórdão nº 000864/2026-PLENV — TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026)
- A pesquisa registra superlotação e déficit de vagas, mas não informa quantificação nem plano atualizado de resposta. [G1 — mudança no comando da Polícia Penal](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/25/governador-interino-exonera-secretaria-de-policia-penal-do-rj.ghtml)
- Uma diretora de presídio foi presa preventivamente, exonerada e submetida a PAD após apuração sobre possível destinação irregular de alimentos; o desfecho administrativo não foi informado. [O Dia — prisão de diretora de presídio](https://odia.ig.com.br/rio-de-janeiro/2026/10/7315090-justica-mantem-presa-diretora-de-presidio-flagrada-com-70-kg-de-comida.html)

## 6. Riscos prioritários
- Vários contratos do recorte estatístico têm término indicado em novembro de 2026, antes da posse: 2025009616 (R$ 5.878.950,00; 26/11/2026), 2025009058 (R$ 4.063.572,50; 24/11/2026) e 2022007522 (R$ 1.299.000,00; 21/11/2026); confirmar prorrogações, encerramentos ou substituições.
- Contrato 2021003307 (Spacecomm Monitoramento, monitoramento eletrônico de reeducandos e dispositivos para vítimas de violência doméstica, R$ 26.834.731,00) consta 'Ativo' no SIGA com fim em 04/08/2026 e não está no PNCP; confirmar aditivo ou nova contratação, pois a interrupção afeta tornozeleiras e medidas protetivas. [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV)
- A pesquisa não esclarece cumprimento integral das determinações patrimoniais do TCE-RJ, o estado do inventário e dos registros contábeis nem a implantação da plataforma tratada com o PRODERJ. [Acórdão nº 000864/2026-PLENV — TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026)
- A denúncia sobre cantinas aponta prejuízo superior a R$ 25 milhões aos cofres públicos, e o GAECO requereu a condenação dos denunciados ao pagamento de R$ 25 milhões para reparação; esses fatos podem gerar risco jurídico e de governança. A fonte não informa decisão de mérito nem impactos sobre contratos atuais. [MPRJ — denúncia sobre cantinas](https://www.mprj.mp.br/visualizar?noticiaId=237301)
- As estatísticas informam R$ 60.743.072,93 em valores a pagar, sem detalhamento de credores, vencimentos ou atrasos; é necessário conciliar obrigações e disponibilidade financeira para a transição.

## 7. Perguntas-chave para IA externa
1. Qual era a situação da licitação de alimentação segundo a reportagem de 28/03/2026, e que decisão cautelar e manifestações da Seap foram registradas até então? [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)
2. O contrato emergencial 2025009168, de R$ 19.296.236,88 e com fim indicado em 07/11/2026, foi prorrogado ou substituído? Qual cobertura está assegurada até 01/01/2027?
3. Qual a situação dos contratos 2025009616 (R$ 5.878.950,00; fim indicado em 26/11/2026), 2025009058 (R$ 4.063.572,50; 24/11/2026) e 2022007522 (R$ 1.299.000,00; 21/11/2026)? Há prorrogações, novos procedimentos ou riscos de descontinuidade?
4. Qual a situação atual do contrato 2021003307, de monitoramento eletrônico, no valor de R$ 26.834.731,00, cujo término indicado é 04/08/2026? Há cobertura vigente e plano de continuidade?
5. Como se compõem os R$ 60.743.072,93 registrados como valores a pagar: credores, vencimentos, valores liquidados, atrasos e previsão de pagamento?
6. Quais determinações sobre bens doados pelo GIFRJ, inventário, registros contábeis, planilha patrimonial e norma do SBM-RJ foram consideradas cumpridas, parcialmente atendidas ou não atendidas pelo TCE-RJ? [Acórdão nº 000864/2026-PLENV — TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026)
7. Qual é a situação do levantamento cadastral e projeto de prevenção e combate a incêndio nas unidades prisionais, hospitais penais e órgãos vinculados? [Acórdão nº 000864/2026-PLENV — TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026)
8. Quais medidas administrativas foram adotadas sobre os procedimentos relativos às cantinas e qual é o andamento do PAD referente à destinação de alimentos no Instituto Penal Oscar Stevenson? [MPRJ — denúncia sobre cantinas](https://www.mprj.mp.br/visualizar?noticiaId=237301) [O Dia — prisão de diretora de presídio](https://odia.ig.com.br/rio-de-janeiro/2026/10/7315090-justica-mantem-presa-diretora-de-presidio-flagrada-com-70-kg-de-comida.html)
9. Quem são o titular e a equipe dirigente atuais, e qual o diagnóstico atualizado de ocupação, vagas, quadro de pessoal, passivos e riscos de continuidade dos serviços?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEAP | Secretaria de Estado de Administração Penitenciária | 47 | R$ 163,8 mi | 10 | R$ 32,0 mi | 0 | Descontinuidade da alimentação prisional: o contrato emergencial 2025009168 (refeições pa… | Confirmar hoje a cobertura contratual da alimentação prisional a partir de 08/11/2026 (pr… |

## Fontes da pesquisa
1. [ PDF  ACÓRDÃO Nº 000864/2026-PLENV - TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026) — 2026-06-26
2. [Couto troca comando da Secretaria de Polícia Penal e do ... - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/25/governador-interino-exonera-secretaria-de-policia-penal-do-rj.ghtml) — 2026-05-25
3. [TCE suspende licitação de R$ 1,3 bilhão da Seap para ... - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml) — 2026-03-28
4. [GAECO/MPRJ denuncia e cumpre mandados contra 22 integrantes de organização criminosa que controlava a exploraç](https://www.mprj.mp.br/visualizar?noticiaId=237301) — 2026-09-07
5. [Justiça mantém presa diretora de presídio flagrada com 70 kg de comida   Rio de Janeiro   O Dia](https://odia.ig.com.br/rio-de-janeiro/2026/10/7315090-justica-mantem-presa-diretora-de-presidio-flagrada-com-70-kg-de-comida.html) — 2026-10-22

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
