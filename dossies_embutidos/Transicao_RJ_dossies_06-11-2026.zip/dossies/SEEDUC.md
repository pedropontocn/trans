# Dossiê reduzido — Secretaria de Estado de Educação (SEEDUC)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEEDUC.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEEDUC_pesquisa.md`.

## Resumo executivo
- As fontes relatam investigações e apontamentos de controle sobre obras escolares contratadas sem licitação e pelo sistema descentralizado de pagamento; os valores e irregularidades citados são suspeitas ou achados ainda sujeitos a apuração, não conclusões definitivas de responsabilidade. [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml) [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml)
- O TCE-RJ determinou a suspensão de pagamentos a seis empresas e, segundo reportagem publicada em outubro, contratos de obras estavam suspensos para reavaliação; as fontes não informam o desfecho posterior dessas medidas. [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml) [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)
- O contrato de apoio escolar em Educação Especial terminou em julho de 2026; fontes de setembro descrevem risco de descontinuidade e uma contratação emergencial estimada em R$ 220 milhões, cujo status final não fica esclarecido. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/) [Blog do Ralfe Reis — cuidadores nas escolas](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/)
- Roberta Barreto deixou a Secretaria em 24 de fevereiro de 2026; as fontes não identificam quem a sucedeu nem detalham a transição administrativa. [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml)

## 1. Missão e competências
- Conduzir a política estadual de educação.
- Atuar na oferta e no apoio à Rede Pública Estadual de Ensino.
- Promover apoio pedagógico e suporte a estudantes da Educação Especial.

## 2. Estrutura essencial
- Titular: a confirmar.
- Unidades listadas no SIGA: SEEDUC - SECRETARIA DE ESTADO DE EDUCAÇÃO; NOVO DEGASE - Dep Geral de Ações Socioeducativas.

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 178 contratos, R$ 1,92 bi (+5 'Ativo' sem data de fim válida, R$ 5,1 mi) |
| Vencem em até 30 dias | 19 contratos, R$ 46,9 mi |
| Vencem em até 90 dias | 108 contratos, R$ 754,0 mi (26 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 138 contratos, R$ 1,33 bi |
| Emergenciais vigentes ou sem data de fim | 1 contratos, R$ 159,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 447,2 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2025000431 | CAPITAL AMBIENTAL CONSTRUÇÃO E SERVIÇOS LTDA | Contratação de empresa para prestar junto à Secretaria de E… | R$ 129.217.957,73 | 04/02/2027 |
| 2025000432 | INFINITY MULTISERVIÇOS LTDA | Contratação de empresa para prestar junto à Secretaria de E… | R$ 121.489.222,80 | 04/02/2027 |
| 2025010945 | FUNDAÇÃO DE APOIO A PESQUISA, ENSINO E ASSIS… | A presente contratação visa dar prosseguimento na segunda f… | R$ 97.796.253,26 | 29/12/2026 (PNCP) |
| 2025000430 | BLUEL RJ OPERACOES EM SERVICOS E ALIMENTACAO… | Contratação de empresa para prestar junto à Secretaria de E… | R$ 76.289.917,72 | 04/02/2027 |
| 2025000429 | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | Contratação de empresa para prestar junto à Secretaria de E… | R$ 58.197.626,16 | 04/02/2027 |
| 2026003049 | AGUAS DO RIO 4 SPE S.A | Contratação de empresa para prestação de serviços de fornec… | R$ 33.440.197,32 | 05/01/2027 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 289 (R$ 3,34 bi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 108 (R$ 754,0 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 3 (R$ 4,6 mi) | 0 | Alerta |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2025000251 | EUREKA SOLUCOES PEDAGOGICAS LTDA | R$ 334.336.436,93 | 21/01/2026 |
| 2024005560 | INSTITUTO POSITIVA SOCIAL | R$ 154.704.000,00 | 18/07/2026 |
| 2025002089 | EBN COMERCIO, IMPORTACAO E EXPORTACAO EIRELI | R$ 146.576.381,70 | 01/04/2026 |

## 5. Alertas vermelhos
- 19 contrato(s) vencem em até 30 dias (R$ 46,9 mi).
- 1 contratação(ões) emergencial(is) vigente(s) ou sem data de fim (R$ 159,0 mi): verificar limite de 1 ano (Lei 14.133, art. 75, VIII).
- 3 contrato(s) com data de fim impossível no SIGA (R$ 4,6 mi): 2015005178 PLANEJAR TERCEIRIZAÇÃO E SERVIÇOS EIRELI (fim 15/10/2105); 2024003402 INSTITUTO ANJOS MAURA DE OLIVEIRA (fim 13/01/2193); 2014004598 IMPRENSA OFICIAL DO ESTADO DO RIO DE JA… (fim 31/08/3014). Corrigir o cadastro e confirmar a vigência real no processo SEI.
- Obras escolares: reportados R$ 1,6 bilhão em contratações sem licitação entre 2023 e 2025, com indícios ainda sujeitos a apuração. [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)
- O TCE-RJ determinou suspender pagamentos a seis empresas; as fontes não informam o resultado posterior das medidas. [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml)
- Apoio à Educação Especial: o contrato terminou em julho de 2026, e as fontes não esclarecem se a contratação emergencial estimada em R$ 220 milhões foi assinada. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/)
- Em 1º de outubro de 2026, foi noticiada operação sobre suspeitas de fraude em contratos da SEEDUC; a investigação não equivale a condenação. [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml)
- A pesquisa relata baixa rastreabilidade de pagamentos do sistema descentralizado de obras e ausência de um total consolidado por empresa. [G1 — TCE abre inquérito](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/02/06/tce-abre-inquerito-para-investigar-obras-em-escolas-estaduais-do-rj-pagas-por-sistema-descentralizado.ghtml)

## 6. Riscos prioritários
- A matéria relata que o contrato com o Instituto Positiva Social terminou em julho e que a contratação emergencial estimada em R$ 220 milhões foi travada por auditoria interna. A Seeduc, por sua vez, afirmou que o processo estava prestes a ser concluído. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/)
- O TCE determinou a suspensão de pagamentos a seis empresas e deu à Secretaria Estadual de Educação quinze dias para se manifestar sobre as irregularidades. A Secretaria informou que iniciou uma revisão administrativa dos procedimentos relacionados a obras, sem divulgar prazo para concluí-la ou impactos por escola. [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml)
- Exposição financeira e necessidade de conciliação: o SIGA/PNCP informa R$ 447.204.680,34 a pagar; a pesquisa não encontrou demonstrativo consolidado de passivos, restos a pagar ou valores devidos a fornecedores.
- Vencimentos próximos da posse: entre os contratos destacados, o 2026003049, de R$ 33.440.197,32, termina em 05/01/2027; os contratos 2025000431, 2025000432, 2025000430 e 2025000429 têm término informado em 04/02/2027. Confirmar continuidade, saldo e providências de contratação.
- Possível lacuna em serviços emergenciais de limpeza: os contratos 2024004521, 2024004523 e 2024004520 somam R$ 66.341.121,00 e têm término informado em 02/10/2025; verificar situação atual e cobertura substituta, sem presumir que estejam vigentes.
- Contratos de obras foram suspensos para reavaliação; em Realengo, uma obra de escola cívico-militar está abandonada, embora já devesse estar pronta. A página não informa repasses relacionados à revisão nem cronogramas atualizados, e não apresenta uma lista completa das escolas afetadas. [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)

## 7. Perguntas-chave para IA externa
1. Quem é o titular atual da SEEDUC, quem responde por contratos e controle interno e qual plano de transição estará disponível para 01/01/2027?
2. Qual é o status, saldo a pagar, execução e plano de continuidade dos contratos 2025000431 (R$ 129.217.957,73), 2025000432 (R$ 121.489.222,80), 2025000430 (R$ 76.289.917,72) e 2025000429 (R$ 58.197.626,16), com término informado em 04/02/2027?
3. Qual é a situação do contrato 2026003049, de R$ 33.440.197,32, com término informado em 05/01/2027, e quais medidas asseguram o fornecimento de água após essa data?
4. Qual é o status de execução, saldo e entrega do contrato 2025010945, de R$ 97.796.253,26, com término informado em 29/12/2026?
5. Os contratos emergenciais 2024004521, 2024004523 e 2024004520, que totalizam R$ 66.341.121,00, têm término informado em 16/06/2025 para os dois primeiros. Para o contrato 2024004520, há divergência entre as datas registradas: 04/09/2026 e 02/09/2026. Eles foram encerrados, prorrogados ou substituídos? Quais instrumentos asseguram a continuidade da limpeza?
6. Qual é a situação atual do apoio escolar na Educação Especial? A Secretaria tentou uma dispensa emergencial estimada em R$ 220 milhões, mas a fonte não esclarece se a contratação foi concluída, quantos profissionais estão ativos ou qual é o cronograma da licitação ordinária de R$ 648 milhões. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/)
7. Qual o saldo, os pagamentos realizados e a situação de entrega do contrato 2024005560, de R$ 154.704.000,00, com término informado em 18/07/2026?
8. Quais decisões, manifestações e providências posteriores foram adotadas sobre a suspensão de pagamentos a seis empresas e a reavaliação das obras? Solicitar inventário por contrato, empresa, escola, valor pago, saldo e cronograma. [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml)
9. Como se compõe o valor de R$ 447.204.680,34 informado como a pagar, por credor, contrato, vencimento e exercício, e como se concilia com restos a pagar e passivos?
10. Qual a situação de entrega e pagamento dos contratos 2025000251 (R$ 334.336.436,93), 2024005560 (R$ 154.704.000,00) e 2025002089 (R$ 146.576.381,70), listados entre os maiores valores da categoria nv24, que reúne contratos ativos com vigência encerrada nos últimos 24 meses?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEEDUC | Secretaria de Estado de Educação | 178 | R$ 1,92 bi | 108 | R$ 754,0 mi | 0 | Descontinuidade de serviços essenciais e obras sob revisão, com passivos ainda não concil… | Obter posição contratual, financeira e operacional atualizada antes da posse. |

## Fontes da pesquisa
1. [Operação Escola de Papel: Ex-secretária do RJ é alvo por fraudes   G1](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml) — 2026-10-01
2. [Dez empresas concentram um terço das contratações sem licitação na reforma bilionária de escolas pelo Governo ](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml) — 2026-10-01
3. [Governo de Ricardo Couto deixa estudantes da Educação Especial nas escolas estaduais sem cuidadores - Blog do ](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/) — 2026-09-16
4. [temporealrj.com › educacao-especial-sem-contratoGoverno do estado deixa contrato vencer, tenta emergencial de ](https://temporealrj.com/educacao-especial-sem-contrato/) — 2026-09-14
5. [TCE-RJ manda suspender repasses para obras em escolas ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml) — 2026-04-22
6. [TCE abre inquérito para investigar obras em escolas estaduais do RJ](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/02/06/tce-abre-inquerito-para-investigar-obras-em-escolas-estaduais-do-rj-pagas-por-sistema-descentralizado.ghtml) — 2026-02-06

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
