# Dossiê reduzido — Secretaria de Estado de Defesa Civil (SEDEC)

**Referência:** 06/11/2026 · **Status do dossiê:** Preenchido com dados públicos (SIGA, PNCP, pesquisa web). Validar com os dados recebidos da secretaria.
**Fontes:** [Base SIGA de contratos](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) (extraída em 06/11/2026), [PNCP](https://pncp.gov.br) e pesquisa web com citações (lista ao final).
**Dossiê completo:** `dossies_automaticos/DOSSIE_SEDEC.md`. Pesquisa integral: `dossies_automaticos/pesquisas/SEDEC_pesquisa.md`.

## Resumo executivo
- A auditoria externa independente dos contratos da Defesa Civil foi exigida pelo governador interino Ricardo Couto como condição para manter Tarciso Salles como secretário e comandante-geral, mas as fontes não informam se a auditoria foi contratada, concluída ou quais foram seus resultados. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml)
- O relatório anual de atividades registra auditoria de contratos de combustíveis e manutenção de postos internos de abastecimento como concluída, e auditoria da gestão do RAS com relatório preliminar encaminhado, sem resultado conclusivo informado. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- Há recomendações do TCE-RJ com status “Implementado” e recomendações SIAUDI ainda “Respondido/em Análise (Pendente)”, conforme o relatório disponibilizado. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- As fontes também registram uma ação civil sobre obras no quartel do 2º GMar ainda submetida ao Judiciário e uma ação penal militar contra um coronel, sem que isso permita concluir por culpa definitiva. [Diário eletrônico do MPF](https://transparencia.mpf.mp.br/conteudo/diarios-e-boletins/diario-eletronico-dmpf-e/2026/DMPF-EXTRAJUDICIAL-2026-06-09.pdf/at_download/file) [G1 — coronel réu por coação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/05/coronel-dos-bombeiros-reu-por-coacao.ghtml)

## 1. Missão e competências
- Atuação em Defesa Civil.
- Atuação relacionada ao Corpo de Bombeiros Militar do Estado do Rio de Janeiro.

## 2. Estrutura essencial
- Titular: Tarciso Salles, citado como secretário e comandante-geral; situação atual a confirmar.
- FUNESBOM - FUNDO ESPECIAL DO CORPO DE BOMBEIROS
- SEDEC - Sec Est Def Civil e Corpo Bomb Militar

## 3. Investimentos e contratos
| Indicador | Valor |
|---|---|
| Contratos com data de fim futura (SIGA/PNCP) | 783 contratos, R$ 559,6 mi (+11 'Ativo' sem data de fim válida, R$ 4,2 mi) |
| Vencem em até 30 dias | 61 contratos, R$ 37,0 mi |
| Vencem em até 90 dias | 165 contratos, R$ 74,6 mi (9 com data confirmada no PNCP/DOERJ) |
| Vencem em até 180 dias | 323 contratos, R$ 210,5 mi |
| Emergenciais vigentes ou sem data de fim | 0 contratos, R$ 0,0 mi |
| Liquidado e não pago (acumulado SIGA) | R$ 58,2 mi |

Maiores contratos que vencem em até 90 dias:

| Contrato SIGA | Fornecedor | Objeto | Valor | Fim |
|---|---|---|---|---|
| 2024001494 | ENGE PRAT ENGENHARIA E SERVIÇOS LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇ… | R$ 14.960.938,65 | 24/01/2027 |
| 2025009401 | BEM ESTAR HOSPITALAR COMÉRCIO DE EQUIPAMENTO… | Aquisição de viaturas tipo ASE | R$ 11.494.440,00 | 24/11/2026 (PNCP) |
| 2022000508 | BRAVO ASSESSORIA E SERVICOS EMPRESARIAIS LTDA | lIMPEZA DAS UNIDADES DE SAÚDE CO CBMERJ. | R$ 7.891.968,75 | 15/01/2027 |
| 2025009915 | HPE AUTOMOTORES DO BRASIL LTDA | Aquisição de viaturas tipo AR | R$ 6.235.443,00 | 04/12/2026 (PNCP) |
| 2023009798 | FUNDAÇÃO DE ENSINO E PESQUISA DO SUL DE MINAS | contratação de uma Instituição de Ensino Superior reconheci… | R$ 5.767.488,00 | 23/11/2026 |
| 2024009106 | HELICÓPTEROS DO BRASIL S/A | Contratação de empresa especializada na prestação de serviç… | R$ 5.108.973,95 | 12/11/2026 (PNCP) |

## 4. Indicadores críticos
| Indicador | Valor | Meta | Status |
|---|---|---|---|
| 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses | 1343 (R$ 596,2 mi) | 0 | Alerta |
| Rescisão crível no PNCP e ainda 'Ativo' no SIGA | 0 (R$ 0,0 mi) | 0 | OK |
| Vencimentos até 90 dias | 165 (R$ 74,6 mi) | Renovação/licitação definida | Alerta |
| Datas de fim inválidas no SIGA (ano > 2100 ou vigência > 40 anos) | 4 (R$ 0,2 mi) | 0 | Alerta |
| Fornecedores em recuperação judicial | 0 | 0 | OK |
| Contratos sem fiscal/gestor designado | Não consta no SIGA | 0 | Solicitar à secretaria |
| Obras paralisadas / desvio de cronograma | Não consta no SIGA | 0 | Solicitar à secretaria |

Maiores contratos 'Ativo' com vigência encerrada (confirmar aditivo ou execução sem cobertura):

| Contrato SIGA | Fornecedor | Valor | Fim no SIGA |
|---|---|---|---|
| 2025004930 | ANGLOCO LIMITED | R$ 77.000.000,00 | 11/06/2026 |
| 2022004828 | ENGE PRAT ENGENHARIA E SERVIÇOS LTDA | R$ 29.901.202,67 | 23/06/2026 |
| 2025007278 | MARDISA VEÍCULOS LTDA | R$ 28.380.000,00 | 12/09/2026 |

## 5. Alertas vermelhos
- 61 contrato(s) vencem em até 30 dias (R$ 37,0 mi).
- 4 contrato(s) com data de fim impossível no SIGA (R$ 0,2 mi): 2018002245 MACAU INDÚSTRIA E COMÉRCIO LTDA (fim 31/12/2108); 2018001018 CONCESSIONÁRIA ÁGUAS DE JUTURNAÍBA S/A (fim 31/12/2108); 2025000168 MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS… (fim 17/11/2193); 2018002195 ESPECIFARMA COMERCIO DE MEDICAMENTOS E … (fim 31/01/2201). Corrigir o cadastro e confirmar a vigência real no processo SEI.
- Auditoria externa dos contratos foi exigida em julho de 2026, mas as fontes não comprovam contratação, execução ou resultados. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml)
- Recomendações SIAUDI dos relatórios 0347 e 606e aparecem como “Respondido/em Análise (Pendente)”. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- A auditoria da gestão do RAS tem relatório preliminar encaminhado, sem resultado conclusivo informado. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- A legalidade das obras no quartel do 2º GMar segue em ação civil; a ausência de liminar não encerra a controvérsia. [Diário eletrônico do MPF](https://transparencia.mpf.mp.br/conteudo/diarios-e-boletins/diario-eletronico-dmpf-e/2026/DMPF-EXTRAJUDICIAL-2026-06-09.pdf/at_download/file)
- Ação penal militar contra Lauro César Botto Maia por supostos crimes de coação; denúncia aceita não equivale a condenação. [G1 — coronel réu por coação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/05/coronel-dos-bombeiros-reu-por-coacao.ghtml)
- Os contratos de mais de R$ 86 milhões citados na investigação do Instituto Rio Metrópole não são atribuídos à SEDEC ou ao CBMERJ. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml)

## 6. Riscos prioritários
- Concentração de vencimentos próxima à transição: 61 contratos somam R$ 36.995.971,43 com vencimento em até 30 dias e 165 somam R$ 74.649.872,03 em até 90 dias; priorizar análise de continuidade e substituição.
- O valor informado a pagar é R$ 58.165.983,31; sem detalhamento de credores, vencimentos e atrasos, há risco de planejamento financeiro incompleto.
- O contrato 2024001494, de R$ 14.960.938,65, tem término indicado para 24/01/2027, após a posse; confirmar execução, saldo e plano de continuidade.
- O contrato 2025009401, de R$ 11.494.440,00, para aquisição de viaturas tipo ASE, tem término indicado para 24/11/2026; verificar entrega, pagamento e encerramento antes da transição.
- O G1 informa que foi exigida uma auditoria externa dos contratos da Defesa Civil, mas não apresenta comprovação de sua execução nem resultados. O RANAT 2025 registra recomendações SIAUDI com status “Respondido/em Análise (Pendente)”. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml) [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- A legalidade das obras do 2º GMar na Praia do Pepê é discutida em ação civil pública ainda em curso, sem liminar de paralisação, conforme deliberação do MPF. [Diário eletrônico do MPF](https://transparencia.mpf.mp.br/conteudo/diarios-e-boletins/diario-eletronico-dmpf-e/2026/DMPF-EXTRAJUDICIAL-2026-06-09.pdf/at_download/file)

## 7. Perguntas-chave para IA externa
1. A auditoria externa independente exigida em julho de 2026 foi contratada ou realizada? Qual o escopo, responsável, cronograma, relatório e providências adotadas?
2. Qual é a lista atualizada dos 61 contratos com vencimento em até 30 dias e dos 165 com vencimento em até 90 dias, incluindo objeto, unidade, saldo, execução e plano de continuidade?
3. No contrato 2024001494, de R$ 14.960.938,65, com término indicado em 24/01/2027, qual o saldo, estágio da obra, pagamentos pendentes e necessidade de prorrogação ou nova contratação?
4. No contrato 2025009401, de R$ 11.494.440,00, para viaturas tipo ASE, qual o status de entrega, recebimento, pagamento e encerramento previsto para 24/11/2026?
5. Qual a situação de entrega e encerramento dos contratos 2025009915, de R$ 6.235.443,00, para viaturas tipo AR, e 2024009106, de R$ 5.108.973,95, de serviços em aeronaves AS350, com términos indicados para 04/12/2026 e 12/11/2026?
6. Os contratos 2025004930, de R$ 77.000.000,00, para viaturas tipo ABSL, e 2025007278, de R$ 28.380.000,00, para viaturas multimissões, indicam términos em 11/06/2026 e 12/09/2026; qual o status atual de execução, recebimento, pagamentos e eventuais pendências?
7. Como se compõe o valor de R$ 58.165.983,31 a pagar, por credor, contrato, vencimento, atraso e unidade, e qual a previsão de liquidação?
8. Qual o relatório final da auditoria do RAS e quais ações encerraram as recomendações SIAUDI 0347 e 606e ainda registradas como pendentes?
9. Qual o estágio atualizado da ação civil sobre as obras do 2º GMar e quais são o cronograma, os contratos relacionados e os possíveis impactos operacionais?

## 8. Linha para ingestão
| id_orgao | nome_orgao | contratos_vigentes | valor_vigente | vencem_90d | valor_90d | rescindidos_pncp | principal_risco | acao_prioritaria |
|---|---|---|---|---|---|---|---|---|
| SEDEC | Secretaria de Estado de Defesa Civil | 783 | R$ 559,6 mi | 165 | R$ 74,6 mi | 0 | Vencimentos contratuais próximos à posse sem plano de continuidade comprovado. | Validar vencimentos, pagamentos e continuidade dos contratos antes da posse. |

## Fontes da pesquisa
1. [Auditoria na Defesa Civil RJ é condição para manter Tarciso ...](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml) — 2026-07-17
2. [ PDF  DIÁRIO DO MINISTÉRIO PÚBLICO FEDERAL ELETRÔNICO](https://transparencia.mpf.mp.br/conteudo/diarios-e-boletins/diario-eletronico-dmpf-e/2026/DMPF-EXTRAJUDICIAL-2026-06-09.pdf/at_download/file) — 2026-11-04
3. [Coronel dos bombeiros investigado por assédio vira réu por ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/05/coronel-dos-bombeiros-reu-por-coacao.ghtml) — 2026-08-05
4. [Relatório Anual de Atividades – RANAT 2025 DADOS GERAIS ...](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf) — 2026-10-21

## Limitações
- O SIGA nem sempre reflete prorrogações. As datas marcadas (PNCP) ou (DOERJ) foram confirmadas; as demais são do SIGA.
- Contratos da Lei 8.666/1993 não estão no PNCP; contratos de gestão (OS), convênios e concessões podem não estar no SIGA.
- A pesquisa web foi sintetizada por modelo de linguagem a partir das fontes listadas; confirme fatos críticos na fonte original.
