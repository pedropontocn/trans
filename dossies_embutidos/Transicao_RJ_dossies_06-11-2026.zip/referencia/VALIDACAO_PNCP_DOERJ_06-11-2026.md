# Validação de vigências — PNCP e documentos oficiais (06/11/2026)

Gerado em 06/11/2026 pela equipe (Perplexity Computer). Base: SIGA (CONTRATOS.CSV, extraído em 06/11/2026) cruzado com o Portal Nacional de Contratações Públicas (PNCP) e com documentos oficiais publicados na web.

## Resumo

Revisado em 06/11/2026, após a revisão de qualidade. A versão anterior deste relatório contava 29 contratos rescindidos no PNCP, mas 25 deles eram termos classificados como rescisão por erro de cadastro. Os números abaixo já estão corrigidos.

- Universo crítico: contratos "Ativo" ou "Em Alteração", com valor de R$ 500 mil ou mais e fim entre 24 meses atrás e 180 dias à frente.
- O pipeline consultou na API oficial do PNCP os contratos críticos que têm link para o portal no SIGA (cerca de 1.880 contratos, todos da Lei 14.133).
- 1.860 contratos tiveram a vigência conferida no PNCP:
  - 1.764 (R$ 11,29 bi) têm a mesma data no SIGA e no PNCP, ou seja, a data foi confirmada;
  - 80 (R$ 804,5 mi) não tinham data de fim no SIGA, e o PNCP forneceu a data. Desses, 39 já venceram (R$ 183,3 mi) e 7 vencem em até 90 dias (R$ 43,2 mi);
  - 12 (R$ 88,0 mi) tiveram prorrogação publicada no PNCP que não aparece no SIGA (9 delas com mais de 5 dias de diferença);
  - 4 (R$ 27,0 mi) têm rescisão crível publicada no PNCP.
- Em 25 contratos (R$ 261,6 mi), o termo cadastrado como rescisão foi desconsiderado. O motivo foi um destes:
  - o termo foi publicado muitos meses antes da própria data de fim (em geral no início do contrato);
  - houve termo aditivo publicado depois dele.
- Em 12 contratos o PNCP mostra fim anterior ao SIGA, sem rescisão válida. Foi mantida a data do SIGA, com a divergência registrada para conferência no processo SEI.
- 31 contratos têm data de fim impossível no SIGA, com anos entre 2102 e 9201, somando R$ 47,1 mi. Eles passaram a ser tratados como "sem data" e geram alerta de correção de cadastro.
- Continuam sem confirmação 1.164 contratos críticos (R$ 17,33 bi), quase todos da Lei 8.666/1993, que não estão no PNCP:
  - 128 vencem em até 90 dias (R$ 1,80 bi);
  - 937 aparecem vencidos no SIGA nos últimos 24 meses (R$ 12,64 bi).
- Na busca web em documentos oficiais foram pesquisados 53 contratos:
  - 2 tiveram a data confirmada e 5 têm confirmação provável;
  - há 5 correções manuais em `pipeline/config/correcoes_vigencia.csv`.

## Como as datas aparecem nos dossiês

| Marca na coluna "Fim" | Significado |
|---|---|
| (PNCP) | Data conferida no último termo publicado no PNCP |
| (PNCP: rescindido) | Termo de Rescisão crível no PNCP (publicado perto do encerramento ou depois dele, sem aditivo posterior) |
| (SIGA, diverge do PNCP) | O PNCP mostra fim anterior ao do SIGA sem rescisão válida. Conferir no processo SEI |
| (DOERJ) | Data confirmada em documento oficial e registrada em `correcoes_vigencia.csv` |
| sem marca | Data apenas do SIGA, sem confirmação |

## Rescisões críveis no PNCP (contratos ainda "Ativo" no SIGA)

| Secretaria | Contrato SIGA | Contratada | Objeto | Valor | Rescisão | Link PNCP |
|---|---|---|---|---|---|---|
| SECC | 2025010736 | FXX Segurança e Transporte de Valores | Vigilância patrimonial emergencial | R$ 24,8 mi | 20/06/2026 | [PNCP 2025/6461](https://pncp.gov.br/app/contratos/42498600000171/2025/6461) |
| SECC | 2025009178 | Academia Brasileira de Letras | Locação temporária de imóvel | R$ 1,0 mi | 04/08/2026 | [PNCP 2025/5924](https://pncp.gov.br/app/contratos/42498600000171/2025/5924) |
| SECTI | 2024008825 | Renal Tec | Manutenção de osmose reversa | R$ 0,6 mi | 12/11/2025 | [PNCP 2024/3179](https://pncp.gov.br/app/contratos/42498600000171/2024/3179) |
| SECTI | 2024005811 | Lifetex | Aventais estéreis (dispensa) | R$ 0,5 mi | 02/08/2025 | [PNCP 2024/1588](https://pncp.gov.br/app/contratos/42498600000171/2024/1588) |

Nos quatro casos, a data da rescisão coincide com o fim previsto no SIGA. Na prática, são encerramentos que o SIGA não baixou. A vigilância emergencial da SECC (R$ 24,8 mi) merece a pergunta: qual contrato substituiu esse serviço depois de 20/06/2026?

### Termos de rescisão desconsiderados (provável erro de cadastro no PNCP)

Os maiores casos são estes:
- SEHIS 2025010152, Abre Construções, R$ 49,2 mi: houve aditivos depois do termo.
- SES 2024004113, Monteiro & Rodriguez, R$ 39,9 mi.
- SES 2024008159, JP Construções, R$ 38,2 mi.
- SEEDUC 2024004521 e 2024004523, Agile Corp, R$ 47,4 mi no total.
- SES 2024007762, Eco Rio, R$ 21,0 mi.

Nesses contratos, o termo "de rescisão" foi publicado no início da vigência, com data de fim igual ao fim original. O padrão é de extrato do contrato cadastrado com o tipo errado. A vigência considerada é a do contrato ou dos aditivos.

## Prorrogações encontradas no PNCP e ausentes do SIGA

| Secretaria | Contrato SIGA | Contratada | Valor | Fim SIGA | Fim PNCP |
|---|---|---|---|---|---|
| SEEDUC | 2024009154 | Agile Corp (emergencial) | R$ 31,4 mi | 13/11/2025 | 28/07/2026 |
| SEIOP | 2025001979 | Econorte | R$ 7,1 mi | 06/05/2026 | 03/09/2027 |
| SECID | 2025002097 | Civilport (ponte do Roncador) | R$ 5,2 mi | 02/10/2026 | 01/12/2026 |
| SES | 2025000529 | COI Clínicas Oncológicas (radioterapia) | R$ 3,7 mi | 27/02/2026 | 27/02/2027 |
| SES | 2025001445 | Rio Med Equipamentos Biomédicos | R$ 2,0 mi | 07/03/2027 | 03/09/2028 |
| SES | 2025000525 | Oncomed (radioterapia) | R$ 1,5 mi | 27/02/2026 | 27/02/2027 |
| SECTI | 2024008654 | Edwards Lifesciences | R$ 1,4 mi | 28/11/2025 | 03/09/2026 |
| SES | 2024002674 | Max Clean Lavanderia (emergencial) | R$ 0,9 mi | 17/04/2025 | 03/09/2027 |
| SECTI | 2024005240 | Bhio Supply (emergencial) | R$ 0,7 mi | 18/07/2025 | 01/09/2026 |

Ponto de atenção: alguns emergenciais foram prorrogados por longos períodos, como Max Clean na SES e Agile Corp na SEEDUC. Vale verificar o limite de 1 ano do art. 75, VIII, da Lei 14.133.

## Divergências PNCP x SIGA (sem rescisão válida)

São 12 contratos. Os principais:

| Secretaria | Contrato SIGA | Contratada | Fim PNCP | Fim SIGA | Link |
|---|---|---|---|---|---|
| SEPM | 2025008496 | Lecard (cartões) | 20/10/2026 | 18/11/2026 | [PNCP 2025/5121](https://pncp.gov.br/app/contratos/42498600000171/2025/5121) |
| SECTI | 2025003073 | UERJ | 02/12/2025 | 04/05/2026 | [PNCP 2025/2099](https://pncp.gov.br/app/contratos/42498600000171/2025/2099) |
| SECTI | 2024007915 | BAM Comércio e Serviço | 06/10/2025 | 21/07/2026 | [PNCP 2024/2536](https://pncp.gov.br/app/contratos/42498600000171/2024/2536) |
| SECTI | 2024009640 | Vyttra Diagnósticos | 01/12/2025 | 04/08/2026 | [PNCP 2024/3462](https://pncp.gov.br/app/contratos/42498600000171/2024/3462) |
| SECTI | 2024009704 e 2024009707 | Labinbraz e Up Med | 05/12/2025 | 07/08/2026 | [PNCP 2024/3559](https://pncp.gov.br/app/contratos/42498600000171/2024/3559) |
| SEDEICS | 2024008397 | IBAP | 03/11/2025 | 22/01/2026 | [PNCP 2024/3058](https://pncp.gov.br/app/contratos/42498600000171/2024/3058) |

A lista completa está nos alertas vermelhos de cada dossiê.

## Confirmações em documentos oficiais (busca web)

| Secretaria | Contrato | Resultado | Fonte |
|---|---|---|---|
| SECID | 001/2023 MUVI (SIGA 2023000622) | Fim em 08/12/2026 (6º TA) | [DOERJ/SEIOP](https://www.rj.gov.br/seiop/sites/default/files/arquivos_pagina_basica/IOERJTraceableFile690de041a69ca_0.pdf) |
| SECID | 016/2023 (SIGA 2023001703) | Fim em 21/05/2026 | [DOERJ/SEIOP](https://www.rj.gov.br/seiop/sites/default/files/arquivos_pagina_basica/IOERJTraceableFile690de041a69ca_0.pdf) |
| SECID | 064/2022 (SIGA 2022009355) | Fim em 25/05/2026 | [CGE-RJ](https://cge.rj.gov.br/wp-content/uploads/2025/09/1a-PUBLICACAO-CITACAO-NIVALDO-NASCIMENTO.pdf) |
| SEAP | 75/2022 Decision Team, geradores (SIGA 2022007522) | Fim em 21/11/2026. Prorrogação não localizada | [Planilha oficial da Polícia Penal](https://www.rj.gov.br/policiapenalrj/sites/default/files/arquivos_paginas/Planilha%20Portal%20da%20Transpar%C3%AAncia%20-%20ATUALIZADA%2021-05-2026%20-%20COOCONT.pdf) |
| SETRAM | 003/2024 CODERTE / Green Card (SIGA 2024000115) | 2º TA prorroga até 24/01/2027 | [AGETRANSP](https://www.agetransp.rj.gov.br/interno/regulatory-sessions/qKWavYi3UG4EyjEOF26EGiws4aA9OmzAcVTSyFAS.pdf) |
| SEAS | 002/2023 Volume Eventos (SIGA 2023002225) | Há TA de prorrogação, mas sem data legível. SIGA indica 16/03/2026 | [SEAS](https://www.rj.gov.br/seas/sites/default/files/arquivos_paginas/16.1%20VOLUME%20-%20Termo%20Aditivo%20e%20publica%C3%A7%C3%A3o.pdf) |
| SECC/DETRAN | 002/2022 M.I. Montreal (SIGA 2022000020) | 1º TA prorroga, sem data no trecho lido | [PRODERJ](https://www.rj.gov.br/proderj/sites/default/files/arquivos-andamento/CONTRATOS_PART5_EMPRESA%20MI%20MONTREAL.pdf) |
| SEGG | 046/2022 Rentcon (SIGA 2022010107) | 3º TA é só quantitativo, sem nova data | [Subsecretaria Militar](https://www.subsecmilitar.rj.gov.br/sites/default/files/2026-10/3%C2%BA%20Termo%20Aditivo.pdf) |
| SETRAM | 03/2025 Omega (SIGA 2025002339) | Contrato localizado, sem data de fim no trecho | [SETRANS](https://www.rj.gov.br/transporte/sites/default/files/arquivos_paginas/Contrato%20032025%20-%20Muros%20-%20%C3%94mega.pdf) |
| SEFAZ | 024/2021 Claro (SIGA 2021006496) | Contrato localizado, sem aditivo | [SEFAZ](https://portal.fazenda.rj.gov.br/licitacoes/wp-content/uploads/sites/44/2023/10/Claro_Contrato024.2021.pdf) |

## O que continua sem confirmação

Os 1.156 contratos críticos da Lei 8.666/1993 não estão no PNCP, e o DOERJ não tem API pública. Os de maior valor são os contratos de gestão da SES com organizações sociais. Exemplos:
- Fundação Saúde, 2022002602: R$ 1,29 bi, fim no SIGA em 28/02/2025.
- Instituto de Desenvolvimento, Ensino e Assistência, 2022000866: R$ 664,5 mi, fim no SIGA em 31/07/2025.
- Vários outros contratos de gestão do mesmo instituto terminam em 31/07/2025 ou 31/07/2026.

Recomendação: pedir à SES e à SEEDUC a planilha de aditivos vigentes, com número do termo e data de publicação no DOERJ. Depois, registrar as datas em `correcoes_vigencia.csv`.

## Método

1. O pipeline (`pipeline/transicao_rj.py`) lê o campo "URL PNCP" do SIGA. Para cada contrato crítico, ele consulta `https://pncp.gov.br/pncp-api/v1/orgaos/42498600000171/contratos/<ano>/<seq>` e o endpoint `/termos`. O cache dura 3 dias, em `_cache/pncp/`.
2. A data adotada é a do último termo publicado (por data de publicação) que não seja de rescisão. Um Termo de Rescisão só é considerado se cumprir duas condições: (a) ter sido publicado no máximo 120 dias antes da própria data de fim, ou depois dela; (b) não ter termo aditivo publicado depois. Se o PNCP indicar fim anterior ao do SIGA sem rescisão válida, mantém-se o SIGA e a divergência é registrada. Datas posteriores a 2100 são descartadas, no PNCP e no SIGA. No SIGA também se descartam vigências de mais de 40 anos.
3. A conferência de qualidade de 06/11/2026 consultou de novo, ao vivo e sem cache, 42 contratos: as 29 rescisões originais e os maiores vencimentos em 30 e 90 dias. Todos bateram com o PNCP, exceto a divergência já registrada da Lecard (SEPM).
4. As correções manuais (`correcoes_vigencia.csv`) têm prioridade sobre o PNCP e o SIGA.
5. Para os contratos fora do PNCP, foi feita busca web por documentos oficiais, com leitura e extração do trecho relevante. Só foram registradas as confirmações com número do contrato, contratada e data legível.
