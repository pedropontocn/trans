# Revisão de qualidade do pacote — Transição RJ

> Atualizado em 06/11/2026: a seção "Segunda etapa" foi acrescentada. Ela cobre todas as demais seções dos dossiês.

**Data:** 06/11/2026 · **Escopo:** 31 dossiês reduzidos (`dossies/`), consolidação estadual, 32 dossiês automáticos e painel (`dossies_automaticos/`), 31 pesquisas aprofundadas, relatório de validação PNCP/DOERJ e pipeline.

## Resumo

- Os números de contratos e vencimentos foram recalculados de forma independente a partir da base bruta do SIGA. Os valores dos dossiês batem com esse recálculo em todas as 31 secretarias.
- Uma nova consulta ao PNCP, ao vivo e sem cache, conferiu 42 contratos. Os 42 batem com os dossiês. A única diferença, no contrato da Lecard (SEPM), já estava registrada como divergência.
- O relatório anterior apontava 29 contratos rescindidos no PNCP e ainda ativos no SIGA, somando R$ 288,5 mi. **Esse número estava errado.** Só 4 rescisões são críveis, somando R$ 27,0 mi. Os outros 25 termos estavam cadastrados como rescisão por erro no PNCP. A regra foi corrigida no pipeline e o relatório `VALIDACAO_PNCP_DOERJ_06-11-2026.md` foi reescrito.
- Foram verificadas, uma a uma, as 380 afirmações das seções de alertas vermelhos e riscos, contra o texto das fontes citadas:
  - 273 confirmadas e 42 com imprecisão menor;
  - 37 com erro relevante, todas corrigidas;
  - 6 não confirmadas e 21 que eram só "ausência de informação", não alerta; essas foram removidas;
  - 1 com fonte inacessível, mantida.
- Ao todo, 79 textos foram reescritos e 27 removidos.

## Contagem atual (31 secretarias, sem autônomos)

| Indicador | Quantidade | Valor |
|---|---|---|
| Contratos "Ativo" com data de fim futura | 6.806 | R$ 22,46 bi |
| Vencem em até 90 dias | 2.053 | R$ 4,14 bi |
| Rescisão crível no PNCP e ainda "Ativo" no SIGA | 4 | R$ 27,0 mi |
| Data de fim inválida no SIGA (ano maior que 2100 ou vigência maior que 40 anos) | 30 (31 com autônomos) | R$ 47,1 mi |
| Emergenciais vigentes ou sem data de fim | 34 | R$ 247,4 mi |

Os dossiês automáticos contam como "vigentes" também os contratos "Ativo" sem data de fim. Os reduzidos mostram essa parcela à parte: "N contratos com data de fim futura (+M sem data de fim válida)". Por isso os totais dos dois podem diferir.

## Método

1. **Checagem estrutural** dos 102 arquivos .md. Foram procurados:
   - emojis, pontos de exclamação e marcadores pendentes (TODO, PREENCHER, campos vazios entre chaves);
   - texto com codificação corrompida;
   - links dos dossiês reduzidos que não estejam na lista de fontes da pesquisa.

   Os dois "TODO" encontrados fazem parte de nomes de fornecedores no SIGA, como "SOMOS TODOS", e não são pendências.
2. **Recálculo independente** (`/tmp/qa/recalc.py`): o script lê o CSV bruto do SIGA e recalcula as contagens de 30 e 90 dias e de vencidos em 24 meses, sem usar o código do pipeline. As faixas de 30 e 90 dias batem com os dossiês nas 31 secretarias. Na SEDEC e na SETRAM, a contagem de vencidos em 24 meses difere em 1 contrato, por causa do limite exato de 730 dias.
3. **Conferência ao vivo no PNCP**: 42 contratos, que incluem as 29 rescisões originais e os maiores vencimentos em 30 e 90 dias.
4. **Verificação das afirmações da pesquisa**, em duas rodadas:
   - Na primeira, as 380 afirmações foram lidas contra o texto das fontes.
   - Na segunda, as 151 não confirmadas foram verificadas de novo, com extração dirigida dos trechos de cada fonte. A primeira rodada tinha falsos negativos em páginas longas, como acórdãos do TCE-RJ e diários oficiais.
   - Cada afirmação recebeu um veredito, e as correções mantêm só o que a fonte sustenta.

## Erros corrigidos no pipeline

| Problema | Efeito | Correção |
|---|---|---|
| Termos do PNCP não eram ordenados por data de publicação | O "último termo" podia ser um termo antigo | Ordenação por `dataPublicacaoPncp` |
| Qualquer "Termo de Rescisão" encerrava o contrato | 25 contratos (R$ 261,6 mi) apareciam como rescindidos, por exemplo SEHIS Abre Construções, SES Monteiro & Rodriguez, JP Construções, Eco Rio, SEEDUC Agile e SETRAM ANDEF (termo com fim em 2193) | A rescisão só vale se for publicada no máximo 120 dias antes do próprio fim (ou depois dele) e se não houver aditivo posterior. As desconsideradas ficam anotadas em `termos_pncp` |
| Datas impossíveis no SIGA, como 09/10/5015 (SES 2015003720) e 2124 (SEDEICS 2021003139) | Contratos apareciam como vigentes por milênios | Novo alerta "data de fim inválida", e a data passa a ser tratada como ausente. Contratos legítimos de longo prazo, como concessões até 2056, são mantidos |
| Filtro de emergenciais pegava pregões e objetos com "atendimento de urgências e emergências" | Contagem inflada | Nova regra `eh_emergencial()` |
| Codificação corrompida em campos do SIGA, por exemplo "SaudÃ¡vel" | Texto ilegível | `sem_mojibake()` aplicado a todos os campos |
| PNCP com fim anterior ao do SIGA e sem rescisão | Datas encurtadas sem base | Mantém-se a data do SIGA, com a marca "(SIGA, diverge do PNCP)" |

## Principais correções nos alertas de pesquisa

- **SECEC:** a notícia do STF sobre o prazo de reestruturação é de 19/10/2026, não de 05/11/2026.
- **SEAP:**
  - Foram removidas duas afirmações sobre os contratos 2021003307 e 2025009168, porque a reportagem citada não fala deles.
  - Os mesmos fatos voltaram ao dossiê com citação ao SIGA/PNCP. O emergencial de alimentação prisional (Comissaria Aérea, R$ 19,3 mi) termina em 07/11/2026, sem aditivo no PNCP, e a licitação de R$ 1,3 bi está suspensa pelo TCE-RJ. **É o alerta mais imediato do pacote.**
  - O monitoramento eletrônico (Spacecomm, R$ 26,8 mi) aparece no SIGA com fim em 04/08/2026.
- **SES:** a afirmação "dano de R$ 3.593.225,20 à época dos fatos" foi confirmada no acórdão TCE-RJ 771/2026. Foi corrigida a mistura de valores atualizados de etapas diferentes. O risco sobre contratos de gestão foi reescrito: 2022002602 (R$ 1,294 bi), 2022000866 (R$ 664,5 mi) e 2024002523 (R$ 466,3 mi) aparecem com vigência encerrada no SIGA.
- **SEIOP:** o valor de R$ 217.923,11 (Peri Formas) foi confirmado. A redação foi corrigida: trata-se de solicitação de disponibilidade orçamentária para Termo de Ajuste de Contas, não de dívida reconhecida. A apuração foi determinada em 17/03/2025, e não pelo Acórdão 9981/2026.
- **SEAS:**
  - O TCE-RJ determinou a suspensão da contratação do Instituto Chaya; não "suspendeu relações".
  - As exonerações citadas são de 157 cargos da SEGOV e 12 lideranças do Inea, não de 250 servidores.
  - Já foram liquidados 77,81% do contrato.
- **SECTI:** a fonte registra o compromisso de recriar a secretaria, não a recriação concluída. Os valores citados são o total dos contratos, não o custo para concluir as obras.
- **SETUR:** os 25 eventos perderam o apoio financeiro do Estado, mas não foram necessariamente cancelados.
- **SEPM:** o valor de R$ 73,0 mi não está na fonte citada e foi retirado.
- **SEGOV:** foi mantida a exoneração de 385 dos 487 cargos comissionados. Foi retirada a inferência de perda de capacidade, que a fonte não sustenta.
- **SEM:** foi corrigido um link do G1 que a reescrita automática tinha alterado.
- **SECTI:** foi corrigido o link do MPRJ (domínio `mprjemnuvem.mprj.mp.br`).
- **SEIJES:** foi corrigida a codificação de "Saudável".

O registro completo dos vereditos, com o texto original, o problema encontrado e o texto corrigido, ficou na área de trabalho da revisão. Pode ser reproduzido sob pedido.

## Limitações que permanecem

- **Contratos sem confirmação.** 1.164 contratos críticos (R$ 17,33 bi) não puderam ser conferidos no PNCP, porque são em sua maioria da Lei 8.666/1993. Eles se dividem em:
  - 128 que vencem em até 90 dias (R$ 1,80 bi);
  - 937 que aparecem vencidos nos últimos 24 meses (R$ 12,64 bi), provavelmente por aditivos não lançados ou falta de baixa no SIGA.

  A confirmação depende do processo SEI ou do DOERJ.
- **Cadastro do PNCP.** O próprio PNCP tem erros de cadastro: rescisões no início do contrato e datas no século XXII. A regra nova reduz o problema, mas não o elimina.
- **Prorrogações de emergenciais.** Alguns emergenciais foram prorrogados por longos períodos, como Max Clean (SES) até 2027 e Agile Corp (SEEDUC). Vale verificar o limite de 1 ano do art. 75, VIII, da Lei 14.133.
- **Afirmações da pesquisa.** A pesquisa web reflete o que as fontes publicaram até 06/11/2026. As afirmações de investigação (PF, MPRJ, TCE-RJ) descrevem apurações, não condenações.

## Segunda etapa: demais seções dos dossiês

Nesta etapa foram revistas todas as seções que ainda não tinham passado por verificação afirmação a afirmação:
- nas pesquisas aprofundadas: Resumo executivo, Contratos e serviços críticos, Pendências legais e de controle, Riscos de apagão administrativo, Fatos recentes e Lacunas da pesquisa;
- nos dossiês reduzidos: Missão, Estrutura, Perguntas-chave, Principal risco e Ação prioritária.

### Método

1. **Afirmações com link (916):** para cada fonte citada, foram extraídos os trechos literais necessários para verificar as afirmações que a citam. São 164 páginas, consultadas novamente em 06/11/2026. Cada afirmação foi então julgada contra esses trechos, com os mesmos vereditos da primeira etapa.
2. **Itens sem link (554):** missão, estrutura, perguntas, principal risco e ação prioritária foram conferidos contra a pesquisa já verificada e as estatísticas do SIGA/PNCP de cada secretaria. Os 103 itens sinalizados passaram por uma segunda conferência, com o registro completo no SIGA (objeto, fornecedor, valor, datas, modalidade) de cada contrato citado.
3. **Remoções:** toda remoção proposta foi conferida manualmente na fonte. Duas eram falsos negativos causados por páginas longas e foram restauradas: as falhas do edital de alimentação apontadas pelo TCE-RJ (SEAP) e o Contrato 031/2021 do MIS (SEIOP). A segunda foi ajustada para deixar claro que a advertência consta nas alegações dos defendentes.
4. **Proteção de links:** nenhum texto corrigido pode introduzir link que não estivesse no texto original. Depois da aplicação, todos os links dos dossiês e pesquisas foram conferidos contra as listas de fontes da pesquisa.

### Resultado

| Grupo | Total | Confirmado ou coerente | Lacuna coerente | Imprecisão menor | Erro relevante | Não confirmado |
|---|---|---|---|---|---|---|
| Pesquisa: demais seções | 876 | 475 | 279 | 19 | 101 | 2 (restaurados após checagem manual) |
| Dossiê reduzido: itens com link | 40 | 4 | 29 | 0 | 7 | 0 |
| Dossiê reduzido: itens sem link | 554 | 501 | — | — | 52 corrigidos | 1 removido |

Ao todo, 120 trechos das pesquisas e 53 itens dos dossiês reduzidos foram reescritos, e 4 perguntas foram removidas.

### Tipos de erro mais frequentes

- **Afirmação mais forte do que a fonte.** Exemplos:
  - SECTI: um compromisso de recriar a secretaria foi tratado como recriação concluída.
  - SEDCON: "175 empresas alvo de penalidades" foi tratado como multas já aplicadas.
  - SEAPA: mandados que ainda estavam sendo cumpridos foram dados como cumpridos.
  - SEAP e SEEL: a fonte não sustentava a qualificação de "principal risco".
- **Pessoas e cargos.** SECC: a coordenação da transição é atribuída pela fonte à secretária das Cidades. A comissão é coordenada pela Casa Civil e presidida por Flávio de Araújo Willeman.
- **Datas.** Exemplos:
  - SEDIPAF: a data de publicação do decreto no DOERJ não está confirmada; 14/07/2026 é a data da reportagem.
  - SEEL: a resolução é de 26/03/2026, mas foi publicada em 27/03/2026.
  - SECEC: o PLANAT 2022 não existe na fonte; para 2022 há apenas o RANAT.
- **Perguntas com estatísticas antigas.** Algumas perguntas dos dossiês reduzidos citavam números de emergenciais e de rescisões anteriores às correções do pipeline. Exemplos: "11 contratos rescindidos" na SES, emergenciais de R$ 6,98 mi na SETD, de R$ 2,49 mi na SECEC e de R$ 516 mil na SEPLAG. Essas perguntas foram removidas ou reescritas com os números atuais.
- **SEAP:** o principal risco e a ação prioritária foram reescritos para refletir o fim do emergencial de alimentação prisional em 07/11/2026.

O registro completo (texto original, problema, texto corrigido) ficou na área de trabalho da revisão. Pode ser reproduzido sob pedido.

### O que continua fora da verificação

- **Seções 1 a 12 dos dossiês automáticos.** São tabelas geradas diretamente da base do SIGA e do PNCP. Foram validadas pelo recálculo independente e pela conferência ao vivo da primeira etapa, não por leitura de fontes web.
- **Lista "Fontes consultadas".** É a lista de links usada pela pesquisa e não contém afirmações.
