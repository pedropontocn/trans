# Dossiê de transição — Secretaria de Estado de Administração Penitenciária / Polícia Penal (SEAP)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/seap)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 706 | R$ 1.183.275.228,46 |
| Com vigência futura (válidos no SIGA) | 48 | R$ 164.152.641,47 |
| até 30 dias | 10 | R$ 32.020.949,10 |
| até 60 dias | 0 | R$ 0,00 |
| até 90 dias | 0 | R$ 0,00 |
| até 180 dias | 4 | R$ 172.360,50 |
| vencido no SIGA | 658 | R$ 1.019.122.586,99 |
| sem data | 1 | R$ 311.520,00 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 1 | R$ 19.296.236,88 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 822,0 mi / R$ 529,6 mi / R$ 471,5 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2025009168 (COMISSARIA AEREA RIO DE JANEIRO LTDA) vence em 07/11/2026 — 1 dias — R$ 19.296.236,88. Objeto: CONTRATAÇÃO EMERGENCIAL DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SERVIÇO CONT…
- Contrato 2022007522 (DECISION TEAM LTDA EPP) vence em 21/11/2026 — 15 dias — R$ 1.299.000,00. Objeto: CONTRATAÇÃO DE EMPRESA PARA PRESTAÇÃO DE SERVIÇOS DE MANUTENÇÃO PARA GRUPO DE G…
- Contrato 2025009058 (LECARD ADMNISTRADORA DE CARTÕES LTDA) vence em 24/11/2026 — 18 dias — R$ 4.063.572,50. Objeto: Contratação de empresa especializada na prestação de serviços de emissão e entr…
- Contrato 2025009616 (INDUSTRIA E COMERCIO DE COLCHOES POLAR LTDA) vence em 26/11/2026 — 20 dias — R$ 5.878.950,00. Objeto: O objeto da presente licitação é o Registro de Preços para aquisição de colchõe…
- Mais 6 contratos menores (R$ 1,5 mi) vencem em até 30 dias — ver seção 3.
- 13 contratos (R$ 32,1 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 142 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 350,5 mi); 14 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 516 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 668,6 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- 1 contratações emergenciais vigentes (R$ 19,3 mi). Verificar prazo máximo legal (1 ano, Lei 14.133 art. 75 VIII) e licitação substitutiva.
- Concentração: A.C.F. DA SILVA LTDA detém 45% do valor vigente (1 contratos).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025009168 | SEPPENRJ | COMISSARIA AEREA RIO DE JANEIRO LTDA | CONTRATAÇÃO EMERGENCIAL DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SE… | R$ 19.296.236,88 | 07/11/2026 (PNCP) | 1 |
| 2022007937 | SEPPENRJ | CLARO S/A (FILIAL) | Contratação de empresas especialiadas na prestação de serviços de tel… | R$ 179.859,90 | 08/11/2026 | 2 |
| 2025005950 | SEPPENRJ | X CAR VEICULOS LTDA | Aquisição de veículos especiais novos tipo pick up 4x4 cabine dupla c… | R$ 465.800,00 | 19/11/2026 | 13 |
| 2025008464 | SEPPENRJ | SERVICO AUTONOMO DE CAPTACAO DE AGUA E TRATA… | O presente Termo de Referência tem por objetivo descrever a contrataç… | R$ 849,82 | 19/11/2026 | 13 |
| 2022007522 | SEPPENRJ | DECISION TEAM LTDA EPP | CONTRATAÇÃO DE EMPRESA PARA PRESTAÇÃO DE SERVIÇOS DE MANUTENÇÃO PARA … | R$ 1.299.000,00 | 21/11/2026 (DOERJ) | 15 |
| 2025007250 | SEPPENRJ | TIMELAB LTDA | Sistema de acompanhamento e de controle de processos de vistoria e re… | R$ 15.960,00 | 24/11/2026 | 18 |
| 2025009058 | SEPPENRJ | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada na prestação de serviços de emis… | R$ 4.063.572,50 | 24/11/2026 (PNCP) | 18 |
| 2025009616 | SEPPENRJ | INDUSTRIA E COMERCIO DE COLCHOES POLAR LTDA | O objeto da presente licitação é o Registro de Preços para aquisição … | R$ 5.878.950,00 | 26/11/2026 (PNCP) | 20 |
| 2025010104 | SEPPENRJ | TOVÁ COMÉRCIO DE PNEUS LTDA | Credenciamento de empresas para prestação de serviços continuados de … | R$ 1.000,00 | 02/12/2026 | 26 |
| 2023009349 | SEPPENRJ | CS BRASIL FROTAS S.A. | Contratação de serviços de locação de veículos de serviço e utilitári… | R$ 819.720,00 | 06/12/2026 | 30 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026001521 | SEPPENRJ | RETA DE ITAGUAI AUTO PEÇAS LTDA | Credenciamento de pessoas jurídicas especializadas para prestação de … | R$ 1.000,00 | 05/03/2027 | 119 |
| 2025009217 | SEPPENRJ | AUTARQUIA COMERCIO E SAUDE ANIMAL LTDA | aquisição de arraçoamento canino, para atender as necessidades do Gru… | R$ 69.240,50 | 18/03/2027 | 132 |
| 2025003245 | FSCABRINI | PONTO A PONTO TELECOMUNICAÇÕES DO BRASIL EIR… | Contratação de empresa especializada para prestação de Serviço Telefô… | R$ 16.800,00 | 20/03/2027 | 134 |
| 2026000222 | FSCABRINI | BANCO DO BRASIL S/A | Contratação de instituição financeira oficial para disponibilização d… | R$ 85.320,00 | 28/04/2027 | 173 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2021003307 | SEPPENRJ | SPACECOMM MONITORAMENTO S/A | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA PRESTAÇÃO DOS SERVIÇOS DEMO… | R$ 26.834.731,00 | 04/08/2026 | -94 |
| 2019006174 | SEPPENRJ | QUALYBEM FOOD E SERVICE S.A | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM FORNECIMENTO DE ALIMENTAÇÃO P… | R$ 25.452.460,44 | 09/10/2025 | -393 |
| 2023000381 | SEPPENRJ | APARECIDA REGINA CASSAROTTI | CONTRATAÇÃO DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SERVIÇO CONTÍN… | R$ 17.779.980,00 | 31/01/2026 | -279 |
| 2023000392 | SEPPENRJ | QUALYBEM FOOD E SERVICE S.A | CONTRATAÇÃO DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SERVIÇO CONTÍN… | R$ 15.975.912,48 | 31/01/2026 | -279 |
| 2023000389 | SEPPENRJ | QUALYBEM FOOD E SERVICE S.A | CONTRATAÇÃO DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SERVIÇO CONTÍN… | R$ 15.499.999,49 | 31/01/2026 | -279 |
| 2023000383 | SEPPENRJ | LOCASEM SERVIÇOS DE LIMPEZA, MANUTENÇÃO E AL… | CONTRATAÇÃO DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SERVIÇO CONTÍN… | R$ 14.542.448,88 | 31/01/2026 | -279 |
| 2023000380 | SEPPENRJ | APARECIDA REGINA CASSAROTTI | CONTRATAÇÃO DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SERVIÇO CONTÍN… | R$ 14.399.986,08 | 31/01/2026 | -279 |
| 2023000388 | SEPPENRJ | QUALYBEM FOOD E SERVICE S.A | CONTRATAÇÃO DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SERVIÇO CONTÍN… | R$ 12.999.994,08 | 31/01/2026 | -279 |
| 2019005644 | SEPPENRJ | COMISSARIA AEREA RIO DE JANEIRO LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM FORNECIMENTO DE ALIMENTAÇÃO P… | R$ 12.999.915,60 | 06/11/2025 | -365 |
| 2023000379 | SEPPENRJ | APARECIDA REGINA CASSAROTTI | CONTRATAÇÃO DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SERVIÇO CONTÍN… | R$ 12.698.993,04 | 31/01/2026 | -279 |
| 2024000354 | SEPPENRJ | VERONA SERVICOS LTDA | CONTRATAÇÃO DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SERVIÇO CONTÍN… | R$ 11.401.609,44 | 31/01/2026 | -279 |
| 2023000391 | SEPPENRJ | QUALYBEM FOOD E SERVICE S.A | CONTRATAÇÃO DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SERVIÇO CONTÍN… | R$ 11.256.984,00 | 31/01/2026 | -279 |
| 2023007730 | SEPPENRJ | REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | ¿CONTRATAÇÃO DE EMPRESA PARA LOCAÇÃO DE VEÍCULOS DE REPRESENTAÇÃO BLI… | R$ 10.032.000,00 | 16/10/2025 | -386 |
| 2023000393 | SEPPENRJ | SELETA SALADAS LTDA | CONTRATAÇÃO DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SERVIÇO CONTÍN… | R$ 10.014.181,20 | 31/01/2026 | -279 |
| 2023000382 | SEPPENRJ | APARECIDA REGINA CASSAROTTI | CONTRATAÇÃO DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SERVIÇO CONTÍN… | R$ 9.494.996,40 | 31/01/2026 | -279 |
| 2024000353 | SEPPENRJ | VERONA SERVICOS LTDA | CONTRATAÇÃO DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SERVIÇO CONTÍN… | R$ 9.410.248,32 | 31/01/2026 | -279 |
| 2023008521 | SEPPENRJ | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | Gestão do abastecimento de frota por intermédio de postos internos e … | R$ 6.572.586,14 | 02/06/2026 | -157 |
| 2022001338 | SEPPENRJ | CLARO S/A (FILIAL) | Contratação de empresa especializada no ramo de Telecomunicações, par… | R$ 6.203.769,12 | 27/02/2026 | -252 |
| 2022007223 | SEPPENRJ | TECHBIZ FORENSE DIGITAL S/A | Contratação de serviços técnicos especializados em solução para foren… | R$ 5.513.265,80 | 09/10/2025 | -393 |
| 2021005503 | SEPPENRJ | AGUAS DO PARAIBA SA | Fornecimento de água e tratamento de esgoto nas Unidades Prisionais e… | R$ 5.489.941,17 | 09/11/2024 | -727 |
| 2025001526 | SEPPENRJ | INDEPENDÊNCIA ADMINISTRADORA DE BENS S/A | 1.1 O presente Termo de Referência destina-se a LOCAÇÃO DE IMÓVEL par… | R$ 4.896.144,00 | 19/03/2026 (PNCP) | -232 |
| 2024003642 | SEPPENRJ | A.C.F. DA SILVA LTDA | Contratação emergencial, com base no art. 75, VIII da Lei Geral de Li… | R$ 4.799.983,20 | 06/06/2025 (PNCP) | -518 |
| 2023007548 | SEPPENRJ | AMPLA ENERGIA E SERVIÇOS S/A | serviços de caráter continuado de fornecimento de energia elétrica po… | R$ 4.482.249,42 | 23/11/2024 | -713 |
| 2024006150 | SEPPENRJ | INBRA-TECNOLOGIA E DEFESA INDUSTRIA E COMERC… | Adesão a Ata de Registro de Preços nº 25/2024 da SENAPPEN, para aquis… | R$ 3.957.358,00 | 18/08/2025 | -445 |
| 2023005355 | SEPPENRJ | DELURB AMBIENTAL LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇO CONTÍNUO… | R$ 3.939.516,00 | 21/07/2026 | -108 |
| 2021005394 | SEPPENRJ | RESTAURANTE NOVA RODOVIA 2007 LTDA | SERVICO DE PREPARO DE ALIMENTACAO, DESCRICAO: CONTRATACAO DEEMPRESA P… | R$ 3.889.820,00 | 24/10/2025 | -378 |
| 2025000723 | SEPPENRJ | ISRAEL WEAPON INDUSTRIES (I.W.I) LTD | Aquisição de 300 (trezentas) carabinas cal. 5,56, para atender a dema… | R$ 3.861.666,00 | 27/05/2026 | -163 |
| 2025001189 | SEPPENRJ | GLOCK AMÉRICA S.A | O objeto da presente licitação é a aquisição, por meio de licitação i… | R$ 3.860.256,00 | 05/06/2026 (PNCP) | -154 |
| 2024006286 | SEPPENRJ | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Contratação de empresa especializada para fornecer serviço de suporte… | R$ 3.457.015,00 | 14/08/2026 | -84 |
| 2024009824 | SEPPENRJ | RC CARD SOLUCOES EM PAGAMENTOS LTDA | Contratação de empresa especializada na prestação de serviços de emis… | R$ 3.112.800,00 | 05/01/2026 (PNCP) | -305 |

_Registros mais antigos (provável falta de baixa no SIGA): 516, R$ 668,6 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026009041 | SEPPENRJ | A.C.F. DA SILVA LTDA | Contratação de empresa especializada na prestação deserviço contínuo … | R$ 73.832.729,76 | 05/11/2028 | 730 |
| 2025007884 | SEPPENRJ | IMC TECNOLOGIA EM SEGURANAÇA LTDA | Consumo da ata SRP 0013/2025/250100-00 | R$ 30.434.429,52 | 19/11/2028 | 744 |
| 2025009168 | SEPPENRJ | COMISSARIA AEREA RIO DE JANEIRO LTDA | CONTRATAÇÃO EMERGENCIAL DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SE… | R$ 19.296.236,88 | 07/11/2026 (PNCP) | 1 |
| 2025009315 | SEPPENRJ | DE NIGRIS DISTRIBUIDORA DE VEICULOS LTDA. | Aquisição de veículos operacionais, tipo VAN, adaptados para transpor… | R$ 12.624.000,00 | 08/06/2027 | 214 |
| 2024002050 | SEPPENRJ | INTERIMAGEM TECNOLOGIA, CONSTRUÇAO E ENERGIA… | contratação de SOLUÇÃO INTEGRADA DE CAPTAÇÃO, ARMAZENAMENTO, TRANSMIS… | R$ 6.066.000,00 | 07/10/2027 | 335 |
| 2025009616 | SEPPENRJ | INDUSTRIA E COMERCIO DE COLCHOES POLAR LTDA | O objeto da presente licitação é o Registro de Preços para aquisição … | R$ 5.878.950,00 | 26/11/2026 (PNCP) | 20 |
| 2025009058 | SEPPENRJ | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada na prestação de serviços de emis… | R$ 4.063.572,50 | 24/11/2026 (PNCP) | 18 |
| 2022007522 | SEPPENRJ | DECISION TEAM LTDA EPP | CONTRATAÇÃO DE EMPRESA PARA PRESTAÇÃO DE SERVIÇOS DE MANUTENÇÃO PARA … | R$ 1.299.000,00 | 21/11/2026 (DOERJ) | 15 |
| 2026003954 | FSCABRINI | INSTITUTO HOLÍSTICO INTEGRAÇÃO - IHI | Contratação de pessoa jurídica OSC para realizar ações de ministrar c… | R$ 1.181.279,00 | 28/05/2027 | 203 |
| 2026001961 | FSCABRINI | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | Contratação de empresa especializada na prestação de serviços de impl… | R$ 955.695,00 | 02/06/2027 | 208 |
| 2026003594 | FSCABRINI | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | O presente Termo de Referência tem por objetivo estabelecer de forma … | R$ 897.900,00 | 29/05/2027 | 204 |
| 2023009349 | SEPPENRJ | CS BRASIL FROTAS S.A. | Contratação de serviços de locação de veículos de serviço e utilitári… | R$ 819.720,00 | 06/12/2026 | 30 |
| 2025004049 | FSCABRINI | GUARAILHA DISTRIBUIDORA DE ALIMENTOS LTDA EPP | Aquisição de gêneros alimentícios e de panificação, para atender às d… | R$ 795.705,47 | 17/06/2027 | 223 |
| 2026006050 | FSCABRINI | F C VIANA MATERIAIS E SERVICOS LTDA | AQUISIÇÃO DE MATERIAIS DE MANUTENÇÃO PREDIAL POR MEIO DE PREGÃO ELETR… | R$ 752.500,00 | 21/10/2028 | 715 |
| 2025003104 | FSCABRINI | CS BRASIL FROTAS S.A. | O objeto do presente procedimento é a contratação de serviços de loca… | R$ 702.303,24 | 22/07/2028 | 624 |
| 2025004095 | FSCABRINI | LCV PINHEIRO COMÉRCIO DE GÊNEROS ALIMENTÍCIOS | Aquisição de gêneros alimentícios e de panificação, para atender às d… | R$ 669.330,85 | 16/06/2027 | 222 |
| 2026003959 | FSCABRINI | INSTITUTO QUALITY - CENTRO DE FORMAÇÃO DE PR… | Contratação de serviços de qualificação profissional em manutenção e … | R$ 666.750,00 | 28/05/2027 | 203 |
| 2025005950 | SEPPENRJ | X CAR VEICULOS LTDA | Aquisição de veículos especiais novos tipo pick up 4x4 cabine dupla c… | R$ 465.800,00 | 19/11/2026 | 13 |
| 2025003105 | FSCABRINI | LOCADORA GRILLO E RIBEIRO LTDA | O objeto do presente procedimento é a contratação de serviços de loca… | R$ 349.755,47 | 22/07/2028 | 624 |
| 2025004037 | FSCABRINI | R3M IMPORTACAO E DISTRIBUICAO LTDA | Aquisição de gêneros alimentícios e de panificação, para atender às d… | R$ 325.364,48 | 16/06/2027 | 222 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025009168 | SEPPENRJ | COMISSARIA AEREA RIO DE JANEIRO LTDA | CONTRATAÇÃO EMERGENCIAL DE EMPRESAS ESPECIALIZADAS NA PRESTAÇÃO DE SE… | R$ 19.296.236,88 | 07/11/2026 (PNCP) | 1 |

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| A.C.F. DA SILVA LTDA | 1 | R$ 73.832.729,76 |
| IMC TECNOLOGIA EM SEGURANAÇA LTDA | 1 | R$ 30.434.429,52 |
| COMISSARIA AEREA RIO DE JANEIRO LTDA | 1 | R$ 19.296.236,88 |
| DE NIGRIS DISTRIBUIDORA DE VEICULOS LTDA. | 1 | R$ 12.624.000,00 |
| INTERIMAGEM TECNOLOGIA, CONSTRUÇAO E ENERGIA LTDA | 1 | R$ 6.066.000,00 |
| INDUSTRIA E COMERCIO DE COLCHOES POLAR LTDA | 1 | R$ 5.878.950,00 |
| LECARD ADMNISTRADORA DE CARTÕES LTDA | 1 | R$ 4.063.572,50 |
| CS BRASIL FROTAS S.A. | 3 | R$ 1.760.453,35 |
| DECISION TEAM LTDA EPP | 1 | R$ 1.299.000,00 |
| INSTITUTO HOLÍSTICO INTEGRAÇÃO - IHI | 1 | R$ 1.181.279,00 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2018002389 | ALIMENTAÇÃO GLOBAL SERVICE LTDA ME | R$ 19.396.640,11 | R$ 13.094.196,82 | R$ 6.302.443,29 |
| 2018005727 | O UNIVERSITARIO REST IND COM E AGROP LTDA | R$ 12.705.864,90 | R$ 8.096.909,85 | R$ 4.608.955,05 |
| 2018005721 | CIAL COMERCIO E INDUSTRIA DE ALIMENTOS LTDA | R$ 11.005.407,00 | R$ 7.000.896,00 | R$ 4.004.511,00 |
| 2018005734 | NUTRYENERGE REFEIÇÕES INDUSTRIAIS LTDA. (MAT… | R$ 11.201.398,40 | R$ 7.224.809,95 | R$ 3.976.588,45 |
| 2018005726 | PREMIER COMÉRCIO DE ALIMENTOS LTDA | R$ 10.053.863,54 | R$ 6.393.733,64 | R$ 3.660.129,90 |
| 2018005728 | A.C.F. DA SILVA LTDA | R$ 9.742.022,40 | R$ 6.325.440,00 | R$ 3.416.582,40 |
| 2018005748 | GUELLI COMERCIO E INDUSTRIA DE ALIMENTAÇÃO L… | R$ 9.008.213,10 | R$ 5.617.182,54 | R$ 3.391.030,56 |
| 2018005722 | COMISSARIA AEREA RIO DE JANEIRO LTDA | R$ 8.665.221,74 | R$ 5.543.011,74 | R$ 3.122.210,00 |
| 2018006720 | ALIMENTAÇÃO GLOBAL SERVICE LTDA - ME | R$ 16.192.886,08 | R$ 13.163.349,84 | R$ 3.029.536,24 |
| 2018005753 | REAL FOOD ALIMENTAÇÃO LTDA | R$ 11.590.524,00 | R$ 8.903.017,20 | R$ 2.687.506,80 |
| 2018005731 | MMW IRMAOS ALIMENTOS LTDA | R$ 6.806.152,08 | R$ 4.337.868,78 | R$ 2.468.283,30 |
| 2018002387 | ALIMENTAÇÃO GLOBAL SERVICE LTDA ME | R$ 6.645.742,30 | R$ 4.302.020,40 | R$ 2.343.721,90 |
| 2021003307 | SPACECOMM MONITORAMENTO S/A | R$ 7.884.102,94 | R$ 5.879.512,10 | R$ 2.004.590,84 |
| 2019005666 | SERV FOOD ALIMENTAÇÃO E SERVIÇOS LTDA | R$ 8.542.539,78 | R$ 7.032.073,65 | R$ 1.510.466,13 |
| 2018006713 | ALIMENTAÇÃO GLOBAL SERVICE LTDA - ME | R$ 6.176.501,00 | R$ 4.846.024,00 | R$ 1.330.477,00 |
| 2018005730 | NORSUL CATERING LTDA | R$ 3.473.295,80 | R$ 2.230.264,00 | R$ 1.243.031,80 |
| 2018005736 | GENERAL GOODS LTDA ME | R$ 3.152.420,88 | R$ 2.062.515,84 | R$ 1.089.905,04 |
| 2019005654 | APARECIDA REGINA CASSAROTTI | R$ 7.667.842,80 | R$ 6.689.755,67 | R$ 978.087,13 |
| 2019005644 | COMISSARIA AEREA RIO DE JANEIRO LTDA | R$ 26.188.252,70 | R$ 25.257.603,01 | R$ 930.649,69 |
| 2018006717 | ALIMENTAÇÃO GLOBAL SERVICE LTDA - ME | R$ 4.458.658,16 | R$ 3.584.223,48 | R$ 874.434,68 |

## 11. Unidades incluídas neste dossiê
- FSCABRINI - FUNDAÇÃO SANTA CABRINI
- FUESP - FUNDO ESPECIAL PENITENCIÁRIO
- SEPPENRJ - SECRETARIA DE ESTADO DE POLICIA PENAL

## 12. Conjuntos de dados abertos da secretaria
- Nenhum conjunto encontrado no portal.

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 5 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo (3-5 linhas)
- O TCE-RJ suspendeu uma licitação da Seap estimada em R$ 1,3 bilhão, cujo pregão estava previsto para 2 de abril de 2026. A fonte não confirma contratação nem interrupção do serviço. [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)
- O TCE-RJ reiterou em 2024 determinações à Seap relativas a controles patrimoniais e a bens doados pelo GIFRJ. Em análise posterior, considerou integralmente atendidos os itens sobre identificação desses bens, registros de incorporação contábil e atualização da planilha; outras determinações ainda permaneciam pendentes. [Acórdão nº 000864/2026-PLENV — TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026)
- Em setembro de 2026, o MPRJ denunciou 22 pessoas por suposta organização criminosa ligada à exploração de cantinas em presídios; entre os denunciados estão um policial penal e um então subsecretário. [MPRJ — denúncia sobre cantinas](https://www.mprj.mp.br/visualizar?noticiaId=237301)
- A última mudança de comando informada ocorreu em maio de 2026, quando Alessandra Rosa Odawara foi nomeada para a pasta; as fontes não confirmam quem ocupa o cargo atualmente. [G1 — mudança no comando da Polícia Penal](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/25/governador-interino-exonera-secretaria-de-policia-penal-do-rj.ghtml)

##### Alertas vermelhos
- **Alimentação prisional:** o TCE-RJ suspendeu a licitação estimada em R$ 1,3 bilhão e proibiu adjudicação, homologação ou celebração de contrato até o julgamento definitivo; a Seap recebeu prazo de 15 dias para esclarecimentos. [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)
- **Cantinas prisionais:** o MPRJ atribui a uma organização criminosa o controle da exploração comercial de cantinas entre 2015 e 2024, com supostas manobras para afastar concorrentes; a denúncia estima prejuízo superior a R$ 25 milhões e requer reparação nesse valor. São alegações da denúncia, não fatos julgados nas informações fornecidas. [MPRJ — denúncia sobre cantinas](https://www.mprj.mp.br/visualizar?noticiaId=237301)
- O TCE-RJ reiterou determinações sobre identificação de bens, registros contábeis, atualização de planilha e regras internas de gestão patrimonial, com prazo improrrogável de 60 dias fixado em 2024. Em 2026, considerou integralmente atendidos os itens sobre identificação, registros e planilha, mas apontou que a norma interna não havia sido editada e determinou o cumprimento pleno das obrigações em 60 dias. [Acórdão nº 000864/2026-PLENV — TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026)
- **Segurança e gestão penitenciária:** reportagem de maio de 2026 descreveu superlotação, déficit de vagas e necessidade de reorganização administrativa, além de registrar fuga de três presos de alta periculosidade em 2023, quando câmeras de segurança estavam desligadas. [G1 — mudança no comando da Polícia Penal](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/25/governador-interino-exonera-secretaria-de-policia-penal-do-rj.ghtml)
- **Apuração disciplinar e criminal:** a diretora de um presídio foi autuada em flagrante por peculato, afastada e exonerada, e a Seppen instaurou PAD; a Justiça manteve sua prisão preventiva após pedido do MPRJ. [O Dia — prisão de diretora de presídio](https://odia.ig.com.br/rio-de-janeiro/2026/10/7315090-justica-mantem-presa-diretora-de-presidio-flagrada-com-70-kg-de-comida.html)

##### Contratos e serviços críticos
- **Alimentação de presos:** a Seap abriu licitação para prestação contínua de serviços de alimentação e nutrição, com preparo e fornecimento de refeições transportadas; o valor estimado era de R$ 1,3 bilhão e o pregão estava previsto para 2 de abril de 2026. [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)
- O TCE-RJ suspendeu o procedimento antes da sessão e determinou que não houvesse adjudicação, homologação ou contrato relacionado enquanto a análise não fosse concluída; a reportagem não informa empresa contratada, vigência ou interrupção do fornecimento. [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)
- **Prevenção e combate a incêndio:** auditoria realizada entre 30/09/2019 e 25/10/2019 registrou processo administrativo então em tramitação para contratar empresa especializada em Engenharia de Segurança do Trabalho, para elaborar levantamento cadastral e projeto básico de prevenção e combate a incêndio em unidades prisionais, hospitais penais e órgãos vinculados. A fonte não informa número do processo, contratada, valor, vigência ou situação atual. [Acórdão nº 000864/2026-PLENV — TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026)
- **Sistema de bens:** a auditoria também registrou tratativas com o PRODERJ sobre nova plataforma de controle de bens móveis, bens de consumo e informações estratégicas; não foram informados contrato, empresa, custo ou cronograma. [Acórdão nº 000864/2026-PLENV — TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026)
- A reportagem sobre a suspensão da licitação de alimentação não informa número do procedimento, nomes de participantes, contrato assinado ou prazo de duração. [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)
- **TCE-RJ — alimentação:** a decisão monocrática suspendeu o pregão e determinou que a Seap não adjudique, homologue nem celebre contrato relacionado à licitação enquanto a análise não for concluída. [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)
- Entre os questionamentos sobre o edital de alimentação estavam possível falta de transparência na pesquisa de preços, julgamento por menor preço global por lote com itens de naturezas distintas e pré-qualificação obrigatória potencialmente restritiva à concorrência; também foram relatadas divergências de datas, conflitos entre edital e termo de referência, multas consideradas desproporcionais e dúvidas sobre reajustes. [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)
- **TCE-RJ — bens patrimoniais:** o Acórdão nº 6.468/2022-PLEN determinou providências à Seap e o Acórdão nº 77.959/2024-PLENV reiterou-as com prazo improrrogável de 60 dias; entre elas estavam aperfeiçoar o planejamento de aquisições, identificar prioritariamente bens doados pelo GIFRJ, registrar incorporações, atualizar planilha de bens e elaborar norma interna sobre o SBM-RJ. [Acórdão nº 000864/2026-PLENV — TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026)
- Os trechos fornecidos do Acórdão nº 000864/2026-PLENV tratam de pendências no cumprimento de determinações pela Seap, mas não permitem identificar integralmente as conclusões e determinações finais do acórdão. [Acórdão nº 000864/2026-PLENV — TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026)
- **MPRJ — cantinas:** em setembro de 2026, o GAECO/MPRJ denunciou 22 integrantes de uma organização criminosa e cumpriu mandados de busca e apreensão; a denúncia atribui a um então subsecretário a desclassificação de empresas que, segundo o órgão, não participavam do esquema, para favorecê-lo. Essas informações são alegações do MPRJ. [MPRJ — denúncia sobre cantinas](https://www.mprj.mp.br/visualizar?noticiaId=237301)
- O MPRJ requereu condenação dos denunciados ao pagamento de R$ 25 milhões para reparação dos danos alegados; a fonte não informa decisão judicial de mérito sobre a denúncia. [MPRJ — denúncia sobre cantinas](https://www.mprj.mp.br/visualizar?noticiaId=237301)
- **Judiciário — caso da diretora:** em outubro de 2026, a Justiça manteve a prisão preventiva da diretora após o MPRJ defender sua manutenção; a Seppen informou a autuação em flagrante por peculato e a abertura de PAD. [O Dia — prisão de diretora de presídio](https://odia.ig.com.br/rio-de-janeiro/2026/10/7315090-justica-mantem-presa-diretora-de-presidio-flagrada-com-70-kg-de-comida.html)

##### Riscos de apagão administrativo
- A suspensão da licitação de alimentação impede a conclusão desse processo de contratação de um serviço contínuo, mas as fontes não relatam falta de refeições, atraso no fornecimento ou interrupção do serviço. [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)
- A auditoria identificou necessidades na gestão e contabilização de bens e registrou que o SBM-RJ estava suspenso, enquanto a Seap desenvolvia um projeto para viabilizar um sistema informatizado e havia tratativas para uma nova plataforma de controle. A fonte informa que alguns subitens das determinações foram atendidos integralmente, outros parcialmente e outros não atendidos, mas não especifica a extensão de eventual passivo patrimonial. [Acórdão nº 000864/2026-PLENV — TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026)
- A reportagem de maio de 2026 apontou superlotação, déficit de vagas e necessidade de reorganização administrativa, mas não quantificou o déficit nem informou plano, prazo ou recursos para enfrentá-lo. [G1 — mudança no comando da Polícia Penal](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/25/governador-interino-exonera-secretaria-de-policia-penal-do-rj.ghtml)
- A fonte registra nomeação de nova secretária em 25/05/2026, mas não informa alterações posteriores de comando nem a equipe atual; a composição vigente na data de referência precisa ser confirmada. [G1 — mudança no comando da Polícia Penal](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/25/governador-interino-exonera-secretaria-de-policia-penal-do-rj.ghtml)
- Nada encontrado nas fontes consultadas sobre dívidas da Secretaria, atrasos de pagamento a fornecedores ou risco confirmado de apagão de serviços. [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)

##### Fatos recentes
- Em 25/05/2026, o governador em exercício Ricardo Couto nomeou Alessandra Rosa Odawara, policial penal de carreira com cerca de 17 anos de experiência, para substituir Maria Rosa Lo Duca Nebel, que estava à frente da pasta desde abril de 2022. [G1 — mudança no comando da Polícia Penal](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/25/governador-interino-exonera-secretaria-de-policia-penal-do-rj.ghtml)
- Em março de 2026, o TCE-RJ suspendeu a licitação de alimentação prisional estimada em R$ 1,3 bilhão, apontando indícios de problemas de transparência e de restrição à concorrência. [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)
- Em 02/09/2026, o MPRJ publicou notícia sobre denúncia contra 22 integrantes de organização criminosa ligada à exploração de cantinas; a ação de 01/09/2026 foi descrita como segunda fase da operação Snack Time, iniciada em novembro de 2024. [MPRJ — denúncia sobre cantinas](https://www.mprj.mp.br/visualizar?noticiaId=237301)
- Em 22/10/2026, foi noticiada a prisão preventiva de uma diretora de presídio, a exoneração de suas funções e a instauração de PAD pela Seppen, após apuração sobre possível destinação irregular de alimentos. [O Dia — prisão de diretora de presídio](https://odia.ig.com.br/rio-de-janeiro/2026/10/7315090-justica-mantem-presa-diretora-de-presidio-flagrada-com-70-kg-de-comida.html)
- A reportagem de maio de 2026 também relatou controvérsia, em 2023, sobre equipamentos previstos para escolas em unidades prisionais, após áreas técnicas da Seap alertarem para riscos de segurança associados a dispositivos com possível acesso à internet e comunicação externa. [G1 — mudança no comando da Polícia Penal](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/25/governador-interino-exonera-secretaria-de-policia-penal-do-rj.ghtml)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)
- Solicitar o processo completo e a situação atual da licitação de alimentação, incluindo edital vigente, decisões e recursos no TCE-RJ, esclarecimentos apresentados pela Seap, contratos emergenciais ou substitutos, fornecedores, valores, vigências e confirmação da continuidade do serviço. [G1 — suspensão da licitação de alimentação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml)
- Solicitar comprovação do cumprimento das determinações do TCE-RJ sobre bens doados pelo GIFRJ, incluindo inventário, registros contábeis, planilha atualizada, norma do SBM-RJ e situação do Acórdão nº 000864/2026-PLENV. [Acórdão nº 000864/2026-PLENV — TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026)
- Solicitar situação e documentação do processo de contratação para levantamento cadastral e projeto básico de prevenção e combate a incêndio, além de informações sobre eventual contratação ou implantação da plataforma de controle patrimonial tratada com o PRODERJ. [Acórdão nº 000864/2026-PLENV — TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026)
- Solicitar manifestação oficial e atualizada sobre os procedimentos do MPRJ relativos às cantinas, eventuais medidas administrativas da Secretaria e impactos sobre licitações ou contratos; as fontes consultadas não informam número de contrato, empresa contratada pela Seap ou decisão judicial definitiva. [MPRJ — denúncia sobre cantinas](https://www.mprj.mp.br/visualizar?noticiaId=237301)
- Solicitar a situação atual do PAD e das medidas de controle sobre a destinação de alimentos no Instituto Penal Oscar Stevenson; a fonte não informa conclusão do processo administrativo. [O Dia — prisão de diretora de presídio](https://odia.ig.com.br/rio-de-janeiro/2026/10/7315090-justica-mantem-presa-diretora-de-presidio-flagrada-com-70-kg-de-comida.html)
- Solicitar organograma e titulares atuais, plano de transição, quadro de pessoal, diagnóstico atualizado de ocupação e vagas, riscos de continuidade dos serviços e passivos financeiros; essas informações não foram encontradas nas fontes consultadas. [G1 — mudança no comando da Polícia Penal](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/25/governador-interino-exonera-secretaria-de-policia-penal-do-rj.ghtml)

##### Fontes consultadas
1. [ PDF  ACÓRDÃO Nº 000864/2026-PLENV - TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/864/2026) — 2026-06-26
2. [Couto troca comando da Secretaria de Polícia Penal e do ... - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/05/25/governador-interino-exonera-secretaria-de-policia-penal-do-rj.ghtml) — 2026-05-25
3. [TCE suspende licitação de R$ 1,3 bilhão da Seap para ... - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/03/28/tce-seap-licitacao-alimentacao-de-presos.ghtml) — 2026-03-28
4. [GAECO/MPRJ denuncia e cumpre mandados contra 22 integrantes de organização criminosa que controlava a exploraç](https://www.mprj.mp.br/visualizar?noticiaId=237301) — 2026-09-07
5. [Justiça mantém presa diretora de presídio flagrada com 70 kg de comida   Rio de Janeiro   O Dia](https://odia.ig.com.br/rio-de-janeiro/2026/10/7315090-justica-mantem-presa-diretora-de-presidio-flagrada-com-70-kg-de-comida.html) — 2026-10-22


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2025009168 (COMISSARIA AEREA RIO DE JANEIRO LTDA) vence em 07/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2022007937 (CLARO S/A (FILIAL)) vence em 08/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025005950 (X CAR VEICULOS LTDA) vence em 19/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2025008464 (SERVICO AUTONOMO DE CAPTACAO DE AGUA E …) vence em 19/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2022007522 (DECISION TEAM LTDA EPP) vence em 21/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2021003307 (SPACECOMM MONITORAMENTO S/A, R$ 26,8 mi) consta 'Ativo' no SIGA com fim em 04/08/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2019006174 (QUALYBEM FOOD E SERVICE S.A, R$ 25,5 mi) consta 'Ativo' no SIGA com fim em 09/10/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2023000381 (APARECIDA REGINA CASSAROTTI, R$ 17,8 mi) consta 'Ativo' no SIGA com fim em 31/01/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2023000392 (QUALYBEM FOOD E SERVICE S.A, R$ 16,0 mi) consta 'Ativo' no SIGA com fim em 31/01/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2023000389 (QUALYBEM FOOD E SERVICE S.A, R$ 15,5 mi) consta 'Ativo' no SIGA com fim em 31/01/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
