# Dossiê de transição — Secretaria de Estado de Polícia Civil (SEPOL)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/sepol)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 555 | R$ 619.944.092,60 |
| Com vigência futura (válidos no SIGA) | 184 | R$ 353.684.000,58 |
| até 30 dias | 12 | R$ 22.054.210,44 |
| até 60 dias | 12 | R$ 39.916.760,78 |
| até 90 dias | 9 | R$ 22.936.031,51 |
| até 180 dias | 17 | R$ 50.225.875,63 |
| vencido no SIGA | 371 | R$ 266.260.092,02 |
| sem data | 8 | R$ 2.793.417,98 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 192,7 mi / R$ 98,2 mi / R$ 98,5 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2025008397 (GENERAL MOTORS DO BRASIL LTDA.) vence em 14/11/2026 — 8 dias — R$ 5.455.500,00. Objeto: Participação na Ata de Registro de Preços nº 17/2025 da Secretaria de Estado de…
- Contrato 2025008584 (NRTT - SOLUCOES E SERVICOS LTDA) vence em 14/11/2026 — 8 dias — R$ 1.199.899,00. Objeto: o presente processo tem por objetivo a aquisição de 05 (cinco) viaturas tipo fu…
- Contrato 2025008585 (NRTT - SOLUCOES E SERVICOS LTDA) vence em 14/11/2026 — 8 dias — R$ 5.828.899,00. Objeto: O presente Termo de Referência tem por objetivo descrever a aquisição de 15 (qu…
- Contrato 2026003781 (2R DATATEL TELEINFORMÁTICA LTDA) vence em 18/11/2026 — 12 dias — R$ 6.360.396,00. Objeto: Participação na Ata de Registro de Preços nº 007/2024 do PRODERJ, para contrata…
- Contrato 2025009303 (MEPROLIGHT (1990) LTD) vence em 02/12/2026 — 26 dias — R$ 1.589.578,87. Objeto: Aquisição de 705 (setecentos e cinco) Miras Optrônicas para fuzis de assalto pa…
- Contrato 2025009743 (HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS LTDA) vence em 09/12/2026 — 33 dias — R$ 19.187.500,00. Objeto: Aquisição de SUV através de Consumo de ARP
- Contrato 2025010652 (HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS LTDA) vence em 26/12/2026 — 50 dias — R$ 12.024.166,67. Objeto: AQUISIÇÃO DE VIATURAS - SUVs por meio de Consumo de Ata SRP Nº 004/2025
- Mais 7 contratos menores (R$ 1,6 mi) vencem em até 30 dias — ver seção 3.
- 38 contratos (R$ 88,6 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 111 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 86,8 mi); 1 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 260 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 179,4 mi): provável falta de baixa no SIGA (risco de controle, não de execução).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025008423 | SEPOL | CALESMON ENGENHARIA LTDA | Contratação de empresa especializada em prestação de serviço comum de… | R$ 139.500,00 | 06/11/2026 | 0 |
| 2025008397 | SEPOL | GENERAL MOTORS DO BRASIL LTDA. | Participação na Ata de Registro de Preços nº 17/2025 da Secretaria de… | R$ 5.455.500,00 | 14/11/2026 (PNCP) | 8 |
| 2025008584 | SEPOL | NRTT - SOLUCOES E SERVICOS LTDA | o presente processo tem por objetivo a aquisição de 05 (cinco) viatur… | R$ 1.199.899,00 | 14/11/2026 (PNCP) | 8 |
| 2025008585 | SEPOL | NRTT - SOLUCOES E SERVICOS LTDA | O presente Termo de Referência tem por objetivo descrever a aquisição… | R$ 5.828.899,00 | 14/11/2026 (PNCP) | 8 |
| 2026003781 | SEPOL | 2R DATATEL TELEINFORMÁTICA LTDA | Participação na Ata de Registro de Preços nº 007/2024 do PRODERJ, par… | R$ 6.360.396,00 | 18/11/2026 (PNCP) | 12 |
| 2024007943 | SEPOL | HEXAGONO QUIMICA E EQUIPAMENTOS PARA LABORAT… | Aquisição de insumos para propiciar o pleno funcionamento do ultrapur… | R$ 14.558,00 | 25/11/2026 | 19 |
| 2025009304 | SEPOL | MEPROLIGHT (1990) LTD | Aquisição de 72 (setenta e dois) Magnificadores para armas de fogo pa… | R$ 178.870,68 | 27/11/2026 | 21 |
| 2025009180 | SEPOL | VMI SISTEMAS DE SEGURANÇA LTDA | Contratação da empresa VMI SISTEMAS DE SEGURANÇA Ltda., inscrita no C… | R$ 109.000,00 | 02/12/2026 | 26 |
| 2025009303 | SEPOL | MEPROLIGHT (1990) LTD | Aquisição de 705 (setecentos e cinco) Miras Optrônicas para fuzis de … | R$ 1.589.578,87 | 02/12/2026 (PNCP) | 26 |
| 2025007758 | SEPOL | LIFE TECHNOLOGIES BRASIL COMÉRCIO E INDÚSTRI… | a) 03 (três) ABI 3500b) 01 (um) Termociclador automático de DNA em te… | R$ 495.077,53 | 03/12/2026 | 27 |
| 2026007670 | SEPOL | MERCK S/A (FILIAL) | Participação em Ata de Registro de Preços nº 0070/2026, Pregão Eletrô… | R$ 20.000,00 | 05/12/2026 | 29 |
| 2025009775 | SEPOL | SABEMI SEGURADORA SA | Contratação de empresa especializada para a prestação do serviço de s… | R$ 662.931,36 | 06/12/2026 (PNCP) | 30 |
| 2025009743 | SEPOL | HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS… | Aquisição de SUV através de Consumo de ARP | R$ 19.187.500,00 | 09/12/2026 (PNCP) | 33 |
| 2025009778 | SEPOL | VIA GRAFICA LTDA | O objeto compreende a contratação de empresa especializada na prestaç… | R$ 119.000,00 | 09/12/2026 | 33 |
| 2025009907 | SEPOL | COMPANHIA BRASILEIRA DE CARTUCHOS (MATRIZ) | Aquisição de munição comum e de treinamento para atender a demanda da… | R$ 1.610.960,00 | 11/12/2026 (PNCP) | 35 |
| 2025009957 | SEPOL | INTERNATIONAL BRANDS GROUP B.V | Aquisição de botas táticas, consideradas equipamentos de proteção ind… | R$ 167.585,00 | 11/12/2026 | 35 |
| 2025009601 | SEPOL | VISÃO ENGENHARIA LTDA | Contratação de empresa especializada, envolvendo Serviços Técnicos de… | R$ 245.000,00 | 17/12/2026 | 41 |
| 2025010196 | SEPOL | ENGESAN ENGENHARIA E SANEAMENTO LTDA | Contratação de empresa especializada na prestação de serviços de oper… | R$ 641.223,39 | 19/12/2026 (PNCP) | 43 |
| 2025009497 | SEPOL | LIFE TECHNOLOGIES BRASIL COMERCIO E INDUSTRI… | O objeto da contratação é a aquisição de condicionador para lavagem n… | R$ 1.969,10 | 22/12/2026 | 46 |
| 2026007960 | SEPOL | M.I. MONTREAL INFORMÁTICA S/A | Participação na Ata de Registro de Preços nº 0003/2025/403200-01 do P… | R$ 2.425.653,63 | 22/12/2026 (PNCP) | 46 |
| 2025008300 | SEPOL | BERKANA DEFENSE & SECURITY, LLC. | Aquisição de Espectrômetro portátil pelo consumo da ARP 003/2025 real… | R$ 361.650,91 | 26/12/2026 | 50 |
| 2025010106 | SEPOL | NISSAN DO BRASIL AUTOMÓVEIS LTDA. | Aquisição de 20 (vinte) viaturas Descaracterizadas Tipo Sedan para at… | R$ 2.118.960,00 | 26/12/2026 (PNCP) | 50 |
| 2025010652 | SEPOL | HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS… | AQUISIÇÃO DE VIATURAS - SUVs por meio de Consumo de Ata SRP Nº 004/20… | R$ 12.024.166,67 | 26/12/2026 (PNCP) | 50 |
| 2025009466 | SEPOL | PERKINELMER DO BRASIL ANALÍTICA LTDA. | Contratação da empresa Perkin Elmer do Brasil Analítica Ltda, para pr… | R$ 1.013.092,08 | 02/01/2027 (PNCP) | 57 |
| 2024007945 | SEPOL | RJC DEFESA E AEROESPACIAL LTDA | Aquisição de 20 (vinte) Explosivos Plásticos (RDX) e 500(quinhentos) … | R$ 38.396,60 | 06/01/2027 | 61 |
| 2025010897 | SEPOL | HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS… | Aquisição de SUV através de consumo da ARP 004/2025 | R$ 8.698.333,33 | 09/01/2027 (PNCP) | 64 |
| 2025010946 | SEPOL | HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS… | Aquisição de SUV através de consumo da ARP 004/2025 | R$ 2.814.166,67 | 09/01/2027 (PNCP) | 64 |
| 2025010517 | SEPOL | AKIYAMA S.A. - INDUSTRIA E COMERCIO DE EQUIP… | Aquisição de mesas coletoras de assinatura., Aquisição de mesas colet… | R$ 1.027.564,01 | 13/01/2027 (PNCP) | 68 |
| 2025010518 | SEPOL | QUALYTECK RJ TECNOLOGIA EM INFORMÁTICA EIREL… | Aquisição de mesas coletoras de assinatura., Aquisição de mesas colet… | R$ 439.898,52 | 13/01/2027 | 68 |
| 2025010880 | SEPOL | NISSAN DO BRASIL AUTOMÓVEIS LTDA. | Aquisição de 30 (trinta) Viaturas Descaracterizadas Tipo Sedan. | R$ 3.178.440,00 | 15/01/2027 (PNCP) | 70 |
| 2025010075 | SEPOL | LÍDER TÁXI AÉREO S/A - AIR BRASIL | Contratação direta por inexigibilidade de licitação, de pessoa jurídi… | R$ 5.220.238,16 | 22/01/2027 (PNCP) | 77 |
| 2025010758 | SEPOL | IBG INDUSTRIA BRASILEIRA DE GASES LTDA | Contratação de empresa para o fornecimento contínuo de gases especiai… | R$ 95.970,70 | 22/01/2027 | 77 |
| 2024009713 | SEPOL | SAFELOCK PRODUTOS DE SEGURANÇA INDUSTRIA E C… | Aquisição das embalagens plásticas, em conformidade com as especifica… | R$ 1.423.023,52 | 29/01/2027 (PNCP) | 84 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000734 | SEPOL | CNS NACIONAL DE SERVIÇOS LTDA | Contratação de empresa especializada para prestar serviços contínuos … | R$ 1.789.917,60 | 12/02/2027 (PNCP) | 98 |
| 2026000377 | SEPOL | DINAMICA RIO FERRAMENTAS ELETRICAS LTDA | Contratação de empresa para o Fornecimento Contínuo de insumos para a… | R$ 17.119,32 | 25/02/2027 | 111 |
| 2026000371 | SEPOL | DP UNION INSTR. ANALITICA E CIENTIFICA LTDA | 01 (um) sistema composto por Microscópio Eletrônico de Varredura com … | R$ 1.505.000,00 | 02/03/2027 (PNCP) | 116 |
| 2026000739 | SEPOL | BERKANA DEFENSE & SECURITY, LLC. | Aquisição de Espectrômetro portátil pelo consumo da ARP 003/2025 real… | R$ 361.650,91 | 05/03/2027 | 119 |
| 2026000376 | SEPOL | M3A PROJETOS E SERVICOS ESPECIALIZADOS LTDA | Contratação de empresa para a prestação de serviço de execução de tes… | R$ 54.132,17 | 06/03/2027 | 120 |
| 2026002669 | SEPOL | NP TECNOLOGIA E GESTAO DE DADOS LTDA | ASSINATURA DE SISTEMAS DE PESQUISA, DESCRIÇÃO: AQUISIÇÃO DE ASSINATUR… | R$ 116.557,55 | 12/04/2027 | 157 |
| 2026001537 | SEPOL | PROSEL DE IGUAÇU PROJETOS E SERVIÇOS ELETRIC… | Prestação de serviços de manutenção preventiva e corretiva, incluindo… | R$ 245.000,00 | 15/04/2027 | 160 |
| 2026002613 | SEPOL | RF COM SISTEMAS LTDA | Contratação de empresa especializada para reparo da viatura tática Ag… | R$ 64.020,00 | 15/04/2027 | 160 |
| 2026001909 | SEPOL | MEDPEJ - EQUIPAMENTOS MEDICOS LTDA | COLPOSCOPIO - TIPO: BINOCULAR, RETO COM FOCO 160MM, ILUMINACAO: LED I… | R$ 189.000,00 | 16/04/2027 | 161 |
| 2026001910 | SEPOL | MEDPEJ - EQUIPAMENTOS MEDICOS LTDA | COLPOSCOPIO - TIPO: BINOCULAR, RETO COM FOCO 160MM, ILUMINACAO: LED I… | R$ 63.000,00 | 16/04/2027 | 161 |
| 2026002831 | SEPOL | CONTAGOV LTDA | Participação de 03 (três) servidores na Masterclass de Auditoria Gove… | R$ 12.663,00 | 22/04/2027 | 167 |
| 2025002227 | SEPOL | REDE SOL FUEL DISTRIBUIDORA S/A | Participação nas Atas de Registro de Preços nº 0012/2025/510100-01 e … | R$ 29.104.442,28 | 24/04/2027 (PNCP) | 169 |
| 2025002228 | SEPOL | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Participação nas Atas de Registro de Preços nº 0012/2025/510100-01 e … | R$ 9.028.008,72 | 24/04/2027 (PNCP) | 169 |
| 2026003333 | SEPOL | CONSULTRE-CONSULTORIA E TREINAMENTO LTDA | Participação de 06 (seis) servidores no curso Compras Públicas: Pesq… | R$ 22.950,00 | 30/04/2027 | 175 |
| 2025002793 | SEPOL | HAMILTON DO BRASIL COMERCIO E SERVICOS LTDA | Participação na Ata de Registro de Preços nº 004/2024 da Secretaria N… | R$ 196.096,08 | 05/05/2027 | 180 |
| 2026003298 | SEPOL | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Participação na Ata de Registro de Preços do Centro deTecnologia de I… | R$ 5.131.318,00 | 05/05/2027 (PNCP) | 180 |
| 2026003302 | SEPOL | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Participação na Ata de Registro de Preços do Centro deTecnologia de I… | R$ 2.325.000,00 | 05/05/2027 (PNCP) | 180 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025002229 | SEPOL | 2R DATATEL TELEINFORMÁTICA LTDA | Participação na Ata de Registro de Preços nº 007/2024 do PRODERJ, par… | R$ 12.435.000,00 | 12/05/2026 (PNCP) | -178 |
| 2025008320 | SEPOL | LECARD ADMNISTRADORA DE CARTÕES LTDA | Participação na Ata de Registro de Preços nº 26/25 da Secretaria de E… | R$ 7.264.400,00 | 05/11/2026 (PNCP) | -1 |
| 2022001444 | SEPOL | CLARO S/A (FILIAL) | Contratação de serviço de conexão de links de comunicação de dados e … | R$ 5.653.908,00 | 10/03/2025 | -606 |
| 2025006841 | SEPOL | GENERAL MOTORS DO BRASIL LTDA. | Aquisição de 15 (quinze) viaturas operacionais do tipo SUV parcialmen… | R$ 5.455.500,00 | 24/09/2026 (PNCP) | -43 |
| 2024009853 | SEPOL | RC CARD SOLUCOES EM PAGAMENTOS LTDA | Participação em Ata de Registro de Preços do Corpo de Bombeiros Milit… | R$ 4.547.520,00 | 10/12/2025 (PNCP) | -331 |
| 2025005706 | SEPOL | EQUIPATEC COMÉRCIO DE PRODUTOS PARA LABORATÓ… | Aquisição de soluções multiespectrais para reconhecer, fixar, coletar… | R$ 4.326.609,00 | 15/08/2026 (PNCP) | -83 |
| 2025003972 | SEPOL | COMPANHIA BRASILEIRA DE CARTUCHOS (MATRIZ) | Participação na Ata de Registro de Preços nº 047/2024 da Secretaria N… | R$ 4.163.800,00 | 09/06/2026 (PNCP) | -150 |
| 2024004849 | SEPOL | THEON SENSORS S.A | O presente Termo de Referência tem por objetivo a aquisição de itens … | R$ 4.106.717,15 | 02/07/2025 | -492 |
| 2025007721 | SEPOL | CLAVIS BBR CONSULTORIA EM INFORMATICA S/A | Participação na Ata de Registro de Preços do Centro de Tecnologia de … | R$ 3.821.406,25 | 15/10/2026 (PNCP) | -22 |
| 2025007902 | SEPOL | GENERAL MOTORS DO BRASIL LTDA. | Aquisição de 10(dez) viaturas operacionais do tipo SUV parcialmente b… | R$ 3.637.000,00 | 16/10/2026 (PNCP) | -21 |
| 2024009316 | SEPOL | TOYOTA DO BRASIL LTDA | Aquisição de aquisição de 20 (vinte) viaturas, tipo sedan descaracter… | R$ 3.403.300,00 | 20/03/2025 | -596 |
| 2025004961 | SEPOL | SOLAB CIENTÍFICA EQUIPAMENTOS PARA LABORATÓR… | Aquisição de mesas para necropsia. | R$ 2.407.650,00 | 15/07/2026 (PNCP) | -114 |
| 2024006277 | SEPOL | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Adesão à Ata de Registro de Preços nº 006/2023 do Centro de Tecnologi… | R$ 2.115.010,00 | 16/09/2025 | -416 |
| 2024009881 | SEPOL | TORINO INFORMÁTICA LTDA | A presente demanda visa à aquisição de computadores workstations e mo… | R$ 1.942.000,00 | 11/12/2025 (PNCP) | -330 |
| 2025004762 | SEPOL | GOLDEM DISTRIBUIDORA E REPRESENTAÇÃO LTDA | Aquisição de aparelhos de ar-condicionado de janela | R$ 1.331.413,14 | 10/08/2026 (PNCP) | -88 |
| 2024005809 | SEPOL | ISRAEL WEAPON INDUSTRIES (I.W.I) LTD | Aquisição de armamentos automáticos: 06 (seis) Sistemas de Armamento … | R$ 1.273.825,44 | 30/07/2025 | -464 |
| 2024009352 | SEPOL | RIKE IS INTELIGÊNCIA DE SOFTWARE LTDA | Participação em Ata de Registro de Preços do Proderj nº 07/2023 para … | R$ 1.263.557,76 | 19/11/2025 | -352 |
| 2024010712 | SEPOL | LIFE TECHNOLOGIES BRASIL COMÉRCIO E INDÚSTRI… | Aquisição de uma solução composta por 1 (uma) Plataforma de DNA Massi… | R$ 1.183.654,63 | 03/01/2026 (PNCP) | -307 |
| 2025000613 | SEPOL | GOLDEM DISTRIBUIDORA E REPRESENTAÇÃO LTDA | Aquisição de aparelhos de ar condicionado tipo JANELA | R$ 1.163.079,40 | 13/02/2026 (PNCP) | -266 |
| 2024005397 | SEPOL | EDIFICAR MANUTENÇÃO E INSTALAÇÃO EIRELI | Prestação de serviço com material, para instalação de aparelhos de ar… | R$ 1.112.396,48 | 14/08/2025 (PNCP) | -449 |
| 2024003287 | SEPOL | ANGELS SEGURANÇA E VIGILANCIA EIRELI | Prestação de serviços continuados de vigilância armada executado por … | R$ 1.084.163,52 | 06/05/2026 | -184 |
| 2025001452 | SEPOL | LIFE TECHNOLOGIES BRASIL COMÉRCIO E INDÚSTRI… | Aquisição de de 01 (um) equipamento AB RAPIDHIT ID SYSTEM para exames… | R$ 990.000,00 | 21/03/2026 (PNCP) | -230 |
| 2025007149 | SEPOL | TORINO INFORMÁTICA LTDA | Aquisição de monitores com o intuito de suprir a necessidade, bem com… | R$ 987.000,00 | 30/09/2026 (PNCP) | -37 |
| 2024006840 | SEPOL | EDIFICAR MANUTENÇÃO E INSTALAÇÃO EIRELI | Prestação de serviço de instalação de aparelhos de ar-condicionado, t… | R$ 754.383,47 | 30/08/2025 (PNCP) | -433 |
| 2024007043 | SEPOL | ECOLD CLIMATIZACAO E SERVICOS DE ENGENHARIA … | Prestação de serviço de instalação de aparelhos de ar-condicionado, t… | R$ 698.525,04 | 08/10/2025 (PNCP) | -394 |
| 2025001258 | SEPOL | X CAR VEICULOS LTDA | aquisição de 7 (sete) veículos automotores terrestres novos (zero qui… | R$ 697.386,67 | 14/03/2026 (PNCP) | -237 |
| 2024009428 | SEPOL | BERKANA TECNOLOGIA EM SEGURANÇA LTDA | Participação em Atas de Registro de Preços do Gabinete de Segurança I… | R$ 636.637,00 | 09/12/2025 | -332 |
| 2023009586 | SEPOL | QUALITY ELETROMOVEIS LTDA | Aquisição de eletrodomésticos | R$ 597.260,29 | 28/11/2024 | -708 |
| 2024007425 | SEPOL | OMETTO & CIA EQUIPAMENTOS DE RADIOPROTEÇÃO E… | Aquisição de equipamentos portáteis de espectrometria por fluorescênc… | R$ 590.000,00 | 04/11/2025 | -367 |
| 2024005810 | SEPOL | SPEAR TACTICAL SOLUTIONS LDA | Aquisição de armamentos automáticos: 06 (seis) Sistemas de Armamento … | R$ 484.563,12 | 30/07/2025 | -464 |

_Registros mais antigos (provável falta de baixa no SIGA): 260, R$ 179,4 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025002227 | SEPOL | REDE SOL FUEL DISTRIBUIDORA S/A | Participação nas Atas de Registro de Preços nº 0012/2025/510100-01 e … | R$ 29.104.442,28 | 24/04/2027 (PNCP) | 169 |
| 2025009743 | SEPOL | HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS… | Aquisição de SUV através de Consumo de ARP | R$ 19.187.500,00 | 09/12/2026 (PNCP) | 33 |
| 2024009281 | SEPOL | TECHBIZ FORENSE DIGITAL S/A | Contratação de solução avançada (incluindo hardware e software) para … | R$ 19.121.304,92 | 21/11/2027 (PNCP) | 380 |
| 2025010798 | SEPOL | AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA L… | Contratação de Empresa Autopel Automação Comercial e Informática Ltda… | R$ 16.278.263,38 | 23/01/2028 | 443 |
| 2024008222 | SEPOL | MAPFRE SEGUROS GERAIS S/A | Contratação de empresa especializada para a prestação do serviço de s… | R$ 16.120.000,00 | 23/12/2027 | 412 |
| 2025010652 | SEPOL | HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS… | AQUISIÇÃO DE VIATURAS - SUVs por meio de Consumo de Ata SRP Nº 004/20… | R$ 12.024.166,67 | 26/12/2026 (PNCP) | 50 |
| 2025007704 | SEPOL | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | Contratação de empresa especializada na prestação de serviços de admi… | R$ 11.339.830,52 | 10/10/2027 | 338 |
| 2025000378 | SEPOL | INNOVA AIR SERVICOS TECNICOS LTDA ME | Contratação de empresa especializada EM PRESTAÇÃO DE SERVIÇOS CONTINU… | R$ 10.455.149,35 | 06/03/2030 | 1216 |
| 2025002228 | SEPOL | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Participação nas Atas de Registro de Preços nº 0012/2025/510100-01 e … | R$ 9.028.008,72 | 24/04/2027 (PNCP) | 169 |
| 2025010897 | SEPOL | HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS… | Aquisição de SUV através de consumo da ARP 004/2025 | R$ 8.698.333,33 | 09/01/2027 (PNCP) | 64 |
| 2026004404 | SEPOL | HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS… | Aquisição de SUV através de consumo da ARP 004/2025 | R$ 8.442.500,00 | 16/06/2027 | 222 |
| 2025000376 | SEPOL | CONSTRUTORA SERGIO PORTO LTDA ME | Contratação de empresa especializada EM PRESTAÇÃO DE SERVIÇOS CONTINU… | R$ 6.455.441,91 | 06/03/2030 | 1216 |
| 2026003781 | SEPOL | 2R DATATEL TELEINFORMÁTICA LTDA | Participação na Ata de Registro de Preços nº 007/2024 do PRODERJ, par… | R$ 6.360.396,00 | 18/11/2026 (PNCP) | 12 |
| 2026008975 | SEPOL | NISSAN DO BRASIL AUTOMÓVEIS LTDA. | Participação em Ata de Registro de Preços nº 0028/2025/510100-01, Pre… | R$ 6.356.880,00 | 28/10/2027 | 356 |
| 2025008585 | SEPOL | NRTT - SOLUCOES E SERVICOS LTDA | O presente Termo de Referência tem por objetivo descrever a aquisição… | R$ 5.828.899,00 | 14/11/2026 (PNCP) | 8 |
| 2025008397 | SEPOL | GENERAL MOTORS DO BRASIL LTDA. | Participação na Ata de Registro de Preços nº 17/2025 da Secretaria de… | R$ 5.455.500,00 | 14/11/2026 (PNCP) | 8 |
| 2026004421 | SEPOL | ECO RIO COMERCIO E SERVIÇOS GERAIS LTDA | Contratação de empresa especializada EM PRESTAÇÃO DE SERVIÇOS CONTINU… | R$ 5.282.182,45 | 15/12/2028 | 770 |
| 2025010075 | SEPOL | LÍDER TÁXI AÉREO S/A - AIR BRASIL | Contratação direta por inexigibilidade de licitação, de pessoa jurídi… | R$ 5.220.238,16 | 22/01/2027 (PNCP) | 77 |
| 2026003298 | SEPOL | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Participação na Ata de Registro de Preços do Centro deTecnologia de I… | R$ 5.131.318,00 | 05/05/2027 (PNCP) | 180 |
| 2026003586 | SEPOL | TAPEVAS SOLUÇÕES INTEGRADAS EIRELI | Contratação do objeto assegurar a continuidade dos serviços de limpez… | R$ 4.671.664,94 | 09/12/2028 | 764 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| HYUNDAI MOTOR BRASIL MONTADORA DE AUTOMOVEIS LTDA | 5 | R$ 51.166.666,66 |
| REDE SOL FUEL DISTRIBUIDORA S/A | 1 | R$ 29.104.442,28 |
| TECHBIZ FORENSE DIGITAL S/A | 2 | R$ 21.558.277,25 |
| AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA LTDA | 1 | R$ 16.278.263,38 |
| MGS CLEAN SOLUÇÕES E SERVIÇOS LTDA | 5 | R$ 16.132.111,33 |
| MAPFRE SEGUROS GERAIS S/A | 1 | R$ 16.120.000,00 |
| NISSAN DO BRASIL AUTOMÓVEIS LTDA. | 5 | R$ 14.197.032,00 |
| PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL LTDA | 1 | R$ 11.339.830,52 |
| TAPEVAS SOLUÇÕES INTEGRADAS EIRELI | 4 | R$ 10.596.512,67 |
| INNOVA AIR SERVICOS TECNICOS LTDA ME | 1 | R$ 10.455.149,35 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2021003848 | FUNDAÇÃO PETROBRAS DE SEGURIDADE SOCIAL PETR… | R$ 1.923.979,99 | R$ 1.147.915,48 | R$ 776.064,51 |
| 2022000791 | SOL SERVIÇOS EMPRESARIAIS EIRELI | R$ 779.003,68 | R$ 469.672,37 | R$ 309.331,31 |
| 2022006304 | TAPEVAS SOLUÇÕES INTEGRADAS EIRELI | R$ 455.734,54 | R$ 191.864,24 | R$ 263.870,30 |
| 2020003230 | LIDERANÇA LIMPEZA E CONSERVAÇÃO LTDA | R$ 1.601.458,67 | R$ 1.395.297,90 | R$ 206.160,77 |
| 2020004286 | PROVAC TERCEIRIZAÇÃO DE MÃO DE OBRA LTDA. | R$ 3.063.764,35 | R$ 2.881.197,70 | R$ 182.566,65 |
| 2021002430 | ORACLE DO BRASIL SISTEMAS LTDA | R$ 1.768.307,86 | R$ 1.594.619,77 | R$ 173.688,09 |
| 2021006254 | DE SÁ CONSTRUÇÕES E SERVIÇOS LTDA | R$ 266.445,57 | R$ 145.019,30 | R$ 121.426,27 |
| 2020004964 | ESPECIALY TERCEIRIZAÇÃO LTDA. | R$ 1.262.406,16 | R$ 1.165.569,13 | R$ 96.837,03 |
| 2020006302 | ENGESAN ENGENHARIA E SANEAMENTO LTDA | R$ 186.896,70 | R$ 93.448,35 | R$ 93.448,35 |
| 2020003259 | PROVAC TERCEIRIZAÇÃO DE MÃO DE OBRA LTDA. | R$ 892.648,57 | R$ 818.348,29 | R$ 74.300,28 |
| 2020006005 | ENGESAN ENGENHARIA E SANEAMENTO LTDA | R$ 330.017,32 | R$ 264.182,24 | R$ 65.835,08 |
| 2020006299 | ENGESAN ENGENHARIA E SANEAMENTO LTDA | R$ 195.303,53 | R$ 130.572,32 | R$ 64.731,21 |
| 2020006428 | LÍDER TÁXI AÉREO S/A - AIR BRASIL | R$ 1.267.672,49 | R$ 1.216.977,82 | R$ 50.694,67 |
| 2020003260 | DUC GAS EQUIPAMENTOS DE SOLDAS LTDA | R$ 122.219,33 | R$ 75.850,36 | R$ 46.368,97 |
| 2021001594 | IPOG INSTITUTO DE POS-GRADUAÇÃO & GRADUAÇÃO … | R$ 73.598,00 | R$ 36.986,75 | R$ 36.611,25 |
| 2020004923 | SERVIOESTE RIO DE JANEIRO LTDA | R$ 511.516,76 | R$ 479.742,32 | R$ 31.774,44 |
| 2022006704 | BRK AMBIENTAL MACAÉ S.A | R$ 48.562,48 | R$ 20.779,85 | R$ 27.782,63 |
| 2020005029 | TCPARK VIX ESTACIONAMENTO LTDA | R$ 243.392,92 | R$ 223.592,92 | R$ 19.800,00 |
| 2022001813 | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | R$ 19.640,90 | R$ 0,00 | R$ 19.640,90 |
| 2020003231 | INNOVA AIR SERVICOS TECNICOS LTDA ME | R$ 1.642.156,90 | R$ 1.622.938,65 | R$ 19.218,25 |

## 11. Unidades incluídas neste dossiê
- PCERJ - POLÍCIA CIVIL DO ESTADO DO RIO DE JANEIRO
- SEPOL - Secretaria de Estado de Policia Civil

## 12. Conjuntos de dados abertos da secretaria
- Nenhum conjunto encontrado no portal.

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 6 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo
- A SEPOL abriu processo sancionador contra a FXX Segurança e Transporte de Valores para apurar indícios de atrasos salariais e de benefícios e falhas na cobertura de postos de vigilância, que podem comprometer a continuidade do serviço. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- A SEPOL também firmou contrato de R$ 6,36 milhões para comprar 60 viaturas descaracterizadas, com vigência de 12 meses. O contrato foi assinado em 27/10/2026; as fontes não informam o andamento da entrega. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- As fontes relatam operações contra extorsão e organizações criminosas, incluindo investigação de policiais civis suspeitos de extorquir comerciantes; essas informações são investigações e acusações, não conclusões judiciais. [Agentes suspeitos de extorsão](https://record.r7.com/balanco-geral-rj/video/agentes-usavam-a-estrutura-da-policia-para-extorquir-donos-de-ferros-velhos-no-rj-diz-mp-04092026/) [Operação Dominus](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/policia-civil-e-mprj-deflagram-a-operacao-dominus.ghtml)
- O governador eleito anunciou a intenção de reunir os comandos das polícias Civil e Militar sob uma Secretaria de Segurança Pública; a fonte informa que a transição transcorria com êxito, mas não detalha plano, cronograma ou impactos para a SEPOL. [Anúncio sobre a Secretaria de Segurança](https://www.cnnbrasil.com.br/blogs/cleber-rodrigues/nacional/sudeste/rj/douglas-ruas-vai-unir-policias-militar-e-civil-em-mesma-pasta-no-rj/)

##### Alertas vermelhos
- **Continuidade da vigilância:** a SEPOL apontou possíveis descumprimentos trabalhistas e contratuais pela FXX, incluindo atraso de salários de agosto de 2026, atraso de vale-transporte e auxílio-alimentação, falhas de substituição e postos sem vigilante; a secretaria afirmou que as falhas podem comprometer a regularidade e a continuidade do serviço. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- **Apuração sancionadora em curso:** a FXX foi notificada para apresentar defesa em cinco dias úteis; as condutas ainda estavam sob apuração e a fonte não informa decisão final ou regularização dos pagamentos e postos. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- **Integridade institucional:** em 04/09/2026, três policiais civis e um homem foram presos em ação contra suspeitos de usar a estrutura policial para extorquir comerciantes; segundo a investigação, houve exigência de valores e transferência de R$ 25 mil por uma vítima. São fatos atribuídos à investigação, sem informação sobre desfecho judicial. [Agentes suspeitos de extorsão](https://record.r7.com/balanco-geral-rj/video/agentes-usavam-a-estrutura-da-policia-para-extorquir-donos-de-ferros-velhos-no-rj-diz-mp-04092026/)
- **Transição e reorganização:** o governador eleito anunciou a intenção de reunir os comandos da Polícia Civil e da Polícia Militar sob a Secretaria de Segurança Pública. A matéria informa que a transição com a gestão atual transcorria com êxito e que a equipe tinha acesso às informações necessárias, mas não detalha um plano de implementação, os efeitos sobre a estrutura da SEPOL ou medidas concretas de continuidade administrativa. [Anúncio sobre a Secretaria de Segurança](https://www.cnnbrasil.com.br/blogs/cleber-rodrigues/nacional/sudeste/rj/douglas-ruas-vai-unir-policias-militar-e-civil-em-mesma-pasta-no-rj/)

##### Contratos e serviços críticos
- **Contrato 022/SEPOL/2024 — FXX Segurança e Transporte de Valores:** vigilância patrimonial armada em unidades da Polícia Civil; o valor e a vigência não foram informados. A SEPOL abriu processo administrativo sancionador para apurar possíveis descumprimentos, incluindo atrasos de salários e benefícios e falhas de cobertura dos postos. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- **Contrato 105/SEPOL/2026 — Nissan do Brasil:** compra de 60 viaturas descaracterizadas tipo sedã por R$ 6,36 milhões, cerca de R$ 106 mil por veículo; assinado em 27/10/2026, com vigência de 12 meses. A fonte não informa cronograma ou situação de entrega. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- **Termo de ajuste de contas — L8 Group:** pagamento de R$ 50 mil por serviços de movimentação das bases das câmeras operacionais portáteis realizados em janeiro de 2024; o débito foi quitado quase três anos depois e o termo foi assinado em 23/10/2026. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- As fontes consultadas não apresentam valores ou vigências do contrato da FXX além da identificação do instrumento, nem relação completa dos contratos da SEPOL ou informação sobre outros serviços sob risco de interrupção. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/) [Operação Dominus](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/policia-civil-e-mprj-deflagram-a-operacao-dominus.ghtml)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)
- **TCE-RJ:** Nada encontrado nas fontes consultadas sobre decisões, auditorias ou determinações do Tribunal relacionadas à SEPOL. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- **Processo administrativo da FXX:** a apuração da SEPOL ainda permitia defesa da empresa; a fonte não informa decisão, sanção aplicada ou comprovação posterior de regularização. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- **MPRJ e Operação Dominus:** em 28/10/2026, a Polícia Civil e o MPRJ deflagraram operação contra organização suspeita de controlar a venda de gás em comunidades e extorquir comerciantes; foram expedidos nove mandados de prisão e 44 de busca e apreensão, e a Justiça determinou bloqueio de mais de R$ 350 milhões e sequestro de bens. A fonte relatou quatro prisões e outras quatro pessoas detidas em flagrante até a atualização; são medidas e informações de investigação, não condenações. [Operação Dominus](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/policia-civil-e-mprj-deflagram-a-operacao-dominus.ghtml)
- **Outras investigações com participação do MPRJ:** em 04/03/2026, a DRFC-CAP e o CyberGaeco/MPRJ realizaram a Operação Pecunia Obscura, com quatro mandados de prisão, 23 de busca e apreensão e sequestro de bens e de R$ 150 milhões; três pessoas haviam sido presas naquele momento. A investigação apurava, entre outros fatos, suspeitas de estelionato, falsificação e lavagem de dinheiro. [Operação Pecunia Obscura](https://www.policiacivil.rj.gov.br/news/15104)
- **Outras ações policiais:** a Operação Alba, em 16/09/2026, investigou suspeita de extorsão de empresários e prestadores de serviço em Paraty; duas pessoas foram presas e eletrônicos foram apreendidos. A fonte não informa o desfecho judicial. [Operação Alba](https://g1.globo.com/rj/sul-do-rio-costa-verde/noticia/2026/09/16/policia-civil-deflagra-operacao-contra-faccao-que-extorquia-barqueiros-em-paraty.ghtml)
- **Ações judiciais envolvendo contratos da SEPOL:** Nada encontrado nas fontes consultadas sobre ações judiciais envolvendo contratos da SEPOL. A Operação Dominus noticiou bloqueio de valores e sequestro de bens vinculados aos investigados, mas não relacionou essas medidas a contratos da SEPOL. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/) [Operação Dominus](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/policia-civil-e-mprj-deflagram-a-operacao-dominus.ghtml)

##### Riscos de apagão administrativo
- **Risco operacional em apuração:** a SEPOL listou falhas a serem apuradas em postos de vigilância armada e afirmou que elas podem comprometer a regularidade e a continuidade do serviço nas unidades policiais. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- **Exposição financeira e trabalhista:** a fonte registra atraso salarial e de benefícios alegado pela fiscalização, mas não esclarece se houve regularização, passivos remanescentes ou plano de contingência para manter a vigilância. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- **Transição organizacional:** a proposta de reunir os comandos das polícias Civil e Militar sob uma Secretaria de Segurança pode exigir mudanças de gestão, mas as fontes não descrevem cronograma, organograma de transição ou riscos operacionais específicos. [Anúncio sobre a Secretaria de Segurança](https://www.cnnbrasil.com.br/blogs/cleber-rodrigues/nacional/sudeste/rj/douglas-ruas-vai-unir-policias-militar-e-civil-em-mesma-pasta-no-rj/)
- **Outros riscos de interrupção de serviços, crises administrativas ou dívidas em aberto:** Nada encontrado nas fontes consultadas, além dos pontos sobre a FXX e do débito quitado no termo de ajuste de contas da L8 Group. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)

##### Fatos recentes
- Em 03/11/2026, o governador eleito Douglas Ruas anunciou que pretende colocar os comandos das polícias Civil e Militar sob a Secretaria de Segurança Pública; o nome do secretário seria anunciado nas semanas seguintes. [Anúncio sobre a Secretaria de Segurança](https://www.cnnbrasil.com.br/blogs/cleber-rodrigues/nacional/sudeste/rj/douglas-ruas-vai-unir-policias-militar-e-civil-em-mesma-pasta-no-rj/)
- A mesma fonte informa que Ruas avaliou positivamente o andamento inicial da transição com a equipe do governador em exercício Ricardo Couto, sem detalhar medidas específicas para a SEPOL. [Anúncio sobre a Secretaria de Segurança](https://www.cnnbrasil.com.br/blogs/cleber-rodrigues/nacional/sudeste/rj/douglas-ruas-vai-unir-policias-militar-e-civil-em-mesma-pasta-no-rj/)
- Em 30/10/2026, foi noticiada a abertura de processo sancionador da SEPOL contra a FXX, relativo a possíveis falhas no contrato de vigilância armada. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- Em 28/10/2026, Polícia Civil e MPRJ iniciaram a Operação Dominus, com medidas de prisão, busca, bloqueio de valores e sequestro de bens contra uma organização suspeita de controlar a comercialização de gás em comunidades. [Operação Dominus](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/policia-civil-e-mprj-deflagram-a-operacao-dominus.ghtml)
- Em 04/09/2026, uma operação da Corregedoria da Polícia Civil e do Ministério Público prendeu três policiais civis e um homem suspeitos de extorsão contra donos de ferros-velhos e empresas de reciclagem. [Agentes suspeitos de extorsão](https://record.r7.com/balanco-geral-rj/video/agentes-usavam-a-estrutura-da-policia-para-extorquir-donos-de-ferros-velhos-no-rj-diz-mp-04092026/)

##### Lacunas da pesquisa
- Solicitar à SEPOL o valor, a vigência completa, a situação de execução e as medidas de contingência do contrato 022/SEPOL/2024, além da atualização sobre salários, benefícios, cobertura dos postos e andamento do processo sancionador da FXX. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- Solicitar cronograma de entrega e situação de execução do contrato 105/SEPOL/2026, pois a fonte informa preço, quantidade, assinatura e vigência, mas não o estágio de entrega das viaturas. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- Solicitar relação atualizada dos contratos, pagamentos pendentes, passivos e serviços essenciais da SEPOL, pois as fontes fornecidas não trazem inventário abrangente nem situação financeira consolidada. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/) [Operação Dominus](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/policia-civil-e-mprj-deflagram-a-operacao-dominus.ghtml)
- Solicitar à secretaria a relação de processos, auditorias, determinações e recomendações do TCE-RJ, uma vez que nada sobre decisões do Tribunal foi encontrado nas fontes consultadas. [Processo contra a FXX](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/)
- Solicitar quadro atualizado de ações judiciais e procedimentos do MPRJ relacionados à SEPOL, inclusive desfechos e providências institucionais das operações noticiadas, pois as fontes descrevem investigações e medidas em curso, mas não oferecem panorama consolidado. [Operação Dominus](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/policia-civil-e-mprj-deflagram-a-operacao-dominus.ghtml) [Agentes suspeitos de extorsão](https://record.r7.com/balanco-geral-rj/video/agentes-usavam-a-estrutura-da-policia-para-extorquir-donos-de-ferros-velhos-no-rj-diz-mp-04092026/)
- Solicitar plano formal de transição para a eventual reorganização das secretarias e comandos policiais, com cronograma, responsabilidades e continuidade dos serviços, pois a fonte apenas registra o anúncio político e uma avaliação geral positiva da transição. [Anúncio sobre a Secretaria de Segurança](https://www.cnnbrasil.com.br/blogs/cleber-rodrigues/nacional/sudeste/rj/douglas-ruas-vai-unir-policias-militar-e-civil-em-mesma-pasta-no-rj/)

##### Fontes consultadas
1. [Operação Dominus combate monopólio do gás do Comando Vermelho ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/28/policia-civil-e-mprj-deflagram-a-operacao-dominus.ghtml) — 2026-10-28
2. [Agentes usavam a estrutura da polícia para extorquir donos ...](https://record.r7.com/balanco-geral-rj/video/agentes-usavam-a-estrutura-da-policia-para-extorquir-donos-de-ferros-velhos-no-rj-diz-mp-04092026/) — 2026-09-04
3. [PCERJ](https://www.policiacivil.rj.gov.br/news/15104) — 2026-03-10
4. [Polícia faz operação contra facção que extorquia barqueiros em Paraty   G1](https://g1.globo.com/rj/sul-do-rio-costa-verde/noticia/2026/09/16/policia-civil-deflagra-operacao-contra-faccao-que-extorquia-barqueiros-em-paraty.ghtml) — 2026-09-16
5. [Polícia Civil do RJ abre processo contra empresa de ...](https://www.ururau.com.br/noticias/estado-rj/policia-civil-do-rj-abre-processo-contra-empresa-de-vigilancia-por-salario-atrasado/82882/) — 2026-10-30
6. [Douglas Ruas vai unir polícias Militar e Civil em mesma pasta no RJ   Blogs   CNN Brasil](https://www.cnnbrasil.com.br/blogs/cleber-rodrigues/nacional/sudeste/rj/douglas-ruas-vai-unir-policias-militar-e-civil-em-mesma-pasta-no-rj/) — 2026-11-03


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2025008423 (CALESMON ENGENHARIA LTDA) vence em 06/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2025008397 (GENERAL MOTORS DO BRASIL LTDA.) vence em 14/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025008584 (NRTT - SOLUCOES E SERVICOS LTDA) vence em 14/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2025008585 (NRTT - SOLUCOES E SERVICOS LTDA) vence em 14/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2026003781 (2R DATATEL TELEINFORMÁTICA LTDA) vence em 18/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2025002229 (2R DATATEL TELEINFORMÁTICA LTDA, R$ 12,4 mi) consta 'Ativo' no SIGA com fim em 12/05/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2025008320 (LECARD ADMNISTRADORA DE CARTÕES LTDA, R$ 7,3 mi) consta 'Ativo' no SIGA com fim em 05/11/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2022001444 (CLARO S/A (FILIAL), R$ 5,7 mi) consta 'Ativo' no SIGA com fim em 10/03/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2025006841 (GENERAL MOTORS DO BRASIL LTDA., R$ 5,5 mi) consta 'Ativo' no SIGA com fim em 24/09/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2024009853 (RC CARD SOLUCOES EM PAGAMENTOS LTDA, R$ 4,5 mi) consta 'Ativo' no SIGA com fim em 10/12/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
