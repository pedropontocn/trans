# Dossiê de transição — Secretaria de Estado Internacional, de Juventude e Envelhecimento Saudável (SEIJES)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/seijes)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 57 | R$ 37.936.616,30 |
| Com vigência futura (válidos no SIGA) | 0 | R$ 0,00 |
| até 30 dias | 0 | R$ 0,00 |
| até 60 dias | 0 | R$ 0,00 |
| até 90 dias | 0 | R$ 0,00 |
| até 180 dias | 0 | R$ 0,00 |
| vencido no SIGA | 57 | R$ 37.936.616,30 |
| sem data | 0 | R$ 0,00 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 0,0 mi / R$ 0,0 mi / R$ 0,0 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- 1 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 0,0 mi); 0 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 56 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 37,9 mi): provável falta de baixa no SIGA (risco de controle, não de execução).

## 3. Vencimentos nos próximos 90 dias
_Nenhum registro._

## 4. Vencimentos entre 91 e 180 dias
_Nenhum registro._

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025002957 | SEIJES | NP TECNOLOGIA E GESTAO DE DADOS LTDA | SISTEMA BANCO DE PREÇOS | R$ 24.600,00 | 07/05/2026 | -183 |

_Registros mais antigos (provável falta de baixa no SIGA): 56, R$ 37,9 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 0)
_Nenhum registro._

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|

## 10. Liquidado e ainda não pago (maiores saldos)
_Nenhum registro._

## 11. Unidades incluídas neste dossiê
- SEESQV - SEC EST ENVELHECIMTO SAUDÁVEL QUAL VIDA
- SEIJES - Secretaria de Estado Intergeracional de Juventude e Envelhecimento Saudável

## 12. Conjuntos de dados abertos da secretaria
- Regimento interno - 4ª Conferência Estadual da Juventude (atualizado 2026-08-05): [Regimento interno APROVADO_27-10-23_23h… PDF](https://dadosabertos.rj.gov.br/dataset/2a7dca6e-393f-44f5-aa52-6af4deba9d7f/resource/8313989a-85a4-4c53-8fe8-fc35247f4b25/download/regimento-interno-aprovado_27-10-23_23h43m.pdf)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 5 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

A auditoria da Casa Civil apontou indícios de irregularidades na execução do “60+ Reabilita”, programa vinculado à Secretaria Intergeracional de Juventude e Envelhecimento Saudável (Seijes), e o governo suspendeu os repasses em agosto de 2026. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml)

As parcerias do programa com o Instituto NATA e a ONG Contato somaram R$ 115 milhões entre 2023 e 2026; as fontes consultadas não discriminam os valores de cada parceria. O Globo informa o Termo de Colaboração nº 001/2024 para o Reabilita II, administrado pelo Instituto NATA. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml) [Metrópoles — irmã do dono do NATA](https://www.metropoles.com/colunas/tacio-lorran/dono-de-os-contratada-no-governo-do-rj-contratou-irma-por-r-12-milhao)

A Seijes foi extinta por decreto, com incorporação de suas atribuições à Secretaria de Desenvolvimento Social e Direitos Humanos e exoneração de 35 servidores, incluindo a secretária Isabela Alves. [Veja](https://veja.abril.com.br/politica/couto-extingue-mais-uma-secretaria-por-irregularidades-em-contratos-r-115-milhoes/)

A sindicância instaurada em 24 de setembro conta com participação da CGE-RJ e do TCE-RJ, mas a fonte não relata decisão específica do Tribunal, ação do MPRJ ou ação judicial relacionada ao caso. [Metrópoles — polos em igreja](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario)

##### Alertas vermelhos

- **Pagamentos sem entregas correspondentes:** segundo a auditoria, o NATA recebeu valores superiores ao que a implantação dos polos justificava em praticamente todas as datas examinadas; em novembro de 2025, o excesso pago sem comprovação de serviço ultrapassava R$ 3,4 milhões, e o texto diz que o quadro foi parecido na ONG Contato. São achados de auditoria, não uma decisão judicial ou condenação informada pelas fontes. [Tempo Real](https://temporealrj.com/couto-extingue-secretaria-auditoria-governo-estado/)
- **Repasse antecipado e unidades não implantadas:** em fevereiro de 2025, o governo havia pago R$ 6 milhões ao NATA, equivalentes a 23% do valor previsto para o primeiro ano da parceria; o relatório citado registrava que nenhum polo funcionava naquele momento. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml)
- **Indícios de direcionamento, superfaturamento, conflito de interesses e desvio de dinheiro:** essas são suspeitas apontadas na auditoria sobre a contratação das organizações, e não fatos comprovados por decisão final nas fontes consultadas. [Veja](https://veja.abril.com.br/politica/couto-extingue-mais-uma-secretaria-por-irregularidades-em-contratos-r-115-milhoes/)
- **Contrato de veículos com empresa ligada a familiar do dono do NATA:** o NATA contratou por R$ 1,2 milhão, por 12 meses, aluguel de carros e vans da RCOM, pertencente à irmã do dono do instituto; a contratação ocorreu antes da implantação de qualquer unidade. O NATA informou que rescindiu o contrato preventivamente. [Metrópoles — irmã do dono do NATA](https://www.metropoles.com/colunas/tacio-lorran/dono-de-os-contratada-no-governo-do-rj-contratou-irma-por-r-12-milhao)
- **Repasse suspenso e continuidade incerta:** o governo suspendeu os repasses ao programa, mas anunciou que as atividades assistenciais continuariam até a conclusão de análise técnica prevista para 30 dias; as fontes consultadas não confirmam o estado atual dos atendimentos em 6 de novembro de 2026. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml)

##### Contratos e serviços críticos

- O programa destinava-se a pessoas com mais de 60 anos e tinha como objeto a implantação de polos de atendimento; as fontes mencionam 225 polos no total e, em outra passagem, 100 polos para cada uma das duas organizações, números que não coincidem. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml)
- As duas parcerias receberam R$ 115 milhões entre 2023 e 2026, dos quais R$ 86,6 milhões nos dois anos mais recentes do período. A reportagem não informa valores individualizados para cada parceria, mas identifica o Termo de Colaboração nº 001/2024 do 60+ Reabilita II. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml)
- A auditoria apontou estruturas administrativas duplicadas, com planos de trabalho, cargos, salários e justificativas técnicas praticamente idênticos; a chamada “estrutura fixa” custaria R$ 3,86 milhões por ano em cada contrato, segundo a reportagem. [Tempo Real](https://temporealrj.com/couto-extingue-secretaria-auditoria-governo-estado/)
- A reportagem do O Globo registra que o NATA afirmou administrar exclusivamente o “60+ Reabilita II”, por meio do Termo de Colaboração nº 001/2024, iniciado em 15/01/2025, e que o “60+ Reabilita I”, alvo da investigação, seria executado por outra instituição; essa é a posição declarada pela entidade, e a fonte não detalha como ela se concilia com a descrição geral das parcerias. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml)
- A mesma reportagem informa que o NATA contratou a RCOM Locadora, Produtos e Serviços por R$ 1,2 milhão por 12 meses para aluguel de veículos e, posteriormente, comprou materiais da RCOM Serviços e Comércio, com o mesmo CNPJ; o valor dessas compras não foi informado. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml)
- Segundo a auditoria, o programa deveria atender as 92 cidades do estado, mas a execução se concentrou em áreas da capital; a reportagem informa que, em três anos, o projeto não chegou aos municípios da Região Metropolitana. [Veja](https://veja.abril.com.br/politica/couto-extingue-mais-uma-secretaria-por-irregularidades-em-contratos-r-115-milhoes/)
- O governo declarou que as atividades assistenciais continuariam até a conclusão de análise técnica prevista para 30 dias, mas as fontes não informam o resultado dessa análise nem a situação operacional dos polos após a suspensão dos repasses. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml) [Metrópoles — polos em igreja](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- Em 24 de setembro, a Secretaria de Direitos Humanos instaurou sindicância para investigar os contratos e a execução do programa, com participação da Controladoria-Geral do Estado e do TCE-RJ. [Metrópoles — polos em igreja](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario)
- A fonte informa a participação do TCE-RJ na apuração, mas não relata decisão, determinação ou julgamento específico do Tribunal. [Metrópoles — polos em igreja](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario)
- **MPRJ:** nada encontrado nas fontes consultadas sobre ação, manifestação ou procedimento do Ministério Público relacionado ao programa. [Metrópoles — polos em igreja](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario)
- **Judiciário:** nada encontrado nas fontes consultadas sobre ações judiciais ou decisões judiciais relativas aos contratos ou à execução do programa. [Metrópoles — irmã do dono do NATA](https://www.metropoles.com/colunas/tacio-lorran/dono-de-os-contratada-no-governo-do-rj-contratou-irma-por-r-12-milhao)
- A reportagem informa que também foi determinada tomada de contas, mas não apresenta o andamento ou o resultado desse procedimento. [Metrópoles — polos em igreja](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario)

##### Riscos de apagão administrativo

- A extinção da Seijes transferiu suas atribuições para a Secretaria de Estado de Desenvolvimento Social e Direitos Humanos, e o decreto determinou a exoneração de 35 servidores, incluindo a secretária Isabela Alves; as fontes não detalham a distribuição de pessoal, processos, arquivos ou sistemas na transição. [Veja](https://veja.abril.com.br/politica/couto-extingue-mais-uma-secretaria-por-irregularidades-em-contratos-r-115-milhoes/)
- A auditoria apontou duplicidade de estruturas administrativas e despesas operacionais entre as ONGs do programa, além da ausência, nas listas de profissionais, de dados básicos como CPF, matrícula, vínculo, período de atuação e carga horária; a fonte não informa se esses dados foram corrigidos. [Veja](https://veja.abril.com.br/politica/couto-extingue-mais-uma-secretaria-por-irregularidades-em-contratos-r-115-milhoes/)
- A suspensão dos repasses, combinada com a continuidade assistencial anunciada apenas até a conclusão de análise técnica, exige confirmação imediata de quais unidades estão abertas, quem mantém os serviços e como são custeados; as fontes não apresentam essa situação atualizada. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml)

##### Fatos recentes

- A reportagem informa que o governo suspendeu os repasses ao “60+ Reabilita” e extinguiu a Seijes, transferindo suas atribuições à Secretaria de Desenvolvimento Social e Direitos Humanos. [Veja](https://veja.abril.com.br/politica/couto-extingue-mais-uma-secretaria-por-irregularidades-em-contratos-r-115-milhoes/)
- Em 24 de setembro, foi instaurada sindicância sobre os contratos e a execução do programa, com participação da CGE-RJ e do Tribunal de Contas fluminense. [Metrópoles — polos em igreja](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario)
- Em outubro de 2026, uma visita técnica a uma igreja batista onde deveria funcionar um polo registrou que o local estava fechado, em obras e sem profissionais do projeto social, segundo documento citado pela reportagem. [Metrópoles — polos em igreja](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario)
- Em 4 de novembro de 2026, reportagem informou que o NATA havia rescindido preventivamente o contrato de aluguel de veículos com a RCOM e declarou que os bens estavam em processo final de desmobilização e devolução. [Metrópoles — irmã do dono do NATA](https://www.metropoles.com/colunas/tacio-lorran/dono-de-os-contratada-no-governo-do-rj-contratou-irma-por-r-12-milhao)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)

- Solicitar à secretaria cópia integral dos contratos, termos de colaboração, aditivos, planos de trabalho e processos de contratação do NATA e da ONG Contato, com os números dos instrumentos relativos às parcerias investigadas, valores individualizados, vigências, pagamentos, saldos e justificativas para a forma de seleção. As fontes informam o valor agregado das parcerias, mas não discriminam os valores totais de cada uma. O Globo cita o Termo de Colaboração nº 001/2024, que, segundo o NATA, diz respeito ao “60+ Reabilita II”, e não identifica por esse número o instrumento do programa alvo da investigação. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml) [Tempo Real](https://temporealrj.com/couto-extingue-secretaria-auditoria-governo-estado/)
- Solicitar o relatório integral da auditoria, a análise técnica anunciada para 30 dias, o andamento da sindicância e da tomada de contas, e eventuais providências ou decisões do TCE-RJ; as fontes consultadas não apresentam esses resultados. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml) [Metrópoles — polos em igreja](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario)
- Solicitar informação formal sobre eventual atuação do MPRJ e existência de ações judiciais, pois nada sobre esses pontos foi encontrado nas fontes consultadas. [Metrópoles — polos em igreja](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario) [Metrópoles — irmã do dono do NATA](https://www.metropoles.com/colunas/tacio-lorran/dono-de-os-contratada-no-governo-do-rj-contratou-irma-por-r-12-milhao)
- Solicitar balanço atualizado dos polos em funcionamento, atendimentos prestados, municípios atendidos, equipes, contratos vigentes, pagamentos pendentes e plano para manter os serviços após a suspensão dos repasses; as fontes não informam esses dados atualizados. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml) [Metrópoles — polos em igreja](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario)
- Solicitar inventário de servidores, sistemas, documentos, obrigações, saldos financeiros e responsabilidades transferidas da Seijes à Secretaria de Desenvolvimento Social e Direitos Humanos; as fontes não descrevem os detalhes da transição administrativa. [Veja](https://veja.abril.com.br/politica/couto-extingue-mais-uma-secretaria-por-irregularidades-em-contratos-r-115-milhoes/)
- Solicitar esclarecimento sobre a divergência entre a previsão de 225 polos e a informação de 100 polos por organização, bem como sobre a distinção entre “60+ Reabilita I” e “60+ Reabilita II” relatada pelo NATA. [O Globo](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml)

##### Fontes consultadas
1. [Couto extingue Secretaria de Juventude e Envelhecimento ...](https://temporealrj.com/couto-extingue-secretaria-auditoria-governo-estado/) — 2026-08-17
2. [Couto extingue mais uma secretaria por irregularidades em contratos de R$ 115 milhões](https://veja.abril.com.br/politica/couto-extingue-mais-uma-secretaria-por-irregularidades-em-contratos-r-115-milhoes/) — 2026-08-17
3. [Dono de OS contratada no governo do RJ contratou irmã por R$ 1,2 milhão](https://www.metropoles.com/colunas/tacio-lorran/dono-de-os-contratada-no-governo-do-rj-contratou-irma-por-r-12-milhao) — 2026-11-04
4. [Auditoria em programa para idosos do Estado do Rio leva a 35 ...](https://oglobo.globo.com/rio/noticia/2026/08/17/auditoria-em-programa-para-idosos-do-estado-do-rio-leva-a-35-exoneracoes-e-fim-de-secretaria.ghtml) — 2026-08-17
5. [Projeto para idosos do RJ tinha unidades em igreja ligada a ex-secretário](https://www.metropoles.com/colunas/tacio-lorran/projeto-para-idosos-no-rj-tinha-unidades-em-igreja-ligada-a-ex-secretario) — 2026-10-27


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2025002957 (NP TECNOLOGIA E GESTAO DE DADOS LTDA, R$ 0,0 mi) consta 'Ativo' no SIGA com fim em 07/05/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
3. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
4. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
5. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
6. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
7. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
