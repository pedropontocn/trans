# Dossiê de transição — Secretaria de Estado de Educação (SEEDUC)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/seeduc)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 3685 | R$ 13.146.255.499,82 |
| Com vigência futura (válidos no SIGA) | 183 | R$ 1.922.590.663,11 |
| até 30 dias | 19 | R$ 46.948.122,06 |
| até 60 dias | 78 | R$ 305.370.483,85 |
| até 90 dias | 11 | R$ 401.649.944,27 |
| até 180 dias | 30 | R$ 573.284.828,37 |
| vencido no SIGA | 3502 | R$ 11.223.664.836,71 |
| sem data | 5 | R$ 5.087.159,14 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 1 | R$ 158.997.240,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 4.024,9 mi / R$ 2.484,0 mi / R$ 2.038,4 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2025009513 (PLASVIVO DISTRIBUIDORA DE ARTIGOS EM GERAL LTDA) vence em 13/11/2026 — 7 dias — R$ 3.770.276,34. Objeto: Solicitação de consumo da ata de absorventes - PLASVIVO
- Contrato 2025009514 (ALFAMA INDÚSTRIA E COMÉRCIO DE DESCARTÁVEIS LTDA) vence em 13/11/2026 — 7 dias — R$ 31.535.351,92. Objeto: Solicitação de consumo da ata de absorventes - PLASVIVO
- Contrato 2025009570 (LECARD ADMNISTRADORA DE CARTÕES LTDA) vence em 17/11/2026 — 11 dias — R$ 1.270.457,50. Objeto: Contratação de empresa especializada na prestação de serviços de emissão e entr…
- Contrato 2025009722 (INSTITUTO DE DESENVOLVIMENTO EDUCACIONAL, CULTURA…) vence em 24/11/2026 — 18 dias — R$ 4.565.910,00. Objeto: CONTRATAÇÃO DE EMPRESA PARA PRESTAÇÃO DE SERVIÇOS DE ORGANIZAÇÃO, EXECUÇÃO E RE…
- Contrato 2022008457 (DADY ILHA SOLUCOES INTEGRADAS LTDA) vence em 29/11/2026 — 23 dias — R$ 3.838.459,19. Objeto: Registro de preços para contratação de empresa especializada no fornecimento de…
- Contrato 2025010859 (PLURAL INDÚSTRIA GRÁFICA LTDA) vence em 23/12/2026 — 47 dias — R$ 30.045.701,00. Objeto: O objeto do presente é a contratação de pessoa jurídica especializada em presta…
- Contrato 2025010945 (FUNDAÇÃO DE APOIO A PESQUISA, ENSINO E ASSISTENCI…) vence em 29/12/2026 — 53 dias — R$ 97.796.253,26. Objeto: A presente contratação visa dar prosseguimento na segunda fase do projeto EDUBE…
- Contrato 2026003098 (LIGHT SERVICOS DE ELETRICIDADE SA) vence em 31/12/2026 — 55 dias — R$ 17.374.384,56. Objeto: O presente Termo de Referência tem por objeto a contratação da concessionária L…
- Contrato 2026003100 (AMPLA ENERGIA E SERVIÇOS S/A) vence em 31/12/2026 — 55 dias — R$ 25.008.110,88. Objeto: Contratação de empresa para prestação de serviços de fornecimento de energia el…
- Contrato 2026003114 (LIGHT SERVICOS DE ELETRICIDADE SA) vence em 31/12/2026 — 55 dias — R$ 26.371.651,68. Objeto: O presente Termo de Referência tem por objeto a contratação da concessionária L…
- Contrato 2026003744 (F AB ZONA OESTE S A) vence em 02/01/2027 — 57 dias — R$ 11.015.718,60. Objeto: O presente Termo de Referência tem por objeto a contratação da concessionária F…
- Contrato 2026003049 (AGUAS DO RIO 4 SPE S.A) vence em 05/01/2027 — 60 dias — R$ 33.440.197,32. Objeto: Contratação de empresa para prestação de serviços de fornecimento de água potáv…
- Contrato 2025000429 (AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA) vence em 04/02/2027 — 90 dias — R$ 58.197.626,16. Objeto: Contratação de empresa para prestar junto à Secretaria de Estado de Educação SE…
- Contrato 2025000430 (BLUEL RJ OPERACOES EM SERVICOS E ALIMENTACAO LTDA) vence em 04/02/2027 — 90 dias — R$ 76.289.917,72. Objeto: Contratação de empresa para prestar junto à Secretaria de Estado de Educação SE…
- Contrato 2025000431 (CAPITAL AMBIENTAL CONSTRUÇÃO E SERVIÇOS LTDA) vence em 04/02/2027 — 90 dias — R$ 129.217.957,73. Objeto: Contratação de empresa para prestar junto à Secretaria de Estado de Educação SE…
- Contrato 2025000432 (INFINITY MULTISERVIÇOS LTDA) vence em 04/02/2027 — 90 dias — R$ 121.489.222,80. Objeto: Contratação de empresa para prestar junto à Secretaria de Estado de Educação SE…
- Mais 14 contratos menores (R$ 2,0 mi) vencem em até 30 dias — ver seção 3.
- 128 contratos (R$ 1.183,7 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 289 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 3.341,5 mi); 66 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 3213 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 7.882,2 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- 3 contrato(s) 'Ativo' com data de fim inválida no SIGA (R$ 4,6 mi), ex.: 2014004598 (31/08/3014); 2015005178 (15/10/2105); 2024003402 (13/01/2193). Corrigir o cadastro e informar a vigência real.
- 1 contrato(s) com fim no PNCP anterior ao do SIGA, sem rescisão: 2024003409 (DIVERGÊNCIA: PNCP indica fim 10/05/2025, SIGA indica 22/05/2025;). Confirmar no processo SEI.
- 1 contratações emergenciais vigentes (R$ 159,0 mi). Verificar prazo máximo legal (1 ano, Lei 14.133 art. 75 VIII) e licitação substitutiva.

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025008965 | SEEDUC | ZETECH MANUTENÇÃO E SERVIÇOS EM ENERGIA LTDA | O objeto da presente contratação é a seleção de empresa especializada… | R$ 19.990,00 | 07/11/2026 | 1 |
| 2026007327 | SEEDUC | CONTAGOV LTDA | 2º CONGRESSO BRASILEIRO DE CONTADORES PÚBLICOS (PRESENCIAL) | R$ 29.900,00 | 09/11/2026 | 3 |
| 2025008028 | NOVO DEGASE | GABBA DISTRIBUIDORA LTDA | AQUISIÇÃO DE PÓ DE CAFÉ. | R$ 64.400,00 | 12/11/2026 | 6 |
| 2025009513 | SEEDUC | PLASVIVO DISTRIBUIDORA DE ARTIGOS EM GERAL L… | Solicitação de consumo da ata de absorventes - PLASVIVO | R$ 3.770.276,34 | 13/11/2026 | 7 |
| 2025009514 | SEEDUC | ALFAMA INDÚSTRIA E COMÉRCIO DE DESCARTÁVEIS … | Solicitação de consumo da ata de absorventes - PLASVIVO | R$ 31.535.351,92 | 13/11/2026 | 7 |
| 2025009554 | NOVO DEGASE | AJURDY DISTRIBUIDORA DE PRODUTOS LTDA | AQUISIÇÃO DE MATERIAL DE HIGIENE PESSOAL PARA OS ADOLESCENTES DO DEGA… | R$ 36.879,00 | 17/11/2026 | 11 |
| 2025009564 | NOVO DEGASE | REAL MIX COM. E ADM. DE VENDAS LTDA-EPP | AQUISIÇÃO DE MATERIAL DE HIGIENE PESSOAL PARA OS ADOLESCENTES DO DEGA… | R$ 41.350,00 | 17/11/2026 | 11 |
| 2025009570 | NOVO DEGASE | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada na prestação de serviços de emis… | R$ 1.270.457,50 | 17/11/2026 (PNCP) | 11 |
| 2025009574 | NOVO DEGASE | CLAUDIA GOMES DE SOUZA DISTRIBUIDORA | AQUISIÇÃO DE MATERIAL DE HIGIENE PESSOAL PARA OS ADOLESCENTES DO DEGA… | R$ 30.000,00 | 17/11/2026 | 11 |
| 2026007586 | SEEDUC | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | Contratação de 17 (DEZESSETE) vagas para a participação no 13º CONTRA… | R$ 94.500,11 | 20/11/2026 | 14 |
| 2025009722 | NOVO DEGASE | INSTITUTO DE DESENVOLVIMENTO EDUCACIONAL, CU… | CONTRATAÇÃO DE EMPRESA PARA PRESTAÇÃO DE SERVIÇOS DE ORGANIZAÇÃO, EXE… | R$ 4.565.910,00 | 24/11/2026 (PNCP) | 18 |
| 2025009658 | NOVO DEGASE | KANARO ARTIGOS DE CAMA, MESA E BANHO LTDA | Aquisição de material de cama e banho para os adolescentes, atender a… | R$ 454.000,00 | 25/11/2026 | 19 |
| 2025009759 | NOVO DEGASE | SAARABEL COMERCIAL EIRELI | AQUISIÇÃO DE MATERIAL DE VESTUÁRIO PARA OS ADOLESCENTES DO DEGASE. | R$ 104.950,00 | 25/11/2026 | 19 |
| 2025009761 | NOVO DEGASE | REAL MIX COM. E ADM. DE VENDAS LTDA-EPP | AQUISIÇÃO DE MATERIAL DE VESTUÁRIO PARA OS ADOLESCENTES DO DEGASE. | R$ 249.790,00 | 25/11/2026 | 19 |
| 2025009768 | NOVO DEGASE | TOP MIX COMÉRCIO E SERVIÇOS LTDA | Aquisição de material de cama e banho para os adolescentes, atender a… | R$ 67.800,00 | 25/11/2026 | 19 |
| 2025009808 | NOVO DEGASE | IC TEXTIL LTDA | Aquisição de material de cama e banho para os adolescentes, atender a… | R$ 217.500,00 | 26/11/2026 | 20 |
| 2025009809 | NOVO DEGASE | REDLEN CONFECÇÕES LTDA. | AQUISIÇÃO DE MATERIAL DE VESTUÁRIO PARA OS ADOLESCENTES DO DEGASE. | R$ 408.000,00 | 26/11/2026 | 20 |
| 2025009954 | NOVO DEGASE | MADELIDER COMERCIAL LTDA | AQUISIÇÃO DE CADEIRAS - FIXAS E GIRATÓRIAS. | R$ 148.608,00 | 28/11/2026 | 22 |
| 2022008457 | SEEDUC | DADY ILHA SOLUCOES INTEGRADAS LTDA | Registro de preços para contratação de empresa especializada no forne… | R$ 3.838.459,19 | 29/11/2026 | 23 |
| 2022009980 | SEEDUC | FUNDAÇÃO SANTA CABRINI | Contratação de mão de obra de até 34 (trinta e quatro) apenados da SE… | R$ 4.127.480,35 | 17/12/2026 | 41 |
| 2025009955 | NOVO DEGASE | TEK ALL UTILIDADES LTDA ME | AQUISIÇÃO DE CADEIRAS - FIXAS E GIRATÓRIAS. | R$ 658.989,96 | 17/12/2026 (PNCP) | 41 |
| 2026008555 | SEEDUC | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | O objeto da pretensa contratação é a participação de até 01 (um) serv… | R$ 4.890,00 | 19/12/2026 | 43 |
| 2025007892 | NOVO DEGASE | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | CONTRATAÇÃO DE SERVIÇOS DE INFRAESTRUTURA E HOSPEDAGEM DE DADOS EM NU… | R$ 44.032,56 | 22/12/2026 | 46 |
| 2025010859 | SEEDUC | PLURAL INDÚSTRIA GRÁFICA LTDA | O objeto do presente é a contratação de pessoa jurídica especializada… | R$ 30.045.701,00 | 23/12/2026 (PNCP) | 47 |
| 2026009105 | SEEDUC | GRIOT CONSULTORIA, ARTE, CULTURA E EDUCAÇÃO … | Contratação da Griot Consultoria, Arte, Cultura e Educação Ltda. para… | R$ 10.000,00 | 27/12/2026 | 51 |
| 2025003626 | SEEDUC | SUPERVIA CONCESSIONÁRIA DE TRANSPORTE FERROV… | O objeto consiste na contratação de prestação de serviço de transport… | R$ 542.446,00 | 29/12/2026 (PNCP) | 53 |
| 2025010945 | SEEDUC | FUNDAÇÃO DE APOIO A PESQUISA, ENSINO E ASSIS… | A presente contratação visa dar prosseguimento na segunda fase do pro… | R$ 97.796.253,26 | 29/12/2026 (PNCP) | 53 |
| 2025010877 | SEEDUC | SINDICATO DAS EMP DE TRANSP DE PASS DE B MAN… | O objeto consiste na contratação de prestação de serviço de transport… | R$ 3.000.000,00 | 30/12/2026 (PNCP) | 54 |
| 2025010913 | SEEDUC | NP TECNOLOGIA E GESTAO DE DADOS LTDA | Contratação de empresa especializada para a prestação de serviço de a… | R$ 27.675,00 | 30/12/2026 | 54 |
| 2021000319 | SEEDUC | LINDAURA BRAZ DE CARVALHO | TRATA O PRESENTE PROCESSO DA LOCAÇÃO DO IMÓVEL QUE ABRIGA O C.E PROFE… | R$ 900.000,00 | 31/12/2026 | 55 |
| 2021000321 | SEEDUC | MANOEL CABRAL DOS SANTOS | Pagamento de aluguel referente ao ao periodo de janeiro a dezembro de… | R$ 1.137.600,00 | 31/12/2026 | 55 |
| 2021000390 | SEEDUC | JOSE ROBERTO FONTANI | PRESTAÇÃO DE SERVIÇO DE ALUGUEL DE IMOVEL | R$ 923.025,60 | 31/12/2026 | 55 |
| 2021000391 | SEEDUC | ADMINISTRADORA DE IMÓVEIS MONT-CLAIR LTDA - … | PRESTAÇÃO DE SERVIÇO DE ALUGUEL DE IMOVEL | R$ 2.559.044,16 | 31/12/2026 | 55 |
| 2021000393 | SEEDUC | COLEGIO MONTEIRO COSTA LTDA-ME | Trata o presente processo do Contrato de Locação do imóvel situado na… | R$ 536.025,60 | 31/12/2026 | 55 |
| 2021000395 | SEEDUC | ESPÓLIO DE JOAQUIM CAVALCANTE DE OLIVEIRA | PRESTAÇÃO DE SERVIÇO DE ALUGUEL DE IMOVEL | R$ 542.304,00 | 31/12/2026 | 55 |
| 2021000396 | SEEDUC | PEDRO AMARAL FALEIRO | TRATA O PRESENTE PROCESSO DO CONTRATO DE LOCAÇÃO DO IMÓVEL,UNIDADE ES… | R$ 499.543,92 | 31/12/2026 | 55 |
| 2021000422 | SEEDUC | ROSANGELA FERREIRA DA PENHA | TRATA O PRESENTE PROCESSO DO CONTRATO DE LOCAÇÃO DE IMÓVEL, DA UNIDAD… | R$ 203.823,36 | 31/12/2026 | 55 |
| 2021000423 | SEEDUC | ROSELLI FERREIRA DA PENHA SOARES DOS SANTOS | TRATA O PRESENTE PROCESSO DO CONTRATO DE LOCAÇÃO DE IMÓVEL, DA UNIDAD… | R$ 203.823,36 | 31/12/2026 | 55 |
| 2021000424 | SEEDUC | ROSELIA FERREIRA DA PENHA | TRATA O PRESENTE PROCESSO DO CONTRATO DE LOCAÇÃO DE IMÓVEL, DA UNIDAD… | R$ 407.647,44 | 31/12/2026 | 55 |
| 2021000479 | SEEDUC | REGINA CELIA NUNES ALVES | Trata o presente processo do Contrato de Locação do imóvel situado na… | R$ 1.979.154,72 | 31/12/2026 | 55 |
| 2021000481 | SEEDUC | DENISE NUNES ALVES KHALIL | Trata o presente processo do Contrato de Locação do imóvel situado na… | R$ 329.859,36 | 31/12/2026 | 55 |
| 2021000483 | SEEDUC | DENILSON NUNES ALVES | Trata o presente processo do Contrato de Locação do imóvel situado na… | R$ 329.859,36 | 31/12/2026 | 55 |
| 2022002251 | SEEDUC | MARCILENE NICODEMOS SERRANO DA SILVA | Trata o presente processo da adoção de procedimentos visando a retoma… | R$ 1.036.042,24 | 31/12/2026 | 55 |
| 2026002980 | SEEDUC | RIO + SANEAMENTO BL3 S.A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 2.943,24 | 31/12/2026 | 55 |
| 2026002989 | SEEDUC | AGUAS DE NITEROI S/A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 39.337,32 | 31/12/2026 | 55 |
| 2026002991 | SEEDUC | SERVICO AUTONOMO DE AGUA E ESGOTO SAAE | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 11.325,40 | 31/12/2026 | 55 |
| 2026002992 | SEEDUC | CONCESSIONÁRIA ÁGUAS DE JUTURNAÍBA S/A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 6.569,28 | 31/12/2026 | 55 |
| 2026003015 | SEEDUC | BRK AMBIENTAL MACAÉ S.A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 1.482,84 | 31/12/2026 | 55 |
| 2026003017 | SEEDUC | CERAL COOPERATIVA DE ELTRIF RURAL DE ARARUAM… | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 36.712,56 | 31/12/2026 | 55 |
| 2026003021 | SEEDUC | ENERGISA MINAS GERAIS - DISTRIBUIDORA DE ENE… | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 41.202,00 | 31/12/2026 | 55 |
| 2026003023 | SEEDUC | FONTES DA SERRA SANEAMENTO DE GUAPIMIRIM LTDA | Contratação de empresa paraprestação de serviços defornecimento de ág… | R$ 37.840,08 | 31/12/2026 | 55 |
| 2026003025 | SEEDUC | ÁGUAS DAS AGULHAS NEGRAS S/A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 5.787,48 | 31/12/2026 | 55 |
| 2026003030 | SEEDUC | AGUAS DE PADUA SPE LTDA | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 132.000,00 | 31/12/2026 | 55 |
| 2026003032 | SEEDUC | SERVICO AUTONOMO DE AGUA E ESGOTO-SAAE | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 32.836,68 | 31/12/2026 | 55 |
| 2026003037 | SEEDUC | AGUAS DA CONDESSA S. A. | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 115.101,24 | 31/12/2026 | 55 |
| 2026003043 | SEEDUC | RIO + SANEAMENTO BL3 S.A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 3.225.679,92 | 31/12/2026 (PNCP) | 55 |
| 2026003048 | SEEDUC | AGUAS DO RIO 4 SPE S.A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 155.860,44 | 31/12/2026 | 55 |
| 2026003050 | SEEDUC | COMPANHIA ESTADUAL DE AGUAS E ESGOTOS-CEDAE | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 22.161,92 | 31/12/2026 | 55 |
| 2026003054 | SEEDUC | AGUAS DO IMPERADOR S/A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 683.118,96 | 31/12/2026 (PNCP) | 55 |
| 2026003055 | SEEDUC | AGUAS DA IMPERATRIZ S A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 381.623,40 | 31/12/2026 | 55 |
| 2026003057 | SEEDUC | ENERGISA MINAS GERAIS - DISTRIBUIDORA DE ENE… | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 341.991,12 | 31/12/2026 | 55 |
| 2026003058 | SEEDUC | AMPLA ENERGIA E SERVIÇOS S/A | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 324.258,36 | 31/12/2026 | 55 |
| 2026003059 | SEEDUC | F AB ZONA OESTE S A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 22.067,64 | 31/12/2026 | 55 |
| 2026003062 | SEEDUC | IGUA RIO DE JANEIRO S.A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 144.620,04 | 31/12/2026 | 55 |
| 2026003065 | SEEDUC | IGUA RIO DE JANEIRO S.A. | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 5.618.869,32 | 31/12/2026 (PNCP) | 55 |
| 2026003067 | SEEDUC | SERVICO AUTONOMO DE AGUA E ESGOTO SAAE | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 1.297.573,92 | 31/12/2026 (PNCP) | 55 |
| 2026003069 | SEEDUC | CONCESSIONÁRIA ÁGUAS DE PARATY S/A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 230.613,12 | 31/12/2026 | 55 |
| 2026003071 | SEEDUC | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 353.083,44 | 31/12/2026 | 55 |
| 2026003073 | SEEDUC | AGUAS DO RIO 1 SPE S.A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 49.527,36 | 31/12/2026 | 55 |
| 2026003078 | SEEDUC | COMPANHIA ESTADUAL DE AGUAS E ESGOTOS-CEDAE | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 935.425,28 | 31/12/2026 (PNCP) | 55 |
| 2026003080 | SEEDUC | PRODUSA LTDA EPP | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 46.865,52 | 31/12/2026 | 55 |
| 2026003081 | SEEDUC | ENERGISA MINAS GERAIS - DISTRIBUIDORA DE ENE… | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 226.687,92 | 31/12/2026 | 55 |
| 2026003083 | SEEDUC | AGUAS DE NITEROI S/A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 4.042.782,48 | 31/12/2026 (PNCP) | 55 |
| 2026003094 | SEEDUC | ÁGUAS DE NOVA FRIBURGO LTDA | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 1.048.637,40 | 31/12/2026 (PNCP) | 55 |
| 2026003095 | SEEDUC | CONCESSIONÁRIA ÁGUAS DE JUTURNAÍBA S/A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 1.247.416,92 | 31/12/2026 (PNCP) | 55 |
| 2026003097 | SEEDUC | AMPLA ENERGIA E SERVIÇOS S/A | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 169.000,32 | 31/12/2026 | 55 |
| 2026003098 | SEEDUC | LIGHT SERVICOS DE ELETRICIDADE SA | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 17.374.384,56 | 31/12/2026 (PNCP) | 55 |
| 2026003100 | SEEDUC | AMPLA ENERGIA E SERVIÇOS S/A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 25.008.110,88 | 31/12/2026 (PNCP) | 55 |
| 2026003101 | SEEDUC | ÁGUAS DAS AGULHAS NEGRAS S/A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 334.272,60 | 31/12/2026 | 55 |
| 2026003102 | SEEDUC | AMPLA ENERGIA E SERVIÇOS S/A | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 9.405.260,16 | 31/12/2026 (PNCP) | 55 |
| 2026003111 | SEEDUC | AGUAS DO RIO 1 SPE S.A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 8.336.633,52 | 31/12/2026 (PNCP) | 55 |
| 2026003112 | SEEDUC | PRO LAGOS S/A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 6.981,12 | 31/12/2026 | 55 |
| 2026003114 | SEEDUC | LIGHT SERVICOS DE ELETRICIDADE SA | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 26.371.651,68 | 31/12/2026 (PNCP) | 55 |
| 2026003120 | SEEDUC | PREFEITURA MUNICIPAL DE BARRA DO PIRAÍ | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 162.122,28 | 31/12/2026 | 55 |
| 2026003799 | SEEDUC | IGUÁ RIO DE JANEIRO S.A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 358.822,80 | 31/12/2026 | 55 |
| 2026003019 | SEEDUC | SERVIÇO AUTÔNOMO DE ÁGUA E ESGOTO DE TRÊS RI… | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 3.574,32 | 01/01/2027 | 56 |
| 2026003744 | SEEDUC | F AB ZONA OESTE S A | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 11.015.718,60 | 02/01/2027 (PNCP) | 57 |
| 2026002987 | SEEDUC | SERVICO AUTONOMO DE AGUA E ESGOTO | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 3.418,68 | 05/01/2027 | 60 |
| 2026003026 | SEEDUC | MUNICÍPIO DE AREAL | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 7.588,56 | 05/01/2027 | 60 |
| 2026003027 | SEEDUC | PREFEITURA DO MUNICIPIO DE PORTO REAL | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 8.301,48 | 05/01/2027 | 60 |
| 2026003028 | SEEDUC | AGUAS DO PARAIBA SA | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 19.375,56 | 05/01/2027 | 60 |
| 2026003049 | SEEDUC | AGUAS DO RIO 4 SPE S.A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 33.440.197,32 | 05/01/2027 (PNCP) | 60 |
| 2026003052 | SEEDUC | SERVIÇO AUTONOMO DE AGUA E ESGOTO DE BARRA M… | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 806.545,68 | 05/01/2027 (PNCP) | 60 |
| 2026003053 | SEEDUC | AGUAS DO PARAIBA SA | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 3.131.599,20 | 05/01/2027 (PNCP) | 60 |
| 2026003082 | SEEDUC | SERVIÇO AUTÔNOMO DE ÁGUA E ESGOTO DE TRÊS RI… | O presente Termo de Referência tem por objeto a contratação da conces… | R$ 204.400,20 | 05/01/2027 | 60 |
| 2026003084 | SEEDUC | BRK AMBIENTAL MACAÉ S.A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 272.834,88 | 05/01/2027 | 60 |
| 2026003116 | SEEDUC | EPAC - ESTRUTURADORA DE PROJETOS, PARCERIAS … | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 222.465,60 | 05/01/2027 | 60 |
| 2023007485 | SEEDUC | CS BRASIL FROTAS S.A. | O processo administrativo tem o objetivo demotivar a contratação de s… | R$ 6.174.885,60 | 06/01/2027 | 61 |
| 2026000007 | SEEDUC | GLOBAL 233 COMERCIAL LTDA | Aquisição de itens para melhor aparelhar o Conselho Estadual de Educa… | R$ 4.753,30 | 06/01/2027 | 61 |
| 2026000006 | SEEDUC | ACANTO SOLUÇÕES INTEGRADAS DE BENS E SERVIÇO… | Aquisição de itens para melhor aparelhar o Conselho Estadual de Educa… | R$ 29.571,00 | 07/01/2027 | 62 |
| 2026000094 | SEEDUC | ATUALIZACAO PROFISSIONAL CONTABIL E JURIDICA… | Contratação de empresa especializada para apresentação de comercializ… | R$ 3.459,96 | 09/01/2027 | 64 |
| 2025008157 | SEEDUC | ACTCON TECNOLOGIA LTDA. | Aquisição de solução de acessibilidade einclusão educacional, dirigid… | R$ 1.965.550,00 | 13/01/2027 (PNCP) | 68 |
| 2025008159 | SEEDUC | ACTCON TECNOLOGIA LTDA. | Aquisição de solução de acessibilidade einclusão educacional, dirigid… | R$ 8.189.000,00 | 13/01/2027 (PNCP) | 68 |
| 2026000223 | SEEDUC | CONSTRUTORA MANTORINNI | O presente Projeto Básico tem como objetivo determinar as diretrizes … | R$ 88.000,00 | 03/02/2027 | 89 |
| 2025000429 | SEEDUC | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | Contratação de empresa para prestar junto à Secretaria de Estado de E… | R$ 58.197.626,16 | 04/02/2027 | 90 |
| 2025000430 | SEEDUC | BLUEL RJ OPERACOES EM SERVICOS E ALIMENTACAO… | Contratação de empresa para prestar junto à Secretaria de Estado de E… | R$ 76.289.917,72 | 04/02/2027 | 90 |
| 2025000431 | SEEDUC | CAPITAL AMBIENTAL CONSTRUÇÃO E SERVIÇOS LTDA | Contratação de empresa para prestar junto à Secretaria de Estado de E… | R$ 129.217.957,73 | 04/02/2027 | 90 |
| 2025000432 | SEEDUC | INFINITY MULTISERVIÇOS LTDA | Contratação de empresa para prestar junto à Secretaria de Estado de E… | R$ 121.489.222,80 | 04/02/2027 | 90 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2021000295 | SEEDUC | SHINE RIO SERVIÇOS EIRELI ME | PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRE… | R$ 55.890.274,73 | 08/02/2027 | 94 |
| 2021000296 | SEEDUC | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRE… | R$ 91.211.633,46 | 08/02/2027 | 94 |
| 2021000297 | SEEDUC | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRE… | R$ 64.490.019,99 | 08/02/2027 | 94 |
| 2021000298 | SEEDUC | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRE… | R$ 66.367.969,48 | 08/02/2027 | 94 |
| 2021000299 | SEEDUC | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRE… | R$ 95.153.414,00 | 08/02/2027 | 94 |
| 2021000300 | SEEDUC | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRE… | R$ 46.038.095,60 | 08/02/2027 | 94 |
| 2025001086 | SEEDUC | MARIA RITA LOPES | Trata o presente processo, inaugurado pelo Colégio Estadual Brigadeir… | R$ 240.000,00 | 12/03/2027 | 126 |
| 2026002520 | NOVO DEGASE | ÁGUAS DE NOVA FRIBURGO LTDA | O objeto do presente processo é a contratação de Prestação de Serviço… | R$ 231.687,50 | 31/03/2027 | 145 |
| 2026002521 | NOVO DEGASE | ENERGISA MINAS GERAIS - DISTRIBUIDORA DE ENE… | Contratação de Prestação de Serviço de Energia Elétrica, visando aten… | R$ 143.256,15 | 31/03/2027 | 145 |
| 2026002524 | NOVO DEGASE | PRO LAGOS S/A | Contratação de Prestação de Serviço para Abastecimento de Água Potáve… | R$ 95.770,93 | 31/03/2027 | 145 |
| 2026002528 | NOVO DEGASE | F AB ZONA OESTE S A | Contratação de Prestação de Serviço para Abastecimento de Água Potáve… | R$ 109.732,02 | 31/03/2027 | 145 |
| 2026002530 | NOVO DEGASE | AMPLA ENERGIA E SERVIÇOS S/A | Contratação de Prestação de Serviço de Energia Elétrica, visando aten… | R$ 945.931,32 | 31/03/2027 (PNCP) | 145 |
| 2026002533 | NOVO DEGASE | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação de Prestação de Serviço de Energia Elétrica, visando aten… | R$ 2.134.845,28 | 31/03/2027 (PNCP) | 145 |
| 2026002534 | NOVO DEGASE | IGUA RIO DE JANEIRO S.A. | Contratação de Prestação de Serviço para Abastecimento de Água Potáve… | R$ 5.000,47 | 31/03/2027 | 145 |
| 2026002547 | NOVO DEGASE | BRK AMBIENTAL MACAÉ S.A | Contratação de Prestação de Serviço para Abastecimento de Água Potáve… | R$ 36.642,08 | 01/04/2027 | 146 |
| 2026002542 | NOVO DEGASE | AGUAS DA IMPERATRIZ S A | Contratação de Prestação de Serviço para Abastecimento de Água Potáve… | R$ 34.238,38 | 01/04/2027 | 146 |
| 2026002544 | NOVO DEGASE | SERVICO AUTONOMO DE AGUA E ESGOTO SAAE | Contratação de Prestação de Serviço para Abastecimento de Água Potáve… | R$ 669.058,87 | 01/04/2027 (PNCP) | 146 |
| 2026002545 | NOVO DEGASE | AGUAS DO PARAIBA SA | Contratação de Prestação de Serviço para Abastecimento de Água Potáve… | R$ 171.388,51 | 01/04/2027 | 146 |
| 2026002546 | NOVO DEGASE | AGUAS DO RIO 4 SPE S.A | Contratação de Prestação de Serviço para Abastecimento de Água Potáve… | R$ 5.652.932,58 | 01/04/2027 (PNCP) | 146 |
| 2026002549 | NOVO DEGASE | AGUAS DE NITEROI S/A | Contratação de Prestação de Serviço para Abastecimento de Água Potáve… | R$ 95.952,68 | 01/04/2027 | 146 |
| 2025002291 | SEEDUC | INSTITUTO DE ENSINO PÓLIS CIVITAS LTDA | Trata o presente Termo de Referência acerca da aquisição de curso e f… | R$ 72.500.000,00 | 07/04/2027 (PNCP) | 152 |
| 2026002748 | NOVO DEGASE | AGUAS DO RIO 1 SPE S.A | CONTRATAÇÃO DE CONCESSIONÁRIA EXCLUSIVA PARA FORNECIMENTO DE ÁGUA / E… | R$ 17.734,95 | 08/04/2027 | 153 |
| 2024006584 | NOVO DEGASE | OUR PEST CONTROL IMUNIZAÇAO LTDA | Contratação de empresa especializada em dedetização e desratização pa… | R$ 41.200,00 | 14/04/2027 | 159 |
| 2026001011 | SEEDUC | SUPERVIA CONCESSIONÁRIA DE TRANSPORTE FERROV… | O objeto consiste na contratação de prestação de serviço de transport… | R$ 591.816,00 | 14/04/2027 (PNCP) | 159 |
| 2026002757 | SEEDUC | CONCESSÃO METROVIARIA DO RIO DE JANEIRO S.A. | O serviço consiste na contratação de transporte escolar urbano interm… | R$ 910.644,00 | 14/04/2027 (PNCP) | 159 |
| 2026002933 | NOVO DEGASE | CLÍNICA VETERINÁRIA E PETSHOP BM LTDA | AQUISIÇÃO DE RAÇÃO CANINA. | R$ 54.522,00 | 14/04/2027 | 159 |
| 2022007484 | SEEDUC | MUNICIPIO DE RIO DE JANEIRO | Trata-se de processo administrativo cujo objeto é a celebração de um … | R$ 30.678.464,40 | 30/04/2027 | 175 |
| 2024008624 | NOVO DEGASE | RESTAURANTE NOVA RODOVIA 2007 LTDA | CONTRATAÇÃO DE EMPRESA PARA PRESTAÇÃO DE SERVIÇOS DE PREPARO, FORNECI… | R$ 20.999.421,00 | 30/04/2027 (PNCP) | 175 |
| 2024008627 | NOVO DEGASE | MENDES DOS SANTOS REFEIÇÕES COLETIVAS E SERV… | CONTRATAÇÃO DE EMPRESA PARA PRESTAÇÃO DE SERVIÇOS DE PREPARO, FORNECI… | R$ 9.875.997,00 | 03/05/2027 (PNCP) | 178 |
| 2024008628 | NOVO DEGASE | MENDES DOS SANTOS REFEIÇÕES COLETIVAS E SERV… | CONTRATAÇÃO DE EMPRESA PARA PRESTAÇÃO DE SERVIÇOS DE PREPARO, FORNECI… | R$ 7.897.185,00 | 03/05/2027 (PNCP) | 178 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025000251 | SEEDUC | EUREKA SOLUCOES PEDAGOGICAS LTDA | A aquisição de Material de Apoio Pedagógico para a Rede Pública Estad… | R$ 334.336.436,93 | 21/01/2026 (PNCP) | -289 |
| 2024005560 | SEEDUC | INSTITUTO POSITIVA SOCIAL | Serviços de apoio profissional (cuidador/ledor/transcritor), atendime… | R$ 154.704.000,00 | 18/07/2026 | -111 |
| 2025002089 | SEEDUC | EBN COMERCIO, IMPORTACAO E EXPORTACAO EIRELI | Requisição de consumo de Kits de Uniformes e Tênis escolares | R$ 146.576.381,70 | 01/04/2026 (PNCP) | -219 |
| 2024010724 | SEEDUC | EUREKA SOLUCOES PEDAGOGICAS LTDA | Para corroborar com a melhoria da ação de aprendizado dos estudantes,… | R$ 125.949.837,44 | 30/12/2025 (PNCP) | -311 |
| 2025000005 | SEEDUC | FUNDAÇÃO GETULIO VARGAS | Contratação de empresa para a prestação de serviços técnicos especial… | R$ 96.742.700,00 | 17/04/2026 (PNCP) | -203 |
| 2024004198 | SEEDUC | FUNDAÇÃO DE APOIO A PESQUISA, ENSINO E ASSIS… | A presente contratação de instituição para realização de estudo e pes… | R$ 95.276.130,48 | 13/10/2025 (PNCP) | -389 |
| 2023010922 | SEEDUC | GESPED - GESTAO E ASSESSORIA EMPRESARIAL E E… | Trata o presente Termo de Referência acerca da aquisição com base no … | R$ 87.990.347,25 | 25/12/2024 | -681 |
| 2021004017 | SEEDUC | PRM SERVICOS E MAO DE OBRA ESPEC. EIRELI | Prestação de serviço de preparo e distribuição de refeição em ambient… | R$ 83.984.264,10 | 04/02/2025 | -640 |
| 2024008916 | SEEDUC | GLOBALTEC TECNOLOGIAS EDUCACIONAIS LTDA | Salas de Leitura Móvel, compacta e dobrável,composta por módulos lite… | R$ 83.806.600,00 | 05/03/2026 | -246 |
| 2024010490 | SEEDUC | ESTUDO PLAY EDITORA E SOLUÇÕES EDUCACIONAIS … | O presente termo de referência tem por objeto a aquisição de material… | R$ 83.414.636,00 | 23/12/2025 (PNCP) | -318 |
| 2024004778 | SEEDUC | HAWAI 2010 COMERCIAL EIRELI | Registro de preços para aquisição de kits de material escolar destina… | R$ 77.906.236,86 | 27/12/2024 | -679 |
| 2021004018 | SEEDUC | SINGULAR GESTÃO DE SERVIÇOS LTDA. | Prestação de serviço de preparo e distribuição de refeição em ambient… | R$ 75.926.218,71 | 04/02/2025 | -640 |
| 2021004015 | SEEDUC | HB MULTISERVIÇOS LTDA | Prestação de serviço de preparo e distribuição de refeição em ambient… | R$ 74.449.825,55 | 04/02/2025 | -640 |
| 2021004014 | SEEDUC | SINGULAR GESTÃO DE SERVIÇOS LTDA. | Prestação de serviço de preparo e distribuição de refeição em ambient… | R$ 74.316.655,22 | 04/02/2025 | -640 |
| 2025002092 | SEEDUC | BRASIL COMÉRCIO E DISTRIBUIDORA LTDA | Requisição de consumo de Kits de Uniformes e Tênis escolares | R$ 67.035.999,36 | 01/04/2026 (PNCP) | -219 |
| 2024008751 | SEEDUC | MAQMOVEIS INDUSTRIA E COMERCIO DE MOVEIS LTDA | Aquisição de mobiliários escolares. | R$ 66.008.046,00 | 23/04/2025 | -562 |
| 2021004324 | SEEDUC | SERVIÇO NACIONAL DE APRENDIZAGEM INDUSTRIAL | Constitui objeto do presente a contratação de instituição para oferta… | R$ 64.024.751,68 | 25/10/2026 | -12 |
| 2024004795 | SEEDUC | EBN COMERCIO, IMPORTACAO E EXPORTACAO EIRELI | Aquisição de Kits de Material Escolar. | R$ 61.998.606,36 | 27/12/2024 | -679 |
| 2023009759 | SEEDUC | FUNDAÇÃO CESGRANRIO | Tratase de processo referente à contratação de instituição especialia… | R$ 59.909.829,11 | 29/11/2025 | -342 |
| 2021003896 | SEEDUC | PRM SERVICOS E MAO DE OBRA ESPEC. EIRELI | Trata-se de processo que propõe a renovação, por doze meses do contra… | R$ 56.970.109,74 | 04/02/2025 | -640 |
| 2025002091 | SEEDUC | LT GLOBAL COMERCIO E SERVIÇOS LTDA | Requisição de consumo de Kits de Uniformes e Tênis escolares. | R$ 56.095.108,40 | 01/04/2026 (PNCP) | -219 |
| 2021003984 | SEEDUC | SINGULAR GESTÃO DE SERVIÇOS LTDA. | Prestação de serviço de preparo e distribuição de refeição em ambient… | R$ 53.983.008,60 | 04/02/2025 | -640 |
| 2021004865 | SEEDUC | LIGHT SERVICOS DE ELETRICIDADE SA | Trata o presente processo da contratação de fornecimento de energia e… | R$ 49.011.936,22 | 10/11/2024 | -726 |
| 2025000254 | SEEDUC | EUREKA SOLUCOES PEDAGOGICAS LTDA | A aquisição de Material de Apoio Pedagógico para a Rede Pública Estad… | R$ 45.132.036,40 | 21/01/2026 (PNCP) | -289 |
| 2025002964 | SEEDUC | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação de concessionária LIGHT - Serviço de Eletricidade S.A - M… | R$ 41.720.376,64 | 13/03/2026 (PNCP) | -238 |
| 2023010916 | SEEDUC | C TRES - ASSESSORIA E CONSULTORIA EDUCACIONA… | Trata o presente Termo de Referência acerca da aquisição com base no … | R$ 40.648.410,00 | 26/12/2024 | -680 |
| 2024009156 | SEEDUC | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | Contratação em caráter emergencial de empresa especializada na presta… | R$ 39.864.300,00 | 13/11/2025 (PNCP) | -358 |
| 2021004016 | SEEDUC | HB MULTISERVIÇOS LTDA | Trata-se de processo que propõe a renovação, por doze meses do contra… | R$ 38.979.675,46 | 04/02/2025 | -640 |
| 2023010919 | SEEDUC | DISLIV EDITORA E DISTRIBUIDORA DE LIVROS LTDA | Trata o presente Termo de Referência acerca da aquisição com base no … | R$ 36.368.502,50 | 25/12/2024 | -681 |
| 2024003027 | SEEDUC | AGUAS DO RIO 4 SPE S.A | Serviço de fornecimento de água etratamento de esgoto nas unidades es… | R$ 34.401.406,91 | 26/04/2025 (PNCP) | -559 |

_Registros mais antigos (provável falta de baixa no SIGA): 3213, R$ 7.882,2 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026008473 | SEEDUC | CENTRO DE DEPARTAMENTO PESSOAL | O PRESENTE PROCESSO VISA A CONTRATAÇÃO EMERGENCIAL DE EMPRESA ESPECIA… | R$ 158.997.240,00 | 11/06/2027 | 217 |
| 2025000431 | SEEDUC | CAPITAL AMBIENTAL CONSTRUÇÃO E SERVIÇOS LTDA | Contratação de empresa para prestar junto à Secretaria de Estado de E… | R$ 129.217.957,73 | 04/02/2027 | 90 |
| 2025000432 | SEEDUC | INFINITY MULTISERVIÇOS LTDA | Contratação de empresa para prestar junto à Secretaria de Estado de E… | R$ 121.489.222,80 | 04/02/2027 | 90 |
| 2021004421 | SEEDUC | INSTITUTO POSITIVA SOCIAL | Consumo da Ata SRP: 0002/2021/180100-02, cujo objeto refere-se a cont… | R$ 109.636.599,60 | 16/09/2027 | 314 |
| 2025010945 | SEEDUC | FUNDAÇÃO DE APOIO A PESQUISA, ENSINO E ASSIS… | A presente contratação visa dar prosseguimento na segunda fase do pro… | R$ 97.796.253,26 | 29/12/2026 (PNCP) | 53 |
| 2026008542 | SEEDUC | FUNDAÇÃO GETULIO VARGAS | Contratação de serviços técnicos especializados de assessoramento à S… | R$ 97.736.000,00 | 09/12/2027 | 398 |
| 2021000299 | SEEDUC | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRE… | R$ 95.153.414,00 | 08/02/2027 | 94 |
| 2021000296 | SEEDUC | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRE… | R$ 91.211.633,46 | 08/02/2027 | 94 |
| 2025009866 | SEEDUC | FUNDAÇÃO CESGRANRIO | Contratação de instituição especializada em avaliação educacional em … | R$ 79.935.748,49 | 28/11/2027 | 387 |
| 2025000430 | SEEDUC | BLUEL RJ OPERACOES EM SERVICOS E ALIMENTACAO… | Contratação de empresa para prestar junto à Secretaria de Estado de E… | R$ 76.289.917,72 | 04/02/2027 | 90 |
| 2025002291 | SEEDUC | INSTITUTO DE ENSINO PÓLIS CIVITAS LTDA | Trata o presente Termo de Referência acerca da aquisição de curso e f… | R$ 72.500.000,00 | 07/04/2027 (PNCP) | 152 |
| 2021000298 | SEEDUC | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRE… | R$ 66.367.969,48 | 08/02/2027 | 94 |
| 2021000297 | SEEDUC | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRE… | R$ 64.490.019,99 | 08/02/2027 | 94 |
| 2025000429 | SEEDUC | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | Contratação de empresa para prestar junto à Secretaria de Estado de E… | R$ 58.197.626,16 | 04/02/2027 | 90 |
| 2021000295 | SEEDUC | SHINE RIO SERVIÇOS EIRELI ME | PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRE… | R$ 55.890.274,73 | 08/02/2027 | 94 |
| 2021000300 | SEEDUC | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRESTAÇÃO DE SERVIÇOS DE VIGIA , PRE… | R$ 46.038.095,60 | 08/02/2027 | 94 |
| 2026003049 | SEEDUC | AGUAS DO RIO 4 SPE S.A | Contratação de empresa para prestação de serviços de fornecimento de … | R$ 33.440.197,32 | 05/01/2027 (PNCP) | 60 |
| 2025009514 | SEEDUC | ALFAMA INDÚSTRIA E COMÉRCIO DE DESCARTÁVEIS … | Solicitação de consumo da ata de absorventes - PLASVIVO | R$ 31.535.351,92 | 13/11/2026 | 7 |
| 2022007484 | SEEDUC | MUNICIPIO DE RIO DE JANEIRO | Trata-se de processo administrativo cujo objeto é a celebração de um … | R$ 30.678.464,40 | 30/04/2027 | 175 |
| 2025010859 | SEEDUC | PLURAL INDÚSTRIA GRÁFICA LTDA | O objeto do presente é a contratação de pessoa jurídica especializada… | R$ 30.045.701,00 | 23/12/2026 (PNCP) | 47 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026008473 | SEEDUC | CENTRO DE DEPARTAMENTO PESSOAL | O PRESENTE PROCESSO VISA A CONTRATAÇÃO EMERGENCIAL DE EMPRESA ESPECIA… | R$ 158.997.240,00 | 11/06/2027 | 217 |

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | 6 | R$ 421.458.758,69 |
| CENTRO DE DEPARTAMENTO PESSOAL | 1 | R$ 158.997.240,00 |
| CAPITAL AMBIENTAL CONSTRUÇÃO E SERVIÇOS LTDA | 1 | R$ 129.217.957,73 |
| INFINITY MULTISERVIÇOS LTDA | 1 | R$ 121.489.222,80 |
| INSTITUTO POSITIVA SOCIAL | 1 | R$ 109.636.599,60 |
| FUNDAÇÃO DE APOIO A PESQUISA, ENSINO E ASSISTENCIA A ESCOLA… | 1 | R$ 97.796.253,26 |
| FUNDAÇÃO GETULIO VARGAS | 1 | R$ 97.736.000,00 |
| FUNDAÇÃO CESGRANRIO | 1 | R$ 79.935.748,49 |
| BLUEL RJ OPERACOES EM SERVICOS E ALIMENTACAO LTDA | 1 | R$ 76.289.917,72 |
| INSTITUTO DE ENSINO PÓLIS CIVITAS LTDA | 1 | R$ 72.500.000,00 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2016006182 | FEDERACAO DAS EMPRESAS DE TRANSPORTE DE PASS… | R$ 56.733.270,00 | R$ 0,00 | R$ 56.733.270,00 |
| 2017005332 | FEDERAÇÃO DAS EMPRESAS DE TRANSPORTES DE PAS… | R$ 56.472.407,00 | R$ 0,00 | R$ 56.472.407,00 |
| 2019007547 | FEDERACAO DAS EMPRESAS DE TRANSPORTE DE PASS… | R$ 54.036.605,00 | R$ 0,00 | R$ 54.036.605,00 |
| 2017004687 | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | R$ 16.158.166,79 | R$ 0,00 | R$ 16.158.166,79 |
| 2020003912 | JUBERLAN FRANCISCO DE BARROS OLIVEIRA | R$ 13.444.000,00 | R$ 0,00 | R$ 13.444.000,00 |
| 2020000338 | SINGULAR GESTÃO DE SERVIÇOS LTDA. | R$ 14.562.154,18 | R$ 2.263.013,13 | R$ 12.299.141,05 |
| 2022006000 | EDM EMPRESA DISTRIBUIDORA DE MOBILIARIO LTDA | R$ 12.199.370,00 | R$ 0,00 | R$ 12.199.370,00 |
| 2018004123 | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | R$ 24.032.567,13 | R$ 12.423.223,66 | R$ 11.609.343,47 |
| 2020000330 | SINGULAR GESTÃO DE SERVIÇOS LTDA. | R$ 13.374.496,08 | R$ 2.234.963,93 | R$ 11.139.532,15 |
| 2018004124 | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | R$ 20.137.808,12 | R$ 9.809.005,12 | R$ 10.328.803,00 |
| 2018004121 | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | R$ 18.120.358,36 | R$ 8.910.803,70 | R$ 9.209.554,66 |
| 2016006264 | MUNICIPIO DE RIO DE JANEIRO | R$ 9.162.058,89 | R$ 0,00 | R$ 9.162.058,89 |
| 2017004951 | MUNICIPIO DE RIO DE JANEIRO | R$ 8.603.761,68 | R$ 0,00 | R$ 8.603.761,68 |
| 2018004110 | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | R$ 14.474.388,24 | R$ 6.479.383,86 | R$ 7.995.004,38 |
| 2018003017 | MUNICIPIO DE RIO DE JANEIRO | R$ 8.537.459,82 | R$ 1.433.960,28 | R$ 7.103.499,54 |
| 2020000336 | SINGULAR GESTÃO DE SERVIÇOS LTDA. | R$ 8.542.691,72 | R$ 1.600.957,12 | R$ 6.941.734,60 |
| 2018004111 | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | R$ 12.965.729,08 | R$ 6.505.564,39 | R$ 6.460.164,69 |
| 2016006181 | SINDICATO DAS EMP DE TRANSP DE PASS DE B MAN… | R$ 4.879.741,00 | R$ 0,00 | R$ 4.879.741,00 |
| 2017005335 | SINDICATO DAS EMP DE TRANSP DE PASS DE B MAN… | R$ 4.803.326,00 | R$ 0,00 | R$ 4.803.326,00 |
| 2021000759 | AGILE CORP SERVIÇOS ESPECIALIZADOS LTDA | R$ 40.859.552,50 | R$ 36.156.131,29 | R$ 4.703.421,21 |

## 11. Unidades incluídas neste dossiê
- NOVO DEGASE - Dep Geral de Ações Socioeducativas
- SEEDUC - SECRETARIA DE ESTADO DE EDUCAÇÃO

## 12. Conjuntos de dados abertos da secretaria
- Diretorias Regionais (atualizado 2026-10-16): [Diretorias Regionais 2026 XLSX](https://dadosabertos.rj.gov.br/dataset/a4cf6905-7eaa-4b1a-b081-acdfe37023b4/resource/8c0744a2-6d0f-4901-b1e5-d8d8440147ba/download/diretorias-regionais_dados_abertos.xlsx)
- Estatísticas de Atendimento (atualizado 2026-07-01): [relatorio-manifestacao.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/50e2c093-f557-4a9c-a64f-b1934381b2ea/resource/76bb855f-ff7a-4168-a2d2-a3117d6a3835/download/2026-02-04-relatorio-manifestacao.xlsx)
- Migração de Docentes (atualizado 2026-06-15): [MIGRAÇÕES DE CARGA HORÁRIA XLSX](https://dadosabertos.rj.gov.br/dataset/a1723214-1b27-4dd6-b1c5-8c442e28a63f/resource/4ff511cb-43cd-4e59-a568-8cd54975efa2/download/migracoes-de-carga-horaria-por-psi.xlsx)
- Informações Pedagógicas (atualizado 2026-06-15): [Quantitativo de alunos 2025 CSV](https://dadosabertos.rj.gov.br/dataset/8114cdb2-a3e4-42b6-b851-556ad40ebc40/resource/46a1a3ba-b294-414b-9aa4-3ac65b663cd9/download/microdados_seeduc_06_2025-1.csv), [Quantitativos de alunos 2026 CSV](https://dadosabertos.rj.gov.br/dataset/8114cdb2-a3e4-42b6-b851-556ad40ebc40/resource/d934d67a-d0db-4049-b498-950e13e201ff/download/microdados_escolas_seeduc_2026.csv), [Itinerários Formativos XLSX](https://dadosabertos.rj.gov.br/dataset/8114cdb2-a3e4-42b6-b851-556ad40ebc40/resource/d22ee9eb-998a-4187-8462-91a567bdefdd/download/itinerarios-por-regional.xlsx)
- Consolidado Mapa de Merenda (atualizado 2026-04-29): [CONSOLIDADO - MAPA DE MERENDA 2025.xlsx XLSX](https://sites.google.com/educa.rj.gov.br/portaldatransparencia/in%C3%ADcio/escolas-e-regionais/mapa-de-merenda), [CONSOLIDADO - MAPA DE MERENDA 2024.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/7fd0cd0e-e396-46b5-be98-796b128562ce/resource/0f426be9-6f36-4630-8d4e-da8035fbc0e1/download/monitoramento-de-mapa-de-merenda_modelo-2024.xlsx), [CONSOLIDADO - MAPA DE MERENDA 2023.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/7fd0cd0e-e396-46b5-be98-796b128562ce/resource/1c7706af-10fa-4b7c-b67f-a8805fc35dce/download/mapa-de-merenda-de-2023.xlsx), [CONSOLIDADO - MAPA DE MARENDA 2022.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/7fd0cd0e-e396-46b5-be98-796b128562ce/resource/8e8ce8e1-7e05-485b-aacf-bb89fd1cf6af/download/monitoramento-de-mapa-de-merenda-dez.2022_27.01.2023-as-11h00min.xlsx)
- Licitações (atualizado 2026-04-29): [Relatório de Licitações 2025 XLSX](https://sites.google.com/educa.rj.gov.br/portaldatransparencia/in%C3%ADcio/licita%C3%A7%C3%B5es-e-contratos/licita%C3%A7%C3%B5es)
- Contratos (atualizado 2026-03-16): [Controle de Contratos 2026 XLSX](https://dadosabertos.rj.gov.br/dataset/74395475-27ed-46d7-9dc6-fed8053030d7/resource/30009434-3f6d-4d76-8333-246969dee032/download/contratos-seeduc.xlsx)
- Convênios (atualizado 2025-12-18): [Controle de Convênios 2025.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/ef324188-cfef-49ab-af0f-a10e6d8b3b12/resource/e7434a2a-04e0-4d0b-9101-df9d3adf20b1/download/controle-de-convenios-2025.xlsx)
- Orçamento e Finanças (atualizado 2025-12-09): [Repasse as escolas 2025.csv CSV](https://dadosabertos.rj.gov.br/dataset/95ba9caf-2736-4636-813f-62f1aa561965/resource/cde02759-fe69-4fee-bd63-220f2db9fcca/download/repasse-as-escolas-2025.csv), [Diarias de viagens 2025.csv CSV](https://dadosabertos.rj.gov.br/dataset/95ba9caf-2736-4636-813f-62f1aa561965/resource/f394d791-0343-4d37-92ed-80970710bd49/download/diarias-de-viagens-2025.csv)
- Relação de Escolas Privadas do Rio de Janeiro (atualizado 2025-05-28): [Relação de Escolas Privadas do Rio de J… XLSX](https://dadosabertos.rj.gov.br/dataset/e4cb3fcd-961c-4dc6-9d30-b2c632c635bc/resource/54886a35-0d78-498e-b250-170611808c58/download/relacao-de-escolas-privadas-do-rio-de-janeiro.xlsx)
- Relação de Escolas Estaduais (atualizado 2025-05-28): [Relação de Escolas Estaduais.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/a99258bb-2cc8-45cc-ad37-ae86e47473d0/resource/95dcf6db-452f-49cc-952b-418888e3e7ec/download/relescolasestaduais.xlsx)
- Metas Físicas do PPA (atualizado 2025-05-28): [Metas_Fisicas_2024-2027.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/3646b1e1-0e61-4783-9cd5-c68be5bbe57a/resource/cd3d40a2-4781-4302-9a94-1759668fa734/download/metas_fisicas_2024-2027.xlsx)
- Indicadores de inciativa do PPA 24-27 (atualizado 2025-05-28): [Indicadores de iniciativa do PPA 24-27 … XLSX](https://dadosabertos.rj.gov.br/dataset/9c13228c-e2dd-4002-ae58-b0e6a02b4344/resource/85489bd9-6db6-4849-a157-9054bd2c756e/download/indicadores-de-iniciativa-seeduc.xlsx)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 6 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

- As fontes relatam investigações e apontamentos de controle sobre obras escolares contratadas sem licitação e pelo sistema descentralizado de pagamento; os valores e irregularidades citados são suspeitas ou achados ainda sujeitos a apuração, não conclusões definitivas de responsabilidade. [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml) [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml)
- O TCE-RJ determinou a suspensão de pagamentos a seis empresas e, segundo reportagem publicada em outubro, contratos de obras estavam suspensos para reavaliação; as fontes não informam o desfecho posterior dessas medidas. [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml) [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)
- O contrato de apoio escolar em Educação Especial terminou em julho de 2026; fontes de setembro descrevem risco de descontinuidade e uma contratação emergencial estimada em R$ 220 milhões, cujo status final não fica esclarecido. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/) [Blog do Ralfe Reis — cuidadores nas escolas](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/)
- Roberta Barreto deixou a Secretaria em 24 de fevereiro de 2026; as fontes não identificam quem a sucedeu nem detalham a transição administrativa. [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml)

##### Alertas vermelhos

- **Obras escolares:** reportagens apontam R$ 1,6 bilhão em contratos de obras sem licitação entre 2023 e 2025; o TCE-RJ havia apontado indícios de burla às regras de licitação e possível dano ao erário, sem que as fontes fornecidas indiquem decisão final sobre responsabilidades. [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml) [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml)
- **Concentração de contratações:** dez empresas concentraram R$ 540,8 milhões, cerca de um terço dos R$ 1,6 bilhão reportados; o GSI teria identificado suspeita de irregularidades em 95% das 1.241 escolas, e os contratos foram suspensos para reavaliação, segundo a reportagem. [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)
- **Educação Especial:** o encerramento do contrato de apoio escolar e o atraso na nova contratação foram associados, em relatos publicados, à falta de cuidadores para estudantes; a SEEDUC contestou a alegação de inércia e afirmou que reforçava o suporte por outros meios. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/) [Blog do Ralfe Reis — cuidadores nas escolas](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/)
- **Contratação emergencial de apoio escolar:** a contratação estimada em R$ 220 milhões foi questionada pelo Controle Interno por problemas nos cálculos, vagas consideradas excessivas e risco de sobrepreço; a SEEDUC afirmou que corrigiu inconsistências antes da assinatura, mas as fontes não esclarecem se o contrato foi assinado ou qual é sua situação atual. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/) [Blog do Ralfe Reis — cuidadores nas escolas](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/)
- **Operação policial e do Ministério Público:** em 1º de outubro de 2026, G1 noticiou operação sobre suspeitas de fraude em contratos da SEEDUC e informou que a ex-secretária era alvo; os fatos descritos são objeto de investigação e não equivalem a condenação. [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml)

##### Contratos e serviços críticos

- **Obras escolares sem licitação:** entre 2023 e 2025, foram reportados R$ 1,6 bilhão em contratos, dos quais R$ 540,8 milhões ficaram concentrados em dez empresas; os dados fornecidos não trazem os números identificadores nem a vigência individual de cada contrato. [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)
- Entre as empresas listadas, a Rod Jeff Obras e Construções aparece com R$ 86,8 milhões; a F.V. Figueiredo, com R$ 70,2 milhões; a Attom Construções e Comércio, com R$ 68,8 milhões; e a M2GA Obras e Reformas Ltda., com R$ 68,7 milhões na lista e R$ 68,8 milhões em outro trecho da reportagem. [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)
- **Sistema descentralizado:** os repasses para obras em escolas superaram R$ 1 bilhão em 2024 e 2025, com cerca de R$ 630 milhões em 2024 e R$ 500 milhões em 2025, segundo levantamento reproduzido em reportagem; os pagamentos não apareciam no sistema orçamentário citado e não era possível saber quanto cada empresa recebeu ao todo. [G1 — TCE abre inquérito](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/02/06/tce-abre-inquerito-para-investigar-obras-em-escolas-estaduais-do-rj-pagas-por-sistema-descentralizado.ghtml) [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml)
- A SEEDUC informou ter definido um teto de R$ 130 mil para intervenções classificadas como manutenção e pequenos reparos e que obras acima desse limite serão executadas pela empresa de obras públicas. [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml)
- Na investigação relatada pelo G1, a MCK Reformas e Construções teria recebido cerca de R$ 6 milhões em contratos, dos quais aproximadamente R$ 4 milhões teriam sido repassados a Fabio Martins Pereira, proprietário da Virtual Construtora; a mesma reportagem diz que, somente em 2025, a MCK recebeu mais de R$ 11 milhões em recursos públicos, parte sacada em dinheiro vivo. [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml)
- A reportagem sobre a operação afirma que investigadores apontaram que a MCK funcionaria em endereço residencial, não teria empregados registrados e não apresentaria histórico compatível com grandes obras; são alegações investigativas, não conclusões judiciais informadas nas fontes. [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml)
- **Apoio escolar na Educação Especial:** o contrato com o Instituto Positiva Social (IPCEP) terminou em julho de 2026; a Seeduc não o renovou, atribuindo a decisão a irregularidades trabalhistas reiteradas, entre elas atrasos salariais e inadimplemento de FGTS e verbas rescisórias. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/) [Blog do Ralfe Reis — cuidadores nas escolas](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/)
- O processo SEI-030001/119257/2025 previa licitação ordinária para contrato de R$ 648 milhões, com validade de dois anos; a reportagem de 14 de setembro de 2026 relata atrasos e informa que a audiência pública do novo edital foi agendada para setembro. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/)
- A contratação emergencial de apoio escolar foi estimada em R$ 220 milhões; a reportagem de 14 de setembro dizia que o processo não estava concluído e a resposta da SEEDUC reproduzida em outra matéria dizia que inconsistências preliminares de cálculo foram corrigidas antes da assinatura, sem esclarecer o status final. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/) [Blog do Ralfe Reis — cuidadores nas escolas](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/)
- O contrato anterior do IPCEP teve aditamento de R$ 66 milhões, associado ao processo SEI-030001/058097/2025, segundo a reportagem; ela informa que o processo do aditivo não estava disponível na pesquisa pública geral do SEI. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/)
- A SEEDUC estimava atendimento a mais de 16 mil estudantes da Educação Especial e necessidade imediata de pelo menos 2,7 mil profissionais no início de 2026, com meta de expansão para até 4 mil postos; outra reportagem reproduziu a afirmação da Secretaria de que o serviço atende cerca de 16 mil estudantes. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/) [Blog do Ralfe Reis — cuidadores nas escolas](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- **TCE-RJ, fevereiro de 2026:** o Tribunal abriu inquérito para apurar possíveis irregularidades nas obras escolares pagas pelo sistema descentralizado e deu à então secretária Roberta Barreto cinco dias para se explicar, conforme representação do deputado estadual Flávio Serafini. [G1 — TCE abre inquérito](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/02/06/tce-abre-inquerito-para-investigar-obras-em-escolas-estaduais-do-rj-pagas-por-sistema-descentralizado.ghtml)
- **TCE-RJ, abril de 2026:** decisão determinou à Secretaria a suspensão de pagamentos a seis empresas e prazo de 15 dias para manifestação sobre irregularidades; a fonte não informa os nomes de todas as empresas nem o resultado posterior da manifestação. [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml)
- O TCE apontou indícios de que obras de grande vulto, sem caráter de urgência, teriam sido pagas por mecanismo destinado a compras emergenciais e pequenos reparos, além de possível falta de pesquisa de preços capaz de demonstrar economicidade; são apontamentos do Tribunal, não decisão final de mérito informada nas fontes. [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml)
- **MPRJ e investigação policial:** a reportagem de 1º de outubro de 2026 noticia operação da Polícia Civil e do Ministério Público sobre suspeitas de fraude em contratos da SEEDUC e aponta Roberta Barreto como alvo; informa que foram expedidos 19 mandados de busca e apreensão e que não havia mandados de prisão. As fontes fornecidas não especificam denúncias oferecidas, outras decisões judiciais ou medidas cautelares, nem o estágio processual da investigação. [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml)
- A investigação descrita pelo G1 apura possível direcionamento de licitações e prejuízo que poderia chegar a R$ 1,6 bilhão; a reportagem atribui essas hipóteses às investigações e não informa condenação ou decisão judicial definitiva. [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml)
- **MPT e contrato de apoio escolar:** a SEEDUC atribuiu a não renovação do contrato com o Instituto Positiva Social a irregularidades trabalhistas apuradas em articulação com o MPT e que resultaram no Termo de Ajustamento de Conduta nº 99/2026; a fonte não detalha eventual cumprimento integral do TAC. [Blog do Ralfe Reis — cuidadores nas escolas](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/)
- O G1 relata também investigação do TCE-RJ iniciada após denúncias e reportagens, além de apuração da Polícia Federal sobre possível influência de Rodrigo Bacellar na antiga gestão da Secretaria; o material fornecido não informa o desfecho dessas apurações. [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml)
- **Judiciário:** Nada encontrado nas fontes consultadas sobre ações judiciais, decisões de primeira ou segunda instância, condenações ou bloqueios de bens relacionados aos temas descritos. [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml) [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml)

##### Riscos de apagão administrativo

- **Continuidade do apoio escolar:** as fontes relatam que, após o término do contrato em julho de 2026, estudantes estavam sem acompanhamento adequado; famílias relataram falta de acompanhamento necessário para alimentação, higiene, locomoção, comunicação e participação nas atividades escolares. A SEEDUC afirmou que reforçava o atendimento por meio do AEE, de professores articuladores, salas de recursos e outras medidas. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/) [Blog do Ralfe Reis — cuidadores nas escolas](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/)
- O processo de licitação ordinária de apoio escolar sofreu atrasos, e a tentativa de contratação emergencial enfrentou revisão de cálculos e questionamentos de controle interno, o que cria risco de demora na recomposição contratual; as fontes não informam se esse risco foi posteriormente resolvido. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/) [Blog do Ralfe Reis — cuidadores nas escolas](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/)
- **Obras escolares:** o TCE-RJ determinou a suspensão de pagamentos a seis empresas, e a Secretaria Estadual de Educação informou ter iniciado uma revisão administrativa de todos os procedimentos relacionados às obras nas unidades da rede estadual. As fontes não informam quais obras foram interrompidas nem os impactos concretos sobre cada escola. [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml) [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)
- A fonte sobre a escola cívico-militar em Realengo relata canteiro abandonado após R$ 1,3 milhão em despesas aprovadas referentes a quatro contratos e R$ 4,7 milhões destinados à desapropriação do terreno; não informa o cronograma atualizado nem a situação posterior da obra. [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)
- O sistema descentralizado movimentou mais de R$ 1 bilhão em dois anos, enquanto reportagens apontaram que os pagamentos não apareciam no sistema orçamentário citado e que não era possível determinar o total recebido por cada empresa; isso sinaliza risco de baixa rastreabilidade, conforme os relatos. [G1 — TCE abre inquérito](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/02/06/tce-abre-inquerito-para-investigar-obras-em-escolas-estaduais-do-rj-pagas-por-sistema-descentralizado.ghtml)

##### Fatos recentes

- Em 14 de setembro de 2026, reportagem informou que a contratação emergencial de apoio escolar, estimada em R$ 220 milhões, ainda não estava concluída e que a licitação ordinária prevista em processo SEI enfrentava atrasos. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/)
- Em 16 de setembro de 2026, a SEEDUC afirmou que corrigiu inconsistências de cálculo tributário antes da assinatura da contratação emergencial e atribuiu a não renovação do contrato anterior a irregularidades trabalhistas reiteradas. [Blog do Ralfe Reis — cuidadores nas escolas](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/)
- Em 1º de outubro de 2026, G1 noticiou operação policial e do Ministério Público sobre suspeitas de fraude em contratos da SEEDUC e informou que a ex-secretária Roberta Barreto era alvo da investigação. [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml)
- Em 1º de outubro de 2026, O Globo publicou levantamento segundo o qual dez empresas concentraram R$ 540,8 milhões em contratações de obras escolares sem licitação, dentro do total de R$ 1,6 bilhão reportado para 2023 a 2025. [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)
- O Globo informa que os contratos de obras estavam suspensos para reavaliação e que o GSI apontava suspeita de irregularidades em 95% das 1.241 escolas; a fonte não apresenta a conclusão da auditoria. [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)

- **Obras:** pedir inventário completo dos contratos, processos de contratação, empresas, valores pagos e a pagar, vigências, escolas atendidas, medições, aditivos, status de execução e justificativas de emergência ou dispensa, pois as fontes não apresentam essa relação completa nem os identificadores e vigências individuais. [G1 — TCE abre inquérito](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/02/06/tce-abre-inquerito-para-investigar-obras-em-escolas-estaduais-do-rj-pagas-por-sistema-descentralizado.ghtml) [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)
- **Controle e investigações:** pedir cópias das decisões e manifestações ao TCE-RJ, da auditoria do GSI, dos procedimentos administrativos e das comunicações com MPRJ, Polícia Civil, Polícia Federal e demais órgãos, pois as fontes não informam resultados finais ou o estado atual das apurações. [G1 — TCE suspende repasses](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml) [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml) [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)
- **Educação Especial:** pedir situação atual do contrato emergencial de R$ 220 milhões, eventual instrumento assinado, fornecedores, valores, cobertura por unidade, número de profissionais ativos, calendário da licitação de R$ 648 milhões e plano de continuidade do serviço; as fontes não esclarecem se a contratação emergencial foi concluída. [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/) [Blog do Ralfe Reis — cuidadores nas escolas](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/)
- **Passivos e débitos:** Nada encontrado nas fontes consultadas sobre estoque de dívidas da SEEDUC, restos a pagar, passivos judiciais, valores devidos a fornecedores ou contingências financeiras consolidadas; solicitar demonstrativo atualizado à Secretaria. [G1 — TCE abre inquérito](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/02/06/tce-abre-inquerito-para-investigar-obras-em-escolas-estaduais-do-rj-pagas-por-sistema-descentralizado.ghtml) [Tempo Real RJ — contrato de apoio escolar](https://temporealrj.com/educacao-especial-sem-contrato/)
- **Gestão e transição:** pedir organograma atualizado, responsáveis por contratos e controle interno, delegações, plano de transição e relação de processos em curso; as fontes não identificam o sucessor de Roberta Barreto nem descrevem a transição. [G1 — operação Escola de Papel](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml)
- **Dados a conciliar:** solicitar esclarecimento sobre a divergência na reportagem do O Globo que lista a Motirô com R$ 52,3 milhões e, em outro trecho, afirma que ela se comprometeu a realizar R$ 525 milhões em melhorias; as fontes não explicam essa diferença. [O Globo — contratos de obras escolares](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml)

##### Fontes consultadas
1. [Operação Escola de Papel: Ex-secretária do RJ é alvo por fraudes   G1](https://g1.globo.com/rj/rio-de-janeiro/bom-dia-rio/noticia/2026/10/01/policia-civil-e-ministerio-publico-deflagram-a-operacao-escola-de-papel.ghtml) — 2026-10-01
2. [Dez empresas concentram um terço das contratações sem licitação na reforma bilionária de escolas pelo Governo ](https://oglobo.globo.com/rio/noticia/2026/10/01/dez-empresas-concentram-um-terco-das-contratacoes-sem-licitacao-na-reforma-bilionaria-de-escolas-pelo-governo-do-estado.ghtml) — 2026-10-01
3. [Governo de Ricardo Couto deixa estudantes da Educação Especial nas escolas estaduais sem cuidadores - Blog do ](https://www.tribunanf.com.br/blogdoralfereis/2026/09/16/governo-de-ricardo-couto-deixa-estudantes-da-educacao-especial-nas-escolas-estaduais-sem-cuidadores/) — 2026-09-16
4. [temporealrj.com › educacao-especial-sem-contratoGoverno do estado deixa contrato vencer, tenta emergencial de ](https://temporealrj.com/educacao-especial-sem-contrato/) — 2026-09-14
5. [TCE-RJ manda suspender repasses para obras em escolas ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/22/tce-ve-indicios-de-irregularidades-obras-na-educacao-do-rj.ghtml) — 2026-04-22
6. [TCE abre inquérito para investigar obras em escolas estaduais do RJ](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/02/06/tce-abre-inquerito-para-investigar-obras-em-escolas-estaduais-do-rj-pagas-por-sistema-descentralizado.ghtml) — 2026-02-06


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2025008965 (ZETECH MANUTENÇÃO E SERVIÇOS EM ENERGIA…) vence em 07/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2026007327 (CONTAGOV LTDA) vence em 09/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025008028 (GABBA DISTRIBUIDORA LTDA) vence em 12/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2025009513 (PLASVIVO DISTRIBUIDORA DE ARTIGOS EM GE…) vence em 13/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025009514 (ALFAMA INDÚSTRIA E COMÉRCIO DE DESCARTÁ…) vence em 13/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2025000251 (EUREKA SOLUCOES PEDAGOGICAS LTDA, R$ 334,3 mi) consta 'Ativo' no SIGA com fim em 21/01/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2024005560 (INSTITUTO POSITIVA SOCIAL, R$ 154,7 mi) consta 'Ativo' no SIGA com fim em 18/07/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2025002089 (EBN COMERCIO, IMPORTACAO E EXPORTACAO E…, R$ 146,6 mi) consta 'Ativo' no SIGA com fim em 01/04/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2024010724 (EUREKA SOLUCOES PEDAGOGICAS LTDA, R$ 125,9 mi) consta 'Ativo' no SIGA com fim em 30/12/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2025000005 (FUNDAÇÃO GETULIO VARGAS, R$ 96,7 mi) consta 'Ativo' no SIGA com fim em 17/04/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
