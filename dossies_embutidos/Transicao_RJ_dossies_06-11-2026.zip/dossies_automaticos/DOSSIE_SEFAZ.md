# Dossiê de transição — Secretaria de Estado de Fazenda (SEFAZ)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/sefaz)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 333 | R$ 480.741.766,96 |
| Com vigência futura (válidos no SIGA) | 112 | R$ 250.074.320,83 |
| até 30 dias | 12 | R$ 25.589.562,65 |
| até 60 dias | 4 | R$ 15.573.877,82 |
| até 90 dias | 2 | R$ 521.897,00 |
| até 180 dias | 16 | R$ 24.711.315,10 |
| vencido no SIGA | 221 | R$ 230.667.446,13 |
| sem data | 10 | R$ 1.251.388,85 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 170,8 mi / R$ 98,5 mi / R$ 86,9 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2025009748 (EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES LTDA) vence em 26/11/2026 — 20 dias — R$ 15.861.602,00. Objeto: Trata-se da Adesão da Ata de Registro de Preços nº Nº 010/2025, cujo o objeto é…
- Contrato 2021006496 (CLARO S/A (FILIAL)) vence em 29/11/2026 — 23 dias — R$ 7.922.703,60. Objeto: Trata-se da adesão à Ata de registro de Preços nº 0001/2021, celebrada pelo Cen…
- Mais 10 contratos menores (R$ 1,8 mi) vencem em até 30 dias — ver seção 3.
- 33 contratos (R$ 65,9 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 89 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 113,8 mi); 3 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 132 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 116,9 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Concentração: BRASOFTWARE INFORMATICA LTDA detém 35% do valor vigente (2 contratos).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026008572 | SEFAZ | CONFECCOES BACELAR LTDA - ME | Trata-se de aquisição de 120 (cento e vinte) camisas polo estampadas … | R$ 8.900,00 | 13/11/2026 | 7 |
| 2026008598 | FAF | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | O presente Termo de Referência tem por objeto a aquisição de 2 (duas)… | R$ 13.000,00 | 13/11/2026 | 7 |
| 2026008658 | FAF | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | 10º Congresso Brasileiro de Governança, Controle Público e Gestão de … | R$ 13.000,00 | 14/11/2026 | 8 |
| 2026007929 | LOTERJ | INSTITUTO DE DESENVOLVIMENTO TURISMO CULTURA… | Contratação com apoio financeiro para o Patrocínio do evento III Fóru… | R$ 150.000,00 | 24/11/2026 | 18 |
| 2025009746 | FAF | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada para a confecção, fornecimento e… | R$ 966.556,50 | 26/11/2026 (PNCP) | 20 |
| 2025009748 | FAF | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Trata-se da Adesão da Ata de Registro de Preços nº Nº 010/2025, cujo … | R$ 15.861.602,00 | 26/11/2026 (PNCP) | 20 |
| 2026009126 | FAF | ESAFI - ESCOLA DE ADMINISTRAÇÃO E TREINAMENT… | O presente tem por escopo analisar a viabilidade técnica e econômica … | R$ 23.166,00 | 27/11/2026 | 21 |
| 2021006496 | FAF | CLARO S/A (FILIAL) | Trata-se da adesão à Ata de registro de Preços nº 0001/2021, celebrad… | R$ 7.922.703,60 | 29/11/2026 | 23 |
| 2025009394 | FAF | JSB COMERCIO E SERVIÇOS LTDA | Contratação de serviços continuados de manutenção preventiva e corret… | R$ 240.000,00 | 01/12/2026 | 25 |
| 2025009395 | FAF | PEMIPA SERVIÇOS E EMPREENDIMENTOS EIRELI ME | Contratação de serviços continuados de manutenção preventiva e corret… | R$ 187.999,92 | 01/12/2026 | 25 |
| 2026009246 | FAF | INSTITUTO ESAFI - CONSULTORIA, TREINAMENTOS … | O presente Termo de Referência tem por objeto estabelecer as condiçõe… | R$ 64.680,00 | 05/12/2026 | 29 |
| 2025007875 | SEFAZ | JAK - OBRAS CIVIS LTDA | Contratação de ``serviços de regularização de sistema de combate a in… | R$ 137.954,63 | 06/12/2026 | 30 |
| 2022009549 | LOTERJ | J G M MOREIRA JUNIOR 3 COMÉRCIO E SERVIÇOS | O presente Termo de Referência tem por objetivoa contratação de empre… | R$ 67.836,38 | 07/12/2026 | 31 |
| 2025010811 | FAF | LGPDNOW TRATAMENTO E HOSPEDAGEM DE DADOS LTDA | Trata-se da Contratação de plataforma de voltada para proteger redes,… | R$ 3.386.358,89 | 20/12/2026 | 44 |
| 2025010995 | FAF | LGPDNOW TRATAMENTO E HOSPEDAGEM DE DADOS LTDA | Trata-se da Contratação de plataforma de Inteligência Artificial (IA)… | R$ 6.119.682,55 | 30/12/2026 (PNCP) | 54 |
| 2026001001 | LOTERJ | ASSOCIAÇÃO LIGA BRASILEIRA DE MMA | Patrocínio pela Loteria do Estado do Rio de Janeiro - LOTERJ à ASSOCI… | R$ 6.000.000,00 | 03/01/2027 (PNCP) | 58 |
| 2026008237 | SEFAZ | GBL OURO EMPREENDIMENTOS E SERVIÇOS EIRELI | O presente relatório de pesquisa de mercado tem como objetivo aquisiç… | R$ 44.498,00 | 12/01/2027 | 67 |
| 2024010489 | LOTERJ | ASSOCIAÇÃO NITEROIENSE DOS DEFICIENTES FISIC… | CONTRATACAO DE EMPRESA ESPECIALIZADA NA PRESTACAO DE SERVICOS DE APOI… | R$ 477.399,00 | 29/01/2027 | 84 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2023010986 | FAF | SERVICO FEDERAL DE PROCESSAMENTO DE DADOS (S… | Contratação de empresa para o provimento de plataforma de compartilha… | R$ 90.329,40 | 05/02/2027 | 91 |
| 2021004149 | LOTERJ | CLARO S/A (FILIAL) | Aquisição de serviço de TI | R$ 356.046,60 | 10/02/2027 | 96 |
| 2026000527 | SEFAZ | COMERCIAL MARCTEL COMERCIO E SERVIÇO DE ALIM… | Contratação de empresa concessionária especializada para prestação de… | R$ 4.685,52 | 10/02/2027 | 96 |
| 2026005908 | LOTERJ | RIOPAR PARTICIPAÇÕES S/A | Fornecimento dos cartões e cargas aos servidores da LOTERJ, para asse… | R$ 163.816,01 | 10/02/2027 | 96 |
| 2026000781 | FAF | CLIMATIZADOR INDUSTRIAL RJ LTDA | Contratação de empresa especializada para locação de climatizadores p… | R$ 658.510,50 | 11/02/2027 (PNCP) | 97 |
| 2026000799 | LOTERJ | AGUAS DO RIO 4 SPE S.A | Contratação do serviço de fornecimento de água potável, coleta e trat… | R$ 57.878,71 | 11/02/2027 | 97 |
| 2026000888 | LOTERJ | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Contratação de serviços contínuos de publicidade legal, visando à rec… | R$ 79.992,00 | 12/02/2027 | 98 |
| 2026000826 | LOTERJ | LIGHT SERVICOS DE ELETRICIDADE SA | Fornecimento de eletricidade de fundamental importância para assegura… | R$ 158.033,83 | 20/02/2027 | 106 |
| 2024000464 | FAF | MULTITECNOLOGIA SERV. DE INFORMATICA LTDA | contratação de empresa especialiada na atualiação tecnológica dos equ… | R$ 14.868.255,86 | 25/02/2027 | 111 |
| 2026007461 | SEFAZ | AZUQ IMPORTACAO DE MULTIMARCAS LTDA | Aquisição de 9 (nove) motores e 9 (nove) hélices para substituição ju… | R$ 51.733,00 | 11/03/2027 | 125 |
| 2023000317 | LOTERJ | OI S/A | Serviços de Telefonia Fixa Comutada STFC | R$ 218.618,40 | 14/03/2027 | 128 |
| 2026001856 | SEFAZ | WEDAX DEDETIZADORA E SERVIÇOS LTDA | Contratação de empresa especializada em prestação de serviço contínuo… | R$ 13.765,11 | 18/03/2027 | 132 |
| 2026001857 | SEFAZ | ANGRA AMBIENTAL LTDA | Contratação de empresa especializada em prestação de serviço contínuo… | R$ 14.779,99 | 26/03/2027 | 140 |
| 2026002248 | FAF | FUNDAÇÃO GETULIO VARGAS | Contratação direta da instituição Fundação Getúlio Vargas  FGV para … | R$ 6.090.000,00 | 26/03/2027 (PNCP) | 140 |
| 2026002507 | FAF | GPBR PARTICIPACOES LTDA | Contratação de empresa especializada na disponibilização de plataform… | R$ 1.431.900,00 | 31/03/2027 (PNCP) | 145 |
| 2026007408 | SEFAZ | JOHNSON CONTROLS HITACHI AR CONDICIONADO DO … | Contratação de serviço de manutenção da operacionalidade dos compress… | R$ 452.970,16 | 13/04/2027 | 158 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2022004816 | FAF | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Contratação de serviço técnico especializado em desenvolvimento e man… | R$ 21.098.000,00 | 12/07/2026 | -117 |
| 2024008526 | FAF | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Contratação de prestação do serviço técnico de sustentação, operação … | R$ 15.742.260,00 | 30/10/2026 | -7 |
| 2025003017 | LOTERJ | ONIX ORGANIZACAO E PRODUCAO DE EVENTOS LTDA | Contratação de apoio financeiro para patrocínio ao ``Campeonato Cario… | R$ 14.000.000,00 | 07/10/2026 (PNCP) | -30 |
| 2022001959 | FAF | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Trata-se de contratação de empresa especializada em fornecimento de s… | R$ 8.052.096,00 | 03/04/2025 | -582 |
| 2024007926 | SEFAZ | FXX SEGURANCA E TRANSPORTE DE VALORES LTDA | Contratação de empresa especializada na atividade de vigilância patri… | R$ 6.393.471,37 | 24/04/2026 | -196 |
| 2021003518 | FAF | CLARO S/A (FILIAL) | Trata-se da utilização da Ata de Registro de Preços n°01/2021 cujo ob… | R$ 4.187.894,40 | 14/09/2026 | -53 |
| 2024002606 | SEFAZ | TIME MULTISSERVIÇOS LTDA | Contratação de empresa especialiada para prestação de serviços de man… | R$ 3.579.977,35 | 15/05/2026 | -175 |
| 2024007443 | FAF | CENTRO BRASILEIRO DE PESQUISA EM AVALIACAO E… | Contratação de instituição para prestação de serviços técnico especia… | R$ 3.297.477,28 | 12/09/2026 (PNCP) | -55 |
| 2021000014 | FAF | ILHA SERVICE TECNOLOGIA E SERVIÇOS LTDA | Contratação de serviços técnicos especializados na área de Tecnologia… | R$ 3.278.726,40 | 20/07/2026 | -109 |
| 2024005572 | FAF | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Contratação de empresa especializada no fornecimento de solução de ap… | R$ 3.118.858,00 | 17/07/2026 | -112 |
| 2024002750 | SEFAZ | FXX SEGURANCA E TRANSPORTE DE VALORES LTDA | Contratação de empresa especializada na atividade de vigilância patri… | R$ 2.965.703,52 | 02/05/2026 | -188 |
| 2024007839 | FAF | RIKE IS INTELIGÊNCIA DE SOFTWARE LTDA | Contratação de empresa especializadano fornecimento de solução de Mon… | R$ 2.259.287,67 | 30/09/2026 | -37 |
| 2023007882 | SEFAZ | BRS SUPRIMENTOS CORPORATIVOS S/A | Registro de Preços para eventual prestação de serviços continuados de… | R$ 2.124.877,48 | 01/11/2026 | -5 |
| 2025004581 | SEFAZ | SERG BRASIL MANUTENCAO E SERVICOS EIRELI ME | Contratação de serviço de prevenção e combate à incêndio, evacuação d… | R$ 1.904.898,96 | 27/06/2026 (PNCP) | -132 |
| 2024007923 | SEFAZ | ANGELS SEGURANÇA E VIGILANCIA EIRELI | Contratação de empresa especializada na atividade de vigilância patri… | R$ 1.760.196,48 | 24/04/2026 | -196 |
| 2024006831 | FAF | NOVE ORGANIZACAO DE EVENTOS LTDA | Contratação de empresa Nove Organização de Eventos LTDA., especializa… | R$ 1.592.251,70 | 03/01/2025 (PNCP) | -672 |
| 2024007838 | FAF | RIKE IS INTELIGÊNCIA DE SOFTWARE LTDA | Contratação de empresa especializadano fornecimento de solução de Mon… | R$ 1.387.314,84 | 30/09/2026 | -37 |
| 2021005963 | SEFAZ | ASSOCIAÇÃO NITEROIENSE DOS DEFICIENTES FISIC… | Prestação de serviços de Manutenção Predial erestauração em geral, at… | R$ 1.303.689,36 | 08/11/2024 | -728 |
| 2024000801 | SEFAZ | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | prestação de serviços de gestão do abastecimento, com utilização de s… | R$ 1.040.033,52 | 19/08/2025 | -444 |
| 2024006938 | LOTERJ | ESFERA BRASIL LTDA | Contratação para apoio financeiro ao Patrocínio do Evento SemináRio. | R$ 1.000.000,00 | 10/12/2024 (PNCP) | -696 |
| 2025009661 | LOTERJ | ASSOCIAÇÃO LIGA BRASILEIRA DE MMA | O presente processo tem por objeto o patrocínio pela Loteria do Estad… | R$ 1.000.000,00 | 18/01/2026 (PNCP) | -292 |
| 2025009842 | LOTERJ | ESFERA BRASIL LTDA | O presente Termo de Referência tem por objeto o patrocínio pela Loter… | R$ 1.000.000,00 | 26/01/2026 (PNCP) | -284 |
| 2026000885 | LOTERJ | PREFEITURA MUNICIPAL DE TERESÓPOLIS | Trata-se de proposta de patrocínio de contratação direta por inexigib… | R$ 1.000.000,00 | 01/05/2026 (PNCP) | -189 |
| 2024010621 | SEFAZ | POWER SAFETY SERVIÇOS E COMERCIO DE ELETROEL… | A presente licitação tem por objeto a contratação de empresa especial… | R$ 999.999,98 | 06/03/2026 (PNCP) | -245 |
| 2022009086 | SEFAZ | CS BRASIL FROTAS S.A. | Contratação de empresa especialiada na prestação de serviço de locaçã… | R$ 976.186,08 | 20/11/2025 | -351 |
| 2024009886 | FAF | RC CARD SOLUCOES EM PAGAMENTOS LTDA | Contratação de empresa especializada na prestação de serviços de emis… | R$ 731.040,00 | 04/12/2025 (PNCP) | -337 |
| 2024007925 | SEFAZ | CONQUISTA VIGILANCIA E SEGURANCA PATRIMONIAL… | Contratação de empresa especializada na atividade de vigilância patri… | R$ 726.253,44 | 24/04/2026 | -196 |
| 2025008953 | LOTERJ | DORIA ADMINISTRAÇÃO E EVENTOS LTDA | Contratação de patrocínio da empresa DORIA ADMINISTRAÇÃO E EVENTOS LT… | R$ 705.000,00 | 29/12/2025 (PNCP) | -312 |
| 2023003653 | SEFAZ | OI S/A | Contratação de serviço telefônico fixo comutado STFC fixofixo e fixom… | R$ 588.907,32 | 30/05/2026 | -160 |
| 2021005817 | SEFAZ | EMPRESA BRASILEIRA DE CORREIOS E TELÉGRAFOS | Trata-se da prorrogação do Contrato 022/2020 cujo objeto e a prestaçã… | R$ 563.250,20 | 08/11/2024 | -728 |

_Registros mais antigos (provável falta de baixa no SIGA): 132, R$ 116,9 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026001111 | FAF | BRASOFTWARE INFORMATICA LTDA | Trata-se da contratação de empresa especializada no fornecimento de u… | R$ 88.435.000,00 | 27/02/2031 | 1574 |
| 2025006538 | FAF | 3STRUCTURE IT LTDA | Consumo de itens de Ata de Sistema de Registro de Preços Backup - PRO… | R$ 28.440.566,48 | 05/09/2030 | 1399 |
| 2025010848 | FAF | ARVVO TECNOLOGIA, CONSULTORIA E SERVIÇOS LTDA | Trata-se da Adesão a Ata de Registro de Preços nº 18/2025, gerenciada… | R$ 25.275.768,00 | 31/12/2028 (PNCP) | 786 |
| 2025009748 | FAF | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Trata-se da Adesão da Ata de Registro de Preços nº Nº 010/2025, cujo … | R$ 15.861.602,00 | 26/11/2026 (PNCP) | 20 |
| 2024000464 | FAF | MULTITECNOLOGIA SERV. DE INFORMATICA LTDA | contratação de empresa especialiada na atualiação tecnológica dos equ… | R$ 14.868.255,86 | 25/02/2027 | 111 |
| 2021006496 | FAF | CLARO S/A (FILIAL) | Trata-se da adesão à Ata de registro de Preços nº 0001/2021, celebrad… | R$ 7.922.703,60 | 29/11/2026 | 23 |
| 2025010995 | FAF | LGPDNOW TRATAMENTO E HOSPEDAGEM DE DADOS LTDA | Trata-se da Contratação de plataforma de Inteligência Artificial (IA)… | R$ 6.119.682,55 | 30/12/2026 (PNCP) | 54 |
| 2026002248 | FAF | FUNDAÇÃO GETULIO VARGAS | Contratação direta da instituição Fundação Getúlio Vargas  FGV para … | R$ 6.090.000,00 | 26/03/2027 (PNCP) | 140 |
| 2026001001 | LOTERJ | ASSOCIAÇÃO LIGA BRASILEIRA DE MMA | Patrocínio pela Loteria do Estado do Rio de Janeiro - LOTERJ à ASSOCI… | R$ 6.000.000,00 | 03/01/2027 (PNCP) | 58 |
| 2019000261 | SEFAZ | FUNDO UNICO DE PREVIDENCIA SOCIAL DO ESTADO … | Trata-se da alteração da Unidade Gestora 206100 (FAF) para 200100 (SE… | R$ 5.672.463,36 | 02/11/2028 | 727 |
| 2026008498 | SEFAZ | MGS CLEAN SOLUÇÕES E SERVIÇOS LTDA | Contratação de empresa especializada para a prestação continuada de s… | R$ 5.054.266,05 | 14/04/2029 | 890 |
| 2025010811 | FAF | LGPDNOW TRATAMENTO E HOSPEDAGEM DE DADOS LTDA | Trata-se da Contratação de plataforma de voltada para proteger redes,… | R$ 3.386.358,89 | 20/12/2026 | 44 |
| 2026007976 | SEFAZ | CNS NACIONAL DE SERVIÇOS LTDA | Contratação dos serviços de prestação continuada de apoio administrat… | R$ 3.285.477,60 | 14/10/2027 | 342 |
| 2024007744 | LOTERJ | VOETUR TURISMO E REPRESENTAÇÕES LTDA. | contratação de agenciamento de viagens para aquisição de passagens aé… | R$ 2.454.812,98 | 10/10/2027 | 338 |
| 2025008770 | FAF | L8 GROUP S/A | Trata-se da contratação, no qual esta Secretaria de Estado de Fazenda… | R$ 2.165.184,72 | 04/11/2028 (PNCP) | 729 |
| 2024007902 | SEFAZ | CS BRASIL FROTAS S.A. | contratação de empresa especializada na prestação de serviço de locaç… | R$ 2.128.294,54 | 09/10/2027 | 337 |
| 2026003913 | FAF | PC SERVICE TECNOLOGIA LTDA | Trata-se da Contratação de empresa especializada na prestação de serv… | R$ 1.885.939,73 | 18/06/2027 | 224 |
| 2026002507 | FAF | GPBR PARTICIPACOES LTDA | Contratação de empresa especializada na disponibilização de plataform… | R$ 1.431.900,00 | 31/03/2027 (PNCP) | 145 |
| 2026003056 | SEFAZ | GENERAL SERVICE SOLUÇÕES EM SERVIÇOS LTDA | contratação de empresa especializada na prestação de serviços contínu… | R$ 1.429.872,45 | 03/07/2027 | 239 |
| 2025000200 | FAF | ELEVADORES ATLAS SCHINDLER LTDA. | Trata-se de processo de contratação de obras de modernização, com pre… | R$ 1.357.434,40 | 16/01/2030 | 1167 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| BRASOFTWARE INFORMATICA LTDA | 2 | R$ 88.584.295,40 |
| 3STRUCTURE IT LTDA | 1 | R$ 28.440.566,48 |
| ARVVO TECNOLOGIA, CONSULTORIA E SERVIÇOS LTDA | 1 | R$ 25.275.768,00 |
| EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES LTDA | 1 | R$ 15.861.602,00 |
| MULTITECNOLOGIA SERV. DE INFORMATICA LTDA | 1 | R$ 14.868.255,86 |
| LGPDNOW TRATAMENTO E HOSPEDAGEM DE DADOS LTDA | 2 | R$ 9.506.041,44 |
| FUNDAÇÃO GETULIO VARGAS | 4 | R$ 8.654.596,08 |
| CLARO S/A (FILIAL) | 3 | R$ 8.285.440,20 |
| ASSOCIAÇÃO LIGA BRASILEIRA DE MMA | 1 | R$ 6.000.000,00 |
| FUNDO UNICO DE PREVIDENCIA SOCIAL DO ESTADO DO RIO DE JANEI… | 1 | R$ 5.672.463,36 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2022004816 | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | R$ 6.242.584,45 | R$ 2.606.317,08 | R$ 3.636.267,37 |
| 2017001783 | ORACLE DO BRASIL SISTEMAS LTDA | R$ 9.774.975,89 | R$ 7.727.507,29 | R$ 2.047.468,60 |
| 2017000883 | ARROW ECS BRASIL DISTRIBUIDORA LTDA. | R$ 12.287.262,30 | R$ 10.830.456,83 | R$ 1.456.805,47 |
| 2022001959 | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | R$ 958.883,55 | R$ 525.894,46 | R$ 432.989,09 |
| 2018005573 | VETORSEG VIGILÂNCIA PATRIMONIAL LTDA ME | R$ 386.934,82 | R$ 0,00 | R$ 386.934,82 |
| 2017004509 | INGRAM MICRO INFORMATICA LTDA | R$ 8.489.023,01 | R$ 8.102.710,83 | R$ 386.312,18 |
| 2022006783 | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | R$ 458.860,45 | R$ 124.775,85 | R$ 334.084,60 |
| 2018003096 | TECHNE ENGENHARIA E SISTEMAS LTDA | R$ 3.712.543,27 | R$ 3.431.317,03 | R$ 281.226,24 |
| 2018004651 | INFOTEC CONSULTORIA E PLANEJAMENTO LTDA | R$ 1.160.235,78 | R$ 922.314,53 | R$ 237.921,25 |
| 2019000520 | CNS NACIONAL DE SERVIÇOS LTDA | R$ 1.447.870,16 | R$ 1.248.278,33 | R$ 199.591,83 |
| 2019000252 | ASSOCIAÇÃO NITEROIENSE DOS DEFICIENTES FISIC… | R$ 740.106,54 | R$ 546.666,96 | R$ 193.439,58 |
| 2019000264 | VETORSEG VIGILÂNCIA PATRIMONIAL LTDA ME | R$ 1.197.168,50 | R$ 1.006.464,94 | R$ 190.703,56 |
| 2021003070 | SERMACOL COMÉRCIO E SERVIÇOS LTDA | R$ 925.196,75 | R$ 742.659,92 | R$ 182.536,83 |
| 2021002966 | VETORSEG VIGILÂNCIA PATRIMONIAL LTDA ME | R$ 1.479.803,21 | R$ 1.319.183,95 | R$ 160.619,26 |
| 2021005963 | ASSOCIAÇÃO NITEROIENSE DOS DEFICIENTES FISIC… | R$ 392.607,44 | R$ 257.913,76 | R$ 134.693,68 |
| 2019000254 | BMC VIGILANCIA E SEGURANCA LTDA EPP | R$ 639.340,84 | R$ 504.767,46 | R$ 134.573,38 |
| 2019000263 | RIOMANSER SERVIÇO E MANUTENÇÃO LTDA | R$ 450.169,70 | R$ 323.999,99 | R$ 126.169,71 |
| 2019000348 | ARMANDO DE ALMEIDA CARNEIRO | R$ 378.678,72 | R$ 278.622,32 | R$ 100.056,40 |
| 2021000014 | ILHA SERVICE TECNOLOGIA E SERVIÇOS LTDA | R$ 975.435,90 | R$ 877.810,74 | R$ 97.625,16 |
| 2018005770 | R MORAES AGÊNCIA DE TURISMO EIRELI | R$ 425.865,80 | R$ 329.233,28 | R$ 96.632,52 |

## 11. Unidades incluídas neste dossiê
- FAF - Fundo Especial de Adm Fazendária
- LOTERJ - LOTERIA DO ESTADO DO RIO DE JANEIRO
- SEFAZ - SECRETARIA DE ESTADO DE FAZENDA

## 12. Conjuntos de dados abertos da secretaria
- Regras de Substituição Tributária (ST) para garantia da segurança jurídica aos pequenos negócios indice remissivo (atualizado 2026-11-04): 
- Regras de Substituição Tributária (ST) para garantia da segurança jurídica aos pequenos negócios SIMEI (atualizado 2026-11-04): 
- Regras de Substituição Tributária (ST) para garantia da segurança jurídica aos pequenos negócios DeSTDA (atualizado 2026-11-04): 
- Regras de Substituição Tributária (ST) para garantia da segurança jurídica aos pequenos negócios. (atualizado 2026-11-04): 
- Regras de Substituição Tributária (ST) para garantia da segurança jurídica aos pequenos negócios combustivel (atualizado 2026-11-04): [Regras de Substituição Tributária (ST) … ](https://legislacao.fazenda.rj.gov.br/80967/#TITULO_I)
- Regras de Substituição Tributária (ST) para garantia da segurança jurídica aos pequenos negócios RICMS (atualizado 2026-11-04): 
- Regras de Substituição Tributária (ST) para garantia da segurança jurídica aos pequenos negócios. (atualizado 2026-11-04): [Regras de Substituição Tributária (ST) … ](https://legislacao.fazenda.rj.gov.br/98875/)
- Investimentos (atualizado 2026-08-05): [Investimento ](https://tfe.fazenda.rj.gov.br/tfe/web/despesalivre)
- Gastos Públicos (atualizado 2026-08-05): [Gastos Públicos ](https://tfe.fazenda.rj.gov.br/tfe/web/despesagenerica)
- Acordos não Financeiros SEFAZ (atualizado 2026-04-28): [Acordos não Financeiros 1.1 SEFAZ XLSX](https://dadosabertos.rj.gov.br/dataset/ded7ac27-12b7-4d7e-9ee4-29c62a13d483/resource/4e6ed2dd-6362-48e3-aa4a-0089cb439e01/download/cge.-planilha.-acordos-nao-financeiros.-22-4-2026-1-1.xlsx), [Acordos não Financeiros SEFAZ XLSX](https://dadosabertos.rj.gov.br/dataset/ded7ac27-12b7-4d7e-9ee4-29c62a13d483/resource/aa3710cc-3d7c-4b09-9631-8349c50ad1b8/download/cge.-planilha.-acordos-nao-financeiros.-22-4-2026-1.xlsx)
- Terceirizados SEFAZ (atualizado 2026-04-28): [Planilha_Portal_de_Dados_Abertos_Sefaz_… XLSX](https://dadosabertos.rj.gov.br/dataset/7001fe51-3f2d-4d17-9f83-f9a5b3210afb/resource/24203974-14d2-42a7-aab9-b9f6dffb07bc/download/planilha_portal_de_dados_abertos_sefaz_terceirizados.xlsx)
- Estagiários SEFAZ (atualizado 2026-04-28): [Estagiários SEFAZ-RJ XLSX](https://dadosabertos.rj.gov.br/dataset/398b78e5-6779-4ef0-bf2b-47363774d908/resource/36baa920-3560-4b8e-a0b8-f450b87e5bee/download/levantamento_estagiarios_atualizado-copia.xlsx)
- Distribuições Constitucionais aos Municípios (Transferências Obrigatórias) (atualizado 2025-10-14): [FUNDEB-ICMS 2013 CSV](https://portal.fazenda.rj.gov.br/transparencia-fiscal/wp-content/uploads/sites/15/2023/12/Participacao-dos-Municipios-no-FUNDEB-ICMS-2013.csv), [FUNDEB-ICMS 2014 XLS](https://portal.fazenda.rj.gov.br/transparencia-fiscal/wp-content/uploads/sites/15/2023/12/Participacao-dos-Municipios-no-FUNDEB-ICMS.xls), [FUNDEB-ICMS 2014 CSV](https://portal.fazenda.rj.gov.br/transparencia-fiscal/wp-content/uploads/sites/15/2023/12/Participacao-dos-Municipios-no-FUNDEB-ICMS-2014.csv), [FUNDEB-IPVA 2013 XLS](https://portal.fazenda.rj.gov.br/transparencia-fiscal/wp-content/uploads/sites/15/2023/12/Participacao-dos-Municipios-no-FUNDEB-IPVA-1.xls)
- Dados de Arrecadação/FECP/Arrecadação mensal (atualizado 2025-07-28): [02_01_FECP_Mensal-2017.csv CSV](https://dadosabertos.rj.gov.br/dataset/5326f477-1540-4d6e-b642-b52c30bb0684/resource/050870bd-09e2-47f3-bc8d-2c12d496421a/download/02_01_fecp_mensal-2017.csv), [02_01_FECP_Mensal-2018.csv CSV](https://dadosabertos.rj.gov.br/dataset/5326f477-1540-4d6e-b642-b52c30bb0684/resource/fd8751b9-eac1-4458-9b08-547860837a0f/download/02_01_fecp_mensal-2018.csv), [02_01_FECP_Mensal-2019.csv CSV](https://dadosabertos.rj.gov.br/dataset/5326f477-1540-4d6e-b642-b52c30bb0684/resource/4de6b857-066f-4a59-9dab-35e990572317/download/02_01_fecp_mensal-2019.csv), [02_01_FECP_Mensal-2020.csv CSV](https://dadosabertos.rj.gov.br/dataset/5326f477-1540-4d6e-b642-b52c30bb0684/resource/17188944-9bbb-4e77-b23c-b12f5e8d58ab/download/02_01_fecp_mensal-2020.csv)
- Dados de Arrecadação/ICMS/Por atividade econômica – Mensal (atualizado 2025-07-28): [01_05_ICMS_Por_atividade_economica-2017… CSV](https://dadosabertos.rj.gov.br/dataset/11c39155-f030-4d0d-876f-40e2db2ed70c/resource/abf39967-576c-49c3-91e6-b3d0552af71e/download/01_05_icms_por_atividade_economica-2017.csv), [01_05_ICMS_Por_atividade_economica-2018… CSV](https://dadosabertos.rj.gov.br/dataset/11c39155-f030-4d0d-876f-40e2db2ed70c/resource/3836a717-e267-449e-b2c3-83383eefe919/download/01_05_icms_por_atividade_economica-2018.csv), [01_05_ICMS_Por_atividade_economica-2019… CSV](https://dadosabertos.rj.gov.br/dataset/11c39155-f030-4d0d-876f-40e2db2ed70c/resource/bb8be3a1-bb6e-463d-b928-dba8cf2eed31/download/01_05_icms_por_atividade_economica-2019.csv), [01_05_ICMS_Por_atividade_economica-2019… CSV](https://dadosabertos.rj.gov.br/dataset/11c39155-f030-4d0d-876f-40e2db2ed70c/resource/b16a7dfb-39a5-4bc2-b84d-559a4e1afbc3/download/01_05_icms_por_atividade_economica-2019.csv)
- Dados de Arrecadação/ICMS/Por setor econômico – Acumulada (atualizado 2025-07-28): [01_02_ICMS_Comparativo_anual-2017.csv CSV](https://dadosabertos.rj.gov.br/dataset/992f999b-8cc6-4665-a944-a71900a73fd2/resource/08b09b3d-28c9-4fec-8f9d-749637efc762/download/01_02_icms_comparativo_anual-2017.csv), [01_02_ICMS_Comparativo_anual-2018.csv CSV](https://dadosabertos.rj.gov.br/dataset/992f999b-8cc6-4665-a944-a71900a73fd2/resource/9bac5d47-94f3-4e60-90f4-52025779479a/download/01_02_icms_comparativo_anual-2018.csv), [01_02_ICMS_Comparativo_anual-2019.csv CSV](https://dadosabertos.rj.gov.br/dataset/992f999b-8cc6-4665-a944-a71900a73fd2/resource/6aef1b8d-75a7-4bb2-b06c-641bf48df8bd/download/01_02_icms_comparativo_anual-2019.csv), [01_02_ICMS_Comparativo_anual-2019.csv CSV](https://dadosabertos.rj.gov.br/dataset/992f999b-8cc6-4665-a944-a71900a73fd2/resource/2ebd9a50-14aa-47b5-a488-053d204d2ee7/download/01_02_icms_comparativo_anual-2019.csv)
- Arrecadação Por Município (atualizado 2025-07-28): [Arrecadação/Receitas CSV](https://dadosabertos.rj.gov.br/dataset/df57fd47-8b7a-4955-b009-cdbc5ff5acf5/resource/c022badf-99b0-4c0f-9774-c58902d8c9c4/download/00_03_arrecadacao_por_municipio_e_regiao_ipva-2017.csv), [Arrecadação/Receitas CSV](https://dadosabertos.rj.gov.br/dataset/df57fd47-8b7a-4955-b009-cdbc5ff5acf5/resource/d387ffa6-9709-46de-bef9-d68cd06f341b/download/00_03_arrecadacao_por_municipio_e_regiao_ipva-2018.csv), [Arrecadação/Receitas CSV](https://dadosabertos.rj.gov.br/dataset/df57fd47-8b7a-4955-b009-cdbc5ff5acf5/resource/77e8411f-4c2b-4ce9-a9c0-502305a41d8c/download/00_03_arrecadacao_por_municipio_e_regiao_ipva-2018.csv), [00_03_Arrecadacao_por_municipio_e_regia… CSV](https://dadosabertos.rj.gov.br/dataset/df57fd47-8b7a-4955-b009-cdbc5ff5acf5/resource/40ac9f2f-c44c-419f-b108-d273da680e42/download/00_03_arrecadacao_por_municipio_e_regiao_ipva-2019.csv)
- Dados de Arrecadação/ICMS/Comparativo Anual (atualizado 2025-07-28): [01_02_ICMS_Comparativo_anual-2017.csv CSV](https://dadosabertos.rj.gov.br/dataset/429aae9a-029e-49fc-a04b-37e4ec12b7db/resource/e4d6f68d-a30f-40d4-b53d-f8630c29b818/download/01_02_icms_comparativo_anual-2017.csv), [01_02_ICMS_Comparativo_anual-2018.csv CSV](https://dadosabertos.rj.gov.br/dataset/429aae9a-029e-49fc-a04b-37e4ec12b7db/resource/cb061738-7911-462a-b09f-023373ce3507/download/01_02_icms_comparativo_anual-2018.csv), [01_02_ICMS_Comparativo_anual-2019.csv CSV](https://dadosabertos.rj.gov.br/dataset/429aae9a-029e-49fc-a04b-37e4ec12b7db/resource/3404f99b-e211-4129-8c56-bf79db2d6ebb/download/01_02_icms_comparativo_anual-2019.csv), [01_02_ICMS_Comparativo_anual-2019.csv CSV](https://dadosabertos.rj.gov.br/dataset/429aae9a-029e-49fc-a04b-37e4ec12b7db/resource/d58a243f-b1ba-4e0c-bcf3-4f16c2ba551c/download/01_02_icms_comparativo_anual-2019.csv)
- Arrecadação Geral (atualizado 2025-07-16): [01_03_ICMS_Por_setor_economico_mensal-2… CSV](https://dadosabertos.rj.gov.br/dataset/77b63c34-2281-4c84-87a7-ac6388d974de/resource/c0167445-9a90-4653-b5f1-7b0c6b468a53/download/01_03_icms_por_setor_economico_mensal-2017.csv), [01_03_ICMS_Por_setor_economico_mensal-2… CSV](https://dadosabertos.rj.gov.br/dataset/77b63c34-2281-4c84-87a7-ac6388d974de/resource/f2f423d5-b4bd-4767-9107-925dd829dcd3/download/01_03_icms_por_setor_economico_mensal-2018.csv), [01_03_ICMS_Por_setor_economico_mensal-2… CSV](https://dadosabertos.rj.gov.br/dataset/77b63c34-2281-4c84-87a7-ac6388d974de/resource/df7ababb-0929-4e91-be43-14e17fc67e96/download/01_03_icms_por_setor_economico_mensal-2019.csv), [01_03_ICMS_Por_setor_economico_mensal-2… CSV](https://dadosabertos.rj.gov.br/dataset/77b63c34-2281-4c84-87a7-ac6388d974de/resource/debb6ac2-4aa0-45d6-9c4a-c3d15f53f013/download/01_03_icms_por_setor_economico_mensal-2019.csv)
- Boletim (atualizado 2025-07-16): [RELATÓRIO DE PRECATÓRIOS PENDENTES DO E… PDF](https://dadosabertos.rj.gov.br/dataset/5c3848f0-e663-4d9c-84b5-bc1922048bf5/resource/d4732e6e-ca75-4fed-a6f4-b32c0412572a/download/06-2025.pdf), [PRECATORIOS-PAGOS-06-2025.pdf PDF](https://dadosabertos.rj.gov.br/dataset/5c3848f0-e663-4d9c-84b5-bc1922048bf5/resource/2299ef90-452a-47d8-abf4-7a33b7a8752b/download/precatorios-pagos-06-2025.pdf)
- Dívida Pública (atualizado 2025-07-16): [Dívida Pública .pibx](https://portal.fazenda.rj.gov.br/tesouro/relatorios/divida-publica/), [Previsao_servico_da_divida_2024.csv CSV](https://dadosabertos.rj.gov.br/dataset/099b2e05-0fe4-4be0-b37d-0d6b5568edbb/resource/4305a9a1-2573-4dee-baa4-1b26862685df/download/previsao_servico_da_divida_2024.csv), [Servico_da_divida.csv CSV](https://dadosabertos.rj.gov.br/dataset/099b2e05-0fe4-4be0-b37d-0d6b5568edbb/resource/5290a6fa-5a33-4a3f-bd71-e648df0e8111/download/servico_da_divida.csv), [Estoque_da_divida.csv CSV](https://dadosabertos.rj.gov.br/dataset/099b2e05-0fe4-4be0-b37d-0d6b5568edbb/resource/1b335034-42ea-4f68-a010-649493d323f5/download/estoque_da_divida.csv)
- TFE Receita (atualizado 2025-07-14): [receita.csv CSV](https://dadosabertos.rj.gov.br/dataset/2743c1ae-0aac-4357-8c35-f9107dd79cb9/resource/2b9d078a-3492-46a1-b5b6-922c9169fd74/download/receita.csv)
- TFE Despesa (atualizado 2025-07-14): [despesa_generica2016.csv CSV](https://dadosabertos.rj.gov.br/dataset/e6315597-0c4e-4d1f-afcf-62312427ba92/resource/09fc0f46-3cb0-40be-bcda-5431ea5d7923/download/despesa_generica2016.csv), [despesa_generica2017.csv CSV](https://dadosabertos.rj.gov.br/dataset/e6315597-0c4e-4d1f-afcf-62312427ba92/resource/1fb526b8-5393-4a7a-b306-c0d8ac705943/download/despesa_generica2017.csv), [despesa_generica2018.csv CSV](https://dadosabertos.rj.gov.br/dataset/e6315597-0c4e-4d1f-afcf-62312427ba92/resource/e4b43bd9-ce9d-41d3-9996-face8b572086/download/despesa_generica2018.csv), [despesa_generica2019.csv CSV](https://dadosabertos.rj.gov.br/dataset/e6315597-0c4e-4d1f-afcf-62312427ba92/resource/723595b6-c6c3-446a-907d-a1aefae591ee/download/despesa_generica2019.csv)
- Relatório Resumido de Execução Orçamentária - RREO e Relatório de Gestão Fiscal -RGF (atualizado 2025-06-30): [contabilidade/relatorios-fiscais CSV](https://portal.fazenda.rj.gov.br/contabilidade/relatorios-fiscais/)
- Dados de Arrecadação ITD (atualizado 2025-05-21): [04_ITD-2024_01_jan.csv CSV](https://dadosabertos.rj.gov.br/dataset/c57efb53-62e7-483b-a2d9-d985cfb6666e/resource/c551be0a-4735-4bb9-bb26-a4ae2edb96fc/download/04_itd-2024_01_jan.csv), [04_ITD-2023.csv CSV](https://dadosabertos.rj.gov.br/dataset/c57efb53-62e7-483b-a2d9-d985cfb6666e/resource/8095ec28-a108-4110-bb9b-2546b060ec90/download/04_itd-2023.csv), [04_ITD-2022.csv CSV](https://dadosabertos.rj.gov.br/dataset/c57efb53-62e7-483b-a2d9-d985cfb6666e/resource/62ec1661-4ab6-4b8d-bc93-2343d838457c/download/04_itd-2022.csv), [04_ITD-2021.csv CSV](https://dadosabertos.rj.gov.br/dataset/c57efb53-62e7-483b-a2d9-d985cfb6666e/resource/b2489cba-1984-4885-8c62-0fdd630b58b5/download/04_itd-2021.csv)
- Dados de Arrecadação/FECP/Por atividade econômica – Mensal (atualizado 2025-05-21): [02_05_FECP_Por_atividade_economica-2024… CSV](https://dadosabertos.rj.gov.br/dataset/f74bcb0c-0d5b-45f4-9784-9feff9f91871/resource/b4b7ff99-edab-4d97-b99f-ae0d8143f5a6/download/02_05_fecp_por_atividade_economica-2024_01_jan.csv), [02_05_FECP_Por_atividade_economica-2023… CSV](https://dadosabertos.rj.gov.br/dataset/f74bcb0c-0d5b-45f4-9784-9feff9f91871/resource/c0d8913a-3a10-480e-8d71-413c8dc75437/download/02_05_fecp_por_atividade_economica-2023.csv), [02_05_FECP_Por_atividade_economica-2022… CSV](https://dadosabertos.rj.gov.br/dataset/f74bcb0c-0d5b-45f4-9784-9feff9f91871/resource/a925043c-d745-4efc-b1fd-12bd647c4f99/download/02_05_fecp_por_atividade_economica-2022.csv), [02_05_FECP_Por_atividade_economica-2021… CSV](https://dadosabertos.rj.gov.br/dataset/f74bcb0c-0d5b-45f4-9784-9feff9f91871/resource/0dd6b7d4-5f42-45ac-bf7a-358bcd78d3df/download/02_05_fecp_por_atividade_economica-2021.csv)
- Dados de Arrecadação/FECP/Comparativo Anual (atualizado 2025-05-21): [04_itd-2024_01_jan.csv CSV](https://dadosabertos.rj.gov.br/dataset/6b040da2-ef5c-4696-a434-87524ab51424/resource/8d0145ec-8830-4651-8dc4-6f259a00579c/download/04_itd-2024_01_jan.csv), [04_itd-2023.csv CSV](https://dadosabertos.rj.gov.br/dataset/6b040da2-ef5c-4696-a434-87524ab51424/resource/dd0a1066-6e42-4553-bdb8-90fabb9c174b/download/04_itd-2023.csv), [04_itd-2022.csv CSV](https://dadosabertos.rj.gov.br/dataset/6b040da2-ef5c-4696-a434-87524ab51424/resource/b70154dd-fd22-4957-8efe-8887a1a1891a/download/04_itd-2022.csv), [04_ITD-2021.csv CSV](https://dadosabertos.rj.gov.br/dataset/6b040da2-ef5c-4696-a434-87524ab51424/resource/5c179abe-6a5f-4172-8255-184c2f618b23/download/04_itd-2021.csv)
- Dados de Arrecadação/FECP/Por setor econômico - Mensal (atualizado 2025-05-21): [02_01_FECP_Mensal-2024_01_jan.xlsx XLS](https://dadosabertos.rj.gov.br/dataset/971eed01-79b0-4142-a900-c966ca9b12dc/resource/2f8a6637-defb-4683-946a-4b4e9ded10db/download/02_01_fecp_mensal-2024_01_jan.xlsx), [02_01_FECP_Mensal-2023.csv CSV](https://dadosabertos.rj.gov.br/dataset/971eed01-79b0-4142-a900-c966ca9b12dc/resource/0863a15d-4a79-4ee7-94a8-848bb6b2fd84/download/02_01_fecp_mensal-2023.csv), [02_01_FECP_Mensal-2022.csv CSV](https://dadosabertos.rj.gov.br/dataset/971eed01-79b0-4142-a900-c966ca9b12dc/resource/0b36607a-9af2-4bb9-b171-8df0784f3cba/download/02_01_fecp_mensal-2022.csv), [02_01_FECP_Mensal-2021.csv CSV](https://dadosabertos.rj.gov.br/dataset/971eed01-79b0-4142-a900-c966ca9b12dc/resource/fdc407db-e3e6-4384-8b3d-62c6c08ec4b5/download/02_01_fecp_mensal-2021.csv)
- Recursos do Petróleo Destinação de Recursos (atualizado 2025-05-21): [despesa-serie-historica-mensal-anualiza… CSV](https://dadosabertos.rj.gov.br/dataset/f3e8cae6-e80e-40b7-9666-9735559c6fec/resource/7eeba26e-fe88-4d88-815d-d502a0f2f704/download/despesa-serie-historica-mensal-anualizada-2013.csv), [despesa-serie-historica-mensal-anualiza… CSV](https://dadosabertos.rj.gov.br/dataset/f3e8cae6-e80e-40b7-9666-9735559c6fec/resource/4414de07-9e21-47e8-a89b-526973c6dc1b/download/despesa-serie-historica-mensal-anualizada-2014.csv), [despesa-serie-historica-mensal-anualiza… CSV](https://dadosabertos.rj.gov.br/dataset/f3e8cae6-e80e-40b7-9666-9735559c6fec/resource/8c245f88-a80a-4ead-86af-3262cbbc44d1/download/despesa-serie-historica-mensal-anualizada-2015.csv), [despesa-serie-historica-mensal-anualiza… CSV](https://dadosabertos.rj.gov.br/dataset/f3e8cae6-e80e-40b7-9666-9735559c6fec/resource/3604a421-2d99-42df-995d-5e48fe4d3984/download/despesa-serie-historica-mensal-anualizada-2016.csv)
- Recursos do Petróleo Receitas (atualizado 2025-05-21): [receita-serie-historica-mensal-anualiza… CSV](https://dadosabertos.rj.gov.br/dataset/263d9bc3-eda0-42ed-bef0-830895852945/resource/21dd4476-5297-46f8-a846-dac344e600b7/download/receita-serie-historica-mensal-anualizada-2013.csv), [receita-serie-historica-mensal-anualiza… CSV](https://dadosabertos.rj.gov.br/dataset/263d9bc3-eda0-42ed-bef0-830895852945/resource/ab2e2a3d-19dc-4363-b084-35c1bdfdf3a4/download/receita-serie-historica-mensal-anualizada-2014.csv), [receita-serie-historica-mensal-anualiza… CSV](https://dadosabertos.rj.gov.br/dataset/263d9bc3-eda0-42ed-bef0-830895852945/resource/26899d45-f038-4279-bbe8-1d214fbc5d9f/download/receita-serie-historica-mensal-anualizada-2015.csv), [receita-serie-historica-mensal-anualiza… CSV](https://dadosabertos.rj.gov.br/dataset/263d9bc3-eda0-42ed-bef0-830895852945/resource/9bb88c5c-8ad8-468a-aa8f-8a14128ff09a/download/receita-serie-historica-mensal-anualizada-2016.csv)
- Recursos do Petróleo Prestação de Contas (atualizado 2025-05-21): [Prestacao_de_Contas_Dez_2024 CSV](https://dadosabertos.rj.gov.br/dataset/fe6adc6b-07be-4c5b-81b0-d94c6fb5aafb/resource/3e775405-1753-4695-80da-0de12dec39b1/download/prestacao_de_contas_dez_2024.csv), [Prestacao_de_Contas_Dez_2024.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/fe6adc6b-07be-4c5b-81b0-d94c6fb5aafb/resource/77ce4b6b-3caf-425a-9a3f-2e70bf5843bf/download/prestacao_de_contas_dez_2024.xlsx)
- Dados de Arrecadação IPVA (atualizado 2025-05-20): [03_IPVA-2024_01_jan.csv CSV](https://dadosabertos.rj.gov.br/dataset/dcfa7aff-c82e-4aa6-bb8d-69f235136302/resource/a4a3d0ac-cefb-4b7d-ab8b-bb1f3cbc592c/download/03_ipva-2024_01_jan.csv), [03_IPVA-2023.csv CSV](https://dadosabertos.rj.gov.br/dataset/dcfa7aff-c82e-4aa6-bb8d-69f235136302/resource/0b893095-9737-45cd-b25e-51f521706eb6/download/03_ipva-2023-2.csv), [03_IPVA-2022.csv CSV](https://dadosabertos.rj.gov.br/dataset/dcfa7aff-c82e-4aa6-bb8d-69f235136302/resource/3a176b4f-16f5-427e-b014-a8bfefb122d1/download/03_ipva-2022.csv), [03_IPVA-2021.csv CSV](https://dadosabertos.rj.gov.br/dataset/dcfa7aff-c82e-4aa6-bb8d-69f235136302/resource/64037858-1009-4e75-b1d5-de9bc00a47bd/download/03_ipva-2021-1.csv)
- Transferências Voluntárias aos Municípios (pela Lei Complementar n.º 101/2000 - Lei de Responsabilidade Fiscal ) (atualizado 2024-12-19): [Transferencias-Voluntarias-aos-Municipi… CSV](https://dadosabertos.rj.gov.br/dataset/6da5bc7e-90e6-4685-9f37-f1d09787083c/resource/a900b440-c87d-42f2-b485-2424ecc65d5c/download/transferencias-voluntarias-aos-municipios-2024.csv), [Transferencias-Voluntarias-aos-Municipi… CSV](https://dadosabertos.rj.gov.br/dataset/6da5bc7e-90e6-4685-9f37-f1d09787083c/resource/bcb79e24-142b-4bc1-bc66-7479b07c9172/download/transferencias-voluntarias-aos-municipios-2015-a-2023.csv)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 6 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo
- A situação fiscal exige acompanhamento prioritário: a Secretaria informou dívida estadual de R$ 242,1 bilhões em julho de 2026, enquanto a LOA de 2026 projetou déficit de quase R$ 19 bilhões; o governo interino esperava reverter o resultado, mas não informou o valor de eventual superávit. [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- Há apurações disciplinares e de controle relevantes na SEFAZ, mas as fontes não permitem concluir que os processos recentes sobre servidores da área de petróleo estejam relacionados às apurações anteriores ou identificar os investigados e as infrações. [PADs na área de petróleo](https://www.ururau.com.br/noticias/estado-rj/corregedoria-da-fazenda-do-rj-abre-processos-contra-seis-servidores-da-area-de-petroleo/82795/) [Apuração sobre ordem judicial](https://veja.abril.com.br/brasil/fazenda-do-rio-investiga-servidores-que-teriam-omitido-ordem-judicial-sobre-auditor-alvo-da-pf/)
- O MPRJ recomendou medidas para identificar e acompanhar devedores contumazes, incluindo banco de dados compartilhado com o órgão, mas as fontes não informam se a SEFAZ iniciou ou concluiu essas providências. [Recomendação do MPRJ](https://valor.globo.com/brasil/noticia/2026/03/11/mp-rj-pede-que-estado-crie-banco-de-dados-para-identificar-devedores-contumazes.ghtml)
- As fontes não trazem inventário de contratos críticos nem indicam risco concreto de interrupção de serviços; essa ausência deve ser tratada como lacuna de informação para a transição. [Entrevista do secretário](https://cbn.globo.com/programas/cbn-rio/entrevista/2026/10/14/a-gente-vai-entregar-um-estado-saneado-mas-sem-duvida-nenhuma-os-desafios-ainda-sao-muito-grandes-diz-secretario-de-fazenda-do-rj.ghtml) [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)

##### Alertas vermelhos
- **Pressão fiscal e dívida:** a Secretaria informou dívida total de R$ 242,1 bilhões em julho de 2026, incluindo R$ 213 bilhões relativos à União e R$ 25,6 bilhões a bancos; a LOA de 2026 projetou déficit de quase R$ 19 bilhões. [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- **Dependência de receitas extraordinárias e espaço fiscal:** segundo dados apresentados pela Secretaria, as despesas de pessoal ficaram abaixo do limite de 60% da RCL previsto na LRF federal, mas, excluídas receitas não recorrentes, a proporção ficaria acima de 60% desde 2021; a disponibilidade líquida de caixa caiu de R$ 22,3 bilhões em 2022 para R$ 14,2 bilhões em 2025. [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- **Apurações disciplinares:** em 22/10/2026, a CTCE decidiu por unanimidade abrir dois PADs contra seis servidores da Auditoria-Fiscal Especializada de Petróleo e Combustível, com base em indícios de autoria e materialidade de infração funcional; a fonte não identifica os servidores nem especifica as infrações, e os processos devem assegurar o direito de defesa. [PADs na área de petróleo](https://www.ururau.com.br/noticias/estado-rj/corregedoria-da-fazenda-do-rj-abre-processos-contra-seis-servidores-da-area-de-petroleo/82795/)
- **Apuração sobre comunicação de ordem judicial:** a Sefaz-RJ abriu PADs para apurar por que uma comunicação judicial sobre o afastamento de um auditor não chegou à Corregedoria; segundo a reportagem, servidores teriam deixado de encaminhá-la e a Secretaria apontou indícios de prevaricação, alegações ainda sob apuração. [Apuração sobre ordem judicial](https://veja.abril.com.br/brasil/fazenda-do-rio-investiga-servidores-que-teriam-omitido-ordem-judicial-sobre-auditor-alvo-da-pf/)
- **Incentivos fiscais à Refit:** em maio de 2026, a Secretaria informou ter aberto auditoria específica para apurar irregularidades na concessão de incentivos fiscais à Refit; a fonte não apresenta conclusão da auditoria. [Apuração sobre a Refit](https://www.brasildefato.com.br/2026/05/19/secretaria-de-fazenda-do-rj-apura-envolvimento-de-servidores-em-favorecimento-do-grupo-fit)
- **Providências recomendadas pelo MPRJ:** o órgão recomendou prazo de até 30 dias para criação de banco de dados sobre fiscalizações e processos envolvendo devedores contumazes e prazo de dez dias para comunicação do início das providências; as fontes não confirmam o cumprimento. [Recomendação do MPRJ](https://valor.globo.com/brasil/noticia/2026/03/11/mp-rj-pede-que-estado-crie-banco-de-dados-para-identificar-devedores-contumazes.ghtml)

##### Contratos e serviços críticos
- Nada encontrado nas fontes consultadas sobre contratos da SEFAZ, empresas contratadas, valores, vigências, vencimentos, renovações ou dependência de fornecedores críticos. [Entrevista do secretário](https://cbn.globo.com/programas/cbn-rio/entrevista/2026/10/14/a-gente-vai-entregar-um-estado-saneado-mas-sem-duvida-nenhuma-os-desafios-ainda-sao-muito-grandes-diz-secretario-de-fazenda-do-rj.ghtml) [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- Nada encontrado nas fontes consultadas sobre risco de interrupção de serviços prestados pela Secretaria. [Entrevista do secretário](https://cbn.globo.com/programas/cbn-rio/entrevista/2026/10/14/a-gente-vai-entregar-um-estado-saneado-mas-sem-duvida-nenhuma-os-desafios-ainda-sao-muito-grandes-diz-secretario-de-fazenda-do-rj.ghtml) [Apuração sobre a Refit](https://www.brasildefato.com.br/2026/05/19/secretaria-de-fazenda-do-rj-apura-envolvimento-de-servidores-em-favorecimento-do-grupo-fit)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)
- **TCE-RJ:** nada encontrado nas fontes consultadas sobre decisões, determinações ou processos do Tribunal relacionados à SEFAZ. [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- **MPRJ:** o Gaesf recomendou à Sefaz-RJ criar, em até 30 dias, banco de dados sobre fiscalizações e processos relativos a devedores contumazes, compartilhá-lo com o grupo e adotar medidas de identificação, monitoramento e comunicação de condutas indicativas de fraude fiscal estruturada e contumácia delitiva; os órgãos mencionados deveriam comunicar o início das providências em dez dias. A fonte registra uma recomendação, não a confirmação de que a SEFAZ tenha praticado as condutas que se pretende identificar. [Recomendação do MPRJ](https://valor.globo.com/brasil/noticia/2026/03/11/mp-rj-pede-que-estado-crie-banco-de-dados-para-identificar-devedores-contumazes.ghtml)
- **Judiciário e PADs:** segundo reportagem de 18/08/2026, a Corregedoria acionou o MPF para investigar se servidores tentaram blindar o auditor fiscal Carlos Eduardo França de Araújo, alvo da Polícia Federal por suspeita de corrupção; a apuração da omissão de uma comunicação da 10.ª Vara Federal Criminal e os PADs são investigações, não conclusões de responsabilidade. [Apuração sobre ordem judicial](https://veja.abril.com.br/brasil/fazenda-do-rio-investiga-servidores-que-teriam-omitido-ordem-judicial-sobre-auditor-alvo-da-pf/)
- **Operação Zaqueu:** a reportagem informa que Carlos Araújo teve as atividades suspensas por determinação judicial no âmbito da operação, que investigava seu suposto envolvimento em esquema de propinas de empresas do setor de combustíveis; a fonte não esclarece quando o auditor foi afastado nem por quanto tempo a comunicação sobre a determinação judicial foi omitida. [Apuração sobre ordem judicial](https://veja.abril.com.br/brasil/fazenda-do-rio-investiga-servidores-que-teriam-omitido-ordem-judicial-sobre-auditor-alvo-da-pf/)
- **Corregedoria:** os dois PADs abertos em outubro decorrem da Correição Extraordinária SEI-040084/000080/2026; a ata também registra o encaminhamento de sugestões de melhoria ao gabinete da Secretaria, sem detalhar seu conteúdo. [PADs na área de petróleo](https://www.ururau.com.br/noticias/estado-rj/corregedoria-da-fazenda-do-rj-abre-processos-contra-seis-servidores-da-area-de-petroleo/82795/)

##### Riscos de apagão administrativo
- Nada encontrado nas fontes consultadas que confirme apagão administrativo, paralisação ou risco de interrupção de serviços da SEFAZ. [Entrevista do secretário](https://cbn.globo.com/programas/cbn-rio/entrevista/2026/10/14/a-gente-vai-entregar-um-estado-saneado-mas-sem-duvida-nenhuma-os-desafios-ainda-sao-muito-grandes-diz-secretario-de-fazenda-do-rj.ghtml) [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- A gestão interina informou que, entre 24 de março e 21 de agosto de 2026, foram exonerados 6.145 servidores comissionados e nomeadas 2.496 pessoas, com economia projetada de R$ 221 milhões até dezembro; as fontes não detalham efeitos dessas mudanças sobre equipes, funções essenciais ou continuidade operacional da SEFAZ. [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- Em maio de 2026, a Secretaria informou a exoneração de cerca de 40 funcionários, o afastamento de servidores envolvidos, o bloqueio de seus acessos ao banco de dados e a abertura de processo administrativo e disciplinar; a fonte não informa impacto sobre a operação dos sistemas ou serviços. [Apuração sobre a Refit](https://www.brasildefato.com.br/2026/05/19/secretaria-de-fazenda-do-rj-apura-envolvimento-de-servidores-em-favorecimento-do-grupo-fit)
- O secretário Guilherme Mercês integrará a equipe de transição do governo Ricardo Couto para o governo Douglas Ruas; a entrevista não apresenta plano de continuidade, distribuição de responsabilidades ou cronograma de transferência da SEFAZ. [Entrevista do secretário](https://cbn.globo.com/programas/cbn-rio/entrevista/2026/10/14/a-gente-vai-entregar-um-estado-saneado-mas-sem-duvida-nenhuma-os-desafios-ainda-sao-muito-grandes-diz-secretario-de-fazenda-do-rj.ghtml)

##### Fatos recentes
- Em 14/10/2026, o secretário Guilherme Mercês afirmou que o estado seria entregue em cenário mais favorável, embora os desafios continuassem grandes, e disse que participaria da equipe de transição; a Certidão Conjunta de Regularidade Fiscal estava prevista para disponibilização a partir de 12 de novembro. [Entrevista do secretário](https://cbn.globo.com/programas/cbn-rio/entrevista/2026/10/14/a-gente-vai-entregar-um-estado-saneado-mas-sem-duvida-nenhuma-os-desafios-ainda-sao-muito-grandes-diz-secretario-de-fazenda-do-rj.ghtml)
- Em 22/10/2026, a CTCE decidiu abrir dois PADs contra seis servidores da área de petróleo e combustíveis; a decisão foi publicada no Diário Oficial em 23/10/2026. [PADs na área de petróleo](https://www.ururau.com.br/noticias/estado-rj/corregedoria-da-fazenda-do-rj-abre-processos-contra-seis-servidores-da-area-de-petroleo/82795/)
- Em agosto de 2026, o Estado transferiu a segunda parcela da dívida com a União sob as condições do Propag: R$ 119 milhões, ante R$ 436 milhões que seriam pagos sem o programa; a adesão ao Propag foi assinada em junho de 2026. [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- Em 24/08/2026, o governo interino anunciou que preparava proposta de Lei de Responsabilidade Fiscal estadual para envio à Alerj, com métrica de receita corrente líquida estrutural; a fonte descreve uma proposta em preparação, não uma lei aprovada. [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- Em 19/05/2026, foi noticiada a abertura de auditoria específica sobre incentivos fiscais à Refit e a adoção de medidas envolvendo afastamentos, bloqueio de acessos e processos administrativos e disciplinares. [Apuração sobre a Refit](https://www.brasildefato.com.br/2026/05/19/secretaria-de-fazenda-do-rj-apura-envolvimento-de-servidores-em-favorecimento-do-grupo-fit)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)
- Solicitar inventário atualizado dos contratos da SEFAZ, com objeto, fornecedor, valor, vigência, vencimentos, renovações, dependência operacional e plano de contingência, pois as fontes não apresentam esses dados. [Entrevista do secretário](https://cbn.globo.com/programas/cbn-rio/entrevista/2026/10/14/a-gente-vai-entregar-um-estado-saneado-mas-sem-duvida-nenhuma-os-desafios-ainda-sao-muito-grandes-diz-secretario-de-fazenda-do-rj.ghtml) [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- Solicitar avaliação de continuidade dos serviços, sistemas e equipes essenciais, incluindo riscos de interrupção e medidas de contingência, já que nada disso foi informado nas fontes consultadas. [Entrevista do secretário](https://cbn.globo.com/programas/cbn-rio/entrevista/2026/10/14/a-gente-vai-entregar-um-estado-saneado-mas-sem-duvida-nenhuma-os-desafios-ainda-sao-muito-grandes-diz-secretario-de-fazenda-do-rj.ghtml) [Apuração sobre a Refit](https://www.brasildefato.com.br/2026/05/19/secretaria-de-fazenda-do-rj-apura-envolvimento-de-servidores-em-favorecimento-do-grupo-fit)
- Solicitar o estágio e o cronograma de cumprimento da recomendação do MPRJ, inclusive a criação do banco de dados e a comunicação das providências, pois as fontes não confirmam atendimento. [Recomendação do MPRJ](https://valor.globo.com/brasil/noticia/2026/03/11/mp-rj-pede-que-estado-crie-banco-de-dados-para-identificar-devedores-contumazes.ghtml)
- Solicitar informações oficiais sobre o andamento e as medidas cautelares dos PADs da área de petróleo, preservados os direitos dos investigados, pois as fontes não identificam os servidores nem detalham as infrações. [PADs na área de petróleo](https://www.ururau.com.br/noticias/estado-rj/corregedoria-da-fazenda-do-rj-abre-processos-contra-seis-servidores-da-area-de-petroleo/82795/)
- Solicitar atualização sobre os PADs relativos à comunicação judicial, a interlocução com o MPF e a situação da auditoria sobre incentivos fiscais à Refit, pois as fontes não informam conclusões ou desfechos. [Apuração sobre ordem judicial](https://veja.abril.com.br/brasil/fazenda-do-rio-investiga-servidores-que-teriam-omitido-ordem-judicial-sobre-auditor-alvo-da-pf/) [Apuração sobre a Refit](https://www.brasildefato.com.br/2026/05/19/secretaria-de-fazenda-do-rj-apura-envolvimento-de-servidores-em-favorecimento-do-grupo-fit)
- Solicitar posição fiscal atualizada, execução orçamentária e estimativa de encerramento de 2026, além do andamento da proposta de LRF estadual, pois as fontes apresentam dados até datas específicas e não informam o resultado final do exercício nem a aprovação da proposta. [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- Solicitar relação de decisões e processos do TCE-RJ e providências adotadas pela SEFAZ, pois nada sobre esses itens foi encontrado nas fontes consultadas. [Contas do RJ](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml)
- Solicitar plano de transição da Secretaria, com responsáveis, entregáveis e pendências prioritárias, já que a fonte confirma a participação do secretário na equipe de transição, mas não descreve o plano operacional. [Entrevista do secretário](https://cbn.globo.com/programas/cbn-rio/entrevista/2026/10/14/a-gente-vai-entregar-um-estado-saneado-mas-sem-duvida-nenhuma-os-desafios-ainda-sao-muito-grandes-diz-secretario-de-fazenda-do-rj.ghtml)

##### Fontes consultadas
1. [Corregedoria da Fazenda do RJ abre processos contra seis servidores da área de petróleo   Ururau Notícias](https://www.ururau.com.br/noticias/estado-rj/corregedoria-da-fazenda-do-rj-abre-processos-contra-seis-servidores-da-area-de-petroleo/82795/) — 2026-10-23
2. [Fazenda do Rio investiga servidores que teriam omitido ordem judicial sobre auditor alvo da PF](https://veja.abril.com.br/brasil/fazenda-do-rio-investiga-servidores-que-teriam-omitido-ordem-judicial-sobre-auditor-alvo-da-pf/) — 2026-08-18
3. [MP-RJ pede que Estado crie banco de dados para identificar ...](https://valor.globo.com/brasil/noticia/2026/03/11/mp-rj-pede-que-estado-crie-banco-de-dados-para-identificar-devedores-contumazes.ghtml) — 2026-03-11
4. [Secretaria de Fazenda do RJ apura envolvimento de servidores em favorecimento do Grupo Fit](https://www.brasildefato.com.br/2026/05/19/secretaria-de-fazenda-do-rj-apura-envolvimento-de-servidores-em-favorecimento-do-grupo-fit) — 2026-05-19
5. [Contas do RJ perdem fôlego após impulso de receita extraordinária, e interino tenta reverter déficit](https://valor.globo.com/brasil/noticia/2026/09/06/contas-do-rj-perdem-flego-aps-impulso-de-receita-extraordinria-e-interino-tenta-reverter-dficit.ghtml) — 2026-09-06
6. ['A gente vai entregar um estado saneado, mas, sem dúvida nenhuma, os desafios ainda são muito grandes', diz se](https://cbn.globo.com/programas/cbn-rio/entrevista/2026/10/14/a-gente-vai-entregar-um-estado-saneado-mas-sem-duvida-nenhuma-os-desafios-ainda-sao-muito-grandes-diz-secretario-de-fazenda-do-rj.ghtml) — 2026-10-14


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2026008572 (CONFECCOES BACELAR LTDA - ME) vence em 13/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2026008598 (INSTITUTO NEGOCIOS PUBLICOS DO BRASIL -…) vence em 13/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2026008658 (INSTITUTO NEGOCIOS PUBLICOS DO BRASIL -…) vence em 14/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2026007929 (INSTITUTO DE DESENVOLVIMENTO TURISMO CU…) vence em 24/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025009746 (LECARD ADMNISTRADORA DE CARTÕES LTDA) vence em 26/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2022004816 (EXTREME DIGITAL CONSULTORIA E REPRESENT…, R$ 21,1 mi) consta 'Ativo' no SIGA com fim em 12/07/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2024008526 (EXTREME DIGITAL CONSULTORIA E REPRESENT…, R$ 15,7 mi) consta 'Ativo' no SIGA com fim em 30/10/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2025003017 (ONIX ORGANIZACAO E PRODUCAO DE EVENTOS …, R$ 14,0 mi) consta 'Ativo' no SIGA com fim em 07/10/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2022001959 (EXTREME DIGITAL CONSULTORIA E REPRESENT…, R$ 8,1 mi) consta 'Ativo' no SIGA com fim em 03/04/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2024007926 (FXX SEGURANCA E TRANSPORTE DE VALORES L…, R$ 6,4 mi) consta 'Ativo' no SIGA com fim em 24/04/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
