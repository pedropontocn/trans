# Dossiê de transição — Secretaria de Estado de Ciência, Tecnologia e Inovação (SECTI)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/secti)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 15937 | R$ 4.240.450.045,98 |
| Com vigência futura (válidos no SIGA) | 1745 | R$ 2.162.935.285,97 |
| até 30 dias | 140 | R$ 75.526.234,81 |
| até 60 dias | 164 | R$ 65.159.383,92 |
| até 90 dias | 45 | R$ 149.919.304,38 |
| até 180 dias | 397 | R$ 276.177.587,87 |
| vencido no SIGA | 14192 | R$ 2.077.514.760,01 |
| sem data | 44 | R$ 2.713.338,78 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 9 | R$ 8.595.742,74 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 911,5 mi / R$ 564,5 mi / R$ 531,3 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2025009139 (LIDER NOTEBOOKS COMERCIO E SERVIÇOS LTDA) vence em 10/11/2026 — 4 dias — R$ 5.094.000,00. Objeto: Aquisição de Computadores e Monitores.
- Contrato 2025003899 (ELEKTA SOLUTIONS AB) vence em 11/11/2026 — 5 dias — R$ 5.192.000,00. Objeto: AQUISIÇÃO DE Acelerador linear Elekta
- Contrato 2025008483 (MAX MOVE COMERCIO DE MOVEIS E TRANSPORTES LTDA) vence em 13/11/2026 — 7 dias — R$ 3.142.764,72. Objeto: Aquisição de mobiliário corporativo com entrega e montagem, visando atender às …
- Contrato 2025002628 (FENIX CONSTRUTORA LTDA) vence em 17/11/2026 — 11 dias — R$ 1.214.819,97. Objeto: REFORMA DOS SERVIÇOS DE MAMOGRAFIA, ULTRASSONOGRAFIA, DENSITOMETRIA, CIRCULAÇÃO…
- Contrato 2025005359 (LABOR-MED APARELHAGEM DE PRECISÃO LTDA) vence em 17/11/2026 — 11 dias — R$ 1.712.194,00. Objeto: A aquisição de equipamento para ecoendoscopia para o setor de Gastroenterologia…
- Contrato 2025008331 (SHELL LIFE MATERIAL HOSPITALAR LTDA) vence em 19/11/2026 — 13 dias — R$ 3.181.403,40. Objeto: A aquisição de equipamento Ventilador Pulmonar para atender a demanda das UTIs …
- Contrato 2025001516 (SGHN - HIGIENIZACAO TEXTIL E NUTRICAO HOSPITALAR …) vence em 27/11/2026 — 21 dias — R$ 36.140.990,84. Objeto: A contratação de empresa especializada na prestação de serviços contínuos de la…
- Contrato 2025009561 (DK8 TECNOLOGIA LTDA) vence em 27/11/2026 — 21 dias — R$ 1.707.999,30. Objeto: Aquisição de Material Permanente Tecnológico para equipar os Laboratórios dos c…
- Contrato 2026005002 (ROKA ASSISTANCE COMÉRCIO E SERVIÇOS LTDA) vence em 27/11/2026 — 21 dias — R$ 1.226.202,60. Objeto: Aquisição de ar-condicionados.
- Contrato 2021003553 (H. STRATTNER & CIA. LTDA.) vence em 30/11/2026 — 24 dias — R$ 1.136.740,68. Objeto: CONTRATAÇÃO DE EMPRESA PARA MANUTENÇÃO DE SISTEMA ROBOTICO DA VINCI E LAVADORA …
- Contrato 2025009911 (MVT EDUCACAO LTDA) vence em 09/12/2026 — 33 dias — R$ 25.283.699,00. Objeto: Aquisição de solução pedagógica de educação financeira, composta por materiais …
- Contrato 2026001775 (UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO) vence em 12/01/2027 — 67 dias — R$ 11.675.798,00. Objeto: Projeto Atenção a Saúde do Homem
- Contrato 2023000345 (SCALLE CONSTRUCOES, REFORMAS E INSTALACOES LTDA) vence em 25/01/2027 — 80 dias — R$ 28.061.749,20. Objeto: O presente Termo de Referência relativo ao Processo Administrativo n SEI2600040…
- Contrato 2024004219 (FOCO SERVICOS ESPECIALIZADOS LTDA) vence em 31/01/2027 — 86 dias — R$ 17.330.379,74. Objeto: O presente Termo de Referência tem por objeto a Contratação de Pessoa Jurídica,…
- Contrato 2026000349 (UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO) vence em 03/02/2027 — 89 dias — R$ 54.500.000,00. Objeto: Processamento de despesa - Prestadores de serviço e estagiários da UERJ para o …
- Contrato 2026000474 (UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO) vence em 03/02/2027 — 89 dias — R$ 10.000.000,00. Objeto: Resolução Conjunta SEDSODH/UERJ nº 201 de 16/01/2026 - Combate ao LGBTI+
- Mais 130 contratos menores (R$ 15,8 mi) vencem em até 30 dias — ver seção 3.
- 617 contratos (R$ 506,6 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 3061 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 857,9 mi); 11 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 11131 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 1.219,6 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- 2 contrato(s) seguem 'Ativo' no SIGA, mas têm Termo de Rescisão publicado no PNCP (R$ 1,1 mi): 2024008825 RENAL TEC INDUSTRIA COMERCIO E SER… (R$ 594.000,00, rescisão em 12/11/2025); 2024005811 LIFETEX INDUSTRIA E COMERCIO LTDA (R$ 521.478,00, rescisão em 02/08/2025). As datas coincidem com o fim previsto: encerramento sem baixa no SIGA. Dar baixa no SIGA.
- 2 contrato(s) 'Ativo' com data de fim inválida no SIGA (R$ 0,0 mi), ex.: 2018000163 (31/12/2201); 2020004629 (01/10/2121). Corrigir o cadastro e informar a vigência real.
- 5 contrato(s) com fim no PNCP anterior ao do SIGA, sem rescisão: 2024007915 (DIVERGÊNCIA: PNCP indica fim 06/10/2025, SIGA indica 21/07/2026; TERMO CLASSIFICADO COMO …); 2024009640 (DIVERGÊNCIA: PNCP indica fim 01/12/2025, SIGA indica 04/08/2026; TERMO CLASSIFICADO COMO …); 2024009704 (DIVERGÊNCIA: PNCP indica fim 05/12/2025, SIGA indica 07/08/2026; TERMO CLASSIFICADO COMO …). Confirmar no processo SEI.
- 9 contratações emergenciais vigentes (R$ 8,6 mi). Verificar prazo máximo legal (1 ano, Lei 14.133 art. 75 VIII) e licitação substitutiva.

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025009153 | UERJ | TOTAL PRODUTOS E SERVICOS HOSPITALARES LTDA | Aquisição de Fraldas Geriátricas via empenhamento de ARP 0158/2025/29… | R$ 118.990,00 | 06/11/2026 | 0 |
| 2025009241 | UERJ | ANTIBIOTICOS DO BRASIL LTDA (FILIAL) | Meropenem 500 mg Pó Sol Inj FA. | R$ 122.400,00 | 07/11/2026 | 1 |
| 2025009249 | UERJ | INJEX INDUSTRIAS CIRURGICAS LTDA | Aquisição de Seringas via empenhamento de ARP 0052/2025/294200-99 | R$ 7.000,00 | 07/11/2026 | 1 |
| 2026003485 | UERJ | L S RODRIGUES COMERCIO INFORMATICA LTDA | Aquisição de notebooks a serem entregues no Campus da Faculdade de Fo… | R$ 29.918,00 | 08/11/2026 | 2 |
| 2025008671 | UERJ | JRG DISTRIBUIDORA DE MEDICAMENTOS HOSPITALAR… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 93.870,00 | 10/11/2026 | 4 |
| 2025008673 | UERJ | PROMEFARMA MEDICAMENTOS E PRODUTOS HOSPITALA… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 41.845,76 | 10/11/2026 | 4 |
| 2025008674 | UERJ | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 159.992,00 | 10/11/2026 | 4 |
| 2025008828 | UERJ | AUTO SUTURE DO BRASIL LTDA | A aquisição, por licitação (pregão eletrônico), de cateter guia para … | R$ 2.295,00 | 10/11/2026 | 4 |
| 2025008829 | UERJ | HOMACC COMERCIO DE MATERIAL MEDICO HOSPITALA… | A aquisição, por licitação (pregão eletrônico), de cateter guia para … | R$ 108.578,35 | 10/11/2026 | 4 |
| 2025009139 | UERJ | LIDER NOTEBOOKS COMERCIO E SERVIÇOS LTDA | Aquisição de Computadores e Monitores. | R$ 5.094.000,00 | 10/11/2026 (PNCP) | 4 |
| 2025009143 | UERJ | FAGUNDEZ DISTRIBUIÇÃO LTDA. | Aquisição de Computadores e Monitores. | R$ 813.336,00 | 10/11/2026 (PNCP) | 4 |
| 2025009218 | UERJ | INJEX INDUSTRIAS CIRURGICAS LTDA | Aquisição de Seringas via empenhamento de ARP 0052/2025/294200-99. | R$ 37.450,00 | 10/11/2026 | 4 |
| 2025008780 | UERJ | CORPHO COMERCIO DE PRODUTOS HOSPITALARES LTDA | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 50.240,00 | 11/11/2026 | 5 |
| 2025003899 | UERJ | ELEKTA SOLUTIONS AB | AQUISIÇÃO DE Acelerador linear Elekta | R$ 5.192.000,00 | 11/11/2026 (PNCP) | 5 |
| 2025008494 | UERJ | EDWARDS LIFESCIENCES COMERCIO DE PRODUTOS ME… | A aquisição, por contratação direta por inexibilidade de licitação, d… | R$ 994.480,00 | 11/11/2026 (PNCP) | 5 |
| 2025008742 | UERJ | MASTER MEDICAL COMERCIO DE PRODUTOS HOSPITAL… | Aquisição de micronebulizador e macronebulizador para o Hospital Univ… | R$ 2.100,00 | 11/11/2026 | 5 |
| 2025008743 | UERJ | MEDMACH SOLUCOES HOSPITALARES LTDA | Aquisição de micronebulizador e macronebulizador para o Hospital Univ… | R$ 76.965,45 | 11/11/2026 | 5 |
| 2025008781 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 12.234,00 | 11/11/2026 | 5 |
| 2025008962 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de medicamentos para o Hospital Universitário Pedro Ernesto. | R$ 17.936,00 | 11/11/2026 | 5 |
| 2025008963 | UERJ | TRES PHARMA DISTRIBUIDORA E SERVIÇOS LTDA | Aquisição de medicamentos para o Hospital Universitário Pedro Ernesto. | R$ 137.257,60 | 11/11/2026 | 5 |
| 2025009024 | UERJ | JRG DISTRIBUIDORA DE MEDICAMENTOS HOSPITALAR… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 133.787,50 | 11/11/2026 | 5 |
| 2025009026 | UERJ | SICAFLA COMERCIO DE PRODUTOS FARMACEUTICOS L… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 49.967,50 | 11/11/2026 | 5 |
| 2025009027 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 557.700,00 | 11/11/2026 (PNCP) | 5 |
| 2025009028 | UERJ | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 179.990,00 | 11/11/2026 | 5 |
| 2026008986 | FAPERJ | ESAFI - ESCOLA DE ADMINISTRAÇÃO E TREINAMENT… | Contratação de inscrição dos servidores abaixo relacionados, para par… | R$ 32.130,00 | 11/11/2026 | 5 |
| 2025009014 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 180.000,00 | 12/11/2026 | 6 |
| 2025009015 | UERJ | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 288.543,00 | 12/11/2026 | 6 |
| 2026006652 | UERJ | FERREIRA B2G LTDA | Aquisição dos equipamentos compra de equipamentos (01 evaporador rota… | R$ 12.730,01 | 12/11/2026 | 6 |
| 2026006656 | UERJ | LIMATEC INDUSTRIA E SERVIÇOS LTDA | Aquisição dos equipamentos compra de equipamentos (01 evaporador rota… | R$ 11.540,00 | 12/11/2026 | 6 |
| 2025008483 | UERJ | MAX MOVE COMERCIO DE MOVEIS E TRANSPORTES LT… | Aquisição de mobiliário corporativo com entrega e montagem, visando a… | R$ 3.142.764,72 | 13/11/2026 (PNCP) | 7 |
| 2025008820 | UERJ | ALLUGGA EQUIPAMENTOS LTDA. | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM LOCAÇÃO DE NOTEBOOKS. | R$ 67.897,20 | 13/11/2026 | 7 |
| 2025010422 | UERJ | FORTIX ENGENHARIA E SOLUCOES LTDA | Contratação de empresa de engenharia para instalação de um Núcleo de … | R$ 82.000,00 | 13/11/2026 | 7 |
| 2025008880 | UERJ | PROMEFARMA MEDICAMENTOS E PRODUTOS HOSPITALA… | Aquisição de medicamentos para o Hospital Universitário Pedro Ernesto. | R$ 31.318,80 | 17/11/2026 | 11 |
| 2025002628 | UERJ | FENIX CONSTRUTORA LTDA | REFORMA DOS SERVIÇOS DE MAMOGRAFIA, ULTRASSONOGRAFIA, DENSITOMETRIA, … | R$ 1.214.819,97 | 17/11/2026 (PNCP) | 11 |
| 2025005359 | UERJ | LABOR-MED APARELHAGEM DE PRECISÃO LTDA | A aquisição de equipamento para ecoendoscopia para o setor de Gastroe… | R$ 1.712.194,00 | 17/11/2026 (PNCP) | 11 |
| 2025007972 | UERJ | FRESENIUS KABI BRASIL LTDA (MATRIZ) | A aquisição, via CONTRATAÇÃO DIRETA, ART.75, INC. III , ALÍNEA B, de … | R$ 75.600,00 | 17/11/2026 | 11 |
| 2025007973 | UERJ | NUTRIC NUTRICIONAL COMÉRCIO LTDA | A aquisição, via CONTRATAÇÃO DIRETA, ART.75, INC. III , ALÍNEA B, de … | R$ 95.482,80 | 17/11/2026 | 11 |
| 2025008881 | UERJ | BOTTI PHARMA LTDA | Aquisição de medicamentos para o Hospital Universitário Pedro Ernesto. | R$ 45.837,00 | 17/11/2026 | 11 |
| 2025008882 | UERJ | TRES PHARMA DISTRIBUIDORA E SERVIÇOS LTDA | Aquisição de medicamentos para o Hospital Universitário Pedro Ernesto. | R$ 468.700,00 | 17/11/2026 | 11 |
| 2025008883 | UERJ | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | Aquisição de medicamentos para o Hospital Universitário Pedro Ernesto. | R$ 32.783,00 | 17/11/2026 | 11 |
| 2025009206 | UERJ | DISTRIBUIÇÃO DE MEDICAMENTOS PAMED LTDA | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 13.804,00 | 17/11/2026 | 11 |
| 2025009207 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 40.572,00 | 17/11/2026 | 11 |
| 2025009208 | UERJ | BOTTI PHARMA LTDA | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 27.738,00 | 17/11/2026 | 11 |
| 2025009501 | UERJ | BAXTER HOSPITALAR LTDA | Glicose 5% (50 mg / mL) sol inj fr 500mL. | R$ 12.000,00 | 17/11/2026 | 11 |
| 2025009507 | UERJ | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Amicacina 250 mg / ml sol inj amp 2 mL. | R$ 4.120,00 | 17/11/2026 | 11 |
| 2025009512 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Etomidato 2 mg / mL sol inj amp 10 mL. | R$ 2.500,00 | 17/11/2026 | 11 |
| 2026006741 | UERJ | DANJAC DISTRIBUIDORA LTDA. | Aquisição de kit de garrafas de tinta colorida, compatível com a impr… | R$ 430,00 | 17/11/2026 | 11 |
| 2025008161 | UERJ | ZAP COMÉRCIO DE PRODUTOS HOSPITALARES LTDA ME | Aquisição, por licitação (pregão eletrônico), de Linhas de sangue e f… | R$ 19.315,40 | 18/11/2026 | 12 |
| 2025009185 | UERJ | BLAU FARMACEUTICA S.A. | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 134.950,00 | 18/11/2026 | 12 |
| 2025009187 | UERJ | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 273,00 | 18/11/2026 | 12 |
| 2025009189 | UERJ | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 17.514,00 | 18/11/2026 | 12 |
| 2025009190 | UERJ | SULMEDIC COMERCIO DE MEDICAMENTOS LTDA FILIA… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 2.640,00 | 18/11/2026 | 12 |
| 2025009250 | UERJ | H C IMPORTAÇÕES EXPORTAÇÕES LTDA | A aquisição de medicamentos, por Compra Direta, para o Hospital Unive… | R$ 552.359,40 | 18/11/2026 (PNCP) | 12 |
| 2025009255 | UERJ | VYTTRA DIAGNOSTICOS S.A | A aquisição de INSUMOS, NO modo de disputa aberto, pelo menor preço g… | R$ 102.531,84 | 18/11/2026 | 12 |
| 2026003829 | UERJ | LEMAN MEDICAMENTOS E CIA LTDA | Aquisição de atadura. | R$ 450,00 | 18/11/2026 | 12 |
| 2025008331 | UERJ | SHELL LIFE MATERIAL HOSPITALAR LTDA | A aquisição de equipamento Ventilador Pulmonar para atender a demanda… | R$ 3.181.403,40 | 19/11/2026 (PNCP) | 13 |
| 2025008498 | UERJ | E TAMUSSINO & CIA LTDA | Aquisição de introdutor diagnóstico, fio guia amplatz e shunt carotíd… | R$ 6.968,16 | 19/11/2026 | 13 |
| 2025008499 | UERJ | BOSTON SCIENTIFIC DO BRASIL LTDA. | Aquisição de introdutor diagnóstico, fio guia amplatz e shunt carotíd… | R$ 30.000,00 | 19/11/2026 | 13 |
| 2025008500 | UERJ | TECMEDIC COMERCIO DE PRODUTOS MEDICOS LTDA | Aquisição de introdutor diagnóstico, fio guia amplatz e shunt carotíd… | R$ 162.300,00 | 19/11/2026 | 13 |
| 2025008539 | UERJ | OTOLOGICA BRASIL PRODUTOS HOSPITALARES LTDA | A aquisição de próteses de estapedectomia para o Hospital Universitár… | R$ 40.000,00 | 19/11/2026 | 13 |
| 2025008679 | UERJ | GLOBAL CARE COMERCIO DE MATERIAL MEDICO LTDA. | A aquisição, por licitação (pregão eletrônico), de agulhas de biópsia… | R$ 440.300,00 | 19/11/2026 | 13 |
| 2025008700 | UERJ | ARC FONTOURA INDÚSTRIA COMÉRCIO E REPRESENTA… | Aquisição, por licitação (pregão eletrônico), de materiais diversos p… | R$ 800,00 | 19/11/2026 | 13 |
| 2025008701 | UERJ | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição, por licitação (pregão eletrônico), de materiais diversos p… | R$ 5.299,20 | 19/11/2026 | 13 |
| 2025008702 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição, por licitação (pregão eletrônico), de materiais diversos p… | R$ 2.046,00 | 19/11/2026 | 13 |
| 2025008703 | UERJ | DONEGATE DISTRIBUIDORA LTDA-ME | Aquisição, por licitação (pregão eletrônico), de materiais diversos p… | R$ 5.596,50 | 19/11/2026 | 13 |
| 2025008704 | UERJ | MICROBAC PRODUTOS E SERVIÇOS PARA LABORATÓRI… | Aquisição, por licitação (pregão eletrônico), de materiais diversos p… | R$ 3.398,40 | 19/11/2026 | 13 |
| 2025008705 | UERJ | NEW LIFE MATERIAIS E EQUIPAMENTOS CIRÚRGICOS… | Aquisição, por licitação (pregão eletrônico), de materiais diversos p… | R$ 6.173,75 | 19/11/2026 | 13 |
| 2025008954 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 22.920,00 | 19/11/2026 | 13 |
| 2025008955 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 2.065,00 | 19/11/2026 | 13 |
| 2025008956 | UERJ | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 36.145,00 | 19/11/2026 | 13 |
| 2025008957 | UERJ | SANTE MEDICA HOSPITALAR LTDA | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 215.406,00 | 19/11/2026 | 13 |
| 2025008958 | UERJ | VOLPHARMA DISTRIBUIDORA DE PRODUTOS HOSPITAL… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 198.765,00 | 19/11/2026 | 13 |
| 2025009334 | UERJ | OBAH PRODUTOS E SERVICOS PARA SEGURANCA E EN… | A aquisição de medicamentos, por Compra Direta, para o Hospital Unive… | R$ 21.981,00 | 19/11/2026 | 13 |
| 2025009590 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Acido Acetilsalicilico 100 mg cp. | R$ 196,00 | 19/11/2026 | 13 |
| 2025009591 | UERJ | DROGAFONTE LTDA. | Aciclovir 200 mg cp. | R$ 491,40 | 19/11/2026 | 13 |
| 2025009592 | UERJ | DISTRIBUIÇÃO DE MEDICAMENTOS PAMED LTDA | Ceftazidima 2000 mg+Avibactam Sód. 500 mg Pó Sol. Inj. FA. | R$ 87.900,80 | 19/11/2026 | 13 |
| 2025009593 | UERJ | CONQUISTA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Diazepam 5 mg / mL sol inj amp 2mL. | R$ 912,00 | 19/11/2026 | 13 |
| 2026008207 | UERJ | COELHO SOFTWARE | Aquisição por importação direta pela Universidade do Estado do Rio de… | R$ 14.214,34 | 21/11/2026 | 15 |
| 2026007963 | UERJ | DANJAC DISTRIBUIDORA LTDA. | Aquisição de materiais educativos/pedagógicos relacionados à perinata… | R$ 2.060,96 | 22/11/2026 | 16 |
| 2026007966 | UERJ | 66808013000108 LARISSA MIRANDA DOS SANTOS TE… | Aquisição de materiais educativos/pedagógicos relacionados à perinata… | R$ 72,99 | 22/11/2026 | 16 |
| 2026006910 | UERJ | ZURIEL DE IGUAÇU COMERCIO E REPRESENTAÇÃO LT… | Aquisição de aparelho de telefone celular institucional, destinado ao… | R$ 1.887,00 | 23/11/2026 | 17 |
| 2026008898 | CECIERJ | 35.430.841 WAGNER LEITE DE OLIVEIRA | Contratação de empresa especializada para execução de pintura interna… | R$ 7.350,00 | 23/11/2026 | 17 |
| 2025008315 | UERJ | ALAL MED EQUIPAMENTOS E MATERIAIS HOSPITALAR… | A aquisição, por licitação (pregão eletrônico), de cateter basket, fi… | R$ 26.500,00 | 24/11/2026 | 18 |
| 2025008316 | UERJ | ASLI COMERCIAL LTDA | A aquisição, por licitação (pregão eletrônico), de cateter basket, fi… | R$ 28.800,00 | 24/11/2026 | 18 |
| 2026007003 | UERJ | TOP MIX COMÉRCIO E SERVIÇOS LTDA | AQUISIÇÃO DE SMART TV 65`` | R$ 18.999,00 | 24/11/2026 | 18 |
| 2024006886 | UERJ | NP TECNOLOGIA E GESTAO DE DADOS LTDA | Contratação de ferramenta de pesquisa e comparação de preço praticado… | R$ 22.724,00 | 25/11/2026 | 19 |
| 2025005947 | UERJ | PERKINELMER U.S. LLC | Aquisição de um Espectrômetro de Emissão Óptica com Plasma Indutivame… | R$ 294.966,99 | 25/11/2026 | 19 |
| 2025009309 | UERJ | MICROBAC PRODUTOS E SERVIÇOS PARA LABORATÓRI… | A aquisição de INSUMOS, modo de disputa aberto, pelo menor preço UNIT… | R$ 144.838,00 | 25/11/2026 | 19 |
| 2025009310 | UERJ | PLAST LABOR IND E COM DE EQUIP HOSP E LAB LT… | A aquisição de INSUMOS, modo de disputa aberto, pelo menor preço UNIT… | R$ 80.856,00 | 25/11/2026 | 19 |
| 2025009719 | UERJ | FARMACE - INDÚSTRIA QUÍMICO FARMACÊUTICA CEA… | Atropina, Sulfato 0,25 mg / 1 mL sol inj amp. | R$ 6.900,00 | 25/11/2026 | 19 |
| 2026002021 | UERJ | SOBERANA COMERCIO E SERVIÇOS LTDA | Aquisição e montagem de mobiliário. | R$ 113.299,95 | 25/11/2026 | 19 |
| 2025007634 | UERJ | ECKERT & ZIEGLER BRASIL COMERCIAL LTDA | A aquisição de Calibrador de dose em câmara de ionização e medidor de… | R$ 344.723,40 | 26/11/2026 | 20 |
| 2025009016 | UERJ | CCGP - CENTRO DE TREINAMENTO E CAPACITACAO L… | Contratação de serviços de capacitação para o Hospital Universitário … | R$ 46.541,00 | 26/11/2026 | 20 |
| 2025009172 | FAPERJ | LECARD ADMNISTRADORA DE CARTÕES LTDA | Participação da Fundação Carlos Chagas Filho de Amparo à Pesquisa do … | R$ 42.250,00 | 26/11/2026 | 20 |
| 2025009793 | UERJ | PROMEFARMA MEDICAMENTOS E PRODUTOS HOSPITALA… | Daptomicina 500mg po liof inj fa. | R$ 3.580,50 | 26/11/2026 | 20 |
| 2025009821 | UERJ | COMERCIAL CIRURGICA RIOCLARENSE LTDA | Gencitabina, Cloridrato 1 g po liof sol inj fa. | R$ 31.200,00 | 26/11/2026 | 20 |
| 2025009822 | UERJ | ORZIL CONSULTORIA E TREINAMENTO LTDA EPP | A contratação de serviços de capacitação para o Hospital Universitári… | R$ 30.429,00 | 26/11/2026 | 20 |
| 2026007004 | UERJ | B2R SOLUCOES E VENDAS LTDA | AQUISIÇÃO DE MESA DE SOM DIGITAL PROFISSIONAL | R$ 21.000,00 | 26/11/2026 | 20 |
| 2026007008 | UERJ | ELOAR SERVIÇOS DE COMUNICAÇÃO E MARKETING LT… | Contratação de serviços editoriais especializados para elaboração de … | R$ 2.400,00 | 26/11/2026 | 20 |
| 2025001516 | UERJ | SGHN - HIGIENIZACAO TEXTIL E NUTRICAO HOSPIT… | A contratação de empresa especializada na prestação de serviços contí… | R$ 36.140.990,84 | 27/11/2026 (PNCP) | 21 |
| 2025009561 | FAETEC | DK8 TECNOLOGIA LTDA | Aquisição de Material Permanente Tecnológico para equipar os Laborató… | R$ 1.707.999,30 | 27/11/2026 (PNCP) | 21 |
| 2025009567 | FAETEC | COMERCIO DE MATERIAIS ESPORTIVOS E EDUCATIVO… | Aquisição de Material Permanente Tecnológico para equipar os Laborató… | R$ 539.959,00 | 27/11/2026 (PNCP) | 21 |
| 2025009568 | FAETEC | AGNUS BRASIL COMERCIO E SERVICOS DE ARTIGOS … | Aquisição de Material Permanente Tecnológico para equipar os Laborató… | R$ 331.700,00 | 27/11/2026 | 21 |
| 2025009862 | UERJ | NSA DISTRIBUIDORA DE MEDICAMENTOS EIRELLI | Azatioprina 50 mg cp. | R$ 1.765,00 | 27/11/2026 | 21 |
| 2025009867 | UERJ | NSA DISTRIBUIDORA DE MEDICAMENTOS EIRELLI | Doxorrubicina, Cloridrato 50 mg po / sol inj fa. | R$ 9.458,40 | 27/11/2026 | 21 |
| 2025009874 | UERJ | ONCOVIT DISTRIBUIDORA DE MEDICAMENTOS LTDA M… | Bortezomibe 3,5 mg po liof / sol inj fa. | R$ 13.103,17 | 27/11/2026 | 21 |
| 2026005002 | UENF | ROKA ASSISTANCE COMÉRCIO E SERVIÇOS LTDA | Aquisição de ar-condicionados. | R$ 1.226.202,60 | 27/11/2026 (PNCP) | 21 |
| 2025008613 | UERJ | BRISTOL MYERS SQUIBB FARMACÊUTICA LTDA | A aquisição por adesão ao Sistema de registro de preços de Medicament… | R$ 521.382,24 | 28/11/2026 (PNCP) | 22 |
| 2025009854 | UERJ | DROGAFONTE LTDA. | Fluconazol 2 mg / mL sol inj bolsa 100mL. | R$ 14.706,00 | 28/11/2026 | 22 |
| 2025009888 | UERJ | ANTIBIOTICOS DO BRASIL LTDA (FILIAL) | Ceftazidima 1 g po sol inj fa. | R$ 8.768,50 | 28/11/2026 | 22 |
| 2024004489 | UERJ | SUAL-TECH COMÉRCIO DE SISTEMAS E SOLUÇÕES TE… | Contratação dos serviços de manutenção preventiva ecorretiva de softw… | R$ 150.914,76 | 29/11/2026 | 23 |
| 2021003553 | UERJ | H. STRATTNER & CIA. LTDA. | CONTRATAÇÃO DE EMPRESA PARA MANUTENÇÃO DE SISTEMA ROBOTICO DA VINCI E… | R$ 1.136.740,68 | 30/11/2026 | 24 |
| 2021006649 | UERJ | SHELL LIFE MATERIAL HOSPITALAR LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA MANUTENÇÃO CORRETIVA. | R$ 580.077,60 | 01/12/2026 | 25 |
| 2024006272 | CECIERJ | LETS RENT A CAR S/A | Prestação de serviços de locação de 5 (cinco) veículos, tipo Van, par… | R$ 715.073,71 | 01/12/2026 | 25 |
| 2025009491 | UERJ | INLABEL SOLUÇÕES EM RÓTULOS ADESIVOS LTDA | A aquisição urgente, por dispensa de licitação, de Sacos plásticos, e… | R$ 152.060,00 | 01/12/2026 | 25 |
| 2025009493 | UERJ | MEDMACH SOLUCOES HOSPITALARES LTDA | A aquisição urgente, por dispensa de licitação, de Sacos plásticos, e… | R$ 16.520,00 | 01/12/2026 | 25 |
| 2025009756 | UERJ | CIRURTECH COMERCIO E MANUTENCAO DE MATERIAIS… | A aquisição, por licitação (pregão eletrônico), de instrumentais cirú… | R$ 1.976,48 | 01/12/2026 | 25 |
| 2025009757 | UERJ | MCN COMÉRCIO E IMPORTAÇÃO DE PRODUTOS CIRÚRG… | A aquisição, por licitação (pregão eletrônico), de instrumentais cirú… | R$ 2.328,00 | 01/12/2026 | 25 |
| 2025010012 | UERJ | PROMEFARMA MEDICAMENTOS E PRODUTOS HOSPITALA… | Aquisição de medicamentos, por Compra Direta Emergencial, para o Hosp… | R$ 45.520,80 | 01/12/2026 | 25 |
| 2025001371 | UERJ | MICROBAC PRODUTOS E SERVIÇOS PARA LABORATÓRI… | Aquisição urgente, por dispensa de licitação, de Escova Endocervical,… | R$ 11.340,00 | 02/12/2026 | 26 |
| 2025008574 | FAETEC | SANRITA COMERCIO E SERVICOS LTDA - ME | Aquisição de material de consumo com a finalidade de composição de Ki… | R$ 173.997,95 | 02/12/2026 | 26 |
| 2025009314 | UERJ | HOLPEMED COMERCIO E DISTRIBUICAO DE MATERIAI… | A aquisição, por licitação (pregão eletrônico), de poltronas de acomp… | R$ 882.997,71 | 02/12/2026 (PNCP) | 26 |
| 2025010036 | UERJ | ONCOVIT DISTRIBUIDORA DE MEDICAMENTOS LTDA M… | Dasatinibe 100 mg cp. | R$ 185.700,00 | 02/12/2026 | 26 |
| 2026005250 | UERJ | LABSYNTH PRODUTOS PARA LABORATORIOS LTDA | É objeto desse termo a aquisição de reagentes para atender as demanda… | R$ 1.232,13 | 02/12/2026 | 26 |
| 2024009366 | UERJ | LABCOR LABORATORIOS LTDA | Aquisição, por licitação (pregão eletrônico), de Prótese Valvar Bioló… | R$ 211.195,00 | 03/12/2026 | 27 |
| 2025009387 | UERJ | ISM3 SERVICOS E SOLUCOES LTDA | Constitui objetivo deste documento a definição das características té… | R$ 260.000,00 | 03/12/2026 | 27 |
| 2025009480 | UERJ | HALEX ISTAR INDÚSTRIA FARMACÊUTICA S/A | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 64.680,00 | 03/12/2026 | 27 |
| 2025009481 | UERJ | ESPECIFARMA COMERCIO DE MEDICAMENTOS E PRODU… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 2.450,00 | 03/12/2026 | 27 |
| 2025009482 | UERJ | CONQUISTA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 73.450,00 | 03/12/2026 | 27 |
| 2025009483 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 8.408,00 | 03/12/2026 | 27 |
| 2025009484 | UERJ | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 238.710,00 | 03/12/2026 | 27 |
| 2025009485 | UERJ | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 3.998,80 | 03/12/2026 | 27 |
| 2025010049 | UERJ | TRES PHARMA DISTRIBUIDORA E SERVIÇOS LTDA | Irinotecano, Cloridrato 20 mg / mL sol inj fa 5 mL | R$ 12.080,00 | 03/12/2026 | 27 |
| 2026009025 | UENF | FAGUNDEZ DISTRIBUIÇÃO LTDA. | Aquisição de Nobreaks | R$ 308.599,20 | 03/12/2026 | 27 |
| 2025007459 | UERJ | ILLUMINA BRASIL PRODUTOS DE BIOTECNOLOGIA LT… | Solicitação de compra de insumos, aquisição de software, e contrato d… | R$ 753.686,50 | 04/12/2026 (PNCP) | 28 |
| 2025009302 | UERJ | E TAMUSSINO & CIA LTDA | Aquisição por licitação (pregão eletrônico), de introdutores e catete… | R$ 34.996,00 | 04/12/2026 | 28 |
| 2025008147 | UERJ | PASCO SCIENTIFIC | Aquisição de equipamentos para o laboratório de mecânica | R$ 192.229,40 | 05/12/2026 | 29 |
| 2022008905 | UERJ | SOFIS INFORMATICA LTDA EPP | O serviço solicitado visa manter em pleno funcionamento o Software He… | R$ 558.705,00 | 06/12/2026 | 30 |
| 2026002883 | UERJ | EMPRESA JUNIOR BITWEBJR | Pagamento da empresa júnior do Instituto de Matemática e Estatística … | R$ 7.000,00 | 06/12/2026 | 30 |
| 2026003001 | UERJ | HIDROS CONSULTORIA-EMPRESA JUNIOR DE ENGENHA… | Empenhamento para pagamento da empresa júnior da Faculdade de Engenha… | R$ 7.000,00 | 06/12/2026 | 30 |
| 2025009126 | UERJ | DONEGATE DISTRIBUIDORA LTDA-ME | Aquisição de materiais médico-hospitalares para garantir o funcioname… | R$ 44.995,20 | 08/12/2026 | 32 |
| 2025009127 | UERJ | ARC FONTOURA INDÚSTRIA COMÉRCIO E REPRESENTA… | Aquisição de materiais médico-hospitalares para garantir o funcioname… | R$ 5.682,00 | 08/12/2026 | 32 |
| 2025009128 | UERJ | PRO AR COMERCIO DE PRODUTOS HOSPITALARES LTD… | Aquisição de materiais médico-hospitalares para garantir o funcioname… | R$ 4.080,00 | 08/12/2026 | 32 |
| 2025009129 | UERJ | BIONEFRO COMÉRCIO DE MATERIAL HOSPITALAR LTD… | Aquisição de materiais médico-hospitalares para garantir o funcioname… | R$ 5.180,00 | 08/12/2026 | 32 |
| 2025009130 | UERJ | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de materiais médico-hospitalares para garantir o funcioname… | R$ 2.340,00 | 08/12/2026 | 32 |
| 2025009579 | UERJ | HOSPINOVA DISTRIBUIDORA DE PRODUTOS HOSPITAL… | AQUISIÇÃO DE MEDICAMENTOS PARA O HURHC. | R$ 8.992,00 | 09/12/2026 | 33 |
| 2025009183 | UERJ | ORIGINAL IMPLANTES E EQUIPAMENTOS HOSPITALAR… | A aquisição, por licitação, de material para Artrodese Cervical para … | R$ 234.999,00 | 09/12/2026 | 33 |
| 2025009576 | UERJ | SULMEDIC COMERCIO DE MEDICAMENTOS LTDA FILIA… | AQUISIÇÃO DE MEDICAMENTOS PARA O HURHC. | R$ 13.965,00 | 09/12/2026 | 33 |
| 2025009577 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | AQUISIÇÃO DE MEDICAMENTOS PARA O HURHC. | R$ 12.570,00 | 09/12/2026 | 33 |
| 2025009581 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | AQUISIÇÃO DE MEDICAMENTOS PARA O HURHC. | R$ 7.530,00 | 09/12/2026 | 33 |
| 2025009582 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | AQUISIÇÃO DE MEDICAMENTOS PARA O HURHC. | R$ 6.561,00 | 09/12/2026 | 33 |
| 2025009790 | UERJ | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | AQUISIÇÃO DE ITENS DE FARMÁCIA PARA O HURHC. | R$ 5.411,52 | 09/12/2026 | 33 |
| 2025009791 | UERJ | ESPECIFARMA COMERCIO DE MEDICAMENTOS E PRODU… | AQUISIÇÃO DE ITENS DE FARMÁCIA PARA O HURHC. | R$ 16.236,72 | 09/12/2026 | 33 |
| 2025009792 | UERJ | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | AQUISIÇÃO DE ITENS DE FARMÁCIA PARA O HURHC. | R$ 8.000,00 | 09/12/2026 | 33 |
| 2025009829 | FAETEC | INTEGRATIVA EDUCACAO E COMUNICACAO CRIATIVA … | Aquisição de materiais de apoio pedagógico para implantação de Projet… | R$ 396.656,50 | 09/12/2026 | 33 |
| 2025009893 | UERJ | HOMACC COMERCIO DE MATERIAL MEDICO HOSPITALA… | Aquisição, por licitação (pregão eletrônico), de cateter diagnóstico … | R$ 99.934,10 | 09/12/2026 | 33 |
| 2025009895 | UERJ | ENDO SYSTEMS IMPORTADORA E DISTRIBUIDORA DE … | Aquisição, por licitação (pregão eletrônico), de cateter diagnóstico … | R$ 7.755,80 | 09/12/2026 | 33 |
| 2025009901 | FAETEC | GUARAILHA DISTRIBUIDORA DE ALIMENTOS LTDA EPP | O objeto da presente aquisição é a contratação da empresa especializa… | R$ 1.467.232,23 | 09/12/2026 (PNCP) | 33 |
| 2025009911 | FAETEC | MVT EDUCACAO LTDA | Aquisição de solução pedagógica de educação financeira, composta por … | R$ 25.283.699,00 | 09/12/2026 (PNCP) | 33 |
| 2025010277 | UERJ | CIRURTECH COMERCIO E MANUTENCAO DE MATERIAIS… | A aquisição, por licitação, de instrumentais cirúrgicos para o Hospit… | R$ 7.982,16 | 09/12/2026 | 33 |
| 2025010282 | UERJ | EXCELENCIA DISTRIBUIDORA DE PRODUTOS E SERVI… | A aquisição, por licitação, de instrumentais cirúrgicos para o Hospit… | R$ 8.201,93 | 09/12/2026 | 33 |
| 2026003010 | UENF | MC TEC INFORMÁTICA LTDA | Aquisição de computadores e notebooks de alta performance. | R$ 408.800,00 | 09/12/2026 | 33 |
| 2026006135 | UENF | ORQUESTRANDO A VIDA - ORAVI | Concessão de apoio financeiro, mediante repasse de recursos a título … | R$ 50.000,00 | 09/12/2026 | 33 |
| 2026008096 | UERJ | METTA ENGENHARIA LDTA | Remoção de entulho classe A (telhas cerâmicas), por meio de caçambas … | R$ 10.500,00 | 09/12/2026 | 33 |
| 2025009584 | UERJ | VASCONCELOS INDUSTRIA FARMACEUTICA E COMERCI… | AQUISIÇÃO DE MEDICAMENTOS PARA O HURHC. | R$ 6.120,00 | 10/12/2026 | 34 |
| 2025009789 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | AQUISIÇÃO DE ITENS DE FARMÁCIA PARA O HURHC. | R$ 1.119,20 | 10/12/2026 | 34 |
| 2026007436 | UERJ | BARBIN EMPRESARIAL LTDA | Aquisição de 6 (seis) webcams com microfone embutido e resolução HD | R$ 389,46 | 10/12/2026 | 34 |
| 2025009451 | UERJ | BOSTON SCIENTIFIC DO BRASIL LTDA. | A aquisição, por licitação (pregão eletrônico), de próteses para fech… | R$ 96.000,00 | 11/12/2026 | 35 |
| 2025009452 | UERJ | HOMACC COMERCIO DE MATERIAL MEDICO HOSPITALA… | A aquisição, por licitação (pregão eletrônico), de próteses para fech… | R$ 286.900,00 | 11/12/2026 | 35 |
| 2025009453 | UERJ | VITORIA HOPITALAR LTDA | A aquisição, por licitação (pregão eletrônico), de próteses para fech… | R$ 422.500,00 | 11/12/2026 | 35 |
| 2025009730 | UERJ | FIRST MED PRODUTOS MÉDICOS LTDA-EPP | A aquisição, por licitação (pregão eletrônico), de materiais a serem … | R$ 124.418,00 | 11/12/2026 | 35 |
| 2025009731 | UERJ | GF LABOR COMERCIO E REPRESENTAÇÃO LTDA | A aquisição, por licitação (pregão eletrônico), de materiais a serem … | R$ 295.382,40 | 11/12/2026 | 35 |
| 2025009924 | UERJ | SURGICAL GROUP IMPORTACAO E EXPORTACAO LTDA | A aquisição de agente hemostático para o Hospital Universitário Pedro… | R$ 18.240,00 | 11/12/2026 | 35 |
| 2025009939 | UERJ | BOSTON SCIENTIFIC DO BRASIL LTDA. | Aquisição de Fibras Laser Holmium com comodato para o Hospital Univer… | R$ 937.639,20 | 11/12/2026 (PNCP) | 35 |
| 2025010016 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 175.054,50 | 11/12/2026 | 35 |
| 2025010017 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 4.763,00 | 11/12/2026 | 35 |
| 2025010018 | UERJ | SICAFLA COMERCIO DE PRODUTOS FARMACEUTICOS L… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 50.167,00 | 11/12/2026 | 35 |
| 2025010019 | UERJ | UNIAO QUIMICA FARMACEUTICA NACIONAL SA | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 399.999,87 | 11/12/2026 | 35 |
| 2025010055 | UERJ | CWD SUPRIMENTOS HOSPITALARES LTDA | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 1.113,15 | 11/12/2026 | 35 |
| 2025010056 | UERJ | DISTRIBUIÇÃO DE MEDICAMENTOS PAMED LTDA | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 1.316.000,00 | 11/12/2026 (PNCP) | 35 |
| 2025010058 | UENF | 2R DATATEL TELEINFORMÁTICA LTDA | Aquisição de Solução de Firewall com Curso de Treinamento | R$ 418.287,50 | 11/12/2026 | 35 |
| 2025010072 | UERJ | PER PRIMA COMÉRCIO E REPRESENTAÇÕES LTDA | Aquisição, por licitação (pregão eletrônico), de material para cirurg… | R$ 129.000,00 | 11/12/2026 | 35 |
| 2025010080 | UERJ | ONCO PROD DIST. PROD. HOSPITALRES E ONCOLÓGI… | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 547.329,60 | 11/12/2026 (PNCP) | 35 |
| 2025010176 | UERJ | SHELL LIFE MATERIAL HOSPITALAR LTDA | Contratação, por inexigibilidade, de empresa especializada para a ven… | R$ 66.030,00 | 11/12/2026 | 35 |
| 2025008136 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 5.850,00 | 12/12/2026 | 36 |
| 2025008137 | UERJ | SICAFLA COMERCIO DE PRODUTOS FARMACEUTICOS L… | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 1.987,44 | 12/12/2026 | 36 |
| 2025008138 | UERJ | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 8.347,42 | 12/12/2026 | 36 |
| 2025008141 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 23.536,50 | 12/12/2026 | 36 |
| 2025008142 | UERJ | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 749,66 | 12/12/2026 | 36 |
| 2025008143 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 1.497,30 | 12/12/2026 | 36 |
| 2025010077 | UERJ | ONCOVIT DISTRIBUIDORA DE MEDICAMENTOS LTDA M… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 391.200,00 | 12/12/2026 | 36 |
| 2026006617 | UERJ | ASSOCIAÇÃO BRASILEIRA DE ENSINO E PESQUISA D… | Pagamento da anuidade da filiação da Faculdade de Serviço Social da U… | R$ 9.000,00 | 13/12/2026 | 37 |
| 2026007154 | UERJ | ELOAR SERVIÇOS DE COMUNICAÇÃO E MARKETING LT… | Aquisição de tenda inflável e tripés para banner, para atendimento da… | R$ 6.490,00 | 14/12/2026 | 38 |
| 2025007024 | UERJ | BREF GESTAO EMPRESARIAL EIRELI ME | Contratação, de empresa especializada no fornecimento de refeições in… | R$ 1.109.700,00 | 15/12/2026 (PNCP) | 39 |
| 2025009449 | UERJ | AUTO SUTURE DO BRASIL LTDA | Aquisição de endopróteses modulares para tratamento do aneurisma daao… | R$ 785.125,00 | 15/12/2026 (PNCP) | 39 |
| 2025009450 | UERJ | INTIMAL SUPRIMENTOS MEDICOS LTDA EPP | Aquisição de endopróteses modulares para tratamento do aneurisma daao… | R$ 116.400,00 | 15/12/2026 | 39 |
| 2025009804 | UERJ | PHILIPS MEDICAL SYSTEMS LTDA | Aquisição de equipamento Arco Cirúrgico para atender a demanda do CC … | R$ 2.090.000,00 | 15/12/2026 (PNCP) | 39 |
| 2025010090 | UERJ | RJD HOSPITALAR EIRELI | A aquisição de fios para o Hospital Universitário Pedro Ernesto. | R$ 7.805,56 | 15/12/2026 | 39 |
| 2025010091 | UERJ | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | A aquisição de fios para o Hospital Universitário Pedro Ernesto. | R$ 14.508,00 | 15/12/2026 | 39 |
| 2025010093 | UERJ | MOGAMI IMPORTAÇÃO E EXPORTAÇÃO LTDA | A aquisição de fios para o Hospital Universitário Pedro Ernesto. | R$ 42.084,96 | 15/12/2026 | 39 |
| 2025010094 | UERJ | HEARTCOM PRODUTOS MEDICOS LTDA | A aquisição de fios para o Hospital Universitário Pedro Ernesto. | R$ 22.746,96 | 15/12/2026 | 39 |
| 2025010157 | UERJ | ALTERDATA TECNOLOGIA EM INFORMÁTICA LTDA | Contratação de solução integrada de gestão fiscal e contábil para o D… | R$ 9.482,88 | 15/12/2026 | 39 |
| 2025010188 | UERJ | ATHENAS ENGENHARIA E AUTOMACAO LTDA | Aquisição emergencial de serviço de Contratação de manutenção prevent… | R$ 82.999,92 | 15/12/2026 | 39 |
| 2026002206 | UERJ | MAX MOVE COMERCIO DE MOVEIS E TRANSPORTES LT… | Aquisição de mobiliário corporativo, com fornecimento, entrega e mont… | R$ 270.873,80 | 15/12/2026 | 39 |
| 2025009879 | UERJ | NOVORTHEC COMÉRCIO INTEGRADO LTDA | A aquisição de mesas de Mayo, mesas auxiliares, carros para transport… | R$ 43.398,76 | 16/12/2026 | 40 |
| 2025009135 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 7.390,50 | 16/12/2026 | 40 |
| 2025009136 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 7.183,80 | 16/12/2026 | 40 |
| 2025009137 | UERJ | LABORATÓRIOS B. BRAUN S.A | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 13.104,00 | 16/12/2026 | 40 |
| 2025009138 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 32.097,60 | 16/12/2026 | 40 |
| 2025009140 | UERJ | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 3.494,40 | 16/12/2026 | 40 |
| 2025009142 | UERJ | CONQUISTA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 15.444,00 | 16/12/2026 | 40 |
| 2025009144 | UERJ | EXCELENCIA DISTRIBUIDORA DE PRODUTOS E SERVI… | Aquisição de materiais médico-hospitalares para atender às necessidad… | R$ 2.778,00 | 16/12/2026 | 40 |
| 2025009145 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de materiais médico-hospitalares para atender às necessidad… | R$ 63.990,00 | 16/12/2026 | 40 |
| 2025009263 | UERJ | DROGAFONTE LTDA. | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 6.801,68 | 16/12/2026 | 40 |
| 2025009266 | UERJ | CONQUISTA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 14.196,00 | 16/12/2026 | 40 |
| 2025009268 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 10.530,00 | 16/12/2026 | 40 |
| 2025009269 | UERJ | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 2.329,98 | 16/12/2026 | 40 |
| 2025009270 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de medicamentos e soluções para a Policlínica Universitária… | R$ 22.799,40 | 16/12/2026 | 40 |
| 2025009632 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de materiais médico-hospitalares para atender às necessidad… | R$ 3.354,00 | 16/12/2026 | 40 |
| 2025009634 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de seringas, agulhas e cateteres de infusão essenciais para… | R$ 7.996,00 | 16/12/2026 | 40 |
| 2025009636 | UERJ | PURAH MEDICAL & CO LTDA | Aquisição de seringas, agulhas e cateteres de infusão essenciais para… | R$ 4.777,50 | 16/12/2026 | 40 |
| 2025009878 | UERJ | LIGA HOSPITALAR EIRELI | A aquisição de mesas de Mayo, mesas auxiliares, carros para transport… | R$ 28.800,00 | 16/12/2026 | 40 |
| 2025010207 | UERJ | RTT INFORMÁTICA E TELECOMUNICAÇÕES LTDA | Aquisição de servidor físico dedicado. | R$ 94.199,00 | 16/12/2026 | 40 |
| 2026007647 | UERJ | QLUZ MATERIAL ELETRICO, HIDRAULICO E BAZAR L… | Aquisição de materiais para manutenção e impermeabilização dos telhad… | R$ 1.386,00 | 17/12/2026 | 41 |
| 2025009764 | UERJ | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de medicamentos Succinato Sódico De Hidrocortisona. | R$ 5.400,00 | 17/12/2026 | 41 |
| 2025010119 | UERJ | MAX PHARMA COMERCIO LTDA | A aquisição de medicamentos, por Compra Direta, para o Hospital Unive… | R$ 1.540,00 | 17/12/2026 | 41 |
| 2025010120 | UERJ | MED CENTER COMERCIAL LTDA | A aquisição de medicamentos, por Compra Direta, para o Hospital Unive… | R$ 10.360,00 | 17/12/2026 | 41 |
| 2025010303 | UERJ | COLOPLAST DO BRASIL LTDA. | A aquisição, por licitação (pregão eletrônico), de Curativos para o H… | R$ 26.140,00 | 17/12/2026 | 41 |
| 2025010305 | UERJ | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | A aquisição, por licitação (pregão eletrônico), de Curativos para o H… | R$ 3.932,50 | 17/12/2026 | 41 |
| 2025010306 | UERJ | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | A aquisição, por licitação (pregão eletrônico), de Curativos para o H… | R$ 61.673,67 | 17/12/2026 | 41 |
| 2025010307 | UERJ | MEDICAL HEALTH COMERCIO SERVIÇOS E IMPORTAÇÃ… | A aquisição, por licitação (pregão eletrônico), de Curativos para o H… | R$ 42.498,75 | 17/12/2026 | 41 |
| 2025010310 | UERJ | SURGICAL MED COMÉRCIO DE IMPORTAÇÃO DE MATER… | A aquisição, por licitação (pregão eletrônico), de Curativos para o H… | R$ 41.540,00 | 17/12/2026 | 41 |
| 2025010324 | UERJ | VERITAS FARMA DISTRIBUIDORA LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 1.584,78 | 17/12/2026 | 41 |
| 2025010325 | UERJ | CWD SUPRIMENTOS HOSPITALARES LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 8.170,00 | 17/12/2026 | 41 |
| 2025010326 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 1.096,00 | 17/12/2026 | 41 |
| 2025010328 | UERJ | SICAFLA COMERCIO DE PRODUTOS FARMACEUTICOS L… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 18.840,00 | 17/12/2026 | 41 |
| 2026007648 | UERJ | GOLDEM DISTRIBUIDORA E REPRESENTAÇÃO LTDA | Aquisição de materiais para manutenção e impermeabilização dos telhad… | R$ 18.800,00 | 17/12/2026 | 41 |
| 2025010287 | UERJ | GF LABOR COMERCIO E REPRESENTAÇÃO LTDA | Aquisição, por licitação (pregão eletrônico), de fios guias para o Ho… | R$ 31.950,00 | 18/12/2026 | 42 |
| 2025010289 | UERJ | M3 CARE SERVIÇO E COMERCIO MATERIAIS HOSPITA… | Aquisição, por licitação (pregão eletrônico), de fios guias para o Ho… | R$ 1.134,00 | 18/12/2026 | 42 |
| 2025010290 | UERJ | SMT IMPORTADORA E DISTRIBUIDORA DE PRODUTOS … | Aquisição, por licitação (pregão eletrônico), de fios guias para o Ho… | R$ 32.980,00 | 18/12/2026 | 42 |
| 2025010388 | UERJ | SENHORINHA MATERIAIS DE CONSTRUCAO LTDA | Execução da obra de construção de uma área de convivência para o Camp… | R$ 96.908,40 | 18/12/2026 | 42 |
| 2025010566 | FAETEC | COMERCIAL MILANO BRASIL LTDA | Aquisição de KIT de gêneros alimentícios diversos, nas condições, qua… | R$ 2.186.999,49 | 18/12/2026 (PNCP) | 42 |
| 2023004444 | CECIERJ | FOCO SERVIÇOS TERCEIRIZADOS LTDA | Contratação de sociedade empresária especialiada na prestação de serv… | R$ 4.410.418,14 | 19/12/2026 | 43 |
| 2025006323 | UERJ | EBSCO BRASIL LTDA | Renovação da assinatura da Plataforma JoVE - Journal os Visualized Ex… | R$ 309.385,51 | 19/12/2026 | 43 |
| 2025007248 | UERJ | CIG PRODUCOES E EVENTOS LTDA - ME | O objeto do presente termo de referência é a contratação de serviço d… | R$ 6.200,00 | 19/12/2026 | 43 |
| 2025010530 | UERJ | ARC FONTOURA INDÚSTRIA COMÉRCIO E REPRESENTA… | A aquisição, por licitação (pregão eletrônico), de Itens Diversos par… | R$ 36.903,60 | 19/12/2026 | 43 |
| 2025010531 | UERJ | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | A aquisição, por licitação (pregão eletrônico), de Itens Diversos par… | R$ 4.320,72 | 19/12/2026 | 43 |
| 2025010533 | UERJ | STERI-GRAU PRODUTOS HOSPITALARES LTDA - ME | A aquisição, por licitação (pregão eletrônico), de Itens Diversos par… | R$ 42.840,00 | 19/12/2026 | 43 |
| 2025010535 | UERJ | ZAMMI INSTRUMENTAL LTDA | A aquisição, por licitação (pregão eletrônico), de Itens Diversos par… | R$ 17.544,00 | 19/12/2026 | 43 |
| 2025010540 | UERJ | PER PRIMA COMÉRCIO E REPRESENTAÇÕES LTDA | a aquisição de para material para o tratamento cirúrgico de fraturas … | R$ 157.986,00 | 19/12/2026 | 43 |
| 2026004297 | UERJ | ASTRAZENECA DO BRASIL LTDA. | AQUISIÇÃO DE MEDICAMENTO PARA O HURHC. | R$ 3.494,40 | 19/12/2026 | 43 |
| 2026007044 | UERJ | FUNDAÇÃO GETULIO VARGAS | Custeio de curso de capacitação  MBA em Gestão de Saúde | R$ 33.470,00 | 19/12/2026 | 43 |
| 2024003206 | CECIERJ | ASSOCIAÇÃO PARANAENSE DE CULTURA | O presente Termo de Referência tem por objetivo a contratação do serv… | R$ 38.593,80 | 20/12/2026 | 44 |
| 2026007836 | UERJ | DANJAC DISTRIBUIDORA LTDA. | AQUISIÇÃO DE SMART TV`S E SUPORTES DE FIXAÇÃO | R$ 684,00 | 20/12/2026 | 44 |
| 2026007837 | UERJ | ZURIEL DE IGUAÇU COMERCIO E REPRESENTAÇÃO LT… | AQUISIÇÃO DE SMART TV`S E SUPORTES DE FIXAÇÃO | R$ 28.687,00 | 20/12/2026 | 44 |
| 2026005196 | UERJ | LICITAPRO CONSULTORIA EM LICITACOES E GESTAO… | Contratação de pessoa jurídica para o fornecimento de 10 (dez) licenç… | R$ 13.480,00 | 21/12/2026 | 45 |
| 2025006834 | UENF | LIFE TECHNOLOGIES BRASIL COMÉRCIO E INDÚSTRI… | Manutenção Preventiva e Corretiva no equipamento Analisador Genético … | R$ 98.159,30 | 22/12/2026 | 46 |
| 2025010551 | UERJ | THASMED PRODUTOS MEDICOS LTDA | A aquisição, por licitação (pregão eletrônico), de Faca para o Hospit… | R$ 32.499,87 | 22/12/2026 | 46 |
| 2025010582 | UERJ | ÁPICE CONFECÇÕES LTDA | Aquisição por dispensa de licitação, de Lâminas e faixas para o Hospi… | R$ 6.486,00 | 22/12/2026 | 46 |
| 2025010659 | UERJ | BOSTON SCIENTIFIC DO BRASIL LTDA. | A aquisição, por licitação (pregão eletrônico), de de Fios Guia e Ext… | R$ 16.800,00 | 23/12/2026 | 47 |
| 2025010660 | UERJ | E TAMUSSINO & CIA LTDA | A aquisição, por licitação (pregão eletrônico), de de Fios Guia e Ext… | R$ 5.303,21 | 23/12/2026 | 47 |
| 2025010661 | UERJ | MESSER MED PRODUTOS MEDICOS E HOSPITALARES L… | A aquisição, por licitação (pregão eletrônico), de de Fios Guia e Ext… | R$ 32.190,00 | 23/12/2026 | 47 |
| 2025010662 | UERJ | SMT IMPORTADORA E DISTRIBUIDORA DE PRODUTOS … | A aquisição, por licitação (pregão eletrônico), de de Fios Guia e Ext… | R$ 70.453,00 | 23/12/2026 | 47 |
| 2025010664 | UERJ | VITORIA HOPITALAR LTDA | A aquisição, por licitação (pregão eletrônico), de de Fios Guia e Ext… | R$ 311.100,00 | 23/12/2026 | 47 |
| 2025010705 | SECTI | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada para confecção, fornecimento e a… | R$ 96.466,50 | 23/12/2026 | 47 |
| 2025010807 | UENF | ENGINEERING SIMULATION AND SCIENTIFIC SOFTWA… | Fornecimento de Software para a UENF. | R$ 263.257,05 | 23/12/2026 | 47 |
| 2025010849 | UERJ | ALKO DO BRASIL INDUSTRIA E COMERCIO LTDA | Aquisição urgente de seringas para bomba injetora, extensor e conecto… | R$ 107.865,00 | 23/12/2026 | 47 |
| 2026008971 | FAPERJ | MOVIMENTO JUNTA RIO PELA SAUDE - MJRS | Participação institucional da Fundação Carlos Chagas Filho de Amparo … | R$ 2.300.000,00 | 23/12/2026 (PNCP) | 47 |
| 2026001938 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto Laboratório de Histocompatibilidade - HLA | R$ 9.737.129,28 | 25/12/2026 (PNCP) | 49 |
| 2026009024 | UERJ | ASSOCIAÇÃO CULTURAL BANTU BRASIL | Contratação de empresa especializada para a prestação de serviços téc… | R$ 47.500,00 | 25/12/2026 | 49 |
| 2025010683 | UERJ | MCA MULTIPLOS SERVICOS LTDA | A contratação de empresa especializada na prestação de serviços de Br… | R$ 1.577.730,88 | 26/12/2026 (PNCP) | 50 |
| 2026004598 | UERJ | PLASVIVO DISTRIBUIDORA DE ARTIGOS EM GERAL L… | Aquisição de produto químico antisséptico, por Compra Direta Emergenc… | R$ 13.464,00 | 26/12/2026 | 50 |
| 2026009237 | UERJ | ACANTO SOLUÇÕES INTEGRADAS DE BENS E SERVIÇO… | Aquisição de equipamentos de áudio e equipamentos de apoio pedagógico… | R$ 1.643,00 | 28/12/2026 | 52 |
| 2025010581 | UENF | REDE NACIONAL DE ENSINO E PESQUISA - RNP | Contratação de Organização Social para a emissão e o registro de dipl… | R$ 40.400,00 | 29/12/2026 | 53 |
| 2025009642 | UERJ | VANGUARDA INFORMATICA LTDA | Aquisição de 56 (cinquenta e seis) tablets,modelo Samsung Galaxy Tab … | R$ 70.775,60 | 30/12/2026 | 54 |
| 2025009643 | UERJ | TOP MIX COMÉRCIO E SERVIÇOS LTDA | Aquisição de 56 (cinquenta e seis) tablets,modelo Samsung Galaxy Tab … | R$ 100.000,00 | 30/12/2026 | 54 |
| 2026006118 | UENF | VOLKSWAGEN DO BRASIL INDUSTRIA DE VEICULOS A… | Aquisição de Picapes | R$ 485.000,00 | 30/12/2026 | 54 |
| 2021005239 | UERJ | HEWLETT-PACKARD BRASIL LTDA. | Serviço de Suporte Técnico para Equipamentos da HPE. | R$ 103.557,84 | 31/12/2026 | 55 |
| 2026001150 | UENF | ASSOCIACAO BRASILEIRA DE RECURSOS HUMANOS - … | Contratação da Associação Brasileira de Recursos Humanos (ABRH-RJ), p… | R$ 7.980,00 | 31/12/2026 | 55 |
| 2026001245 | UENF | ASSOCIAÇÃO BRASILEIRA DOS REITORES DAS UNIVE… | Pagamento de Anuidade da ABRUEM. | R$ 22.000,00 | 31/12/2026 | 55 |
| 2026001391 | UENF | ASSOCIACAO DE ASSESSORIAS DE INSTITUCOES DE … | Pagamento de anuidade da FAUBAI - Associação de Assessorias de Instit… | R$ 3.037,92 | 31/12/2026 | 55 |
| 2026006975 | UENF | FORUM NACIONAL DE PRO-REITORES DE PESQUISA E… | Pagamento da anuidade institucional da Universidade Estadual do Norte… | R$ 1.500,00 | 31/12/2026 | 55 |
| 2026008222 | UERJ | BRUKER DO BRASIL COMERCIO E REPRESENTACAO DE… | Aquisição de peças para os equipamentos GEO-D2 PHASER (Número de séri… | R$ 17.348,15 | 31/12/2026 | 55 |
| 2026002999 | UERJ | EMPRESA JUNIOR DE PSICOLOGIA DA UERJ | Empenhamento para pagamento da Empresa Júnior de Psicologia da UERJ -… | R$ 7.000,00 | 01/01/2027 | 56 |
| 2026009274 | UERJ | ÁGORA PRODUÇÃO AUDIOVISUAL E ARTÍSTICA LTDA | Trata-se de contratação de serviços especializados de produção execut… | R$ 8.400,00 | 02/01/2027 | 57 |
| 2026009294 | UERJ | PESO CERTO EQUIPAMENTOS GASTRONOMICOS LTDA | Aquisição de ar condicionados | R$ 10.136,00 | 02/01/2027 | 57 |
| 2024010270 | UENF | TENNESSINE INSTRUMENTAÇÃO ANALÍTICA COMÉRCIO… | Serviço de Manutenção de Raio-X de Bancada | R$ 214.000,00 | 03/01/2027 | 58 |
| 2026001343 | UERJ | AVANTE JF COMERCIAL LTDA | Aquisição de 1 (uma) unidade de Impressora Plotter de Grande Formato,… | R$ 4.480,00 | 03/01/2027 | 58 |
| 2026004648 | UERJ | BR LIFE, LLC | Aquisição de Reagentes | R$ 2.569.192,97 | 03/01/2027 (PNCP) | 58 |
| 2026004912 | UERJ | 55.096.997 BHEATRIZ CAMPOS DE OLIVEIRA | AQUISIÇÃO DE MULTIFUCIONAL | R$ 14.511,73 | 03/01/2027 | 58 |
| 2026009327 | UERJ | JPD ARTES EM MADEIRA LTDA | Serviços de personalização gráfica destinados ao Projeto ``Meninas pe… | R$ 1.405,00 | 03/01/2027 | 58 |
| 2026009330 | UERJ | ONYX CAXIENSE COMÉRCIO E SERVIÇOS LTDA | Serviços de personalização gráfica destinados ao Projeto ``Meninas pe… | R$ 2.572,50 | 03/01/2027 | 58 |
| 2026009331 | UERJ | TERRA COMUNICACAO VISUAL E SERVICOS LTDA | Serviços de personalização gráfica destinados ao Projeto ``Meninas pe… | R$ 12.250,00 | 03/01/2027 | 58 |
| 2026009335 | UERJ | GPS REPRESENTAÇOES COMERCIO E SERVIÇOS LTDA | Trata-se de contratação objetivando a aquisição de equipamentos de cl… | R$ 3.850,00 | 04/01/2027 | 59 |
| 2026009337 | UERJ | TOP MIX COMÉRCIO E SERVIÇOS LTDA | Trata-se de contratação objetivando a aquisição de equipamentos de cl… | R$ 16.900,00 | 04/01/2027 | 59 |
| 2026009338 | UERJ | ELOAR SERVIÇOS DE COMUNICAÇÃO E MARKETING LT… | Contratação de serviço para aquisição de cartilhas educativas com, a … | R$ 7.100,10 | 04/01/2027 | 59 |
| 2026009380 | UERJ | JUAR BRINDES LTDA | Aquisição de materiais de apoio, divulgação e suporte às atividades p… | R$ 5.600,00 | 04/01/2027 | 59 |
| 2026009381 | UERJ | 35.006.828 VIVIANE DE OLIVEIRA MOISES | Aquisição de materiais de apoio, divulgação e suporte às atividades p… | R$ 1.148,90 | 04/01/2027 | 59 |
| 2022008206 | UERJ | SERVIOESTE SOLUÇÕES AMBIENTAIS LTDA | Contratação de Serviço de Coleta, Transporte, Tratamento destinação e… | R$ 80.856,00 | 05/01/2027 | 60 |
| 2025010313 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | AQUISIÇÃO DE MEDICAMENTOS PARA O HURHC. | R$ 16.253,10 | 05/01/2027 | 60 |
| 2025010317 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | AQUISIÇÃO DE MEDICAMENTOS PARA O HURHC. | R$ 82.797,80 | 05/01/2027 | 60 |
| 2025010320 | UERJ | COMERCIAL CIRURGICA RIOCLARENSE LTDA | AQUISIÇÃO DE MEDICAMENTOS PARA O HURHC. | R$ 4.037,50 | 05/01/2027 | 60 |
| 2025010321 | UERJ | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | AQUISIÇÃO DE MEDICAMENTOS PARA O HURHC. | R$ 29.991,90 | 05/01/2027 | 60 |
| 2025010397 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos, por Compra Direta Emergencial, para o Hosp… | R$ 1.506,00 | 05/01/2027 | 60 |
| 2026003504 | UERJ | SUPER ÁGUA PURIFICADORES E COMÉRCIO LTDA | Fornecimento, entrega e instalação de purificadores de água, a fim de… | R$ 24.560,00 | 06/01/2027 | 61 |
| 2026008419 | UERJ | AGI BELEFRAN CONFECÇOES LTDA | Aquisição de materiais personalizados com identidade visual do Projet… | R$ 278,00 | 06/01/2027 | 61 |
| 2026008421 | UERJ | BRUNO SIEGBERT KUTTNER | Aquisição de materiais personalizados com identidade visual do Projet… | R$ 491,10 | 06/01/2027 | 61 |
| 2026008423 | UERJ | ELOAR SERVIÇOS DE COMUNICAÇÃO E MARKETING LT… | Aquisição de materiais personalizados com identidade visual do Projet… | R$ 2.238,00 | 06/01/2027 | 61 |
| 2025010063 | UERJ | EXCELENCIA DISTRIBUIDORA DE PRODUTOS E SERVI… | AQUISIÇÃO DE CATETERES ESPECIAIS E ETC PARA O HURHC. | R$ 3.989,59 | 08/01/2027 | 63 |
| 2025010064 | UERJ | CEI COMERCIO EXPORTACAO E IMPORTACAO DE MATE… | AQUISIÇÃO DE CATETERES ESPECIAIS E ETC PARA O HURHC. | R$ 2.195,20 | 08/01/2027 | 63 |
| 2025010065 | UERJ | PROHOSP DISTRIBUIDORA DE MEDICAMENTOS LTDA | AQUISIÇÃO DE CATETERES ESPECIAIS E ETC PARA O HURHC. | R$ 8.280,00 | 08/01/2027 | 63 |
| 2025010066 | UERJ | NEO MEDICAL COMERCIAL HOSPITALAR LTDA. | AQUISIÇÃO DE CATETERES ESPECIAIS E ETC PARA O HURHC. | R$ 4.400,00 | 08/01/2027 | 63 |
| 2024009940 | CECIERJ | GPS ALIMENTACAO E SERVICOS LTDA | A presente contratação tem por objetivo aquisição de pó de café, açúc… | R$ 34.152,00 | 09/01/2027 | 64 |
| 2025000057 | CECIERJ | PURIN COMERCIO E DISTRIBUICAO LTDA | O presente Termo de Referência tem por objetivo a contratação de empr… | R$ 25.833,60 | 09/01/2027 | 64 |
| 2025010620 | CECIERJ | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | Contratação de empresa especializada na prestação de serviços de Agen… | R$ 916.800,00 | 09/01/2027 (PNCP) | 64 |
| 2026005412 | UERJ | INSTITUTO BRASILEIRO DE DIREITO ADMINISTRATI… | INSCRIÇÃO CAPACITAÇÃO INSTITUCIONAL | R$ 2.250,00 | 09/01/2027 | 64 |
| 2026008619 | UERJ | DEMAFE SOLUCOES INTEGRADAS E GOVERNAMENTAIS … | Aquisição de mobiliário para implementação de salas de estudos em gru… | R$ 27.369,82 | 11/01/2027 | 66 |
| 2026008621 | UERJ | MR COMERCIO DE PRODUTOS ALIMENTICIOS E FERRA… | Aquisição de mobiliário para implementação de salas de estudos em gru… | R$ 764,00 | 11/01/2027 | 66 |
| 2026001775 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto Atenção a Saúde do Homem | R$ 11.675.798,00 | 12/01/2027 (PNCP) | 67 |
| 2026001729 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto CINC | R$ 1.568.160,00 | 13/01/2027 (PNCP) | 68 |
| 2026005674 | UERJ | GOLDEM DISTRIBUIDORA E REPRESENTAÇÃO LTDA | Aquisição de 1 (um) micro-ondas de 30 litros e de 1 (um) frigobar com… | R$ 1.944,00 | 16/01/2027 | 71 |
| 2026001871 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto Oncologia - Subprojeto 1 | R$ 2.624.248,00 | 17/01/2027 (PNCP) | 72 |
| 2026003031 | UERJ | ECONOMUS CONSULTORIA JÚNIOR | Empenhamento para pagamento da empresa júnior da Faculdade de Ciência… | R$ 7.000,00 | 17/01/2027 | 72 |
| 2026003786 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | NDC 2026dc00005 - Projeto FIA / NACA - Portaria Conjunta 40 de 05/03/… | R$ 9.096.270,29 | 18/01/2027 (PNCP) | 73 |
| 2026008974 | UERJ | GPS REPRESENTAÇOES COMERCIO E SERVIÇOS LTDA | Aquisição de Condicionador de Ar, tipo Split, de 24.000 BTUs para a F… | R$ 4.950,00 | 21/01/2027 | 76 |
| 2025010698 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de insumos médico-hospitalares. | R$ 21.140,00 | 22/01/2027 | 77 |
| 2025010699 | UERJ | FIRST LINE COMÉRCIO DE MATERIAL HOSPITALAR L… | Aquisição de insumos médico-hospitalares. | R$ 2.940,00 | 22/01/2027 | 77 |
| 2025010703 | UERJ | M.N.P. CUSTÓDIO COMÉRCIO DE PRODUTOS HOSPITA… | Aquisição de insumos médico-hospitalares. | R$ 8.069,40 | 22/01/2027 | 77 |
| 2023000345 | CECIERJ | SCALLE CONSTRUCOES, REFORMAS E INSTALACOES L… | O presente Termo de Referência relativo ao Processo Administrativo n … | R$ 28.061.749,20 | 25/01/2027 | 80 |
| 2023000398 | CECIERJ | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | A presente Ata tem por objeto o Registro de Preços para eventual cont… | R$ 1.199.999,64 | 26/01/2027 | 81 |
| 2026002362 | UERJ | MERCK S/A (FILIAL) | Ácido sulfúrico PA, Éter etílico PA, Acetato de etila PA, Cloreto de … | R$ 2.432,84 | 26/01/2027 | 81 |
| 2026000243 | SECTI | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Contratação de empresa especializada na prestação de serviços de impl… | R$ 922.367,04 | 27/01/2027 (PNCP) | 82 |
| 2026004149 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Resolução Conjunta SES/UERJ nº 1514 de 04/05/2026 - Projeto Consórcio… | R$ 221.263,07 | 28/01/2027 | 83 |
| 2026006971 | UERJ | ORBITAL PRODUTOS PARA LABORATORIOS LTDA | AQUISIÇÃO DE PRODUTOS QUÍMICOS | R$ 16.258,12 | 28/01/2027 | 83 |
| 2026006974 | UERJ | MERCK S/A (FILIAL) | AQUISIÇÃO DE PRODUTOS QUÍMICOS | R$ 102,00 | 28/01/2027 | 83 |
| 2026007804 | UERJ | ZURIEL DE IGUAÇU COMERCIO E REPRESENTAÇÃO LT… | Aquisição de equipamentos de informática, compreendendo notebook, imp… | R$ 7.186,70 | 28/01/2027 | 83 |
| 2026007806 | UERJ | 37.568.044 THAIS HAILA EUFRASIO GONCALVES SE… | Aquisição de equipamentos de informática, compreendendo notebook, imp… | R$ 5.641,00 | 28/01/2027 | 83 |
| 2026001866 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto Cirurgia de Cabeça e Pescoço | R$ 3.136.360,00 | 30/01/2027 (PNCP) | 85 |
| 2026001872 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto NIPNDIM | R$ 1.892.924,00 | 30/01/2027 (PNCP) | 85 |
| 2026005147 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | PAGAMENTO DE PESSOAL | R$ 2.776.205,03 | 31/01/2027 (PNCP) | 86 |
| 2024004219 | CECIERJ | FOCO SERVICOS ESPECIALIZADOS LTDA | O presente Termo de Referência tem por objeto a Contratação de Pessoa… | R$ 17.330.379,74 | 31/01/2027 | 86 |
| 2021005625 | UERJ | GL ELETRO-ELETRONICOS LTDA | CONTRATAÇÃO DE MANUTENÇÃO PREVENTIVA E CORRETIVA DE EQUIPAMENTO ELETR… | R$ 38.160,00 | 01/02/2027 | 87 |
| 2025010370 | UERJ | GPS REPRESENTAÇOES COMERCIO E SERVIÇOS LTDA | Aquisição de 10 unidades balde a chute para a Unidade de Cirurgia Amb… | R$ 6.250,00 | 03/02/2027 | 89 |
| 2026000349 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Processamento de despesa - Prestadores de serviço e estagiários da UE… | R$ 54.500.000,00 | 03/02/2027 (PNCP) | 89 |
| 2026000474 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Resolução Conjunta SEDSODH/UERJ nº 201 de 16/01/2026 - Combate ao LGB… | R$ 10.000.000,00 | 03/02/2027 (PNCP) | 89 |
| 2026001376 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Resolução Conjunta SEIJES/UERJ nº 10 de 01/01/2026 - Projeto QUALIdade | R$ 1.000.000,00 | 03/02/2027 (PNCP) | 89 |
| 2020005671 | UERJ | PRO SIGMA SERVICOS DE PROTECAO RADIOLOGICA E… | CONTRATAÇÃO DE EMPRESA PARA PRESTAÇÃO DE SERVIÇOS DE FÍSICA MÉDICA (C… | R$ 1.860.000,00 | 04/02/2027 | 90 |
| 2026006043 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto de Tratamento Hepático | R$ 874.830,00 | 04/02/2027 (PNCP) | 90 |
| 2026009227 | UERJ | 37.568.044 THAIS HAILA EUFRASIO GONCALVES SE… | Aquisição de 05 (cinco) tendas gazebo articuladas, modelo retrátil, c… | R$ 3.075,00 | 04/02/2027 | 90 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000564 | UERJ | HEXAGONO QUIMICA E EQUIPAMENTOS PARA LABORAT… | Aquisição de produtos químicos, visando a realização das atividades p… | R$ 210,00 | 05/02/2027 | 91 |
| 2026000566 | UERJ | LABSYNTH PRODUTOS PARA LABORATORIOS LTDA | Aquisição de produtos químicos, visando a realização das atividades p… | R$ 767,80 | 05/02/2027 | 91 |
| 2026001768 | UERJ | B2R SOLUCOES E VENDAS LTDA | Aquisição de televisões. | R$ 2.440,00 | 07/02/2027 | 93 |
| 2026002525 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | OBSERVAÇÃO DA REQUISIÇÃORESOLUÇÃO CONJUNTA SEDSODH/UERJ Nº 218/2026 D… | R$ 450.000,00 | 07/02/2027 | 93 |
| 2026001755 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto Assistência Integral Multidisciplinar - AIM | R$ 14.000.000,00 | 09/02/2027 (PNCP) | 95 |
| 2026002411 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Resolução Conjunta 1458 do Projeto Qualificação de Gestores da SES | R$ 383.000,00 | 09/02/2027 | 95 |
| 2026000638 | UERJ | IMEXPERTS DO BRASIL CONSULTORIA E GESTÃO DE … | Contratação de licença perpétua de software Teleform, bem como suport… | R$ 104.807,00 | 10/02/2027 | 96 |
| 2026006545 | UERJ | SM SERVICOS CONSULTIVOS E PROJETOS EMPRESARI… | Contratação de serviços de capacitação para o Hospital Universitário … | R$ 57.000,00 | 11/02/2027 | 97 |
| 2024001172 | UERJ | LABORPEC RIO COMERCIAL LTDA | Ração e substrato para acomodação. | R$ 43.398,00 | 12/02/2027 | 98 |
| 2025010309 | FAPERJ | GPBR PARTICIPACOES LTDA | Contratação da Empresa GPBR PARTICIPACOES LTDA., nome fantasia WELLHU… | R$ 162.756,00 | 12/02/2027 | 98 |
| 2026005485 | UENF | SIGNO CONSTRUÇÕES E SERVIÇOS LTDA | Contratação de empresa especializada em raspagem, calafetação, polime… | R$ 32.000,00 | 15/02/2027 | 101 |
| 2025000185 | UENF | SHIMADZU DO BRASIL COMERCIO LTDA | Manutenção Shimadzu CBB 2024 | R$ 1.192.007,41 | 17/02/2027 (PNCP) | 103 |
| 2024006488 | UERJ | MINHA BIBLIOTECA LTDA | CONTRATAÇÃO DE BASE DE DADOS | R$ 525.492,48 | 19/02/2027 (PNCP) | 105 |
| 2025000421 | UERJ | AUTO SUTURE DO BRASIL LTDA | Aquisição, por licitação (pregão eletrônico), de implante percutâneo … | R$ 344.000,00 | 20/02/2027 | 106 |
| 2026001141 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de Especulo M, através de empenhamento de SC da ARP 0088/20… | R$ 2.580,00 | 26/02/2027 | 112 |
| 2026001143 | UERJ | ORZIL CONSULTORIA E TREINAMENTO LTDA EPP | Contratação de serviços de capacitação para o Hospital Universitário … | R$ 40.439,60 | 26/02/2027 | 112 |
| 2025000699 | SECTI | GRANA 298 DISTRIBUIDORA DE ALIMENTOS LTDA EPP | Fornecimento Anual de 480 Garrafões de 20 litros de Água Mineral Natu… | R$ 6.492,30 | 27/02/2027 | 113 |
| 2023000368 | CECIERJ | KRATUS TECNOLOGIA COMERCIO E SERVIÇOS LTDA | Prestação de Serviços Contínuos de Limpeza e Higienização. | R$ 35.363.302,18 | 28/02/2027 | 114 |
| 2026001889 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto Oncologia - Subprojetos 3 e 4 | R$ 1.706.100,00 | 28/02/2027 (PNCP) | 114 |
| 2026003362 | UERJ | SAMANTA CHU 22144171840 | CONTRATAÇÃO DE TREINAMENTO P/ PRIMEIROS SOCORROS EM TRABALHOS DE CAMP… | R$ 14.580,00 | 28/02/2027 | 114 |
| 2026000201 | UERJ | CARL ZEISS DO BRASIL LTDA | Contratação por inexigibilidade de empresa especializada para forneci… | R$ 40.609,64 | 02/03/2027 | 116 |
| 2025010786 | UERJ | ARDO DO BRASIL DISTRIBUIDORA DE PECAS E SERV… | Fornecimento e entrega de telhas e materiais correlatos às suas insta… | R$ 16.160,50 | 04/03/2027 | 118 |
| 2025010787 | UERJ | UNIMAC UNIVERSO DAS MAQUINAS LTDA | Fornecimento e entrega de telhas e materiais correlatos às suas insta… | R$ 14.380,00 | 04/03/2027 | 118 |
| 2025010788 | UERJ | VIXNU COMERCIO LTDA-EPP | Fornecimento e entrega de telhas e materiais correlatos às suas insta… | R$ 66.896,50 | 04/03/2027 | 118 |
| 2025010655 | UERJ | ALTERNATIVA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição por licitação (pregão eletrônico), de materiais hospitalare… | R$ 22.968,00 | 05/03/2027 | 119 |
| 2025010656 | UERJ | ECOMED COMERCIO DE PRODUTOS MEDICOS LTDA | Aquisição por licitação (pregão eletrônico), de materiais hospitalare… | R$ 47.599,20 | 05/03/2027 | 119 |
| 2025010819 | UERJ | COMERCIAL CIRURGICA RIOCLARENSE LTDA | a aquisição, por licitação (pregão eletrônico), de Compressas para o … | R$ 942.760,00 | 05/03/2027 (PNCP) | 119 |
| 2026000567 | UERJ | RPM COMERCIO DE MATERIAL HOSPITALAR LTDA | A aquisição de material para cirurgias de artroplastia total de joelh… | R$ 1.500.000,00 | 05/03/2027 (PNCP) | 119 |
| 2026000726 | UERJ | PROCARE COMÉRCIO DE PRODUTOS HOSPITALARES LT… | A aquisição de Filtros para o Hospital Universitário Pedro Ernesto. | R$ 652.475,00 | 05/03/2027 (PNCP) | 119 |
| 2026000862 | UERJ | CARE SURGICAL COMERCIO DE MATERIAIS CIRURGIC… | Aquisição, por licitação (pregão eletrônico), de material para cirurg… | R$ 86.899,92 | 05/03/2027 | 119 |
| 2026000920 | UERJ | WM WORLD MEDICAL IMPORTACAO E EXPORTACAO LTDA | Aquisição, por licitação (pregão eletrônico), de cânula rosqueada, eq… | R$ 107.320,20 | 05/03/2027 | 119 |
| 2026000247 | UERJ | SMITH&NEPHEW COMERCIO DE PRODUTOS MEDICOS LT… | Aquisição, por licitação (pregão eletrônico), de agulha de sutura com… | R$ 217.320,00 | 06/03/2027 | 120 |
| 2025011009 | UERJ | CATHLAB COMERCIO DE PRODUTOS MEDICOS LTDA | A aquisição de Fibra Laser para o Hospital Universitário Pedro Ernest… | R$ 351.600,00 | 06/03/2027 | 120 |
| 2026000053 | UERJ | FORTE SINAL EQUIPAMENTOS-EIRELI-EPP | A aquisição, por licitação (pregão eletrônico), de Toucas e sapatilha… | R$ 48.440,00 | 06/03/2027 | 120 |
| 2026000129 | UERJ | PANMEDICA NEGÓCIOS HOSPITALARES LTDA. | Aquisição de Cobertura para o Hospital Universitário Pedro Ernesto. | R$ 2.988,00 | 06/03/2027 | 120 |
| 2026000486 | UERJ | HOMACC COMERCIO DE MATERIAL MEDICO HOSPITALA… | Aquisição, por licitação (pregão eletrônico), de stent farmacológico … | R$ 688.995,00 | 06/03/2027 (PNCP) | 120 |
| 2026001096 | UERJ | ORZIL CONSULTORIA E TREINAMENTO LTDA EPP | Contratação de serviços de capacitação para o Hospital Universitário … | R$ 3.547,00 | 06/03/2027 | 120 |
| 2026001432 | UERJ | INJEX INDUSTRIAS CIRURGICAS LTDA | Aquisição de seringas via empenhamento de ARP 0052/2025/294200-99 | R$ 13.430,00 | 06/03/2027 | 120 |
| 2026001477 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de Seringas via empenhamento de ARP 0224/2025/296100-01 | R$ 2.420,00 | 06/03/2027 | 120 |
| 2022001421 | CECIERJ | CLARO S/A (FILIAL) | Contratação de serviço de acesso à internet e à rede do governo. | R$ 40.460.972,40 | 09/03/2027 | 123 |
| 2026000077 | UERJ | TECMEDIC COMERCIO DE PRODUTOS MEDICOS LTDA | Aquisição, por licitação (pregão eletrônico), de oclusores para fecha… | R$ 44.190,00 | 09/03/2027 | 123 |
| 2026000078 | UERJ | CATHLAB COMERCIO DE PRODUTOS MEDICOS LTDA | Aquisição, por licitação (pregão eletrônico), de oclusores para fecha… | R$ 185.500,00 | 09/03/2027 | 123 |
| 2026000079 | UERJ | VITORIA HOPITALAR LTDA | Aquisição, por licitação (pregão eletrônico), de oclusores para fecha… | R$ 722.346,25 | 09/03/2027 (PNCP) | 123 |
| 2026000135 | UERJ | MF EQUIPAMENTOS MEDICOS LTDA EPP | A aquisição de Equipamento e Insumos de Polissonografia para o Hospit… | R$ 42.633,00 | 09/03/2027 | 123 |
| 2026000731 | UERJ | JRG DISTRIBUIDORA DE MEDICAMENTOS HOSPITALAR… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 9.241,92 | 09/03/2027 | 123 |
| 2026000732 | UERJ | ONCO PROD DISTRIBUIDORA DE PRODUTOS HOSPITAL… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 99.750,00 | 09/03/2027 | 123 |
| 2026000750 | UERJ | BIOKARDIÁ COMERCIAL DE PRODUTOS HOSPITALARES… | A aquisição, por licitação (pregão eletrônico), de endoprótese, agent… | R$ 39.437,50 | 09/03/2027 | 123 |
| 2026000752 | UERJ | FAYNE HOSPITALAR DISTRIBUIDORA DE MEDICAMENT… | A aquisição, por licitação (pregão eletrônico), de endoprótese, agent… | R$ 8.779,65 | 09/03/2027 | 123 |
| 2026001522 | UERJ | MEDICARE DISTRIBUIDORA DE PRODUTOS FARMACEUT… | Cetoprofeno CAP 50 mg. | R$ 1.350,00 | 09/03/2027 | 123 |
| 2026001541 | UERJ | ASLI COMERCIAL LTDA | Aquisição de sistema arterial via empenhamento de ARP 0090/2025/29420… | R$ 1.240,00 | 09/03/2027 | 123 |
| 2025000876 | UERJ | GRINVERT MANUTENÇÃO CONSERVAÇÃO MODERNIZAÇÃO… | Contratação da prestação de serviços continuados de manutenção preven… | R$ 313.000,00 | 10/03/2027 | 124 |
| 2025008927 | FAPERJ | 2R DATATEL TELEINFORMÁTICA LTDA | Suprir as necessidades da FAPERJ, com aquisição perpétua de solução d… | R$ 307.843,75 | 10/03/2027 | 124 |
| 2025008930 | FAPERJ | 2R DATATEL TELEINFORMÁTICA LTDA | A contratação objeto deste Documento de Formalização de Demanda visa … | R$ 2.400,00 | 10/03/2027 | 124 |
| 2026000255 | UERJ | ESPECIFARMA COMERCIO DE MEDICAMENTOS E PRODU… | A aquisição de fios cirúrgicos para o Hospital Universitário Pedro Er… | R$ 1.095,12 | 10/03/2027 | 124 |
| 2026000256 | UERJ | HEALTH CARE COMÉRCIO DE MATERIAIS MEDICO CIR… | A aquisição de fios cirúrgicos para o Hospital Universitário Pedro Er… | R$ 73.814,40 | 10/03/2027 | 124 |
| 2026000257 | UERJ | RJD HOSPITALAR EIRELI | A aquisição de fios cirúrgicos para o Hospital Universitário Pedro Er… | R$ 24.998,40 | 10/03/2027 | 124 |
| 2026000555 | UERJ | SOARES & MARINS.PAES LTDA | A aquisição, por licitação (pregão eletrônico), de Seringas para o Ho… | R$ 65.575,00 | 10/03/2027 | 124 |
| 2026001157 | UERJ | WM WORLD MEDICAL IMPORTACAO E EXPORTACAO LTDA | A aquisição de material para cirurgias de artroscopia de ombro para o… | R$ 537.500,00 | 11/03/2027 (PNCP) | 125 |
| 2026001688 | UERJ | ONMED DISTRIBUIDORA DE MEDICAMENTOS LTDA | Tretinoina 10 mg cap | R$ 51.870,00 | 11/03/2027 | 125 |
| 2026001690 | UERJ | JRG DISTRIBUIDORA DE MEDICAMENTOS HOSPITALAR… | Hidroxiureia 500 mg cap. | R$ 25.038,00 | 11/03/2027 | 125 |
| 2026001701 | UERJ | TRES PHARMA DISTRIBUIDORA E SERVIÇOS LTDA | Irinotecano, Cloridrato 20 mg / mL sol inj fa 5 mL | R$ 10.872,00 | 11/03/2027 | 125 |
| 2025010766 | UERJ | PROMEFARMA MEDICAMENTOS E PRODUTOS HOSPITALA… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 4.584,00 | 12/03/2027 | 126 |
| 2026000074 | UERJ | E TAMUSSINO & CIA LTDA | Aquisição, por licitação (pregão eletrônico), de endoproteses toracoa… | R$ 444.000,00 | 12/03/2027 | 126 |
| 2026000075 | UERJ | GF LABOR COMERCIO E REPRESENTAÇÃO LTDA | Aquisição, por licitação (pregão eletrônico), de endoproteses toracoa… | R$ 724.807,02 | 12/03/2027 (PNCP) | 126 |
| 2026001014 | UERJ | BIOSINTESE HOSPITALAR LTDA | Aquisição, por licitação (pregão eletrônico), de placas, parafusos, f… | R$ 32.799,99 | 12/03/2027 | 126 |
| 2026001015 | UERJ | WM WORLD MEDICAL IMPORTACAO E EXPORTACAO LTDA | Aquisição, por licitação (pregão eletrônico), de placas, parafusos, f… | R$ 162.810,00 | 12/03/2027 | 126 |
| 2026001116 | UERJ | ATLASMED COMERCIO E IMPORTACAO DE PRODUTOS M… | Aquisição, por licitação (pregão eletrônico), de Componentes de próte… | R$ 690.000,00 | 12/03/2027 (PNCP) | 126 |
| 2026001592 | UERJ | ANTIBIOTICOS DO BRASIL LTDA (FILIAL) | Aquisição de medicamento (Meropenem 500 mg). | R$ 38.964,00 | 12/03/2027 | 126 |
| 2026001698 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Escopolamina, Butilbrometo CP 10 mg. | R$ 2.772,00 | 12/03/2027 | 126 |
| 2026001718 | UERJ | NOVA RIO SERVIÇOS GERAIS LTDA | Trata-se do objeto deste contrato o serviço de higienização hospitala… | R$ 30.500.818,32 | 12/03/2027 (PNCP) | 126 |
| 2026001748 | UERJ | AMX COMERCIO E REPRESENTAÇÕES EIRELI | Trata-se do objeto deste contrato o serviço de higienização hospitala… | R$ 5.503.883,88 | 12/03/2027 (PNCP) | 126 |
| 2026001759 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto Cardiovascular - Hemodinâmica | R$ 10.899.730,00 | 12/03/2027 (PNCP) | 126 |
| 2026001778 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto Cardiovascular - Cardiopatias Congênitas | R$ 4.113.419,20 | 12/03/2027 (PNCP) | 126 |
| 2026001789 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto Radiologia Oral e PNE | R$ 1.998.440,00 | 12/03/2027 (PNCP) | 126 |
| 2026001708 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Clonazepam 2,5 mg/ml Sol Oral FR 20 ml. | R$ 1.863,00 | 13/03/2027 | 127 |
| 2026001743 | UERJ | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | OMEPRAZOL SODICO 40 MG PO SOL INJ FA. | R$ 56.720,00 | 13/03/2027 | 127 |
| 2026001746 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Acido Folico CP 5 mg. | R$ 245,00 | 13/03/2027 | 127 |
| 2026001751 | UERJ | DISTRIBUIÇÃO DE MEDICAMENTOS PAMED LTDA | Ceftazidima 2000 mg+Avibactam Sód. 500 mg Pó Sol. Inj. FA | R$ 121.708,80 | 13/03/2027 | 127 |
| 2026001767 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto de Manutenção da Capacidade de Assistência ao Paciente | R$ 17.689.560,00 | 13/03/2027 (PNCP) | 127 |
| 2026001798 | UERJ | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Ocitocina 5 UI / ml Sol. Inj. Amp 1 mlsol inj fa. | R$ 10.080,00 | 13/03/2027 | 127 |
| 2026001817 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto Dor Crônica | R$ 1.603.879,20 | 13/03/2027 (PNCP) | 127 |
| 2026001833 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto Excelência em Oftalmologia | R$ 3.220.536,00 | 13/03/2027 (PNCP) | 127 |
| 2026001874 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto NIPAC | R$ 5.916.222,40 | 13/03/2027 (PNCP) | 127 |
| 2026000134 | UERJ | INSTITUTO NEGOCIOS PUBLICOS ESTUDOS E PESQUI… | Contratação de serviços de capacitação para o Hospital Universitário … | R$ 2.500,00 | 16/03/2027 | 130 |
| 2026000453 | UERJ | FRESENIUS KABI BRASIL LTDA (MATRIZ) | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 739.038,40 | 16/03/2027 (PNCP) | 130 |
| 2026000473 | UERJ | RPM COMERCIO DE MATERIAL HOSPITALAR LTDA | Aquisição, por adesão a ata de registro de preços, de cimentos ortopé… | R$ 66.707,00 | 16/03/2027 | 130 |
| 2026000655 | UERJ | MOGAMI IMPORTAÇÃO E EXPORTAÇÃO LTDA | Aquisição, por licitação (pregão eletrônico), de Itens Diversos para … | R$ 195.270,00 | 16/03/2027 | 130 |
| 2026000656 | UERJ | BW MEDICAL PRODUTOS HOSPITALARES LTDA | Aquisição, por licitação (pregão eletrônico), de Itens Diversos para … | R$ 103.397,40 | 16/03/2027 | 130 |
| 2026000657 | UERJ | MEDICAL SUTURE COMERCIO DE MATERIAL HOSPITAL… | Aquisição, por licitação (pregão eletrônico), de Itens Diversos para … | R$ 3.499,92 | 16/03/2027 | 130 |
| 2026000678 | UERJ | BIOMEDICAL PRODUTOS CIENTIFICOS MEDICOS E HO… | Aquisição de Cateter para o Hospital Universitário Pedro Ernesto. | R$ 72.175,72 | 16/03/2027 | 130 |
| 2026000679 | UERJ | BY MEDICAL LTDA | Aquisição de Cateter para o Hospital Universitário Pedro Ernesto. | R$ 4.300,00 | 16/03/2027 | 130 |
| 2026000680 | UERJ | QUALITY LIFE COMERCIO HOSPITALAR LTDA - ME | Aquisição de Cateter para o Hospital Universitário Pedro Ernesto. | R$ 25.500,00 | 16/03/2027 | 130 |
| 2026001267 | UERJ | SM SERVICOS CONSULTIVOS E PROJETOS EMPRESARI… | Contratação de serviços de capacitação para o Hospital Universitário … | R$ 114.000,00 | 16/03/2027 | 130 |
| 2026001820 | UERJ | BAXTER HOSPITALAR LTDA | Glicose 5% (50 mg / ml) sol inj FR 500 ml. | R$ 30.000,00 | 16/03/2027 | 130 |
| 2026001841 | UERJ | PROMEFARMA MEDICAMENTOS E PRODUTOS HOSPITALA… | Mercaptopurina CP 50 mg. | R$ 6.780,00 | 16/03/2027 | 130 |
| 2025009152 | UERJ | SMITH&NEPHEW COMERCIO DE PRODUTOS MEDICOS LT… | Atender o solicitado no documento de formalização da demanda Doc. Sei… | R$ 279.355,18 | 17/03/2027 | 131 |
| 2025009916 | UERJ | LABORCLIN PRODUTOS PARA LABORATORIOS LTDA | Aquisição de Fitas testes, Soros, colorações e insumos diversos, para… | R$ 13.085,00 | 17/03/2027 | 131 |
| 2025009917 | UERJ | MASTERLAB COMERCIAL LTDA | Aquisição de Fitas testes, Soros, colorações e insumos diversos, para… | R$ 4.938,50 | 17/03/2027 | 131 |
| 2025009918 | UERJ | BIOSAVE DIAGNOSTICA LTDA | Aquisição de Fitas testes, Soros, colorações e insumos diversos, para… | R$ 18.746,32 | 17/03/2027 | 131 |
| 2025010658 | UERJ | BAXTER HOSPITALAR LTDA | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 72.807,00 | 17/03/2027 | 131 |
| 2025010884 | UERJ | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de medicamentos, por Compra Direta, para o Hospital Univers… | R$ 18.588,00 | 17/03/2027 | 131 |
| 2026000008 | UERJ | AUTO SUTURE DO BRASIL LTDA | A aquisição de endoprótese balão expansível e sistema defixação proxi… | R$ 178.295,25 | 17/03/2027 | 131 |
| 2026000009 | UERJ | 3T MEDICAL MATERIAL HOSPITALAR LTDA | A aquisição de endoprótese balão expansível e sistema defixação proxi… | R$ 72.000,00 | 17/03/2027 | 131 |
| 2026000251 | UERJ | ONCO PROD DISTRIBUIDORA DE PRODUTOS HOSPITAL… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 43.012,00 | 17/03/2027 | 131 |
| 2026000491 | UERJ | ASTRAZENECA DO BRASIL LTDA. | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 1.221.924,00 | 17/03/2027 (PNCP) | 131 |
| 2026001033 | UERJ | ORTHOFACOS PRODUTOS PARA ORTOPEDIA E OFTALMO… | Aquisição de medicamentos, por licitação (pregão eletrônico), para oH… | R$ 83.021,70 | 17/03/2027 | 131 |
| 2025010879 | UERJ | BIONEFRO COMÉRCIO DE MATERIAL HOSPITALAR LTD… | Aquisição urgente, por dispensa de licitação, de linhas e isolador pa… | R$ 110.006,15 | 18/03/2027 | 132 |
| 2025001056 | UERJ | MAC ID COMERCIO SERVICOS E TECNOLOGIA DA INF… | e contratação contínua de uma empresa especializada para fornecer, po… | R$ 612.204,00 | 18/03/2027 (PNCP) | 132 |
| 2025001344 | UERJ | DONEGATE DISTRIBUIDORA LTDA-ME | A aquisição, por licitação (pregão eletrônico), de cateter ureteral t… | R$ 7.070,70 | 18/03/2027 | 132 |
| 2026000016 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos para o Hospital Universitário Pedro Ernesto. | R$ 48.684,00 | 18/03/2027 | 132 |
| 2026000017 | UERJ | CWD SUPRIMENTOS HOSPITALARES LTDA | Aquisição de medicamentos para o Hospital Universitário Pedro Ernesto. | R$ 53.400,00 | 18/03/2027 | 132 |
| 2026000018 | UERJ | ESPECIFARMA COMERCIO DE MEDICAMENTOS E PRODU… | Aquisição de medicamentos para o Hospital Universitário Pedro Ernesto. | R$ 11.060,00 | 18/03/2027 | 132 |
| 2026000020 | UERJ | MAX PHARMA COMERCIO LTDA | Aquisição de medicamentos para o Hospital Universitário Pedro Ernesto. | R$ 4.151,00 | 18/03/2027 | 132 |
| 2026000021 | UERJ | SULMEDIC COMERCIO DE MEDICAMENTOS LTDA FILIA… | Aquisição de medicamentos para o Hospital Universitário Pedro Ernesto. | R$ 2.720,00 | 18/03/2027 | 132 |
| 2026000196 | UERJ | CENTRAL COMERCIO DE PRODUTOS HOSPITALARES LT… | A aquisição de lentes de contato rígida e de implante de drenagem val… | R$ 249.026,16 | 18/03/2027 | 132 |
| 2026000228 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 37.740,00 | 18/03/2027 | 132 |
| 2026000404 | UERJ | BOSTON SCIENTIFIC DO BRASIL LTDA. | Aquisição, por licitação (pregão eletrônico), de sistema incontinênci… | R$ 139.650,00 | 18/03/2027 | 132 |
| 2026000405 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 1.035,00 | 18/03/2027 | 132 |
| 2026000406 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 74.830,00 | 18/03/2027 | 132 |
| 2026000407 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 23.134,00 | 18/03/2027 | 132 |
| 2026000408 | UERJ | MAX PHARMA COMERCIO LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 875,00 | 18/03/2027 | 132 |
| 2026000409 | UERJ | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 3.496,00 | 18/03/2027 | 132 |
| 2026000431 | UERJ | UNIAO QUIMICA FARMACEUTICA NACIONAL SA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 376.000,00 | 18/03/2027 | 132 |
| 2026000756 | UERJ | EXCELENCIA DISTRIBUIDORA DE PRODUTOS E SERVI… | Aquisição de instrumentais cirúrgicos para o Hospital Universitário P… | R$ 6.102,50 | 18/03/2027 | 132 |
| 2026000758 | UERJ | MCN COMÉRCIO E IMPORTAÇÃO DE PRODUTOS CIRÚRG… | Aquisição de instrumentais cirúrgicos para o Hospital Universitário P… | R$ 3.988,00 | 18/03/2027 | 132 |
| 2026000759 | UERJ | CIRURTECH COMERCIO E MANUTENCAO DE MATERIAIS… | Aquisição de instrumentais cirúrgicos para o Hospital Universitário P… | R$ 15.143,44 | 18/03/2027 | 132 |
| 2026000760 | UERJ | ENDOGERAIS EQUIPAMENTOS MEDICOS LTDA ME | Aquisição de instrumentais cirúrgicos para o Hospital Universitário P… | R$ 284,32 | 18/03/2027 | 132 |
| 2026000761 | UERJ | INTERJET COMERCIAL EIRELI - EPP | Aquisição de instrumentais cirúrgicos para o Hospital Universitário P… | R$ 2.338,77 | 18/03/2027 | 132 |
| 2026001010 | UERJ | HUNTER CIENTIFICA COMERCIAL E SERVIÇOS LTDA | Aquisição, por licitação (pregão eletrônico), de Campo Cirúrgico para… | R$ 27.840,00 | 18/03/2027 | 132 |
| 2026001016 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 607.720,00 | 18/03/2027 (PNCP) | 132 |
| 2026001017 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 34.340,00 | 18/03/2027 | 132 |
| 2026001019 | UERJ | BY MEDICAL LTDA | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 45.936,00 | 18/03/2027 | 132 |
| 2026001020 | UERJ | MAX PHARMA COMERCIO LTDA | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 3.213,00 | 18/03/2027 | 132 |
| 2026001021 | UERJ | CONQUISTA DISTRIBUIDORA DE MEDICAMENTOS E PR… | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 16.576,00 | 18/03/2027 | 132 |
| 2026001022 | UERJ | SMART PHARMA DISTRIBUIDORA E IMPORTADORA DE … | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 11.862,00 | 18/03/2027 | 132 |
| 2026001632 | UERJ | AIR LIQUIDE BRASIL LTDA (FILIAL) | GAS,PRODUTO: NITROGENIO, TIPO: LIQUIDO, COMPOSICAO / FORMULA: FORMULA… | R$ 343.584,00 | 18/03/2027 | 132 |
| 2026002047 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Clonazepam CP 0,5 mg. | R$ 115,20 | 19/03/2027 | 133 |
| 2025008504 | UERJ | A W M ARAUJO ALIMENTAÇÃO E SERVIÇOS LTDA | Contratação de serviço comum de empresa especializada no fornecimento… | R$ 2.897.640,00 | 19/03/2027 (PNCP) | 133 |
| 2026000976 | UERJ | MICROPORT SCIENTIFIC VASCULAR BRASIL LTDA | Aquisição, por licitação (pregão eletrônico), de catéteres balão para… | R$ 196.650,40 | 19/03/2027 | 133 |
| 2026000977 | UERJ | ENDOLIFE IMPORTAÇÃO EXPORTAÇÃO COMERCIO E RE… | Aquisição, por licitação (pregão eletrônico), de catéteres balão para… | R$ 202.200,00 | 19/03/2027 | 133 |
| 2026001423 | UERJ | BFM MEDICAL LTDA | A aquisição de cateter diagnóstico, cateter de reentrada cateter guia… | R$ 153.424,00 | 19/03/2027 | 133 |
| 2026001424 | UERJ | SELLMED PRODUTOS MEDICOS E HOSPITALARES LTDA | A aquisição de cateter diagnóstico, cateter de reentrada cateter guia… | R$ 24.399,97 | 19/03/2027 | 133 |
| 2026001428 | UERJ | E TAMUSSINO & CIA LTDA | A aquisição de cateter diagnóstico, cateter de reentrada cateter guia… | R$ 42.000,00 | 19/03/2027 | 133 |
| 2026001865 | UERJ | ONCO PROD DISTRIBUIDORA DE PRODUTOS HOSPITAL… | Tacrolimo 5 mg cap | R$ 51.024,00 | 19/03/2027 | 133 |
| 2026001868 | UERJ | FARMACE - INDÚSTRIA QUÍMICO FARMACÊUTICA CEA… | Cloreto de Potassio 10 % (100 mg / mL) sol inj amp 10 mL. | R$ 2.400,00 | 19/03/2027 | 133 |
| 2026001870 | UERJ | DISTRIBUIÇÃO DE MEDICAMENTOS PAMED LTDA | Rituximabe 500 mg (10 mg / ml) Sol Inj FA 50 ml. | R$ 90.762,00 | 19/03/2027 | 133 |
| 2026002050 | UERJ | BLAU FARMACEUTICA S.A. | Azacitidina 100 mg FA pó Liófilo. | R$ 58.011,05 | 19/03/2027 | 133 |
| 2026002051 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Epinefrina 1 mg / ml Sol Inj Amp 1 ml. | R$ 10.000,00 | 19/03/2027 | 133 |
| 2026002054 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Hidrocortisona, Succ. Sódico 500 mg Pó Sol Inj FA. | R$ 3.800,00 | 19/03/2027 | 133 |
| 2026002055 | UERJ | NSA DISTRIBUIDORA DE MEDICAMENTOS EIRELLI | Doxorrubicina, Cloridrato 50 mg po / sol inj fa. | R$ 15.764,00 | 19/03/2027 | 133 |
| 2026000574 | UERJ | MEDICARE DISTRIBUIDORA DE PRODUTOS FARMACEUT… | A aquisição de medicamentos, para o Hospital Universitário Pedro Erne… | R$ 1.800,00 | 20/03/2027 | 134 |
| 2026000575 | UERJ | MAX PHARMA COMERCIO LTDA | A aquisição de medicamentos, para o Hospital Universitário Pedro Erne… | R$ 2.175,00 | 20/03/2027 | 134 |
| 2026000576 | UERJ | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | A aquisição de medicamentos, para o Hospital Universitário Pedro Erne… | R$ 1.040,00 | 20/03/2027 | 134 |
| 2026000578 | UERJ | SULMEDIC COMERCIO DE MEDICAMENTOS LTDA FILIA… | A aquisição de medicamentos, para o Hospital Universitário Pedro Erne… | R$ 768,00 | 20/03/2027 | 134 |
| 2026000579 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | A aquisição de medicamentos, para o Hospital Universitário Pedro Erne… | R$ 37.071,00 | 20/03/2027 | 134 |
| 2026002076 | UERJ | COMERCIAL CIRURGICA RIOCLARENSE LTDA | Fitomenadiona (Vitamina K) 10 mg / ml IM sol inj amp 1 ml. | R$ 1.408,00 | 20/03/2027 | 134 |
| 2026002079 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Diazepam CP 5 mg. | R$ 200,00 | 20/03/2027 | 134 |
| 2026002123 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Clonazepam CP 0,5 mg. | R$ 268,80 | 20/03/2027 | 134 |
| 2026002126 | UERJ | PROMEFARMA MEDICAMENTOS E PRODUTOS HOSPITALA… | Daptomicina 500mg Pó Liof Inj FA. | R$ 10.230,00 | 20/03/2027 | 134 |
| 2026002135 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de seringa. | R$ 23.650,00 | 20/03/2027 | 134 |
| 2026007369 | UERJ | BECTON DICKINSON INDÚSTRIAS CIRÚRGICAS LTDA | Aquisição urgente, por dispensa de licitação, de tubos para o Hospita… | R$ 181.890,00 | 21/03/2027 | 135 |
| 2026001104 | UERJ | SMART PHARMA DISTRIBUIDORA E IMPORTADORA DE … | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 5.478,00 | 23/03/2027 | 137 |
| 2026001105 | UERJ | HALEX ISTAR INDÚSTRIA FARMACÊUTICA S/A | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 9.352,00 | 23/03/2027 | 137 |
| 2026001107 | UERJ | CONQUISTA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 1.467,00 | 23/03/2027 | 137 |
| 2026001108 | UERJ | MAX PHARMA COMERCIO LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 1.545,00 | 23/03/2027 | 137 |
| 2026001109 | UERJ | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 5.760,00 | 23/03/2027 | 137 |
| 2026001436 | UERJ | VERTICAL RJ SOLUÇÕES PARA SAÚDE LTDA | A aquisição, por licitação, de dietas enterais e suplementos pediátri… | R$ 169.847,56 | 23/03/2027 | 137 |
| 2026001438 | UERJ | NUTRIC NUTRICIONAL COMÉRCIO LTDA | A aquisição, por licitação, de dietas enterais e suplementos pediátri… | R$ 36.420,80 | 23/03/2027 | 137 |
| 2026001439 | UERJ | FRESENIUS KABI BRASIL LTDA (MATRIZ) | A aquisição, por licitação, de dietas enterais e suplementos pediátri… | R$ 6.851,00 | 23/03/2027 | 137 |
| 2026001443 | UERJ | PROGMED RIO COMERCIO E SERVIÇO DE EQUIPAMENT… | Aquisição, por licitação (pregão eletrônico), de Endoscópios para o H… | R$ 15.000,00 | 23/03/2027 | 137 |
| 2026001832 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Projeto Oncologia - Subprojeto 5 | R$ 1.848.880,00 | 23/03/2027 (PNCP) | 137 |
| 2026002067 | UERJ | DROGAFONTE LTDA. | Dexametasona, Acetato 1 mg/g creme Tubo 10 g. | R$ 1.620,00 | 23/03/2027 | 137 |
| 2026002069 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de sonda foley. | R$ 1.071,00 | 23/03/2027 | 137 |
| 2026002073 | UERJ | RJD HOSPITALAR EIRELI | Aquisição de cera óssea. | R$ 2.305,00 | 23/03/2027 | 137 |
| 2026002075 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de termômetro. | R$ 400,00 | 23/03/2027 | 137 |
| 2026002096 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Dexametasona, Fosfato Dissodico 4 mg / ml Sol Inj FA 2,5 ml. | R$ 11.050,00 | 23/03/2027 | 137 |
| 2026000904 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 59.400,00 | 24/03/2027 | 138 |
| 2026000905 | UERJ | HALEX ISTAR INDÚSTRIA FARMACÊUTICA S/A | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 26.550,00 | 24/03/2027 | 138 |
| 2026000906 | UERJ | MAX PHARMA COMERCIO LTDA | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 2.860,00 | 24/03/2027 | 138 |
| 2026000907 | UERJ | SICAFLA COMERCIO DE PRODUTOS FARMACEUTICOS L… | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 32.763,00 | 24/03/2027 | 138 |
| 2026000908 | UERJ | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 1.960,00 | 24/03/2027 | 138 |
| 2026001004 | UERJ | BECTON DICKINSON INDUSTRIAS CIRURGICAS LTDA | Aquisição, por inexigibilidade de licitação, de insumos destinados à … | R$ 199.703,24 | 24/03/2027 | 138 |
| 2026001032 | UERJ | DUMALE PRODUTOS PARA SAUDE LTDA | Aquisição, por licitação (pregão eletrônico), de fixadores de cateter… | R$ 26.972,00 | 24/03/2027 | 138 |
| 2026001863 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Prometazina, Cloridrato 25 mg / ml Sol. Inj. Amp. 2 ml. | R$ 1.112,00 | 24/03/2027 | 138 |
| 2026002077 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de Equipos de soro via empenhamento de ARP 0121/2025/296100… | R$ 12.600,00 | 24/03/2027 | 138 |
| 2026002078 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de escovas degermantes. | R$ 5.286,72 | 24/03/2027 | 138 |
| 2026002080 | UERJ | MEDICAL SUTURE COMERCIO DE MATERIAL HOSPITAL… | Aquisição de fio cirúrgico. | R$ 5.132,16 | 24/03/2027 | 138 |
| 2026002087 | UERJ | INJEX INDUSTRIAS CIRURGICAS LTDA | Aquisição de seringas. | R$ 25.740,00 | 24/03/2027 | 138 |
| 2026002088 | UERJ | DROGAFONTE LTDA. | Enalapril, Maleato 10 mg cp. | R$ 84,00 | 24/03/2027 | 138 |
| 2025001239 | UERJ | PER PRIMA COMÉRCIO E REPRESENTAÇÕES LTDA | Aquisição, por licitação (pregão eletrônico), de material para cirurg… | R$ 449.848,00 | 25/03/2027 | 139 |
| 2025001568 | UERJ | RCOM DIGITAL TELECOMUNICAÇÕES LTDA | Contratação de empresa para locação de 5 (cinco) rádios comunicadores… | R$ 12.640,00 | 25/03/2027 | 139 |
| 2025011002 | UERJ | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 88.984,50 | 25/03/2027 | 139 |
| 2025011003 | UERJ | PACLIMED DISTRIBUIDORA DE PRODUTOS FARMACÊUT… | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 115.900,00 | 25/03/2027 | 139 |
| 2026000910 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 2.520,00 | 25/03/2027 | 139 |
| 2026000911 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 110.200,00 | 25/03/2027 | 139 |
| 2026000912 | UERJ | COMERCIAL CIRURGICA RIOCLARENSE LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 76.983,00 | 25/03/2027 | 139 |
| 2026000913 | UERJ | CONQUISTA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 67.368,00 | 25/03/2027 | 139 |
| 2026000914 | UERJ | JRG DISTRIBUIDORA DE MEDICAMENTOS HOSPITALAR… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 72.570,00 | 25/03/2027 | 139 |
| 2026000915 | UERJ | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 35.457,93 | 25/03/2027 | 139 |
| 2026000916 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 57.960,00 | 25/03/2027 | 139 |
| 2026000917 | UERJ | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 119.667,60 | 25/03/2027 | 139 |
| 2026002056 | UERJ | NSA DISTRIBUIDORA DE MEDICAMENTOS EIRELLI | Cianocobalamina (Vitamina B12) 2500 mcg / mL sol inj amp 2mL. | R$ 2.244,00 | 25/03/2027 | 139 |
| 2026002059 | UERJ | NEWARIS LIFESCIENCES LTDA | Micofenolato de Mofetila CP 500 mg. | R$ 3.200,00 | 25/03/2027 | 139 |
| 2026002150 | UERJ | BLAU FARMACEUTICA S.A. | Metotrexato 25 mg / ml Sol. Inj. FA 20 ml. | R$ 19.062,00 | 25/03/2027 | 139 |
| 2026002230 | UERJ | INJEX INDUSTRIAS CIRURGICAS LTDA | Aquisição de agulha hipodérmica. | R$ 3.800,00 | 25/03/2027 | 139 |
| 2026002239 | UERJ | ROMA DISTRIBUIDORA DE MATERIAIS HOSPITALARES… | Aquisição de agulha. | R$ 4.566,00 | 25/03/2027 | 139 |
| 2026002250 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Acido Valproico Cap 250 mg. | R$ 1.110,00 | 25/03/2027 | 139 |
| 2026000492 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 2.124,00 | 26/03/2027 | 140 |
| 2026000494 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 124.044,00 | 26/03/2027 | 140 |
| 2026000495 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 8.184,00 | 26/03/2027 | 140 |
| 2026000659 | UERJ | ABC FARMACEUTICO LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 826.570,00 | 26/03/2027 (PNCP) | 140 |
| 2026002234 | UERJ | MULTIFARMA COMÉRCIO E REPRESENTAÇÕES LTDA | Azitromicina 40 mg/ml Pó / Susp Oral FR 15 ml. | R$ 634,00 | 26/03/2027 | 140 |
| 2026002308 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de sondas. | R$ 3.828,80 | 26/03/2027 | 140 |
| 2026002333 | UERJ | EXCELENCIA DISTRIBUIDORA DE PRODUTOS E SERVI… | Aquisição de sondas. | R$ 1.420,00 | 26/03/2027 | 140 |
| 2026002334 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de sonda. | R$ 611,00 | 26/03/2027 | 140 |
| 2026002345 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de agulhas hipodérmicas. | R$ 4.300,00 | 26/03/2027 | 140 |
| 2026002378 | UERJ | ONCOVIT DISTRIBUIDORA DE MEDICAMENTOS LTDA M… | Capecitabina CP 500 mg | R$ 77.338,80 | 26/03/2027 | 140 |
| 2026002385 | UERJ | HTS TECNOLOGIA EM SAÚDE, COMÉRCIO, IMPORTAÇÃ… | Aquisição de cateter. | R$ 9.024,00 | 26/03/2027 | 140 |
| 2025000749 | UERJ | RIO TERUMED COMÉRCIO DE MATERIAL CIRÚRGICO L… | Aquisição, por licitação (pregão eletrônico), de Sistema de Suporte C… | R$ 802.800,00 | 27/03/2027 (PNCP) | 141 |
| 2025001250 | UERJ | WM WORLD MEDICAL IMPORTACAO E EXPORTACAO LTDA | A aquisição, por licitação (pregão eletrônico), de PRÓTESE JOELHO REV… | R$ 667.000,00 | 27/03/2027 (PNCP) | 141 |
| 2026000030 | UERJ | FELIPE LEVY DISTRIBUIDORA LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 35.965,00 | 27/03/2027 | 141 |
| 2026000031 | UERJ | ONCOVIT DISTRIBUIDORA DE MEDICAMENTOS LTDA M… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 236.544,00 | 27/03/2027 | 141 |
| 2026001563 | CECIERJ | NASMELLO COMÉRCIO E SERVIÇO LTDA-ME | Contratação de empresa especializada para prestação de serviços de ma… | R$ 275.000,00 | 27/03/2027 | 141 |
| 2026001732 | UERJ | BIOSINTESE HOSPITALAR LTDA | Aquisição, por licitação (pregão eletrônico), de placas, parafusos e … | R$ 84.999,96 | 27/03/2027 | 141 |
| 2023002097 | CECIERJ | OI S/A | Comunicação de Adesão a Ata de Registro de Preços 00152022 Serviço Te… | R$ 1.623.607,46 | 30/03/2027 | 144 |
| 2026000457 | UERJ | CARDIOVENT COMERCIO E SERVICOS LTDA | Aquisição, por licitação (pregão eletrônico), de Sistema Regulação Té… | R$ 141.600,00 | 30/03/2027 | 144 |
| 2026001026 | UERJ | SMART COMERCIO DE PRODUTOS FARMACEUTICOS LTDA | Aquisição de Drenos e sistemas fechados para o Hospital Universitário… | R$ 5.009,90 | 30/03/2027 | 144 |
| 2026001028 | UERJ | ZAMMI INSTRUMENTAL LTDA | Aquisição de Drenos e sistemas fechados para o Hospital Universitário… | R$ 20.793,00 | 30/03/2027 | 144 |
| 2026001029 | UERJ | VIBEMED COMERCIO E REPRESENTAÇÃO LTDA ME | Aquisição de Drenos e sistemas fechados para o Hospital Universitário… | R$ 10.200,00 | 30/03/2027 | 144 |
| 2026001415 | UERJ | CARE SURGICAL COMERCIO DE MATERIAIS CIRURGIC… | Aquisição de Neuromonitorização Eletrofisiológica per Operatória com … | R$ 283.999,80 | 30/03/2027 | 144 |
| 2026001474 | UERJ | VIBEMED COMERCIO E REPRESENTAÇÃO LTDA ME | Aquisição urgente, por dispensa de licitação, de kits de monitorizaçã… | R$ 199.305,00 | 30/03/2027 | 144 |
| 2026002423 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Furosemida CP 40 mg. | R$ 199,50 | 30/03/2027 | 144 |
| 2026002426 | UERJ | ESPECIFARMA COMERCIO DE MEDICAMENTOS E PRODU… | Aquisição de gel ECG. | R$ 11.000,00 | 30/03/2027 | 144 |
| 2026000367 | UERJ | INVASIVE IMPORTACAO E COMERCIO DE PRODUTOS M… | Aquisição, por contratação direta por inexibilidade de licitação, de … | R$ 445.000,00 | 31/03/2027 | 145 |
| 2026001098 | UERJ | EXCELENCIA DISTRIBUIDORA DE PRODUTOS E SERVI… | A aquisição, por licitação (pregão eletrônico), de Itens diversos par… | R$ 25.062,50 | 31/03/2027 | 145 |
| 2026001099 | UERJ | LABORATÓRIOS B. BRAUN S.A | A aquisição, por licitação (pregão eletrônico), de Itens diversos par… | R$ 69.600,00 | 31/03/2027 | 145 |
| 2026001101 | UERJ | MICROBAC PRODUTOS E SERVIÇOS PARA LABORATÓRI… | A aquisição, por licitação (pregão eletrônico), de Itens diversos par… | R$ 14.307,00 | 31/03/2027 | 145 |
| 2026001102 | UERJ | COMERCIAL CARDU EIRELLI ME | A aquisição, por licitação (pregão eletrônico), de Itens diversos par… | R$ 13.398,00 | 31/03/2027 | 145 |
| 2026001103 | UERJ | LEGACY LIFE MEDICAL LTDA ME | A aquisição, por licitação (pregão eletrônico), de Itens diversos par… | R$ 12.600,00 | 31/03/2027 | 145 |
| 2026001122 | UERJ | INLABEL SOLUÇÕES EM RÓTULOS ADESIVOS LTDA | Aquisição, por licitação (pregão eletrônico), de itens diversos para … | R$ 442.855,20 | 31/03/2027 | 145 |
| 2026001123 | UERJ | FIT PLAST AUTO ADESIVOS LTDA | Aquisição, por licitação (pregão eletrônico), de itens diversos para … | R$ 16.898,40 | 31/03/2027 | 145 |
| 2026001124 | UERJ | MEDMACH SOLUCOES HOSPITALARES LTDA | Aquisição, por licitação (pregão eletrônico), de itens diversos para … | R$ 31.800,00 | 31/03/2027 | 145 |
| 2026001145 | UERJ | PRANALIFE PRODUTOS MÉDICOS E CIRURGICOS LTDA | Aquisição, por licitação (pregão eletrônico), de material de artrodes… | R$ 419.000,00 | 31/03/2027 | 145 |
| 2026001151 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 148.000,00 | 31/03/2027 | 145 |
| 2026001153 | UERJ | PHOENIX DISTRIBUIDORA E IMPORTADORA DE PRODU… | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 1.904,00 | 31/03/2027 | 145 |
| 2026001421 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Portaria Conjunta DER-RJ/UERJ Nº42 de 19/02/2026 - Projeto DER-RJ/UER… | R$ 1.201.389,00 | 31/03/2027 (PNCP) | 145 |
| 2026001454 | UERJ | SURGITEXTIL INDÚSTRIA TEXTIL LTDA. | Aquisição, por licitação (pregão eletrônico), de Mascara e protetor o… | R$ 66.576,00 | 31/03/2027 | 145 |
| 2026001456 | UERJ | CRYSSIL FORNECEDORA DE MATERIAIS E SERVIÇOS … | Aquisição, por licitação (pregão eletrônico), de Mascara e protetor o… | R$ 8.531,00 | 31/03/2027 | 145 |
| 2026001584 | UERJ | WM WORLD MEDICAL IMPORTACAO E EXPORTACAO LTDA | A aquisição de material para cirurgias de Revisão de Joelho commecani… | R$ 578.084,00 | 31/03/2027 (PNCP) | 145 |
| 2026001719 | UERJ | CEI COMERCIO EXPORTACAO E IMPORTACAO DE MATE… | A aquisição de Cateter para o Hospital Universitário Pedro Ernesto. | R$ 105.085,00 | 31/03/2027 | 145 |
| 2026001720 | UERJ | ASLI COMERCIAL LTDA | A aquisição de Cateter para o Hospital Universitário Pedro Ernesto. | R$ 241.189,50 | 31/03/2027 | 145 |
| 2026001722 | UERJ | NEXON MEDICAL LTDA | A aquisição de Cateter para o Hospital Universitário Pedro Ernesto. | R$ 30.303,00 | 31/03/2027 | 145 |
| 2026001848 | UERJ | NUTRIC NUTRICIONAL COMÉRCIO LTDA | Aquisição regular, via licitação (pregão eletrônico), de suplementos … | R$ 297.944,40 | 31/03/2027 | 145 |
| 2026001850 | UERJ | NUTRIR SOLUÇÕES EM SAUDE EIRELI | Aquisição regular, via licitação (pregão eletrônico), de suplementos … | R$ 269.178,96 | 31/03/2027 | 145 |
| 2026001852 | UERJ | VERTICAL RJ SOLUÇÕES PARA SAÚDE LTDA | Aquisição regular, via licitação (pregão eletrônico), de suplementos … | R$ 69.979,44 | 31/03/2027 | 145 |
| 2026001912 | UERJ | COMERCIAL CIRURGICA RIOCLARENSE LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 42.000,00 | 31/03/2027 | 145 |
| 2026001914 | UERJ | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 146.675,00 | 31/03/2027 | 145 |
| 2026002402 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Portaria Conjunta FIA/UERJ Nº 40 DE 04/02/2026 -FIA/NACA | R$ 3.000.000,00 | 31/03/2027 (PNCP) | 145 |
| 2026002514 | UERJ | DISK MED PÁDUA DISTRIBUIDORA DE MEDICAMENTOS… | Digoxina 0,25 mg cp. | R$ 48,00 | 31/03/2027 | 145 |
| 2026002515 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Gliconato de Calcio 10% (100 mg / ml) Sol Inj Amp 10 ml. | R$ 7.280,00 | 31/03/2027 | 145 |
| 2024000246 | UERJ | CONFIANCE MEDICAL PRODUTOS MEDICOS S/A | ALUGUEL DE RACKS DE VIDEOLAPAROSCOPIA PARA ATENDER O GRANDE NÚMERO DE… | R$ 1.350.000,00 | 01/04/2027 | 146 |
| 2025000774 | UERJ | PER PRIMA COMÉRCIO E REPRESENTAÇÕES LTDA | Aquisição, por licitação (pregão eletrônico), de parafusos canulados … | R$ 53.300,00 | 01/04/2027 | 146 |
| 2025001558 | UERJ | TAPEVAS SOLUÇÕES INTEGRADAS EIRELI | Contratação de serviços continuados de apoio hospitalar. | R$ 1.331.445,72 | 01/04/2027 (PNCP) | 146 |
| 2026000443 | UERJ | COSTA CAMARGO COMERCIO DE PRODUTOS HOSPITALA… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 44.520,00 | 01/04/2027 | 146 |
| 2026000444 | UERJ | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 14.731,27 | 01/04/2027 | 146 |
| 2026001152 | UERJ | ONCO PROD DISTRIBUIDORA DE PRODUTOS HOSPITAL… | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 1.200,00 | 01/04/2027 | 146 |
| 2026002532 | UERJ | DROGAFONTE LTDA. | Aciclovir CP 200 mg. | R$ 245,70 | 01/04/2027 | 146 |
| 2026002541 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Paracetamol 200 mg/ml Sol Oral FR 15 ml | R$ 1.270,20 | 01/04/2027 | 146 |
| 2024010398 | UERJ | IDS MEDICAL IMPORTACAO, DISTRIBUICAO E SERVI… | Aquisição, por licitação (pregão eletrônico), de pinças para cirurgia… | R$ 236.160,00 | 02/04/2027 | 147 |
| 2025000765 | UERJ | TOPNEW COMERCIAL LTDA. | A aquisição, por licitação (pregão eletrônico), de Cateter Balão por … | R$ 610.651,50 | 02/04/2027 (PNCP) | 147 |
| 2026001686 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 21.600,00 | 02/04/2027 | 147 |
| 2026001687 | UERJ | SICAFLA COMERCIO DE PRODUTOS FARMACEUTICOS L… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 13.363,00 | 02/04/2027 | 147 |
| 2026002562 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aciclovir CP 200 mg. | R$ 690,00 | 02/04/2027 | 147 |
| 2026002590 | UERJ | MEDITON FARMACEUTICA LTDA | Hidralazina, Cloridrato Drag. 25 mg | R$ 8.664,00 | 02/04/2027 | 147 |
| 2023001979 | CECIERJ | MINHA BIBLIOTECA LTDA | Contratação de serviço de assinatura deplataforma de livros eletrônic… | R$ 2.737.761,60 | 04/04/2027 | 149 |
| 2025001510 | UERJ | PHILIPS MEDICAL SYSTEMS LTDA | Tem por objetivo a Contratação de empresa especializada para realizaç… | R$ 3.408.781,68 | 04/04/2027 (PNCP) | 149 |
| 2025011020 | UERJ | LEMARC PRODUTOS MÉDICOS HOSPITALARES LTDA-ME | O presente Termo tem por objetivo a aquisição, por licitação (pregão … | R$ 270.462,55 | 06/04/2027 | 151 |
| 2025011021 | UERJ | MP COMERCIO DE MATERIAIS MEDICOS E HOSPITALA… | O presente Termo tem por objetivo a aquisição, por licitação (pregão … | R$ 18.306,00 | 06/04/2027 | 151 |
| 2025011022 | UERJ | IMPULSE PRODUTOS HOSPITALARES LTDA | O presente Termo tem por objetivo a aquisição, por licitação (pregão … | R$ 300,49 | 06/04/2027 | 151 |
| 2026000237 | UERJ | CIRÚRGICA CAPITAL COMÉRCIO DE PRODUTOS HOSPI… | Aquisição, por licitação (pregão eletrônico), de grampeadores cirúrgi… | R$ 29.520,00 | 06/04/2027 | 151 |
| 2026000238 | UERJ | LABORATÓRIOS B. BRAUN S.A | Aquisição, por licitação (pregão eletrônico), de grampeadores cirúrgi… | R$ 2.400.444,74 | 06/04/2027 (PNCP) | 151 |
| 2026000239 | UERJ | PANTHER HEALTHCARE BRASIL DISTRIBUIDORA DE P… | Aquisição, por licitação (pregão eletrônico), de grampeadores cirúrgi… | R$ 45.140,00 | 06/04/2027 | 151 |
| 2026001450 | UERJ | BAXTER HOSPITALAR LTDA | A aquisição de materiais hemostáticos, cateteres de intervenção e kit… | R$ 48.000,00 | 06/04/2027 | 151 |
| 2026001451 | UERJ | JOTEC DO BRASIL IMPORTAÇÃO E COMÉRCIO DE EQU… | A aquisição de materiais hemostáticos, cateteres de intervenção e kit… | R$ 474.999,60 | 06/04/2027 | 151 |
| 2026001452 | UERJ | ECOMED COMERCIO DE PRODUTOS MEDICOS LTDA | A aquisição de materiais hemostáticos, cateteres de intervenção e kit… | R$ 21.318,00 | 06/04/2027 | 151 |
| 2026001453 | UERJ | BIONEFRO COMÉRCIO DE MATERIAL HOSPITALAR LTD… | A aquisição de materiais hemostáticos, cateteres de intervenção e kit… | R$ 83.999,60 | 06/04/2027 | 151 |
| 2026002049 | UERJ | ALKO DO BRASIL INDUSTRIA E COMERCIO LTDA | Aquisição por dispensa de licitação, de kit seringas para o Hospital … | R$ 50.768,00 | 06/04/2027 | 151 |
| 2026002331 | UERJ | QUÍRON PHARMA LTDA | Aquisição de medicamentos para o Hospital Universitário Pedro Ernesto… | R$ 56.840,00 | 06/04/2027 | 151 |
| 2026002614 | UERJ | JRG DISTRIBUIDORA DE MEDICAMENTOS HOSPITALAR… | Insulina Humana Regular 100 UI/ml Sol Inj FA 10 ml. | R$ 32.718,00 | 06/04/2027 | 151 |
| 2026002615 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Dipirona Sodica CP 500 mg. | R$ 4.200,00 | 06/04/2027 | 151 |
| 2026002616 | UERJ | FARMACE - INDÚSTRIA QUÍMICO FARMACÊUTICA CEA… | Dipirona Sodica 500 mg / ml Sol Oral FR 10 ml. | R$ 1.090,00 | 06/04/2027 | 151 |
| 2026002638 | UERJ | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Nitrofurantoina Cap. 100 mg. | R$ 302,40 | 06/04/2027 | 151 |
| 2026002646 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Cefalexina 50 mg / mL po susp oral fr 60 mL. | R$ 455,00 | 06/04/2027 | 151 |
| 2025001966 | CECIERJ | PARTNERS COMUNICAÇÃO INTEGRADA | Contratações de Prestação de Serviços de produção de Videoaulas, a pa… | R$ 1.700.000,00 | 07/04/2027 | 152 |
| 2026002165 | UERJ | DLW COMERCIAL DISTRIBUIDORA LTDA | Aquisição de cateter guia para o Hospital Universitário Pedro Ernesto. | R$ 9.060,00 | 07/04/2027 | 152 |
| 2026002662 | UERJ | NSA DISTRIBUIDORA DE MEDICAMENTOS EIRELLI | Poliestirenossulfonato de Calcio 900mg/g Pó Sol. Oral Env. 30 g. | R$ 26.840,00 | 07/04/2027 | 152 |
| 2026006120 | UERJ | NOTORIO REPR. E SERV. EM GERAL LTDA | Instituto de Aplicação Fernando Rodrigues da Silveira  CAp-UERJ, que… | R$ 6.498.488,64 | 07/04/2027 (PNCP) | 152 |
| 2025001795 | UERJ | SIEMENS HEALHTCARE DIAGNOSTICOS LTDA(FILIAL) | A AQUISIÇÃO DE REAGENTES, MODO DE DISPUTA ABERTO, PELO MENOR PREÇO GL… | R$ 683.474,50 | 08/04/2027 (PNCP) | 153 |
| 2026000248 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 2.599,20 | 08/04/2027 | 153 |
| 2026000719 | UERJ | DMAX DISTRIBUIDORA DE MEDICAMENTOS E MATERIA… | Aquisição, por licitação (pregão eletrônico), de seringas para bomba … | R$ 130.108,00 | 08/04/2027 | 153 |
| 2026000720 | UERJ | ALKO DO BRASIL INDUSTRIA E COMERCIO LTDA | Aquisição, por licitação (pregão eletrônico), de seringas para bomba … | R$ 74.572,00 | 08/04/2027 | 153 |
| 2026000721 | UERJ | ALPHARAD MATERIAIS PARA DIAGNÓSTICOS EIRELI … | Aquisição, por licitação (pregão eletrônico), de seringas para bomba … | R$ 95.832,00 | 08/04/2027 | 153 |
| 2026001018 | UERJ | DBI COMÉRCIO E IMPORTAÇÃO EIRELI | A aquisição, por licitação, de Itens diversos para o Hospital Univers… | R$ 33.042,60 | 08/04/2027 | 153 |
| 2026001023 | UERJ | FAYNE HOSPITALAR DISTRIBUIDORA DE MEDICAMENT… | A aquisição, por licitação, de Itens diversos para o Hospital Univers… | R$ 22.644,30 | 08/04/2027 | 153 |
| 2026001024 | UERJ | HEALTH CARE COMÉRCIO DE MATERIAIS MEDICO CIR… | A aquisição, por licitação, de Itens diversos para o Hospital Univers… | R$ 63.450,00 | 08/04/2027 | 153 |
| 2026001025 | UERJ | GAMA MED 13 COMERCIO E SERVIÇO LTDA | A aquisição, por licitação, de Itens diversos para o Hospital Univers… | R$ 3.999,60 | 08/04/2027 | 153 |
| 2026001819 | UERJ | ELEKTA SOLUTIONS AB | A aquisição de um equipamento de Acelerador Linear para atender a dem… | R$ 10.139.800,00 | 08/04/2027 (PNCP) | 153 |
| 2026001834 | UERJ | BLAU FARMACEUTICA S.A. | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 174.296,00 | 08/04/2027 | 153 |
| 2026001835 | UERJ | CERTA MEDICAMENTOS COMERCIAL LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 49.980,00 | 08/04/2027 | 153 |
| 2026001836 | UERJ | DISTRIBUIÇÃO DE MEDICAMENTOS PAMED LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 37.992,00 | 08/04/2027 | 153 |
| 2026001837 | UERJ | TRES PHARMA DISTRIBUIDORA E SERVIÇOS LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 95.970,00 | 08/04/2027 | 153 |
| 2026002091 | UERJ | NOVA LINEA COMERCIO DE PRODUTOS FARMACEUTICO… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 3.838,00 | 08/04/2027 | 153 |
| 2026002092 | UERJ | MAX PHARMA COMERCIO LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 2.850,00 | 08/04/2027 | 153 |
| 2026002093 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 281.430,00 | 08/04/2027 | 153 |
| 2026002095 | UERJ | BY MEDICAL LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 6.848,00 | 08/04/2027 | 153 |
| 2026002315 | UERJ | ENDOGERAIS EQUIPAMENTOS MEDICOS LTDA ME | A aquisição, por licitação (pregão eletrônico), de instrumentais cirú… | R$ 4.505,73 | 08/04/2027 | 153 |
| 2026002317 | UERJ | INTERJET COMERCIAL EIRELI - EPP | A aquisição, por licitação (pregão eletrônico), de instrumentais cirú… | R$ 2.910,18 | 08/04/2027 | 153 |
| 2026002318 | UERJ | MCN COMÉRCIO E IMPORTAÇÃO DE PRODUTOS CIRÚRG… | A aquisição, por licitação (pregão eletrônico), de instrumentais cirú… | R$ 5.496,00 | 08/04/2027 | 153 |
| 2026002319 | UERJ | SMART COMERCIO DE PRODUTOS FARMACEUTICOS LTDA | A aquisição, por licitação (pregão eletrônico), de instrumentais cirú… | R$ 13.222,19 | 08/04/2027 | 153 |
| 2026000197 | UERJ | COMERCIAL CARDU EIRELLI ME | Aquisição de Itens diversos para o Hospital Universitário Pedro Ernes… | R$ 13.383,50 | 09/04/2027 | 154 |
| 2026000198 | UERJ | DONEGATE DISTRIBUIDORA LTDA-ME | Aquisição de Itens diversos para o Hospital Universitário Pedro Ernes… | R$ 8.544,00 | 09/04/2027 | 154 |
| 2026000199 | UERJ | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de Itens diversos para o Hospital Universitário Pedro Ernes… | R$ 26.573,28 | 09/04/2027 | 154 |
| 2026000200 | UERJ | ZAMMI INSTRUMENTAL LTDA | Aquisição de Itens diversos para o Hospital Universitário Pedro Ernes… | R$ 1.118,48 | 09/04/2027 | 154 |
| 2026002418 | UERJ | CITOPHARMA MANIPULAÇÃO DE MEDICAMENTOS ESPEC… | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 41.400,00 | 09/04/2027 | 154 |
| 2026002419 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 15.779,00 | 09/04/2027 | 154 |
| 2026002420 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | A aquisição de medicamentos para o Hospital Universitário Pedro Ernes… | R$ 21.560,00 | 09/04/2027 | 154 |
| 2026002780 | UERJ | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Levotiroxina sodica CP 25 mcg. | R$ 564,00 | 09/04/2027 | 154 |
| 2025002230 | UERJ | MARTELL COMERCIO DE PRODUTOS HOSPITALARES LT… | A aquisição, por licitação (pregão eletrônico), de antissoros para a … | R$ 4.023,16 | 10/04/2027 | 155 |
| 2025002232 | UERJ | PROCARE COMÉRCIO DE PRODUTOS HOSPITALARES LT… | A aquisição, por licitação (pregão eletrônico), de antissoros para a … | R$ 27.108,15 | 10/04/2027 | 155 |
| 2025011005 | UERJ | LIFETEX INDUSTRIA E COMERCIO LTDA | A aquisição urgente, por dispensa de licitação, de kit cirúrgico Cesá… | R$ 38.232,00 | 10/04/2027 | 155 |
| 2026001596 | UERJ | AUTO SUTURE DO BRASIL LTDA | Aquisição, por licitação (pregão eletrônico), de stent expansível por… | R$ 116.250,00 | 10/04/2027 | 155 |
| 2026001597 | UERJ | BFM MEDICAL LTDA | Aquisição, por licitação (pregão eletrônico), de stent expansível por… | R$ 93.600,00 | 10/04/2027 | 155 |
| 2026002471 | UERJ | NOTORIO REPR. E SERV. EM GERAL LTDA | Contratação, de empresa especializada no Serviço de Alimentação e Nut… | R$ 2.720.160,00 | 10/04/2027 (PNCP) | 155 |
| 2025005063 | UERJ | THERMO ELECTRON NORTH AMERICA LLC | AQUISIÇÃO DE Sistema de espectrometria de massa ICP/MS de alta resolu… | R$ 6.176.665,16 | 12/04/2027 (PNCP) | 157 |
| 2026001773 | UERJ | DO VALE RAMOS ENGENHARIA LTDA | Aquisição de televisões. | R$ 23.490,00 | 13/04/2027 | 158 |
| 2026002429 | UERJ | PRANALIFE PRODUTOS MÉDICOS E CIRURGICOS LTDA | Aquisição, por licitação (pregão eletrônico), de clips de aneurisma, … | R$ 28.055,74 | 13/04/2027 | 158 |
| 2026002430 | UERJ | CRITICARE COMÉRCIO DE PRODUTOS CIRÚRGICOS LT… | Aquisição, por licitação (pregão eletrônico), de clips de aneurisma, … | R$ 189.662,98 | 13/04/2027 | 158 |
| 2026002441 | UERJ | STRYKER DO BRASIL LTDA | Aquisição, por licitação (pregão eletrônico), de cânula de aspiração,… | R$ 204.510,80 | 13/04/2027 | 158 |
| 2026002812 | UERJ | LIFETEX INDUSTRIA E COMERCIO LTDA | Este objeto de contrato é essencial para garantir a segurança tanto d… | R$ 51.360,00 | 13/04/2027 | 158 |
| 2026002834 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de espéculo vaginal. | R$ 544,00 | 13/04/2027 | 158 |
| 2025007690 | FAETEC | MAIS MOBI SERVICOS LTDA | Aquisição de vale-transporte eletrônico -Cartão RioCard Mais para Ser… | R$ 3.669.435,76 | 14/04/2027 (PNCP) | 159 |
| 2026002584 | UERJ | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 6.000,00 | 14/04/2027 | 159 |
| 2026002585 | UERJ | BLAU FARMACEUTICA S.A. | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 103.968,00 | 14/04/2027 | 159 |
| 2026002586 | UERJ | ESPECIFARMA COMERCIO DE MEDICAMENTOS E PRODU… | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 5.000,00 | 14/04/2027 | 159 |
| 2026002719 | UERJ | ORTOBENS DISTRIBUIDORA DE PRODUTOS HOSPITALA… | Aquisição, por licitação (pregão eletrônico), de Itens diversos para … | R$ 11.340,50 | 14/04/2027 | 159 |
| 2026002720 | UERJ | LEGACY LIFE MEDICAL LTDA ME | Aquisição, por licitação (pregão eletrônico), de Itens diversos para … | R$ 50.872,50 | 14/04/2027 | 159 |
| 2026002721 | UERJ | ARC FONTOURA INDÚSTRIA COMÉRCIO E REPRESENTA… | Aquisição, por licitação (pregão eletrônico), de Itens diversos para … | R$ 7.392,00 | 14/04/2027 | 159 |
| 2026002722 | UERJ | ZAMMI INSTRUMENTAL LTDA | Aquisição, por licitação (pregão eletrônico), de Itens diversos para … | R$ 38.113,46 | 14/04/2027 | 159 |
| 2025001169 | UERJ | BIOPLASMA PRODUTOS PARA LABORATORIOS E CORRE… | Aquisição de reagentes, pelo menor preço global por lote, sendo bioqu… | R$ 1.224.690,00 | 15/04/2027 (PNCP) | 160 |
| 2025001172 | UERJ | LABINBRAZ COMERCIAL LTDA | Aquisição de reagentes, pelo menor preço global por lote, sendo bioqu… | R$ 1.174.440,00 | 15/04/2027 (PNCP) | 160 |
| 2026002788 | UERJ | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição, por licitação (pregão eletrônico), de soluções para o Hosp… | R$ 141.650,00 | 15/04/2027 | 160 |
| 2026002944 | UERJ | CIENLABOR INDUSTRIA E COMERCIO LTDA | Aquisição de agulha de veress. | R$ 2.814,00 | 15/04/2027 | 160 |
| 2026000250 | UERJ | AM SPECIAL LTDA | A aquisição, por licitação (pregão eletrônico), de itens demobiliário… | R$ 110.000,00 | 16/04/2027 | 161 |
| 2026001702 | UERJ | E TAMUSSINO & CIA LTDA | Aquisição, por licitação (pregão eletrônico), de stent dissecção de a… | R$ 96.000,00 | 16/04/2027 | 161 |
| 2026001710 | UERJ | MONTEGGIA PRODUTOS HOSPITALARES LTDA EPP | A aquisição, por licitação (pregão eletrônico), de Escovas, qualifica… | R$ 26.325,00 | 16/04/2027 | 161 |
| 2026002574 | UERJ | XEMEN SAUDE E TECNOLOGIA LTDA | Aquisição, por licitação (pregão eletrônico), de endoprótese para o H… | R$ 115.000,00 | 16/04/2027 | 161 |
| 2026002619 | UERJ | LABORCLIN PRODUTOS PARA LABORATORIOS LTDA | AQUISIÇÃO, POR LICITAÇÃO (PREGÃO ELETRÔNICO) DE INSUMOS POR LOTE PARA… | R$ 412.976,40 | 16/04/2027 | 161 |
| 2026003040 | UERJ | ABC FARMACEUTICO LTDA | Cabergolina CP 0,5 mg. | R$ 633,60 | 16/04/2027 | 161 |
| 2026003041 | UERJ | ASLI COMERCIAL LTDA | Aquisição de sistema arterial radial. | R$ 1.240,00 | 16/04/2027 | 161 |
| 2025001571 | UERJ | PRANALIFE PRODUTOS MÉDICOS E CIRURGICOS LTDA | A aquisição, por licitação (pregão eletrônico), de Kits de vertebropl… | R$ 13.590,00 | 17/04/2027 | 162 |
| 2026003286 | UERJ | SERRA JUNIOR ENGENHARIA S/C | A Universidade do Estado do Rio de Janeiro torna público o presente E… | R$ 7.000,00 | 17/04/2027 | 162 |
| 2026003159 | UERJ | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Amicacina 250 mg / ml sol inj amp 2 ml. | R$ 8.240,00 | 20/04/2027 | 165 |
| 2025002190 | UERJ | WM WORLD MEDICAL IMPORTACAO E EXPORTACAO LTDA | A aquisição, por licitação (pregão eletrônico), de placa volar, paraf… | R$ 633.905,00 | 24/04/2027 (PNCP) | 169 |
| 2025000050 | UERJ | ÂNCORA DISTRIBUIDORA DE MEDICAMENTOS LTDA | Aquisição de medicamentos, por licitação (pregão eletrônico), para o … | R$ 21.003,84 | 25/04/2027 | 170 |
| 2025002176 | UERJ | MOGAMI IMPORTAÇÃO E EXPORTAÇÃO LTDA | Contratação de serviço de locação de equipamento para videolaparoscop… | R$ 676.920,00 | 25/04/2027 (PNCP) | 170 |
| 2026003222 | UERJ | ARCESP SEGURADORA SA | Contratação de empresa especializada para prestação de seguro de vida… | R$ 592,61 | 27/04/2027 | 172 |
| 2025002207 | UERJ | GF LABOR COMERCIO E REPRESENTAÇÃO LTDA | A aquisição, por licitação (pregão eletrônico), de sistema de drenage… | R$ 64.602,00 | 28/04/2027 | 173 |
| 2025002610 | UERJ | VYTTRA DIAGNOSTICOS S.A | AQUISIÇÃO DE REAGENTES, PELO MENOR PREÇO GLOBAL POR LOTE, COM A CESSÃ… | R$ 3.396.240,00 | 28/04/2027 (PNCP) | 173 |
| 2026001845 | UERJ | BRSIL CONSULTORIA E PROMOCOES EIRELI | Aquisição, por licitação (pregão eletrônico), de implantes mamários d… | R$ 63.000,00 | 28/04/2027 | 173 |
| 2026002414 | UERJ | VIBEMED COMERCIO E REPRESENTAÇÃO LTDA ME | Aquisição, por licitação (pregão eletrônico), de kits de monitorizaçã… | R$ 275.010,00 | 28/04/2027 | 173 |
| 2026002424 | UERJ | I11 COMERCIO DE MATERIAIS HOSPITALARES LTDA | Aquisição, por licitação (pregão eletrônico), de cimentos ortopédicos… | R$ 8.399,00 | 28/04/2027 | 173 |
| 2026002425 | UERJ | PUBLIX HOSPITALAR COMÉRCIO DE PRODUTOS MEDIO… | Aquisição, por licitação (pregão eletrônico), de cimentos ortopédicos… | R$ 226.395,00 | 28/04/2027 | 173 |
| 2026002598 | UERJ | DLW COMERCIAL DISTRIBUIDORA LTDA | A aquisição de material para o tratamento de pacientes pediátricos co… | R$ 13.998,00 | 28/04/2027 | 173 |
| 2026002599 | UERJ | HOMACC COMERCIO DE MATERIAL MEDICO HOSPITALA… | A aquisição de material para o tratamento de pacientes pediátricos co… | R$ 78.273,50 | 28/04/2027 | 173 |
| 2026002600 | UERJ | SELLMED PRODUTOS MEDICOS E HOSPITALARES LTDA | A aquisição de material para o tratamento de pacientes pediátricos co… | R$ 6.200,00 | 28/04/2027 | 173 |
| 2026002844 | UERJ | DLW COMERCIAL DISTRIBUIDORA LTDA | Aquisição por dispensa de licitação, de Gesso para o Hospital Univers… | R$ 6.240,00 | 28/04/2027 | 173 |
| 2026006643 | UERJ | ARDO DO BRASIL DISTRIBUIDORA DE PECAS E SERV… | Aquisição de Carroceria aberta de aço com tampas de alumínio para cha… | R$ 29.040,00 | 28/04/2027 | 173 |
| 2025002410 | UERJ | SAMTRONIC INDUSTRIA E COMERCIO LTDA | A aquisição, por licitação (pregão eletrônico), de equipos para bomba… | R$ 1.808.062,00 | 29/04/2027 (PNCP) | 174 |
| 2025002411 | UERJ | VIBEMED COMERCIO E REPRESENTAÇÃO LTDA ME | A aquisição, por licitação (pregão eletrônico), de equipos para bomba… | R$ 309.060,80 | 29/04/2027 | 174 |
| 2026002328 | CECIERJ | GENTE SEGURADORA S.A. | Contratação de empresa especializada na prestação de serviço de segur… | R$ 4.973,67 | 29/04/2027 | 174 |
| 2026002347 | CECIERJ | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Contratação da Imprensa Oficial do Estado do Rio de Janeiro (IOERJ) p… | R$ 157.500,00 | 30/04/2027 | 175 |
| 2025007337 | UENF | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | Contratação de empresa especializada na prestação de serviços de admi… | R$ 4.114.293,75 | 30/04/2027 (PNCP) | 175 |
| 2026002483 | UERJ | NOVA BIO INDUSTRIA E COMERCIO LTDA - EPP | Aquisição por dispensa de licitação, de coletor de urina para o Hospi… | R$ 12.177,00 | 30/04/2027 | 175 |
| 2026003340 | UERJ | BIONEFRO COMÉRCIO DE MATERIAL HOSPITALAR LTD… | Aquisição de coletor de urina. | R$ 418,00 | 30/04/2027 | 175 |
| 2026003341 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de seringas. | R$ 4.855,00 | 30/04/2027 | 175 |
| 2026003360 | UERJ | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de agulhas. | R$ 2.075,00 | 30/04/2027 | 175 |
| 2026002447 | UERJ | SCITECH PRODUTOS MEDICOS S.A | Aquisição, por licitação (pregão eletrônico), de Agulhas diversas, câ… | R$ 26.498,80 | 04/05/2027 | 179 |
| 2026002074 | UERJ | AUTO SUTURE DO BRASIL LTDA | Aquisição, por licitação (pregão eletrônico), de balão de angioplasti… | R$ 212.951,00 | 04/05/2027 | 179 |
| 2026002445 | UERJ | CEI COMERCIO EXPORTACAO E IMPORTACAO DE MATE… | Aquisição, por licitação (pregão eletrônico), de Agulhas diversas, câ… | R$ 125.962,30 | 04/05/2027 | 179 |
| 2026002446 | UERJ | PURAH MEDICAL & CO LTDA | Aquisição, por licitação (pregão eletrônico), de Agulhas diversas, câ… | R$ 15.816,40 | 04/05/2027 | 179 |
| 2026002450 | UERJ | UNIBIO DISTRIBUIDORA E SERVIÇOS LTDA | Aquisição, por licitação (pregão eletrônico), de Agulhas diversas, câ… | R$ 15.799,20 | 04/05/2027 | 179 |
| 2026002894 | UERJ | CEI COMERCIO EXPORTACAO E IMPORTACAO DE MATE… | Aquisição, por licitação (pregão eletrônico), de Filtros para o Hospi… | R$ 7.989,50 | 04/05/2027 | 179 |
| 2026002896 | UERJ | TECNYMAGEM SUPRIMENTOS HOSPITALARES LTDA-ME | Aquisição, por licitação (pregão eletrônico), de Filtros para o Hospi… | R$ 55.746,00 | 04/05/2027 | 179 |
| 2026003388 | UERJ | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de sistema fechado de aspiração traqueal. | R$ 4.016,88 | 04/05/2027 | 179 |
| 2026002814 | UERJ | DANJAC DISTRIBUIDORA LTDA. | A presente aquisição de lixeiras para a Policlínica Universitária Piq… | R$ 10.889,95 | 05/05/2027 | 180 |
| 2026002816 | UERJ | LC LOG REPRESENTACOES COMERCIO E SERVICOS LT… | A presente aquisição de lixeiras para a Policlínica Universitária Piq… | R$ 10.943,50 | 05/05/2027 | 180 |
| 2026002817 | UERJ | GPS REPRESENTAÇOES COMERCIO E SERVIÇOS LTDA | A presente aquisição de lixeiras para a Policlínica Universitária Piq… | R$ 12.739,80 | 05/05/2027 | 180 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025001497 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Empenhamento da despesa com o pessoal contratado do projeto | R$ 29.348.417,30 | 11/03/2026 (PNCP) | -240 |
| 2021007476 | CECIERJ | CNS NACIONAL DE SERVIÇOS LTDA | Prevê-se com esta prestação de serviço a garantia da oferta de apoio … | R$ 28.082.435,15 | 02/03/2025 | -614 |
| 2022002255 | CECIERJ | HAWK SEGURANÇA E VIGILÂNCIA LTDA | Contratação de empresa prestadora de serviço terceirizados, devidamen… | R$ 26.817.159,91 | 06/04/2026 | -214 |
| 2024005287 | UERJ | SAVVY SERVIÇOS LTDA | Contratação emergencial de empresa especializada em Prestação de serv… | R$ 19.882.483,44 | 11/07/2025 (PNCP) | -483 |
| 2024005775 | FAETEC | COMERCIAL MILANO BRASIL LTDA | Contratação de Empresa especializada, devidamente regularizada para o… | R$ 19.652.647,04 | 23/07/2025 (PNCP) | -471 |
| 2024005128 | FAETEC | COMERCIAL MILANO BRASIL LTDA | Contratação de Empresa especializada, devidamente regularizada para o… | R$ 16.402.963,47 | 04/07/2025 (PNCP) | -490 |
| 2025000978 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Resolução Conjunta SEDSODH 161 DE 16/01/2025 - RIOLGBT+ | R$ 15.400.000,00 | 19/04/2025 (PNCP) | -566 |
| 2025003042 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Descentalização para o projeto Manutenção da Capacidade de Assistênci… | R$ 14.742.000,00 | 07/05/2026 (PNCP) | -183 |
| 2023004139 | CECIERJ | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | O presente Termo de Referência tem por objeto o Registro de Preços pa… | R$ 13.367.650,00 | 13/07/2025 | -481 |
| 2024008760 | FAETEC | ERMAR ALIMENTOS LTDA | Contratação de Empresa especializada, devidamente regularizada para o… | R$ 11.110.047,51 | 28/10/2025 (PNCP) | -374 |
| 2025001875 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Portaria Conjunta DER/UERJ nº 36 de 22/01/2025 | R$ 10.421.779,84 | 27/05/2025 (PNCP) | -528 |
| 2025003048 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Descentralização para os projetos Atenção à Saúde do Homem e Centro d… | R$ 9.731.328,00 | 07/03/2026 (PNCP) | -244 |
| 2025003106 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Descentralização para o projeto Pró-Saúde Cardiovascular | R$ 9.083.520,00 | 10/02/2026 (PNCP) | -269 |
| 2025003138 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Descentralização para o Projeto Assistência Integral Multidisciplinar | R$ 9.077.720,00 | 06/02/2026 (PNCP) | -273 |
| 2025001313 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Portaria Conjunta FIA/UERJ nº 35 de 21 de Fevereiro de 2025 - Projeto… | R$ 8.859.761,54 | 12/05/2025 (PNCP) | -543 |
| 2023003296 | CECIERJ | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Este termo de referência reúne o conjunto de informações necessárias … | R$ 8.612.147,40 | 30/08/2026 | -68 |
| 2019004668 | UERJ | APPROACH TECNOLOGIA LTDA | Aquisição de servidor de rede. | R$ 7.560.512,00 | 03/12/2024 | -703 |
| 2025003807 | UERJ | GRUPO ARCO IRIS DE CONSCIENTIZACAO HOMOSSEXU… | Cooperação Técnica junto ao Grupo Arco-Íris de Cidadania LGBTI+, para… | R$ 7.495.010,90 | 28/02/2026 (PNCP) | -251 |
| 2025005010 | FAPERJ | MMAR MONTAGENS EVENTOS E PROGRAMACAO VISUAL … | Contratação de Empresa de Eventos com a finalidade da participação da… | R$ 6.867.504,00 | 07/09/2025 (PNCP) | -425 |
| 2026004749 | FAPERJ | FUNDAÇÃO EUCLIDES DA CUNHA DE APOIO INSTITUC… | Viabilizar a contratação, por inexigibilidade de licitação, da FUNDAC… | R$ 6.584.450,00 | 18/10/2026 (PNCP) | -19 |
| 2025003073 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Descentralização dos projetos Cirurgia Ortopédica de Média Complexida… | R$ 6.560.136,00 | 04/05/2026 (SIGA, diverge do PNCP) | -186 |
| 2024006397 | UERJ | BASE MONTAGENS E SERVIÇOS PROMOCIONAIS LTDA | Locação de área para exposição para participação na Rio Innovation We… | R$ 6.510.400,00 | 13/11/2024 (PNCP) | -723 |
| 2024004072 | UERJ | SAVVY SERVIÇOS LTDA | Contratação emergencial para produção e distribuição das seguinte ref… | R$ 6.457.548,00 | 04/06/2025 (PNCP) | -520 |
| 2024005767 | FAETEC | COMERCIAL MILANO BRASIL LTDA | Contratação de Empresa especializada, devidamente regularizada para o… | R$ 6.365.593,49 | 24/07/2025 (PNCP) | -470 |
| 2025002711 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Resolução Conjunta do projeto Laboratório de Histocompatibilidade - H… | R$ 6.358.932,00 | 25/04/2026 (PNCP) | -195 |
| 2025001657 | UERJ | O UNIVERSITARIO REST IND COM E AGROP LTDA | Contratação de empresa para produção e distribuição das seguinte refe… | R$ 5.922.114,00 | 23/05/2026 (PNCP) | -167 |
| 2025003044 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Descentralização para o projeto Litíase Urinária | R$ 5.330.540,00 | 07/05/2026 (PNCP) | -183 |
| 2024008762 | FAETEC | R3M IMPORTACAO E DISTRIBUICAO LTDA | Contratação de Empresa especializada, devidamente regularizada para o… | R$ 5.288.964,87 | 28/10/2025 (PNCP) | -374 |
| 2025000025 | UERJ | HOSPINOVA DISTRIBUIDORA DE PRODUTOS HOSPITAL… | A aquisição de medicamentos, por licitação (pregão eletrônico), para … | R$ 5.231.800,00 | 21/02/2026 (PNCP) | -258 |
| 2025007901 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Portaria Conjunta Nº 025 FSC/UERJ, de 10/09/2025 - Projeto Mudar de V… | R$ 5.179.853,90 | 16/02/2026 (PNCP) | -263 |

_Registros mais antigos (provável falta de baixa no SIGA): 11131, R$ 1.219,6 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026007187 | FAETEC | SERVIÇO NACIONAL DE APRENDIZAGEM COMERCIAL -… | Contratação de instituição especializada em Educação Profissional e T… | R$ 209.288.851,32 | 04/09/2028 | 668 |
| 2022003948 | UERJ | SCALLE CONSTRUCOES, REFORMAS E INSTALACOES L… | CONTRATAÇÃO DE EMPRESA PARA SERVICO DE MANUTENCAOPREDIAL, COM FORNECI… | R$ 199.653.084,60 | 09/06/2027 | 215 |
| 2026000027 | UERJ | MULTSERV SEGURANÇA E VIGILANCIA PATRIMONIAL … | Contratação de empresa especializada para prestação dos serviços de V… | R$ 164.122.000,00 | 06/01/2028 | 426 |
| 2024009958 | UERJ | SOLL SERVICOS, OBRAS E LOCACOES LTDA. | Contratação de empresa prestadora de serviços de limpeza e conservaçã… | R$ 105.838.115,99 | 22/08/2030 | 1385 |
| 2026007094 | FAETEC | SERVIÇO NACIONAL DE APRENDIZAGEM INDUSTRIAL | Contratação de instituição especializada em Educação Profissional e T… | R$ 103.896.000,00 | 08/03/2028 | 488 |
| 2023006032 | CECIERJ | TAPEVAS SOLUÇÕES INTEGRADAS EIRELI | Contratação de empresa prestadora de serviços especializados de secre… | R$ 76.266.048,78 | 10/09/2027 | 308 |
| 2025003030 | UENF | FUNDAÇÃO DE DESENVOLVIMENTO DE TECNOPOLIS FU… | Prestação de serviços de apoio na gestão administrativa e financeira … | R$ 65.300.506,35 | 10/05/2027 | 185 |
| 2026000349 | UERJ | UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | Processamento de despesa - Prestadores de serviço e estagiários da UE… | R$ 54.500.000,00 | 03/02/2027 (PNCP) | 89 |
| 2026008418 | UERJ | BLUEL RJ OPERACOES EM SERVICOS E ALIMENTACAO… | Contratação de empresa especializada para prestação de serviços conti… | R$ 47.985.000,00 | 26/10/2028 | 720 |
| 2025003556 | UERJ | RESTAURANTE NOVA RODOVIA 2007 LTDA | Contratação de Prestação de serviço continuado de nutrição e alimenta… | R$ 41.168.144,16 | 23/05/2027 | 198 |
| 2022001421 | CECIERJ | CLARO S/A (FILIAL) | Contratação de serviço de acesso à internet e à rede do governo. | R$ 40.460.972,40 | 09/03/2027 | 123 |
| 2025005068 | UERJ | VR BENEFICIOS E SERVICOS DE PROCESSAMENTO IN… | Contratação a prestação de serviços contínuos de implementação,gerenc… | R$ 37.535.400,00 | 30/07/2027 | 266 |
| 2025001516 | UERJ | SGHN - HIGIENIZACAO TEXTIL E NUTRICAO HOSPIT… | A contratação de empresa especializada na prestação de serviços contí… | R$ 36.140.990,84 | 27/11/2026 (PNCP) | 21 |
| 2023000368 | CECIERJ | KRATUS TECNOLOGIA COMERCIO E SERVIÇOS LTDA | Prestação de Serviços Contínuos de Limpeza e Higienização. | R$ 35.363.302,18 | 28/02/2027 | 114 |
| 2024009959 | UERJ | MULTIPLY SERVIÇOS E MANUTENÇÃO EIRELI | Contratação de empresa prestadora de serviços de limpeza e conservaçã… | R$ 30.742.400,53 | 22/08/2030 | 1385 |
| 2026001718 | UERJ | NOVA RIO SERVIÇOS GERAIS LTDA | Trata-se do objeto deste contrato o serviço de higienização hospitala… | R$ 30.500.818,32 | 12/03/2027 (PNCP) | 126 |
| 2023000345 | CECIERJ | SCALLE CONSTRUCOES, REFORMAS E INSTALACOES L… | O presente Termo de Referência relativo ao Processo Administrativo n … | R$ 28.061.749,20 | 25/01/2027 | 80 |
| 2024007067 | UERJ | TEKNO SISTEMAS DE ENGENHARIA LTDA | De ordem do Sr. Prefeito dos Campi, o presente processo objetiva real… | R$ 25.504.923,22 | 24/09/2027 | 322 |
| 2025009911 | FAETEC | MVT EDUCACAO LTDA | Aquisição de solução pedagógica de educação financeira, composta por … | R$ 25.283.699,00 | 09/12/2026 (PNCP) | 33 |
| 2024004997 | UERJ | MULTIPLY SERVIÇOS E MANUTENÇÃO EIRELI | A contratação de empresa especializada para prestação continuada de s… | R$ 23.905.388,01 | 30/07/2027 | 266 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026006301 | UENF | FERTHYMAR EMPREENDIMENTOS E PARTICIPAÇÕES LT… | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇO CONTINUA… | R$ 8.331.042,02 | 10/08/2027 | 277 |
| 2025010188 | UERJ | ATHENAS ENGENHARIA E AUTOMACAO LTDA | Aquisição emergencial de serviço de Contratação de manutenção prevent… | R$ 82.999,92 | 15/12/2026 | 39 |
| 2026006549 | UERJ | DISTRIBUIÇÃO DE MEDICAMENTOS PAMED LTDA | Aquisição de medicamentos, por Compra Direta Emergencial, para o Hosp… | R$ 61.700,00 | 11/08/2027 | 278 |
| 2025010012 | UERJ | PROMEFARMA MEDICAMENTOS E PRODUTOS HOSPITALA… | Aquisição de medicamentos, por Compra Direta Emergencial, para o Hosp… | R$ 45.520,80 | 01/12/2026 | 25 |
| 2026004609 | UERJ | ONCOVIT DISTRIBUIDORA DE MEDICAMENTOS LTDA M… | Aquisição de medicamentos, por Compra Direta Emergencial, para o Hosp… | R$ 35.280,00 | 19/06/2027 | 225 |
| 2026005673 | UERJ | VITAL PRODUTOS HOSPITALARES LTDA | Aquisição de medicamentos, por Compra Direta Emergencial, para o Hosp… | R$ 14.000,00 | 24/07/2027 | 260 |
| 2026004598 | UERJ | PLASVIVO DISTRIBUIDORA DE ARTIGOS EM GERAL L… | Aquisição de produto químico antisséptico, por Compra Direta Emergenc… | R$ 13.464,00 | 26/12/2026 | 50 |
| 2025009826 | UERJ | COSTA CAMARGO COMERCIO DE PRODUTOS HOSPITALA… | Aquisição de medicamentos, por Compra Direta Emergencial, para o Hosp… | R$ 10.230,00 | — |  |
| 2025010397 | UERJ | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos, por Compra Direta Emergencial, para o Hosp… | R$ 1.506,00 | 05/01/2027 | 60 |

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| SCALLE CONSTRUCOES, REFORMAS E INSTALACOES LTDA | 2 | R$ 227.714.833,80 |
| SERVIÇO NACIONAL DE APRENDIZAGEM COMERCIAL - SENAC ARRJ | 1 | R$ 209.288.851,32 |
| UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO | 29 | R$ 187.056.880,50 |
| MULTSERV SEGURANÇA E VIGILANCIA PATRIMONIAL LTDA | 1 | R$ 164.122.000,00 |
| SOLL SERVICOS, OBRAS E LOCACOES LTDA. | 1 | R$ 105.838.115,99 |
| SERVIÇO NACIONAL DE APRENDIZAGEM INDUSTRIAL | 1 | R$ 103.896.000,00 |
| TAPEVAS SOLUÇÕES INTEGRADAS EIRELI | 3 | R$ 91.710.389,40 |
| FUNDAÇÃO DE DESENVOLVIMENTO DE TECNOPOLIS FUNTEC | 1 | R$ 65.300.506,35 |
| MULTIPLY SERVIÇOS E MANUTENÇÃO EIRELI | 2 | R$ 54.647.788,54 |
| BLUEL RJ OPERACOES EM SERVICOS E ALIMENTACAO LTDA | 1 | R$ 47.985.000,00 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2019002670 | CONQUISTA SERVICO E TERCEIRIZACAO DE MAO DE … | R$ 45.184.789,17 | R$ 42.743.056,63 | R$ 2.441.732,54 |
| 2016004424 | MMW IRMAOS ALIMENTOS LTDA | R$ 12.428.394,94 | R$ 10.350.106,77 | R$ 2.078.288,17 |
| 2023005170 | MEDICAL HEALTH COMERCIO SERVIÇOS E IMPORTAÇÃ… | R$ 1.448.111,60 | R$ 0,00 | R$ 1.448.111,60 |
| 2016001079 | ATMOSFERA GESTÃO E HIGIENIZAÇÃO DE TEXTEIS SA | R$ 10.164.371,34 | R$ 8.769.823,25 | R$ 1.394.548,09 |
| 2016002597 | FERTHYMAR EMPREENDIMENTOS E PARTICIPAÇÕES LT… | R$ 6.643.838,03 | R$ 5.504.444,14 | R$ 1.139.393,89 |
| 2021003561 | VINIL GESTÃO E FACILITIES LTDA | R$ 3.905.250,40 | R$ 2.871.378,90 | R$ 1.033.871,50 |
| 2018002665 | VETORSEG VIGILÂNCIA PATRIMONIAL LTDA ME | R$ 4.473.120,95 | R$ 3.503.600,27 | R$ 969.520,68 |
| 2021000006 | CNS NACIONAL DE SERVIÇOS LTDA | R$ 5.775.147,70 | R$ 4.952.232,25 | R$ 822.915,45 |
| 2021003230 | MULTIPLY SERVIÇOS E MANUTENÇÃO EIRELI | R$ 3.873.804,35 | R$ 3.165.767,58 | R$ 708.036,77 |
| 2023002931 | STRATTNER B.V. | R$ 2.724.220,75 | R$ 2.042.306,73 | R$ 681.914,02 |
| 2021003559 | VINIL GESTÃO E FACILITIES LTDA | R$ 3.002.439,57 | R$ 2.339.788,15 | R$ 662.651,42 |
| 2016003049 | TECHNIP BRASIL ENGENHARIA INSTALAÇÕES E APOI… | R$ 990.000,00 | R$ 330.000,00 | R$ 660.000,00 |
| 2021003235 | MULTIPLY SERVIÇOS E MANUTENÇÃO EIRELI | R$ 3.979.010,93 | R$ 3.363.698,08 | R$ 615.312,85 |
| 2016005732 | CONQUISTA SERVICO E TERCEIRIZACAO DE MAO DE … | R$ 2.428.364,38 | R$ 1.827.023,42 | R$ 601.340,96 |
| 2021003502 | JP CONSTRUÇÕES REFORMAS E INSTALAÇÕES EM GER… | R$ 10.587.134,15 | R$ 10.028.596,55 | R$ 558.537,60 |
| 2021003511 | VINIL GESTÃO E FACILITIES LTDA | R$ 2.261.417,85 | R$ 1.826.663,01 | R$ 434.754,84 |
| 2016001564 | ONCOVIT DISTRIBUIDORA DE MEDICAMENTOS LTDA M… | R$ 487.550,00 | R$ 55.720,00 | R$ 431.830,00 |
| 2023006264 | JF FARMA DISTRIBUIDORA DE PRODUTOS FARMACÊUT… | R$ 401.579,82 | R$ 0,00 | R$ 401.579,82 |
| 2023005394 | RPM COMERCIO DE MATERIAL HOSPITALAR LTDA | R$ 400.000,00 | R$ 0,00 | R$ 400.000,00 |
| 2023002432 | BRACOM MACAE VEICULOS S/A | R$ 384.332,00 | R$ 0,00 | R$ 384.332,00 |

## 11. Unidades incluídas neste dossiê
- CECIERJ - FUND CENTRO CIÊN EDUC SUP DISTÂN DO EST RJ
- FAETEC - CCF - FUND DE APOIO À ESCOLA TÉCNICA DO EST DO RJ
- FAPERJ - FUNDAÇÃO C.C.F. DE AMPARO À PESQUISA DO ERJ
- FENORTE - FUNDAÇÃO ESTADUAL DO NORTE-FLUMINENSE
- SECTI - SECRETARIA DE ESTADO DE CIÊNCIA TECNOLOGIA
- UENF - Univ Est do Norte Fluminense Darcy Rib
- UERJ - ADMINISTRACAO CENTRAL
- UERJ - HOSPITAL UNIVERSITÁRIO - HOSPITAL UNIVERSITARIO PEDRO ERNESTO
- UERJ-ZO - CAMPUS UERJ - ZONA OESTE
- UEZO - Centro Universitário Estadual Zona Oeste

## 12. Conjuntos de dados abertos da secretaria
- CARTA DE SERRVIÇOS SECTI 2026 (atualizado 2026-07-29): [carta-servicos-secti-2026.pdf PDF](https://dadosabertos.rj.gov.br/dataset/29dd1f5e-6ffc-40d2-a2ea-c122c22f2989/resource/ffd1eb1c-d371-429b-841c-a3988173a793/download/carta-servicos-secti-2026.pdf)
- RESOLUÇÃO SECTI  Nº 184 DE 25 DE MARÇO DE 2026. (atualizado 2026-03-25): [Resolução_SECTI_184_Aprova o Regimento … PDF](https://dadosabertos.rj.gov.br/dataset/2dce53c1-616c-489d-bbb1-5edf4309d6b0/resource/309b1f23-7d20-414c-89fc-c434c8c11837/download/resolucao_secti_184_aprova-o-regimento-interno-da-secretaria-de-estado-de-ciencia-tecnologia-e-i.pdf)
- TERMO DE COOPERAÇÃO TÉCNICA QUE ENTRE SI CELEBRAM A SEDIPAF E A SECTI. (atualizado 2025-10-30): [Termo de Cooperação Técnica que entre s… CSV](https://dadosabertos.rj.gov.br/dataset/34f7c9c8-c2d7-4315-9efa-378958597620/resource/06aae274-44d1-4c75-b59f-c78cc2da7591/download/termo-de-cooperacao-tecncia-sedipaf.csv)
- ACORDO DE COOPERAÇÃO TÉCNICA PROGRAMA HUB RJ STARTUP (atualizado 2025-08-20): [ACORDO-DE-COOPERAÇÃO-TÉCNICA-SECTI-FAPE… CSV](https://dadosabertos.rj.gov.br/dataset/d24fcaf2-9a66-4d3b-af25-9e761b4ab618/resource/5953269c-3732-4a52-ad8e-689768510a39/download/acordo-de-cooperacao-tecnica-secti-faperj-hub-rj-startup.csv)
- RESOLUÇÃO SECTI Nº 177 DE 12 DE MAIO DE 2025 (atualizado 2025-08-20): [RESOLUÇÃO-SECTI-Nº-177-DE-12-DE-MAIO-DE… CSV](https://dadosabertos.rj.gov.br/dataset/a2e0cc37-ffcc-48b0-ae21-24966edab403/resource/d6ed178f-ba07-4f9b-b41c-0cfe3c20ab87/download/resolucao-secti-n-177-de-12-de-maio-de-2025-dispoe-sobre-o-codigo-de-etica-e-conduta-profissiona.csv)
- RELATÓRIO TRIMESTRAL DE OUVIDORIA (atualizado 2025-08-14): [Relatório-trimestral-de-Ouvidoria-2025.… CSV](https://dadosabertos.rj.gov.br/dataset/0fc26b4c-c375-4880-bd2e-4a425715129b/resource/80a0e495-6567-4676-ab36-d1e5d34d036a/download/relatorio-trimestral-de-ouvidoria-2025.1-1.csv)
- RESOLUÇÃO SECTI Nº 178 DE 01 DE JULHO DE 2025 (atualizado 2025-08-12): [RESOLUCAO_SECTI_178_CRIA_COMISSAO_DE_ET… CSV](https://dadosabertos.rj.gov.br/dataset/3ea66382-a162-4b6b-a9d1-0265f2d730af/resource/8a529c33-a625-4d8c-8ff4-2fa31b94536d/download/resolucao_secti_178_cria_comissao_de_etica_e_regimento_1.csv)
- CONTRATOS SECTI 2025 (atualizado 2025-06-23): [Contratos vigentes SECTI 2025.pdf PDF](https://dadosabertos.rj.gov.br/dataset/116a5ff7-9f7e-4952-a041-3ed54028d72e/resource/90b14ab5-a7bf-48ad-a15b-5fb1b8ca217d/download/contratos-vigentes-secti-2025.pdf), [Contratos_SECTI_2025.pdf PDF](https://dadosabertos.rj.gov.br/dataset/116a5ff7-9f7e-4952-a041-3ed54028d72e/resource/16728ffe-71ce-4c8e-9ebf-cc6c647ff8d1/download/contratos_secti_2025.pdf)
- PPA SECTI (atualizado 2025-06-23): [PPA_Detalhado.pdf PDF](https://dadosabertos.rj.gov.br/dataset/07e0e691-4a9b-419b-8222-56cc720233b3/resource/247105e5-b698-4f60-a324-7ee38098a648/download/ppa_detalhado.pdf)
- LOA SECTI 2025 (atualizado 2025-06-23): [LOA_2025.pdf PDF](https://dadosabertos.rj.gov.br/dataset/59601e22-0386-47c4-b766-e06052677f27/resource/f171541e-3567-44f4-a4b3-e46094988dd6/download/loa_2025.pdf)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 6 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo (3-5 linhas)
- A reportagem relata a paralisação das obras do contrato do Governo do Estado com a Construtora Metropolitana S/A para construção de oito unidades, a rescisão unilateral em março de 2026 e a ausência de previsão de conclusão para a unidade de Tamoios. [Folha dos Lagos — obra da FAETEC em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/)
- Há alerta de financiamento da FAETEC: o MPRJ recomendou à SEEDUC regularizar repasses do Fundeb e apontou subfinanciamento, precariedade de infraestrutura e carência de profissionais; a fonte não informa cumprimento da recomendação. [MPRJ — recomendação sobre repasses do Fundeb à FAETEC](https://mprjemnuvem.mprj.mp.br/web/guest/visualizar?noticiaId=218201)
- O TCE-RJ manteve multa individual contra Caroline de Andrade Cunha por acumulação ilícita de vínculos, mas o acórdão não menciona a SECTI nem atribui responsabilidade à Secretaria. [TCE-RJ — Acórdão nº 003919/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/3919/2026)
- Em agosto de 2026, após a incorporação da pasta à estrutura de Desenvolvimento Econômico, o governo anunciou o compromisso de recriar a Secretaria de Ciência, Tecnologia e Inovação em até dez dias. Em outubro, o secretário afirmou ter sido nomeado pouco mais de um mês antes. As fontes apresentam informações sobre projetos e recursos, mas não detalham um organograma final ou um plano de transição para 2027. [Tempo Real RJ — recriação da SECTI](https://temporealrj.com/governo-do-estado-recua-e-vai-recriar-secretaria-de-ciencia-tecnologia-e-inovacao-apos-reacao-da-comunidade-cientifica/) [O Globo — projetos e estrutura da SECTI](https://oglobo.globo.com/rio/noticia/2026/10/20/vamos-entregar-uma-secretaria-pronta-para-novos-saltos-assegura-secretario-estadual-de-ciencia-e-tecnologia-do-rio-veja-seus-projetos.ghtml)

##### Alertas vermelhos
- **Obra da FAETEC sem conclusão identificada:** a reportagem informa que o contrato das oito unidades, com valor inicial de R$ 154,6 milhões, chegou a R$ 191.649.941,68 após aditivos e foi rescindido unilateralmente pela FAETEC em março de 2026; a obra de Tamoios estava abandonada desde 2024 e sem previsão de conclusão. [Folha dos Lagos — obra da FAETEC em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/)
- **Fundeb e condições de funcionamento da FAETEC:** o MPRJ recomendou à SEEDUC regularizar imediatamente os repasses e apresentar plano de regularização, medidas de transparência e providências de planejamento orçamentário; a notícia associa o quadro a problemas de infraestrutura e falta de profissionais. A fonte não confirma que a recomendação tenha sido cumprida. [MPRJ — recomendação sobre repasses do Fundeb à FAETEC](https://mprjemnuvem.mprj.mp.br/web/guest/visualizar?noticiaId=218201)
- **Pendência financeira individual perante o TCE-RJ:** Caroline de Andrade Cunha teve recurso de reconsideração negado e a multa de 2.000 UFIR-RJ foi mantida, com prazo de 15 dias após o recebimento da comunicação para recolhimento; as fontes não informam se houve pagamento. O caso é relativo a uma pessoa vinculada à FAETEC, não a uma sanção contra a SECTI. [TCE-RJ — Acórdão nº 003919/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/3919/2026)
- **Contrato educacional suspenso pelo TCE-RJ, com identificação insuficiente:** reportagem de outubro menciona a suspensão de um contrato entre o Governo do Estado e uma plataforma educacional por suspeita de irregularidades, mas não informa contrato, empresa, valor, vigência ou conteúdo da decisão; não é possível confirmar pelas fontes consultadas se a SECTI ou entidade vinculada é parte. [O Globo — projetos e estrutura da SECTI](https://oglobo.globo.com/rio/noticia/2026/10/20/vamos-entregar-uma-secretaria-pronta-para-novos-saltos-assegura-secretario-estadual-de-ciencia-e-tecnologia-do-rio-veja-seus-projetos.ghtml)

##### Contratos e serviços críticos
- **Contrato de obras da FAETEC:** assinado em dezembro de 2021 pelo Governo do Estado por meio da FAETEC e da SECTI, com a Construtora Metropolitana S/A, abrangia oito unidades e tinha valor inicial de R$ 154,6 milhões. [Folha dos Lagos — obra da FAETEC em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/)
- A reportagem informa aditivos que elevaram o valor em R$ 36.996.993,60, para R$ 191.649.941,68, aumento aproximado de 23,9%; também relata pedido da construtora de reequilíbrio econômico-financeiro, com alegação de custos adicionais de aproximadamente R$ 18 milhões. [Folha dos Lagos — obra da FAETEC em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/)
- Para a unidade de Tamoios, a reportagem informa investimento previsto de R$ 23.956.242,70 e que, segundo o site Pacto RJ, cerca de 70,97% desse valor teria sido pago à construtora; a mesma reportagem diz que a FAETEC informou ter aplicado multa de quase R$ 10 milhões à empresa. [Folha dos Lagos — obra da FAETEC em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/)
- O edital previa entrega das oito unidades em julho de 2023; foram relatadas prorrogações até junho de 2024, dezembro de 2024 e setembro de 2025, além de termo publicado em 30 de setembro de 2025 que estendeu a validade até setembro de 2026. A reportagem também informa rescisão unilateral em março de 2026, sequência que deve ser conferida nos autos e instrumentos contratuais. [Folha dos Lagos — obra da FAETEC em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/)
- Segundo a reportagem, todas as obras estavam paralisadas desde 18 de dezembro de 2024, a pedido da FAETEC; a construção de Tamoios estava abandonada desde 2024, com mais de três anos de atraso e sem previsão de conclusão. Esses relatos indicam risco de atraso na entrega de instalações, mas as fontes não confirmam interrupção de serviços educacionais atualmente em funcionamento. [Folha dos Lagos — obra da FAETEC em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/)
- **Plataforma educacional:** há apenas a notícia de que o TCE-RJ suspendeu contrato do Governo do Estado por suspeita de irregularidades; nada encontrado nas fontes consultadas sobre empresa, objeto detalhado, valor, vigência, órgão gestor ou situação atual do contrato. [O Globo — projetos e estrutura da SECTI](https://oglobo.globo.com/rio/noticia/2026/10/20/vamos-entregar-uma-secretaria-pronta-para-novos-saltos-assegura-secretario-estadual-de-ciencia-e-tecnologia-do-rio-veja-seus-projetos.ghtml)
- Nada encontrado nas fontes consultadas sobre contratos da SECTI com a UERJ, UENF, FAPERJ ou Cecierj que informem valores, vigências ou riscos de continuidade. [O Globo — projetos e estrutura da SECTI](https://oglobo.globo.com/rio/noticia/2026/10/20/vamos-entregar-uma-secretaria-pronta-para-novos-saltos-assegura-secretario-estadual-de-ciencia-e-tecnologia-do-rio-veja-seus-projetos.ghtml) [Relatório parcial de gestão 2024-2025 da UERJ](https://www.uerj.br/wp-content/uploads/2026/10/Relatorio-de-Gestao-Documento-final.pdf)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)
- **TCE-RJ — caso individual ligado à FAETEC:** em 29/09/2025, o Plenário rejeitou as razões de defesa de Caroline de Andrade Cunha e aplicou multa de R$ 9.501,60, equivalente então a 2.000 UFIR-RJ/2024; em 09/02/2026, negou provimento ao recurso e determinou comunicação para recolhimento da multa atualizada em 15 dias do recebimento. [TCE-RJ — Acórdão nº 003919/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/3919/2026)
- O TCE-RJ considerou demonstrada acumulação ilícita de quatro vínculos públicos entre novembro de 2021 e junho de 2022 e registrou declaração inverídica sobre vínculos quando a interessada assumiu novo cargo na Prefeitura de Barra Mansa; o acórdão não menciona a SECTI nem aponta responsabilidade institucional da Secretaria. [TCE-RJ — Acórdão nº 003919/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/3919/2026)
- **MPRJ — Fundeb:** a 2ª Promotoria de Justiça de Tutela Coletiva de Proteção à Educação da Capital expediu recomendação à SEEDUC para regularizar repasses do Fundeb à FAETEC, apresentar plano para regularizar o fluxo, adotar transparência ativa e assegurar planejamento orçamentário; trata-se de recomendação, e a fonte não relata decisão judicial nem seu cumprimento. [MPRJ — recomendação sobre repasses do Fundeb à FAETEC](https://mprjemnuvem.mprj.mp.br/web/guest/visualizar?noticiaId=218201)
- O MPRJ relata investigação sobre ausência de repasses regulares e proporcionais do Fundeb à FAETEC e associa o quadro a precariedade de infraestrutura, carência de professores e insuficiência de profissionais de apoio; a notícia não informa valores de repasses, período exato, resposta da SEEDUC ou desfecho da apuração. [MPRJ — recomendação sobre repasses do Fundeb à FAETEC](https://mprjemnuvem.mprj.mp.br/web/guest/visualizar?noticiaId=218201)
- **Judiciário:** nada encontrado nas fontes consultadas sobre ações judiciais em curso contra a SECTI ou sobre judicialização do contrato de obras da FAETEC. [Folha dos Lagos — obra da FAETEC em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/) [MPRJ — recomendação sobre repasses do Fundeb à FAETEC](https://mprjemnuvem.mprj.mp.br/web/guest/visualizar?noticiaId=218201)

##### Riscos de apagão administrativo
- Após a incorporação da SECTI à estrutura da Secretaria de Desenvolvimento Econômico, o governo se comprometeu a recriá-la em até dez dias e anunciou um comitê para estruturar o novo modelo e discutir suas atribuições. A fonte não informa o ato final, o organograma, a distribuição de competências ou a situação dos processos durante a reorganização. [Tempo Real RJ — recriação da SECTI](https://temporealrj.com/governo-do-estado-recua-e-vai-recriar-secretaria-de-ciencia-tecnologia-e-inovacao-apos-reacao-da-comunidade-cientifica/)
- Em outubro de 2026, o secretário afirmou que ainda precisava “tomar pé” de situações na FAETEC e que avaliações e ajustes haviam sido feitos antes de sua chegada; a reportagem não descreve quais ajustes, pendências ou medidas de continuidade administrativa foram formalizados. [O Globo — projetos e estrutura da SECTI](https://oglobo.globo.com/rio/noticia/2026/10/20/vamos-entregar-uma-secretaria-pronta-para-novos-saltos-assegura-secretario-estadual-de-ciencia-e-tecnologia-do-rio-veja-seus-projetos.ghtml)
- O risco de atraso na entrega das unidades da FAETEC é sustentado pelos relatos de paralisação, rescisão e ausência de previsão para Tamoios; as fontes não demonstram apagão de aulas ou fechamento de unidades em operação. [Folha dos Lagos — obra da FAETEC em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/)
- ## Riscos de apagão administrativo

O relatório da UERJ registra a regularização, em 2025, do pagamento de despesas de exercícios anteriores a 1.311 servidores inativos; informa que alguns sistemas aguardam migração e que os projetos SICT e SUPE tiveram a execução temporariamente suspensa; e contabiliza bolsas distribuídas em 2025. Esses dados não comprovam atrasos gerais de pagamentos, indisponibilidade de sistemas ou risco de interrupção de bolsas e serviços. As fontes não informam vacâncias de cargos na SECTI nem plano de transição administrativa para 01/01/2027. [O Globo — projetos e estrutura da SECTI](https://oglobo.globo.com/rio/noticia/2026/10/20/vamos-entregar-uma-secretaria-pronta-para-novos-saltos-assegura-secretario-estadual-de-ciencia-e-tecnologia-do-rio-veja-seus-projetos.ghtml) [Relatório parcial de gestão 2024-2025 da UERJ](https://www.uerj.br/wp-content/uploads/2026/10/Relatorio-de-Gestao-Documento-final.pdf)

##### Fatos recentes
- Em 07/08/2026, após reação da comunidade científica à incorporação da SECTI à Secretaria de Desenvolvimento Econômico, o governo em exercício anunciou o compromisso de recriar a pasta em até dez dias e a criação de comitê para discutir sua estrutura e atribuições. [Tempo Real RJ — recriação da SECTI](https://temporealrj.com/governo-do-estado-recua-e-vai-recriar-secretaria-de-ciencia-tecnologia-e-inovacao-apos-reacao-da-comunidade-cientifica/)
- Em reportagem publicada em 20/10/2026, Antonio Claudio da Nóbrega foi identificado como secretário, nomeado havia pouco mais de um mês; o texto informa que a diretoria da FAETEC havia sido transferida para o Centro após episódios de violência no campus de Quintino, enquanto alunos e professores continuavam no campus. [O Globo — projetos e estrutura da SECTI](https://oglobo.globo.com/rio/noticia/2026/10/20/vamos-entregar-uma-secretaria-pronta-para-novos-saltos-assegura-secretario-estadual-de-ciencia-e-tecnologia-do-rio-veja-seus-projetos.ghtml)
- Em março de 2026, a FAETEC oficializou a rescisão unilateral do contrato de construção das oito unidades; a reportagem diz que a fundação não informou o motivo da rescisão. [Folha dos Lagos — obra da FAETEC em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/)
- Em 17/04/2026, o MPRJ publicou recomendação à SEEDUC sobre regularização dos repasses do Fundeb destinados à FAETEC. [MPRJ — recomendação sobre repasses do Fundeb à FAETEC](https://mprjemnuvem.mprj.mp.br/web/guest/visualizar?noticiaId=218201)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)
- Solicitar o processo administrativo completo do contrato das oito unidades da FAETEC, incluindo contrato e aditivos, medições, pagamentos, justificativas de reequilíbrio, notificações, aplicação e eventual recurso da multa, termo de rescisão, inventário do estado das obras e plano de retomada ou conclusão. As fontes consultadas relatam valores, paralisação e rescisão, mas não apresentam esses documentos nem o destino das obras após a rescisão. [Folha dos Lagos — obra da FAETEC em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/)
- Solicitar manifestação da SECTI e da SEEDUC sobre a recomendação do MPRJ, série de repasses do Fundeb à FAETEC, critérios de distribuição, eventuais valores pendentes e plano para atender às necessidades de infraestrutura e pessoal relatadas. [MPRJ — recomendação sobre repasses do Fundeb à FAETEC](https://mprjemnuvem.mprj.mp.br/web/guest/visualizar?noticiaId=218201)
- Solicitar cópia da decisão do TCE-RJ sobre a plataforma educacional, identificação do contrato e órgão gestor, medidas de cumprimento e situação atual, pois a reportagem não fornece esses dados. [O Globo — projetos e estrutura da SECTI](https://oglobo.globo.com/rio/noticia/2026/10/20/vamos-entregar-uma-secretaria-pronta-para-novos-saltos-assegura-secretario-estadual-de-ciencia-e-tecnologia-do-rio-veja-seus-projetos.ghtml)
- Solicitar o ato de recriação da SECTI, organograma vigente, atribuições, quadro de pessoal, orçamento, contratos transferidos e plano de transição para a posse de 01/01/2027; as fontes relatam o compromisso político de recriação e a nomeação do secretário, mas não detalham esses itens. [Tempo Real RJ — recriação da SECTI](https://temporealrj.com/governo-do-estado-recua-e-vai-recriar-secretaria-de-ciencia-tecnologia-e-inovacao-apos-reacao-da-comunidade-cientifica/) [O Globo — projetos e estrutura da SECTI](https://oglobo.globo.com/rio/noticia/2026/10/20/vamos-entregar-uma-secretaria-pronta-para-novos-saltos-assegura-secretario-estadual-de-ciencia-e-tecnologia-do-rio-veja-seus-projetos.ghtml)
- Solicitar posição atualizada sobre a multa aplicada pelo TCE-RJ à interessada no processo 103.012-7/2022, inclusive comprovação de recolhimento ou cobrança, pois o acórdão fixa prazo contado do recebimento da comunicação e as fontes não informam a data de recebimento nem o pagamento. [TCE-RJ — Acórdão nº 003919/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/3919/2026)
- Nada encontrado nas fontes consultadas sobre dívidas da SECTI, contingenciamento orçamentário, ações judiciais contra a Secretaria, situação atual de contratos de universidades e entidades vinculadas ou plano de continuidade de bolsas, pesquisas e serviços; solicitar inventário atualizado diretamente à Secretaria e às entidades vinculadas. [O Globo — projetos e estrutura da SECTI](https://oglobo.globo.com/rio/noticia/2026/10/20/vamos-entregar-uma-secretaria-pronta-para-novos-saltos-assegura-secretario-estadual-de-ciencia-e-tecnologia-do-rio-veja-seus-projetos.ghtml) [Relatório parcial de gestão 2024-2025 da UERJ](https://www.uerj.br/wp-content/uploads/2026/10/Relatorio-de-Gestao-Documento-final.pdf)

##### Fontes consultadas
1. [ PDF  ACÓRDÃO Nº 003919/2026-PLENV - TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/3919/2026) — 2026-06-26
2. [RELATÓRIO PARCIAL DE GESTÃO 2024-2025](https://www.uerj.br/wp-content/uploads/2026/10/Relatorio-de-Gestao-Documento-final.pdf) — 2026-10-13
3. [Notícia - Rio de Janeiro - MPRJ em Nuvem](https://mprjemnuvem.mprj.mp.br/web/guest/visualizar?noticiaId=218201) — 2026-09-24
4. ['Vamos entregar uma secretaria pronta para novos saltos', assegura secretário estadual de Ciência e Tecnologia](https://oglobo.globo.com/rio/noticia/2026/10/20/vamos-entregar-uma-secretaria-pronta-para-novos-saltos-assegura-secretario-estadual-de-ciencia-e-tecnologia-do-rio-veja-seus-projetos.ghtml) — 2026-10-20
5. [Douglas Ruas e Dra Gabriela mantém silêncio sobre paralisação da obra da Faetec em Tamoios](https://www.folhadoslagos.com/geral/douglas-ruas-e-dra-gabriela-mantem-silencio-sobre-paralisacao-da-obra/22151/) — 2026-10-18
6. [Governo do estado recua e vai recriar Secretaria de Ciência, Tecnologia e Inovação após reação da comunidade c](https://temporealrj.com/governo-do-estado-recua-e-vai-recriar-secretaria-de-ciencia-tecnologia-e-inovacao-apos-reacao-da-comunidade-cientifica/) — 2026-08-07


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2025009153 (TOTAL PRODUTOS E SERVICOS HOSPITALARES …) vence em 06/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2025009241 (ANTIBIOTICOS DO BRASIL LTDA (FILIAL)) vence em 07/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025009249 (INJEX INDUSTRIAS CIRURGICAS LTDA) vence em 07/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2026003485 (L S RODRIGUES COMERCIO INFORMATICA LTDA) vence em 08/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025008671 (JRG DISTRIBUIDORA DE MEDICAMENTOS HOSPI…) vence em 10/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2025001497 (UNIVERSIDADE DO ESTADO DO RIO DE JANEIRO, R$ 29,3 mi) consta 'Ativo' no SIGA com fim em 11/03/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2021007476 (CNS NACIONAL DE SERVIÇOS LTDA, R$ 28,1 mi) consta 'Ativo' no SIGA com fim em 02/03/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2022002255 (HAWK SEGURANÇA E VIGILÂNCIA LTDA, R$ 26,8 mi) consta 'Ativo' no SIGA com fim em 06/04/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2024005287 (SAVVY SERVIÇOS LTDA, R$ 19,9 mi) consta 'Ativo' no SIGA com fim em 11/07/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2024005775 (COMERCIAL MILANO BRASIL LTDA, R$ 19,7 mi) consta 'Ativo' no SIGA com fim em 23/07/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
