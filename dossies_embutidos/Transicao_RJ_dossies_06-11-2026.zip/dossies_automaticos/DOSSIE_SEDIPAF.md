# Dossiê de transição — Secretaria de Estado de Desenvolvimento Regional, Interior, Pesca e Agricultura Familiar (SEDIPAF)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/sedipaf)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 8 | R$ 12.866.761,02 |
| Com vigência futura (válidos no SIGA) | 8 | R$ 12.866.761,02 |
| até 30 dias | 0 | R$ 0,00 |
| até 60 dias | 0 | R$ 0,00 |
| até 90 dias | 0 | R$ 0,00 |
| até 180 dias | 3 | R$ 11.720.736,87 |
| vencido no SIGA | 0 | R$ 0,00 |
| sem data | 0 | R$ 0,00 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 0,0 mi / R$ 0,0 mi / R$ 0,0 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- 3 contratos (R$ 11,7 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- Concentração: GRUPO SBV EMPREENDIMENTOS E PARTICIPAÇÕES detém 85% do valor vigente (1 contratos).

## 3. Vencimentos nos próximos 90 dias
_Nenhum registro._

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000677 | SEDIPAF | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | Contratação de empresa especializada na prestação de serviços de agen… | R$ 783.546,00 | 13/03/2027 (PNCP) | 127 |
| 2026000676 | SEDIPAF | AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA L… | Contratação centralizada tem como objeto a prestação dos serviços con… | R$ 37.190,87 | 18/03/2027 | 132 |
| 2026001259 | SEDIPAF | GRUPO SBV EMPREENDIMENTOS E PARTICIPAÇÕES | Contratação de empresa especializada  em regime de não exclusividade… | R$ 10.900.000,00 | 18/03/2027 (PNCP) | 132 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
_Nenhum registro._

_Registros mais antigos (provável falta de baixa no SIGA): 0, R$ 0,0 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 8)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026001259 | SEDIPAF | GRUPO SBV EMPREENDIMENTOS E PARTICIPAÇÕES | Contratação de empresa especializada  em regime de não exclusividade… | R$ 10.900.000,00 | 18/03/2027 (PNCP) | 132 |
| 2026004781 | SEDIPAF | AVANTE MARKETING E LOGÍSTICA LTDA | Locação de veículos de serviço e de representação | R$ 821.048,04 | 23/06/2029 | 960 |
| 2026000677 | SEDIPAF | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | Contratação de empresa especializada na prestação de serviços de agen… | R$ 783.546,00 | 13/03/2027 (PNCP) | 127 |
| 2026004151 | SEDIPAF | PLUXEE BENEFICIOS BRASIL S.A. | Contratação de empresa especializada na implementação, gerenciamento … | R$ 312.650,00 | 02/06/2027 | 208 |
| 2026000676 | SEDIPAF | AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA L… | Contratação centralizada tem como objeto a prestação dos serviços con… | R$ 37.190,87 | 18/03/2027 | 132 |
| 2026004453 | SEDIPAF | LEQ COMÉRCIO E SERVIÇOS AUXILIARES LTDA | Contratação de empresa especializada em serviços de fornecimento de á… | R$ 5.990,11 | 10/07/2027 | 246 |
| 2026004451 | SEDIPAF | AVANTE JF COMERCIAL LTDA | Contratação de empresa especializada em serviços de fornecimento de á… | R$ 4.176,00 | 10/07/2027 | 246 |
| 2026004452 | SEDIPAF | DISK AGUA DO FABIO LTDA | Contratação de empresa especializada em serviços de fornecimento de á… | R$ 2.160,00 | 10/07/2027 | 246 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| GRUPO SBV EMPREENDIMENTOS E PARTICIPAÇÕES | 1 | R$ 10.900.000,00 |
| AVANTE MARKETING E LOGÍSTICA LTDA | 1 | R$ 821.048,04 |
| CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTADO DO RIO DE JAN… | 1 | R$ 783.546,00 |
| PLUXEE BENEFICIOS BRASIL S.A. | 1 | R$ 312.650,00 |
| AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA LTDA | 1 | R$ 37.190,87 |
| LEQ COMÉRCIO E SERVIÇOS AUXILIARES LTDA | 1 | R$ 5.990,11 |
| AVANTE JF COMERCIAL LTDA | 1 | R$ 4.176,00 |
| DISK AGUA DO FABIO LTDA | 1 | R$ 2.160,00 |

## 10. Liquidado e ainda não pago (maiores saldos)
_Nenhum registro._

## 11. Unidades incluídas neste dossiê
- SEDIPAF - SEC. EST. DESENV. REGIONAL, INTERIOR, PESCA E AGRIC. FAMILIAR

## 12. Conjuntos de dados abertos da secretaria
- Nenhum conjunto encontrado no portal.

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 7 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo
- O Decreto nº 50.380, datado de 13/07/2026, incorporou a SEDIPAF à SEAPA e criou a Secretaria de Estado de Agricultura, Pecuária, Pesca, Abastecimento e Desenvolvimento do Interior (SEAPPADI), sem aumento de despesa, conforme o texto do decreto. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- O decreto transferiu à nova secretaria contratos, convênios, instrumentos de contratação em curso, orçamentos, bens e obrigações da SEDIPAF, mas não discrimina valores nem identifica os instrumentos transferidos. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- As fontes consultadas não registram decisões do TCE-RJ, ações do MPRJ, processos judiciais ou interrupções de serviços associados à SEDIPAF. [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca) [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- Há divergência entre as fontes sobre a forma de reorganização e o nome do órgão resultante, o que recomenda confirmar a estrutura vigente e as competências na documentação administrativa atualizada. [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca) [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)

##### Alertas vermelhos
- **Ponto confirmado para verificação imediata:** o decreto transferiu contratos vigentes e atribuiu à nova secretaria responsabilidade pelas despesas e demais obrigações correspondentes, mas as fontes não fornecem lista, valores, vencimentos ou situação de execução dos contratos. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- **Indício de pressão sobre a estrutura administrativa, sem comprovação de falha de serviço:** reportagem informa que 173 comissionados da área de agricultura foram exonerados em dois dias e estima economia de cerca de R$ 5 milhões até o fim de 2026, equivalente a R$ 780 mil por mês; a fonte não detalha os cargos ou os efeitos sobre a continuidade dos serviços. [DOC PRESS](https://docpress.inf.br/2026/07/21/couto-unifica-secretarias-de-agro-e-interior/)
- **Não há alerta confirmado de interrupção de serviços, crise, dívida específica da SEDIPAF ou irregularidade nas fontes consultadas.** [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca) [DOC PRESS](https://docpress.inf.br/2026/07/21/couto-unifica-secretarias-de-agro-e-interior/)

##### Contratos e serviços críticos
- O decreto determina a transferência para a SEAPPADI de orçamentos, bens móveis e imóveis, instrumentos de contratação em curso, contratos, convênios e instrumentos congêneres celebrados pela SEDIPAF, além das obrigações de regularização patrimonial e das despesas e demais obrigações dos contratos vigentes. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- A fonte oficial consultada não informa os valores transferidos nem identifica contratos, fornecedores, objeto, vigência, saldo, fiscal ou situação de pagamento; a reportagem do G1 também não especifica número, valor ou prazo dos contratos. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf) [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml)
- O decreto prevê atuação da secretaria resultante em agricultura, pecuária, pesca, aquicultura, abastecimento, agricultura familiar e desenvolvimento regional do interior, mas as fontes não identificam serviços específicos ameaçados de interrupção. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf) [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml)
- Para os primeiros 90 dias, a principal verificação documental derivada das lacunas das fontes é obter o inventário dos contratos e convênios transferidos, com valores, vigências, obrigações, pagamentos pendentes e responsáveis pela fiscalização; as fontes fornecidas não contêm esse inventário. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)
- **TCE-RJ:** Nada encontrado nas fontes consultadas sobre decisões, auditorias, determinações ou processos relativos à SEDIPAF ou à fusão. [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca) [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- **MPRJ:** Nada encontrado nas fontes consultadas sobre ações, procedimentos ou recomendações relativos à SEDIPAF ou à fusão. [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca)
- **Judiciário e ações judiciais:** Nada encontrado nas fontes consultadas sobre ações judiciais relacionadas à secretaria ou à reorganização. [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca)
- **Irregularidades:** Nada encontrado nas fontes consultadas que confirme irregularidades; a ausência de menções nas fontes não equivale a uma verificação abrangente dos registros de controle ou judiciais. [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca)

##### Riscos de apagão administrativo
- O decreto transfere o quadro de pessoal efetivo e comissionado da SEDIPAF à SEAPPADI e determina exonerações e nomeações de ocupantes de cargos em comissão conforme o Anexo I; isso documenta uma transição de pessoal, mas as fontes não registram falhas operacionais decorrentes dela. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- O decreto prevê criação de uma Subsecretaria de Gestão, Planejamento e Administração sem aumento de despesas e alterações na estrutura administrativa; a fonte do G1 também relata extinção de unidades, alteração de nomenclaturas e mudança de subordinação de setores. [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- Como risco a verificar, e não como ocorrência confirmada, a combinação de transferência de contratos, mudança de estrutura e alteração de ocupantes de cargos exige confirmar quem assumiu a gestão contratual, patrimonial, orçamentária e dos serviços; as fontes não identificam os responsáveis atuais por essas rotinas. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf) [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml)
- Não há informação fornecida sobre plano de continuidade, migração de sistemas, atendimento ao público, pagamentos, arquivos ou designação de responsáveis durante a reorganização. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf) [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml)

##### Fatos recentes
- O Decreto nº 50.380, datado de 13/07/2026, foi assinado pelo governador em exercício Ricardo Couto de Castro e determina que entra em vigor na data de sua publicação. O texto do decreto não informa a data efetiva de publicação; a reportagem do G1, publicada em 14/07/2026, informa que o decreto foi publicado no Diário Oficial, mas os trechos disponíveis não especificam quando. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf) [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml)
- Há divergência nas descrições: o decreto e o G1 dizem que a SEDIPAF foi incorporada à SEAPA, formando a SEAPPADI, enquanto a Agência Brasil descreve a SEDIPAF como órgão que passou a concentrar as atribuições das duas secretarias. Os trechos fornecidos não permitem confirmar a descrição atribuída ao Brasil de Fato; a divergência deve ser esclarecida com a estrutura e os atos vigentes. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf) [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca) [Brasil de Fato](https://www.brasildefato.com.br/2026/07/15/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca/)
- Agência Brasil e Brasil de Fato identificam Ricardo Augusto Rosa Mansur como comandante da secretaria reorganizada; o decreto fornecido não esclarece essa nomeação. [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca) [Brasil de Fato](https://www.brasildefato.com.br/2026/07/15/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca/) [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- DOC PRESS informa que a fusão foi oficializada no Diário Oficial de 14 de julho (sem especificar o ano) e que 173 comissionados da área de agricultura foram exonerados em dois dias; atribui à medida economia estimada de cerca de R$ 5 milhões até o fim de 2026, ou R$ 780 mil por mês. [DOC PRESS](https://docpress.inf.br/2026/07/21/couto-unifica-secretarias-de-agro-e-interior/)
- Uma notícia sobre atividade da SEDIPAF informa que os encontros “Diálogos e Conexões Regionais – Agroecologia e Produção Orgânica”, destinados a subsidiar a revisão do Pleapo, estavam previstos para 8, 9, 15 e 16 de julho em Italva e 22 e 23 de julho em Cachoeiras de Macacu. A fonte não informa se a programação foi executada nem apresenta informações sobre eventual reorganização ou absorção posterior. [Folha de Italva](https://www.folhadeitalva.com.br/2026/07/emater-rio-sedia-encontro-sobre.html)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)
- **Contratos e convênios:** pedir relação integral dos instrumentos transferidos, valores, objetos, fornecedores, vigências, saldos, pagamentos pendentes, aditivos, fiscais e eventuais riscos de descontinuidade; esses dados não constam das fontes fornecidas. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- **Orçamento e passivos:** pedir execução orçamentária transferida, obrigações vencidas e a vencer, restos a pagar e situação patrimonial, pois o decreto prevê transferência de orçamentos e obrigações, mas não discrimina valores. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf)
- **Continuidade operacional:** pedir plano de transição, responsáveis por serviços e contratos, situação de sistemas e arquivos, e registro de interrupções ou atrasos; nada disso foi encontrado nas fontes consultadas. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf) [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml)
- **Estrutura e pessoal:** pedir organograma vigente, atos de nomeação e exoneração, relação atualizada de servidores, cargos vagos e definição das competências após a fusão; as fontes descrevem a reorganização, mas não oferecem quadro atualizado completo da estrutura em vigor em 06/11/2026. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf) [DOC PRESS](https://docpress.inf.br/2026/07/21/couto-unifica-secretarias-de-agro-e-interior/)
- **Controle e litígios:** solicitar certidões e relação atualizada de processos, determinações ou auditorias do TCE-RJ, procedimentos do MPRJ e ações judiciais; nada foi encontrado sobre esses temas nas fontes consultadas. [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca)
- **Ações e programas:** pedir prestação de contas e situação atual dos programas transferidos, inclusive a execução dos encontros destinados à revisão do Pleapo, pois a fonte disponível apresenta programação prevista, não resultados ou situação posterior. [Folha de Italva](https://www.folhadeitalva.com.br/2026/07/emater-rio-sedia-encontro-sobre.html)
- **Nome e configuração oficial do órgão:** pedir os atos posteriores ao Decreto nº 50.380 e a confirmação formal da denominação, estrutura e autoridade responsável, dada a divergência entre o decreto/G1 e as descrições da Agência Brasil e do Brasil de Fato. [Decreto nº 50.380](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf) [G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) [Agência Brasil](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca) [Brasil de Fato](https://www.brasildefato.com.br/2026/07/15/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca/)

##### Fontes consultadas
1. [RJ funde secretarias de Agricultura e Desenvolvimento Regional - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/14/governo-do-rj-funde-secretarias-de-agricultura-e-desenvolvimento-regional-em-primeira-fusao-de-pastas-da-gestao-interina.ghtml) — 2026-07-14
2. [Rio de Janeiro funde secretarias de Agricultura e de Pesca](https://agenciabrasil.ebc.com.br/politica/noticia/2026-07/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca) — 2026-07-15
3. [Rio de Janeiro funde secretarias de Agricultura e de Pesca](https://www.brasildefato.com.br/2026/07/15/rio-de-janeiro-funde-secretarias-de-agricultura-e-de-pesca/) — 2026-07-15
4. [Combined PDF](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/07/DECRETO-50.380_SEAPPADI-14-07-26.pdf) — 2026-07-16
5. [Desenvolvimento Regional do Interior](https://www.rj.gov.br/sedipaf/node/723) — 2026-06-08
6. [Emater-Rio sedia Encontro Sobre Agroecologia nesta quarta-feira em Italva](https://www.folhadeitalva.com.br/2026/07/emater-rio-sedia-encontro-sobre.html) — 2026-07-07
7. [Couto unifica secretarias de Agro e Interior - DOC PRESS](https://docpress.inf.br/2026/07/21/couto-unifica-secretarias-de-agro-e-interior/) — 2026-07-21


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
3. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
4. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
5. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
6. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
