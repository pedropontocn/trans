# Dossiê de transição — Secretaria de Estado de Defesa do Consumidor (SEDCON)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/sedcon)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 327 | R$ 314.933.458,47 |
| Com vigência futura (válidos no SIGA) | 60 | R$ 181.914.163,31 |
| até 30 dias | 6 | R$ 918.669,10 |
| até 60 dias | 7 | R$ 17.583.828,47 |
| até 90 dias | 2 | R$ 111.854,40 |
| até 180 dias | 5 | R$ 4.197.248,08 |
| vencido no SIGA | 267 | R$ 133.019.295,16 |
| sem data | 4 | R$ 1.137.018,77 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 55,6 mi / R$ 23,8 mi / R$ 20,8 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2022004831 (TRIVALE INSTITUICAO DE PAGAMENTO LTDA) vence em 01/01/2027 — 56 dias — R$ 15.376.894,27. Objeto: Fornecimento de vale alimentação, na modalidade eletrônica, através de cartão m…
- Mais 6 contratos menores (R$ 0,9 mi) vencem em até 30 dias — ver seção 3.
- 19 contratos (R$ 22,8 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 78 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 63,9 mi); 1 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 189 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 69,1 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Concentração: CABERJ INTEGRAL SAÚDE S/A detém 41% do valor vigente (1 contratos).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024009764 | SEDCON | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | O objeto da pretensa contratação consiste em Serviço de Hospedagem em… | R$ 30.387,84 | 21/11/2026 | 15 |
| 2025009004 | PROCON RJ | CBD BOLHETE DIGITAL S/A | SERVICO DE FORNECIMENTO/RECARGA VALE TRANSPORTE,DESCRIÇÃO: CONTRATACA… | R$ 588.107,52 | 25/11/2026 (PNCP) | 19 |
| 2025009335 | PROCON RJ | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | aquisição de 04 (quatro) certificados digitais com tokens, sendo 03 (… | R$ 1.077,00 | 26/11/2026 | 20 |
| 2025009609 | PROCON RJ | PORTO SEGURO CIA DE SEGUROS GERAIS | Contratação de seguro total, pelo período de 01 (um) ano, para os 03 … | R$ 5.871,46 | 26/11/2026 | 20 |
| 2024009559 | SEDCON | NOVA VIDA LOCACOES LTDA | Veículo de Representação, tipo Sedan, com blindagem nível III-A | R$ 264.113,28 | 27/11/2026 | 21 |
| 2024009652 | SEDCON | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Serviços de hospedagem de mensageriaeletrônica (e-mail), inc luindo a… | R$ 29.112,00 | 05/12/2026 | 29 |
| 2024009766 | SEDCON | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Trata-se de contratação de serviços de hospedagem de servidores web (… | R$ 39.623,12 | 10/12/2026 | 34 |
| 2025009005 | PROCON RJ | RIOPAR PARTICIPAÇÕES S/A | SERVICO DE FORNECIMENTO/RECARGA VALETRANSPORTE,DESCRIÇÃO: CONTRATACAO… | R$ 615.783,17 | 11/12/2026 (PNCP) | 35 |
| 2025008190 | SEDCON | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | Contratação de empresa especializada para a Prestação de Serviços de … | R$ 76.505,40 | 15/12/2026 | 39 |
| 2025010476 | SEDCON | LECARD ADMNISTRADORA DE CARTÕES LTDA | Trata-se de consumo de saldo existente na Ata de Registro de Preços n… | R$ 53.950,00 | 16/12/2026 | 40 |
| 2022004831 | IPEM-RJ | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Fornecimento de vale alimentação, na modalidade eletrônica, através d… | R$ 15.376.894,27 | 01/01/2027 | 56 |
| 2025010873 | PROCON RJ | LECARD ADMNISTRADORA DE CARTÕES LTDA | contratação de empresa especializada para aconfecção, fornecimento e … | R$ 117.273,00 | 02/01/2027 | 57 |
| 2026000002 | PROCON RJ | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Contratação de empresa especializada naprestação de serviços de imple… | R$ 1.303.799,51 | 02/01/2027 (PNCP) | 57 |
| 2024010443 | SEDCON | CCN CENTRO DE CONVENCOES LTDA. | A presente contratação se faz necessária para preservar os veículos d… | R$ 100.800,00 | 18/01/2027 | 73 |
| 2024005882 | PROCON RJ | SMARTTRACK - MONITORAMENTO E LOGÍSTICA LTDA. | Contratação de empresa especializada no fornecimento em comodato de s… | R$ 11.054,40 | 30/01/2027 | 85 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025009811 | PROCON RJ | SEDEP  SERVIÇO DE ENTREGA DE DESPACHOS E PU… | software de acompanhamento e andamento de processos judiciais no Pode… | R$ 14.976,00 | 06/02/2027 | 92 |
| 2025005345 | IPEM-RJ | FUNDAÇÃO GETULIO VARGAS | Contratação de pessoa jurídica especializada na prestação de serviços… | R$ 42.312,00 | 13/02/2027 | 99 |
| 2023001050 | IPEM-RJ | INJET POINT COMERCIO E SERVIÇOS DE VEICULOS … | CONTRATAÇÃO DE SERVIÇOS ESPECIALIZADOS DE MANUTENÇÃO PREVENTIVA E COR… | R$ 3.560.000,08 | 01/03/2027 | 115 |
| 2024007952 | SEDCON | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | Contratação de Serviços de Gestão do Abastecimento, com utilização de… | R$ 525.960,00 | 26/03/2027 (PNCP) | 140 |
| 2026000415 | IPEM-RJ | AGUAS DO RIO 4 SPE S.A | PROVISIONAMENTO PARA O EXERCÍCIO 2026 [AGUAS DO RIO 4 SPE S.A.] | R$ 54.000,00 | 09/04/2027 | 154 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2021004801 | IPEM-RJ | INVICTA SERVICE CLEAN LTDA | prestação de serviços de copeiragem, portaria e recepção, conservação… | R$ 14.913.319,51 | 30/09/2026 | -37 |
| 2025006914 | PROCON RJ | SOS TECNOLOGIA E GESTÃO DA INFORMAÇÃO LTDA -… | Registro de preços para eventual contratação de empresa especializada… | R$ 8.000.435,84 | 07/10/2026 (PNCP) | -30 |
| 2025008687 | PROCON RJ | CENTRAL UNICA DAS FAVELAS DO RIO DE JANEIRO | Contratação, por inexigibilidade de licitação, de patrocínio instituc… | R$ 7.056.000,00 | 22/01/2026 (PNCP) | -288 |
| 2025005040 | SEDCON | A PÁGINA DISTRIBUIDORA DE LIVROS LTDA | Livro físico em formato de cartilha e colorido, com teorias e ativida… | R$ 6.796.500,00 | 13/09/2025 (PNCP) | -419 |
| 2025006575 | PROCON RJ | INSTITUTO NEMESIS DE ESTUDOS AVANCADOS EM DI… | A presente contratação destina-se à prestação de serviços por escopo,… | R$ 5.229.835,00 | 25/02/2026 (PNCP) | -254 |
| 2024005503 | PROCON RJ | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Contratação voltada a adequação do PROCON-RJ a Lei Geral de Proteção … | R$ 3.481.208,00 | 21/08/2025 | -442 |
| 2026002089 | PROCON RJ | CENTRAL UNICA DAS FAVELAS DO RIO DE JANEIRO | Participação no evento Expo Favela Innovation Rio de Janeiro 2026. | R$ 3.124.058,00 | 23/06/2026 (PNCP) | -136 |
| 2025004744 | PROCON RJ | TIMES BRASIL MEDIA LTDA | contratação, por inexigibilidade de licitação, da empresa Times Brasi… | R$ 2.210.000,00 | 02/08/2025 (PNCP) | -461 |
| 2021007218 | PROCON RJ | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | Contratação de empresa para seleção de estagiários (aplicação de prov… | R$ 1.630.976,00 | 19/12/2024 | -687 |
| 2025004730 | PROCON RJ | PPN TECNOLOGIA E INFORMÁTICA LTDA | A presente demanda visa o desenvolvimento de estudo técnicos para a b… | R$ 1.599.228,07 | 14/07/2026 (PNCP) | -115 |
| 2023010842 | PROCON RJ | INSTITUTO NEMESIS DE ESTUDOS AVANCADOS EM DI… | CAPACITAÇÃO DE SERVIDORES | R$ 970.802,40 | 28/12/2024 | -678 |
| 2021001940 | IPEM-RJ | CLARO S/A (FILIAL) | contratação de serviços de comunicação de dados de longa distância (W… | R$ 874.066,80 | 06/05/2026 | -184 |
| 2025008041 | SEDCON | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 799.877,00 | 08/10/2026 (PNCP) | -29 |
| 2024007322 | PROCON RJ | SAFE CONVERSÃO DIGITAL LTDA | Digitalização dos processos administrativos físicos circulantes e não… | R$ 664.462,50 | 01/08/2025 | -462 |
| 2025000302 | IPEM-RJ | RIOPAR PARTICIPAÇÕES S/A | Aprovisionamento do valor estimado de R$ 579.600,00 (quinhentos e set… | R$ 579.600,00 | 14/02/2026 (PNCP) | -265 |
| 2025001674 | PROCON RJ | CENTRAL UNICA DAS FAVELAS DO RIO DE JANEIRO | contratação de patrocínio para a realização do evento em comemoração … | R$ 465.000,00 | 14/04/2025 | -571 |
| 2023000372 | PROCON RJ | HADDAD RENT A CAR LOCADORA LTDA | Serviços de locação veículo automotor categoria especial 2 capacidade… | R$ 388.800,00 | 25/01/2026 | -285 |
| 2023000550 | PROCON RJ | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | Empresa especializada na prestação de serviço de Outsourcing de equip… | R$ 319.800,00 | 11/01/2026 | -299 |
| 2025000288 | IPEM-RJ | CBD BOLHETE DIGITAL S/A | Aprovisionamento de valor estimado para o exercício de 2025, CBD BILH… | R$ 302.755,20 | 25/06/2026 | -134 |
| 2025001478 | IPEM-RJ | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | PRESTAÇÃO DE SERVIÇO [IMPRENSA OFICIAL  PUBLICAÇÕES] | R$ 300.000,00 | 20/03/2026 | -231 |
| 2025005902 | IPEM-RJ | MAIS MOBI SERVICOS LTDA | Aprovisionamento para os gastos com VALE TRANSPORTE no ano de 2025  … | R$ 294.740,16 | 11/08/2026 | -87 |
| 2025000297 | IPEM-RJ | LIGHT SERVICOS DE ELETRICIDADE SA | Requisição de Prestação de Serviço, em favor de LIGHT SERVIÇOS DE ELE… | R$ 289.200,00 | 10/03/2026 | -241 |
| 2024007995 | PROCON RJ | LEVEL 33 COMERCIO E SERVICO DE TECNOLOGIA LT… | Contratação de empresa especializada para prestação de serviços e for… | R$ 270.113,58 | 10/10/2025 | -392 |
| 2023006104 | PROCON RJ | FXX SEGURANCA E TRANSPORTE DE VALORES LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇOS DE VIGI… | R$ 244.421,28 | 10/08/2025 | -453 |
| 2024005807 | PROCON RJ | RIO SHOP SERVIÇOS LTDA | Contratação de empresa prestadora de serviços de condutores de veícul… | R$ 233.010,72 | 01/10/2025 | -401 |
| 2023010623 | PROCON RJ | INTEGRAR EMPREENDIMENTOS LTDA | Prestação de serviços de recepção para contratação de 4 quatro colabo… | R$ 228.941,76 | 21/12/2024 | -685 |
| 2025004283 | PROCON RJ | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Hospedagem em Servidores Virtuais Privados (VPS) para atender as nece… | R$ 228.179,04 | 26/08/2026 | -72 |
| 2025003974 | SEDCON | 2R DATATEL TELEINFORMÁTICA LTDA | AQUISIÇÃO DE APPLIANCE FIREWALL TIPO 3 - INCLUSOS: HARDWARE, LICENCIA… | R$ 204.343,75 | 27/12/2025 | -314 |
| 2023003259 | PROCON RJ | LIBEX SERVIÇOS E LOCAÇÕES DE VEÍCULOS LTDA E… | Serviço de locação de veículos padrão descrição contratação de serviç… | R$ 186.120,00 | 15/03/2026 | -236 |
| 2025000725 | PROCON RJ | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Contratação da Imprensa Oficial do Estado do Rio de Janeiro (IOERJ) p… | R$ 150.000,00 | 12/03/2026 | -239 |

_Registros mais antigos (provável falta de baixa no SIGA): 189, R$ 69,1 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2022006086 | IPEM-RJ | CABERJ INTEGRAL SAÚDE S/A | Contratação de Operadora de Plano de Saúde | R$ 74.989.442,75 | 22/08/2027 | 289 |
| 2025001885 | PROCON RJ | CCN ADMINISTRAÇÃO E LOCAÇÃO DE BENS LTDA. | Trata-se de processo que visa a locação de imóvel para a realocação d… | R$ 17.449.892,40 | 26/03/2030 | 1236 |
| 2022004831 | IPEM-RJ | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Fornecimento de vale alimentação, na modalidade eletrônica, através d… | R$ 15.376.894,27 | 01/01/2027 | 56 |
| 2023006358 | IPEM-RJ | VELOZ TRANSRIO TRANSPORTE LTDA | Contratação de empresa especialiada em prestação de serviços de locaç… | R$ 8.403.043,68 | 12/03/2028 | 492 |
| 2025010008 | IPEM-RJ | OPUS 651 EMPREENDIMENTOS IMOBILIARIOS LTDA | Contratação de empresa especializada para a prestação de serviços de … | R$ 8.299.989,51 | 12/12/2027 | 401 |
| 2026005670 | IPEM-RJ | PLIMA VIGILANCIA E SEGURANCA PRIVADA LTDA ME | O presente tem como objetivo à contratação do serviço de vigilância p… | R$ 7.650.000,00 | 16/07/2028 (PNCP) | 618 |
| 2026008255 | IPEM-RJ | JRF MANUTENCAO E SERVICOS EIRELI ME | Prestação de serviços de portaria, conservação predial e limpeza para… | R$ 6.939.124,25 | 20/10/2028 | 714 |
| 2026007444 | PROCON RJ | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de serviços de confecção, fornecimento e administração, i… | R$ 4.926.240,00 | 24/09/2027 | 322 |
| 2023001537 | IPEM-RJ | BRS SUPRIMENTOS CORPORATIVOS S/A | CONTRATO DE PRESTAÇÃO DE SERVIÇOS CONTÍNUOS DE OUTSOURCING PARA OPERA… | R$ 4.652.684,38 | 20/03/2028 | 500 |
| 2023001050 | IPEM-RJ | INJET POINT COMERCIO E SERVIÇOS DE VEICULOS … | CONTRATAÇÃO DE SERVIÇOS ESPECIALIZADOS DE MANUTENÇÃO PREVENTIVA E COR… | R$ 3.560.000,08 | 01/03/2027 | 115 |
| 2026002735 | PROCON RJ | CONSORCIO LPM-7LAN | Atualização tecnológica da infraestrutura de redes lógicas de TI nos … | R$ 3.483.653,90 | 22/05/2029 | 928 |
| 2025007281 | IPEM-RJ | CLIMATIZACAO FRESCORPLUS REFRIGERACAO LTDA | Contratação de empresa especializada na manutenção de equipamentos de… | R$ 3.199.798,59 | 16/09/2027 | 314 |
| 2023009929 | IPEM-RJ | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | SERVICO DE FORNECIMENTO DE COMBUSTIVELDESCRICAO CONTRATACAO DE EMPRES… | R$ 2.886.264,00 | 01/07/2027 | 237 |
| 2024008399 | SEDCON | CS BRASIL FROTAS S.A. | O objeto do presente procedimento é a contratação de empresa especial… | R$ 2.097.092,75 | 08/12/2028 | 763 |
| 2024006409 | IPEM-RJ | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Contratação de empresa para o fornecimento de solução tecnológica de … | R$ 1.642.619,74 | 18/08/2027 | 285 |
| 2024003634 | SEDCON | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Contratação de SERVIÇOS DE AGENCIAMENTO DE VIAGENS, compreendendo a r… | R$ 1.620.000,00 | 21/05/2027 | 196 |
| 2026000002 | PROCON RJ | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Contratação de empresa especializada naprestação de serviços de imple… | R$ 1.303.799,51 | 02/01/2027 (PNCP) | 57 |
| 2026008236 | IPEM-RJ | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | Contratação do serviço de locação de 200 computadores e 35 notebooks … | R$ 1.238.280,00 | 20/10/2028 | 714 |
| 2023005700 | IPEM-RJ | GRUPO PREDIAL FACILITY LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM PRESTAÇÃO DE SERVIÇOS DE FORM… | R$ 1.140.169,60 | 08/08/2027 | 275 |
| 2024008400 | SEDCON | LOCADORA GRILLO E RIBEIRO LTDA | O objeto do presente procedimento é a contratação de empresa especial… | R$ 948.051,95 | 02/12/2027 (PNCP) | 391 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| CABERJ INTEGRAL SAÚDE S/A | 1 | R$ 74.989.442,75 |
| CCN ADMINISTRAÇÃO E LOCAÇÃO DE BENS LTDA. | 1 | R$ 17.449.892,40 |
| TRIVALE INSTITUICAO DE PAGAMENTO LTDA | 3 | R$ 17.059.048,43 |
| VELOZ TRANSRIO TRANSPORTE LTDA | 1 | R$ 8.403.043,68 |
| OPUS 651 EMPREENDIMENTOS IMOBILIARIOS LTDA | 1 | R$ 8.299.989,51 |
| PLIMA VIGILANCIA E SEGURANCA PRIVADA LTDA ME | 1 | R$ 7.650.000,00 |
| JRF MANUTENCAO E SERVICOS EIRELI ME | 1 | R$ 6.939.124,25 |
| LECARD ADMNISTRADORA DE CARTÕES LTDA | 3 | R$ 5.097.463,00 |
| BRS SUPRIMENTOS CORPORATIVOS S/A | 1 | R$ 4.652.684,38 |
| INJET POINT COMERCIO E SERVIÇOS DE VEICULOS EIRELI | 1 | R$ 3.560.000,08 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2017003233 | ANGELS SEGURANÇA E VIGILANCIA EIRELI | R$ 5.500.173,25 | R$ 4.540.096,63 | R$ 960.076,62 |
| 2022004831 | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | R$ 1.404.138,80 | R$ 705.682,36 | R$ 698.456,44 |
| 2018004717 | SÉRGIO CASTRO IMÓVEIS LTDA | R$ 5.640.445,25 | R$ 5.150.772,82 | R$ 489.672,43 |
| 2017004147 | FITEL SERVICE LTDA - ME | R$ 4.565.467,95 | R$ 4.081.718,04 | R$ 483.749,91 |
| 2020001238 | DISTRI THECH COMERCIO E SERVICOS EIRELI | R$ 353.630,44 | R$ 172.368,39 | R$ 181.262,05 |
| 2023001050 | INJET POINT COMERCIO E SERVIÇOS DE VEICULOS … | R$ 56.299,32 | R$ 5.985,84 | R$ 50.313,48 |
| 2023001537 | BRS SUPRIMENTOS CORPORATIVOS S/A | R$ 34.544,53 | R$ 0,00 | R$ 34.544,53 |
| 2021005389 | LIGHT SERVICOS DE ELETRICIDADE SA | R$ 133.827,62 | R$ 103.788,68 | R$ 30.038,94 |
| 2022002912 | JOAQUIM TEODORO DE PAIVA | R$ 28.624,14 | R$ 6.691,70 | R$ 21.932,44 |
| 2019006248 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 203.382,74 | R$ 183.186,20 | R$ 20.196,54 |
| 2017004054 | TRANSFORMATIO TECHNOLOGY EIRELI | R$ 468.019,33 | R$ 457.539,33 | R$ 10.480,00 |
| 2021001940 | CLARO S/A (FILIAL) | R$ 51.362,00 | R$ 43.676,00 | R$ 7.686,00 |
| 2017004012 | LOGICA TECNOLOGIA LTDA EPP | R$ 366.997,97 | R$ 359.507,97 | R$ 7.490,00 |
| 2017001998 | CLARO S/A | R$ 11.930,26 | R$ 4.722,14 | R$ 7.208,12 |
| 2019003110 | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | R$ 158.711,00 | R$ 152.208,46 | R$ 6.502,54 |
| 2017003901 | VENUS WORLD COMERCIO DE EQUIPAMENTOS E MATER… | R$ 274.482,00 | R$ 268.362,00 | R$ 6.120,00 |
| 2016003296 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 5.775,00 | R$ 0,00 | R$ 5.775,00 |
| 2016004740 | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | R$ 2.120,00 | R$ 0,00 | R$ 2.120,00 |
| 2023003259 | LIBEX SERVIÇOS E LOCAÇÕES DE VEÍCULOS LTDA E… | R$ 23.265,00 | R$ 22.768,68 | R$ 496,32 |
| 2016000262 | CLARO S/A | R$ 330,45 | R$ 268,22 | R$ 62,23 |

## 11. Unidades incluídas neste dossiê
- IPEM-RJ - INSTITUTO DE PESOS E MEDIDAS DO ESTADO DO RJ
- PROCON RJ - Proteção e Defesa do Consumidor
- SEDCON - SECRETARIA DE ESTADO DE DEFESA DO CONSUMIDOR

## 12. Conjuntos de dados abertos da secretaria
- Nenhum conjunto encontrado no portal.

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 6 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

- O principal risco financeiro e de controle identificado é a parceria de R$ 52 milhões para o Balcão do Consumidor: cerca de R$ 17 milhões já haviam sido pagos, e a segunda parcela foi suspensa cautelarmente diante de falhas documentais apontadas em auditorias. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- A fonte sobre essa parceria registra risco de execução e prestação de contas, mas não confirma interrupção dos postos ou dos serviços; a entidade afirma que as atividades e unidades estavam em funcionamento. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- Há uma representação do TCE-RJ sobre licitação do Procon-RJ para vale-refeição, estimada em R$ 880.200,00, julgada parcialmente procedente; o acórdão determinou ajustes caso o certame seja retomado ou republicado. [TCE-RJ — Acórdão nº 047887/2025-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025)
- As fontes também registram fiscalização de empresas de apostas, uma apuração de acidente envolvendo serviço de abastecimento e sindicâncias relativas a notícias sobre vazamento de informações de fiscalizações, sem demonstrar desfecho definitivo desses procedimentos. [BNLData — Procon-RJ e empresas de apostas](https://bnldata.com.br/en/procon-rj-multa-175-bets-por-infracoes-a-leis-do-consumidor-no-estado/) [O Globo — notificação à Águas do Rio](https://oglobo.globo.com/rio/noticia/2026/11/04/procon-rj-da-72-horas-para-aguas-do-rio-explicar-rompimento-de-tubulacao-que-destruiu-casas-em-iraja.ghtml) [O Brasilianista — reportagem sobre investigados e manifestação do governo](https://obrasilianista.com.br/2026/10/15/justica/biscoito-calcinha-e-tchetcheco-trindade-saiba-quem-sao-esses-e-outros-investigados-por-ligacao-com-a-mafia-dos-combustiveis/)

##### Alertas vermelhos

- **Parceria do Balcão do Consumidor:** o contrato prevê R$ 52 milhões e 20 postos; até a conclusão da auditoria, aproximadamente R$ 17 milhões haviam sido pagos, e o governador em exercício determinou a suspensão cautelar da segunda parcela. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- **Risco de controle e prestação de contas:** auditorias apontaram comprovação documental insuficiente de despesas, fragilidades de controle e monitoramento e risco potencial de desvio de finalidade e dano ao erário; a AGE registrou riscos relevantes para a execução do objeto. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- **Controvérsia sobre condenação anterior da entidade:** a reportagem informa que a organização foi condenada pelo TCE-RJ a devolver cerca de R$ 27 milhões em outro projeto; a CPASC contesta, afirmando que o processo ainda tramita e que não há decisão definitiva transitada em julgado determinando o ressarcimento. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- **Notícia de possível vazamento de informações de fiscalização:** uma reportagem atribui a investigados ligação com a chamada “Máfia dos Combustíveis” e relata suspeita de antecipação de informações sobre fiscalizações; a manifestação estadual reproduzida na matéria diz que os órgãos desconheciam vazamentos e que foram instauradas sindicâncias para apurar os fatos. As alegações não devem ser tratadas como conclusões de responsabilidade. [O Brasilianista — reportagem sobre investigados e manifestação do governo](https://obrasilianista.com.br/2026/10/15/justica/biscoito-calcinha-e-tchetcheco-trindade-saiba-quem-sao-esses-e-outros-investigados-por-ligacao-com-a-mafia-dos-combustiveis/)
- **Ocorrência recente com impacto sobre consumidores:** após rompimento de tubulação em Irajá, Sedcon e Procon-RJ notificaram a concessionária e deram prazo de 72 horas para esclarecimentos; a reportagem informa 12 imóveis alagados e interrupção de abastecimento em cerca de 25 bairros, sem afirmar que falhas de manutenção tenham sido comprovadas. [O Globo — notificação à Águas do Rio](https://oglobo.globo.com/rio/noticia/2026/11/04/procon-rj-da-72-horas-para-aguas-do-rio-explicar-rompimento-de-tubulacao-que-destruiu-casas-em-iraja.ghtml)

##### Contratos e serviços críticos

- **Balcão do Consumidor:** o contrato com a ONG Contato, posteriormente denominada Centro de Pesquisas e de Ações Sociais e Culturais (CPASC), previa R$ 52 milhões e 20 postos de atendimento; a fonte não informa número do contrato nem prazo de vigência. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- A Secretaria de Defesa do Consumidor informou que solicitou à entidade os relatórios de execução física e financeira e os comprovantes de despesas, e que os repasses permanecerão suspensos até a apresentação e análise da documentação pelos órgãos competentes. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- A CPASC afirma que executava as atividades previstas, mantinha unidades em funcionamento e havia encaminhado relatórios por meio dos Ofícios nº 140/2026 e nº 141/2026; também afirma possuir notas fiscais, contratos e comprovantes de pagamento relativos à primeira parcela. Essas são declarações da entidade, não uma validação independente apresentada na fonte. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- **Vale-refeição do Procon-RJ:** o Pregão Eletrônico nº 01/2025 tinha valor estimado de R$ 880.200,00 e foi temporariamente suspenso pelo Procon-RJ; o TCE-RJ confirmou a tutela de suspensão e julgou parcialmente procedente a representação. [TCE-RJ — Acórdão nº 047887/2025-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025)
- O TCE-RJ determinou que, caso o certame seja retomado ou republicado, o Procon-RJ conceda prazo adicional e razoável para atendimento nas regiões previstas, não exija cadastramento em marcas específicas de plataformas de delivery e reavalie o critério econômico-financeiro relativo ao índice de endividamento. [TCE-RJ — Acórdão nº 047887/2025-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025)
- **Outsourcing de impressoras da SEDCON:** a Resolução SEDCON nº 83, de 30 de janeiro de 2026, designou equipes para planejamento, contratação e fiscalização de serviços contínuos de outsourcing de impressoras; a fonte não informa valor, empresa contratada ou resultado da licitação. [PGE-RJ — Resolução SEDCON nº 83](https://cj.estrategia.com/portal/wp-content/uploads/2025/12/03083918/comissao.pdf)
- **Fiscalização de apostas:** a fonte informa que o Procon-RJ iniciou a fase de aplicação de sanções contra plataformas de apostas e que 175 empresas foram alvo de penalidades. Relaciona a atuação à Nota Técnica Conjunta nº 01/2025, que abrange publicidade enganosa ou abusiva, falta de transparência, incentivo ao endividamento, vulnerabilidade de menores e operação irregular; não informa os valores efetivamente aplicados por empresa nem o total das multas. [BNLData — Procon-RJ e empresas de apostas](https://bnldata.com.br/en/procon-rj-multa-175-bets-por-infracoes-a-leis-do-consumidor-no-estado/)
- **Serviço de abastecimento:** em 4 de novembro de 2026, Sedcon e Procon-RJ notificaram Águas do Rio para esclarecer o rompimento de tubulação e questões de assistência, ressarcimento, abastecimento e eventual abatimento nas contas; a concessionária declarou ainda não ter recebido a notificação e que responderia quando oficialmente acionada. [O Globo — notificação à Águas do Rio](https://oglobo.globo.com/rio/noticia/2026/11/04/procon-rj-da-72-horas-para-aguas-do-rio-explicar-rompimento-de-tubulacao-que-destruiu-casas-em-iraja.ghtml)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- **TCE-RJ — vale-refeição:** o processo nº 104.133-0/25 examinou representação sobre o Pregão Eletrônico nº 01/2025 do Procon-RJ; em 15/09/2025, o Plenário Virtual confirmou a tutela, julgou a representação parcialmente procedente e determinou ajustes para eventual retomada ou republicação do certame. [TCE-RJ — Acórdão nº 047887/2025-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025)
- A fonte do acórdão registra o arquivamento do processo após a decisão e as determinações; não informa se o Procon-RJ retomou ou republicou a licitação nem se comprovou o cumprimento dos ajustes. [TCE-RJ — Acórdão nº 047887/2025-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025)
- **TCE-RJ — CPASC:** a reportagem sobre a parceria do Balcão informa uma condenação anterior a devolver cerca de R$ 27 milhões, mas também registra a contestação da entidade e sua afirmação de que não há decisão definitiva transitada em julgado; é necessário obter os autos e a situação processual diretamente. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- **Judiciário e sindicâncias:** reportagem publicada em 15 de outubro de 2026 relata investigação de pessoas por possível ligação com organização criminosa e suspeita de uso ou vazamento de informações de fiscalização; a manifestação estadual diz que sindicâncias foram instauradas, mas as fontes não apresentam números, datas, resultados ou decisões judiciais finais. [O Brasilianista — reportagem sobre investigados e manifestação do governo](https://obrasilianista.com.br/2026/10/15/justica/biscoito-calcinha-e-tchetcheco-trindade-saiba-quem-sao-esses-e-outros-investigados-por-ligacao-com-a-mafia-dos-combustiveis/)
- **MPRJ:** O Balcão do Consumidor passou a ser investigado pelo Ministério Público do Estado do Rio de Janeiro, que apura possíveis irregularidades na contratação e na execução do projeto, além da destinação dos recursos públicos. O acórdão do TCE-RJ trata de representação sobre licitação do Procon-RJ e menciona o Ministério Público junto ao Tribunal de Contas (MPC/TCE-RJ), não o MPRJ. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml) [TCE-RJ — Acórdão nº 047887/2025-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025)
- **Outras ações judiciais:** Nada encontrado nas fontes consultadas sobre ações judiciais em curso contra a SEDCON ou o Procon-RJ, além das referências acima a investigação e a processo de controle externo. [O Brasilianista — reportagem sobre investigados e manifestação do governo](https://obrasilianista.com.br/2026/10/15/justica/biscoito-calcinha-e-tchetcheco-trindade-saiba-quem-sao-esses-e-outros-investigados-por-ligacao-com-a-mafia-dos-combustiveis/) [TCE-RJ — Acórdão nº 047887/2025-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025)

##### Riscos de apagão administrativo

- Nada encontrado nas fontes consultadas que confirme interrupção de postos do Balcão do Consumidor, paralisação de serviços da SEDCON ou descontinuidade administrativa; a CPASC, ao contrário, afirma que suas unidades estavam em funcionamento, embora a fonte não apresente verificação independente dessa declaração. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- A suspensão de repasses ao Balcão constitui risco de continuidade financeira a verificar nos primeiros 90 dias, mas a fonte não afirma que o serviço tenha sido interrompido. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- A contratação de outsourcing de impressoras foi objeto de resolução que designou equipes do processo e de fiscalização; como não há informação sobre resultado, contrato ou situação atual da licitação, a dependência operacional e eventual risco de descontinuidade precisam ser verificados, sem que as fontes confirmem apagão. [PGE-RJ — Resolução SEDCON nº 83](https://cj.estrategia.com/portal/wp-content/uploads/2025/12/03083918/comissao.pdf)
- A fonte do TCE-RJ não esclarece se o serviço de vale-refeição foi contratado após a suspensão do pregão; não há informação suficiente para concluir que houve interrupção do benefício. [TCE-RJ — Acórdão nº 047887/2025-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025)

##### Fatos recentes

- Em 4 de novembro de 2026, Sedcon e Procon-RJ notificaram Águas do Rio e deram prazo de 72 horas para explicações sobre o rompimento de tubulação em Irajá; a reportagem informa danos a 12 imóveis e interrupção de abastecimento em cerca de 25 bairros, mas não confirma falha de manutenção. [O Globo — notificação à Águas do Rio](https://oglobo.globo.com/rio/noticia/2026/11/04/procon-rj-da-72-horas-para-aguas-do-rio-explicar-rompimento-de-tubulacao-que-destruiu-casas-em-iraja.ghtml)
- Em 15 de outubro de 2026, uma reportagem publicou alegações sobre investigados e possível vazamento de informações de fiscalizações; a manifestação estadual reproduzida no texto informou a instauração de sindicâncias e negou conhecimento de vazamentos. [O Brasilianista — reportagem sobre investigados e manifestação do governo](https://obrasilianista.com.br/2026/10/15/justica/biscoito-calcinha-e-tchetcheco-trindade-saiba-quem-sao-esses-e-outros-investigados-por-ligacao-com-a-mafia-dos-combustiveis/)
- Em 24 de setembro de 2026, reportagem informou que o Procon-RJ iniciou a fase de aplicação de sanções contra 175 empresas de apostas e descreveu a base técnica e as categorias de infração consideradas; não informou o montante total aplicado nem o estágio individual dos processos. [BNLData — Procon-RJ e empresas de apostas](https://bnldata.com.br/en/procon-rj-multa-175-bets-por-infracoes-a-leis-do-consumidor-no-estado/)
- Em 17 de junho de 2026, foi publicada a suspensão cautelar da segunda parcela do projeto do Balcão do Consumidor, após recomendações da CGE e da AGE e apontamentos sobre documentação e prestação de contas. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)

- Solicitar o contrato integral do Balcão do Consumidor, seus aditivos, cronograma, saldo, situação da segunda parcela, relatórios de execução e prestação de contas, documentos apresentados pela CPASC e providências adotadas pela CGE, AGE, SEDCON e Procon-RJ. As fontes não informam número ou vigência do contrato nem o resultado final da análise documental. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- Solicitar os autos e a situação atual do processo do TCE-RJ referente aos cerca de R$ 27 milhões atribuídos a projeto anterior da CPASC, incluindo decisões e eventuais recursos, para esclarecer a divergência entre a reportagem e a entidade. [G1 — suspensão de repasses ao Balcão do Consumidor](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml)
- Solicitar a situação atual do pregão de vale-refeição, eventual republicação, comprovação de cumprimento das determinações do TCE-RJ e informação sobre a continuidade do benefício. A fonte não registra esses desdobramentos. [TCE-RJ — Acórdão nº 047887/2025-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025)
- Solicitar o estágio, resultado e responsáveis pelas sindicâncias mencionadas na manifestação estadual sobre possível vazamento de informações de fiscalização, bem como protocolos atuais de sigilo e controle de acesso a operações. A reportagem não informa números, datas ou resultados dos procedimentos. [O Brasilianista — reportagem sobre investigados e manifestação do governo](https://obrasilianista.com.br/2026/10/15/justica/biscoito-calcinha-e-tchetcheco-trindade-saiba-quem-sao-esses-e-outros-investigados-por-ligacao-com-a-mafia-dos-combustiveis/)
- Solicitar o resultado das notificações e do procedimento administrativo sobre o rompimento de tubulação, as respostas da concessionária, medidas de assistência e ressarcimento, e eventual aplicação de sanções; a fonte disponível relata apenas a notificação e a resposta de que a empresa ainda não a havia recebido. [O Globo — notificação à Águas do Rio](https://oglobo.globo.com/rio/noticia/2026/11/04/procon-rj-da-72-horas-para-aguas-do-rio-explicar-rompimento-de-tubulacao-que-destruiu-casas-em-iraja.ghtml)
- Solicitar valores, decisões e situação processual das multas às empresas de apostas, além da relação de processos concluídos e pendentes; a fonte não apresenta montante total ou desfecho individual. [BNLData — Procon-RJ e empresas de apostas](https://bnldata.com.br/en/procon-rj-multa-175-bets-por-infracoes-a-leis-do-consumidor-no-estado/)
- Solicitar o resultado e a situação atual da contratação de outsourcing de impressoras, incluindo empresa contratada, valor, vigência e eventual início dos serviços; esses dados não constam da resolução fornecida. [PGE-RJ — Resolução SEDCON nº 83](https://cj.estrategia.com/portal/wp-content/uploads/2025/12/03083918/comissao.pdf)
- Nada encontrado nas fontes consultadas sobre orçamento global da SEDCON, quadro de pessoal, passivos e dívidas da Secretaria, contratos além dos citados, ações do MPRJ ou plano formal de continuidade de serviços; solicitar esses dados à Secretaria para subsidiar a transição. [PGE-RJ — Resolução SEDCON nº 83](https://cj.estrategia.com/portal/wp-content/uploads/2025/12/03083918/comissao.pdf) [TCE-RJ — Acórdão nº 047887/2025-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025)

##### Fontes consultadas
1. [RJ suspende repasses a projeto de R$ 52 milhões por suspeita ... - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/17/governo-do-rj-suspende-pagamentos-de-projeto-de-r-52-milhoes-por-suspeita-de-desvio-de-dinheiro-publico.ghtml) — 2026-06-17
2. [Procon-RJ fines 175 betting companies for violating consumer laws in the state - BNLData](https://bnldata.com.br/en/procon-rj-multa-175-bets-por-infracoes-a-leis-do-consumidor-no-estado/) — 2026-09-24
3. [Procuradoria Geral do Estado](https://cj.estrategia.com/portal/wp-content/uploads/2025/12/03083918/comissao.pdf) — 2026-02-13
4. [Procon-RJ dá 72 horas para Águas do Rio explicar rompimento de tubulação que destruiu casas em Irajá](https://oglobo.globo.com/rio/noticia/2026/11/04/procon-rj-da-72-horas-para-aguas-do-rio-explicar-rompimento-de-tubulacao-que-destruiu-casas-em-iraja.ghtml) — 2026-11-04
5. [Biscoito, Calcinha e Tchetcheco Trindade; saiba quem os investigados por ligação com a Máfia dos Combustíveis](https://obrasilianista.com.br/2026/10/15/justica/biscoito-calcinha-e-tchetcheco-trindade-saiba-quem-sao-esses-e-outros-investigados-por-ligacao-com-a-mafia-dos-combustiveis/) — 2026-10-15
6. [ PDF  ACÓRDÃO Nº 047887/2025-PLENV - TCE-RJ](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/47887/2025) — 2026-06-30


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2024009764 (PRODERJ - CENTRO DE TECNOLOGIA DE INFOR…) vence em 21/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2025009004 (CBD BOLHETE DIGITAL S/A) vence em 25/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025009335 (IMPRENSA OFICIAL DO ESTADO DO RIO DE JA…) vence em 26/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2025009609 (PORTO SEGURO CIA DE SEGUROS GERAIS) vence em 26/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2024009559 (NOVA VIDA LOCACOES LTDA) vence em 27/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2021004801 (INVICTA SERVICE CLEAN LTDA, R$ 14,9 mi) consta 'Ativo' no SIGA com fim em 30/09/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2025006914 (SOS TECNOLOGIA E GESTÃO DA INFORMAÇÃO L…, R$ 8,0 mi) consta 'Ativo' no SIGA com fim em 07/10/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2025008687 (CENTRAL UNICA DAS FAVELAS DO RIO DE JAN…, R$ 7,1 mi) consta 'Ativo' no SIGA com fim em 22/01/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2025005040 (A PÁGINA DISTRIBUIDORA DE LIVROS LTDA, R$ 6,8 mi) consta 'Ativo' no SIGA com fim em 13/09/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2025006575 (INSTITUTO NEMESIS DE ESTUDOS AVANCADOS …, R$ 5,2 mi) consta 'Ativo' no SIGA com fim em 25/02/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
