# Dossiê de transição — Secretaria de Estado de Segurança Pública (SESP)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/sesp)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 152 | R$ 192.473.264,11 |
| Com vigência futura (válidos no SIGA) | 43 | R$ 86.702.615,73 |
| até 30 dias | 1 | R$ 32.264,44 |
| até 60 dias | 8 | R$ 827.554,97 |
| até 90 dias | 4 | R$ 842.682,95 |
| até 180 dias | 4 | R$ 688.959,80 |
| vencido no SIGA | 109 | R$ 105.770.648,38 |
| sem data | 8 | R$ 1.661.418,13 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 67,8 mi / R$ 26,8 mi / R$ 33,3 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Mais 1 contratos menores (R$ 0,0 mi) vencem em até 30 dias — ver seção 3.
- 15 contratos (R$ 1,7 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 36 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 12,4 mi); 0 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 73 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 93,3 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Concentração: SIG SAUER INC detém 66% do valor vigente (1 contratos).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025009740 | RIO SEGURANÇA | MARC COMÉRCIO DE MATERIAIS TECNOLOGIA E SERV… | Aquisição de equipamentos de informática, desntre os quais estaçõees … | R$ 32.264,44 | 25/11/2026 | 19 |
| 2026007468 | RIO SEGURANÇA | A4 GRAFICA E EDITORA LTDA | O presente processo tem por finalidade dar início às providências des… | R$ 38.000,00 | 10/12/2026 | 34 |
| 2025009720 | RIO SEGURANÇA | ACANTO SOLUÇÕES INTEGRADAS DE BENS E SERVIÇO… | Aquisição de equipamentos de informática, desntre os quais estaçõees … | R$ 6.300,00 | 11/12/2026 | 35 |
| 2025009739 | RIO SEGURANÇA | HIGH LEVEL COMERCIAL LTDA | Aquisição de equipamentos de informática, desntre os quais estaçõees … | R$ 35.500,00 | 11/12/2026 | 35 |
| 2025009741 | RIO SEGURANÇA | MICRO BIT INFORMATICA LTDA | Aquisição de equipamentos de informática, desntre os quais estaçõees … | R$ 195.000,00 | 11/12/2026 | 35 |
| 2025009742 | RIO SEGURANÇA | QUALYTECK TECNOLOGIA EM INFORMÁTICA LTDA | Aquisição de equipamentos de informática, desntre os quais estaçõees … | R$ 50.460,00 | 11/12/2026 | 35 |
| 2025009803 | RIO SEGURANÇA | MBM SEGURADORA S.A. | Contratação de seguro de acidentes pessoais coletivo para os estagiár… | R$ 1.204,56 | 19/12/2026 | 43 |
| 2025008353 | RIO SEGURANÇA | TAVELO COMÉRCIO E DISTRIBUIDORA LTDA | Fornecimento, instalação e comissionamento de sistema de ar-condicion… | R$ 79.338,00 | 26/12/2026 | 50 |
| 2025011013 | RIO SEGURANÇA | ZOOM TECNOLOGIA LTDA | Aquisição de Servidores (Equipamentos de TIC) para atender as necessi… | R$ 421.752,41 | 30/12/2026 | 54 |
| 2026007424 | RIO SEGURANÇA | CENTRO DE ESTUDOS E PESQUISA E DESENVOLVIMEN… | O objeto do processo é a contratação de serviço de consultoria técnic… | R$ 556.437,60 | 08/01/2027 (PNCP) | 63 |
| 2026008432 | RIO SEGURANÇA | LIRA REFORMAS E CONSTRUÇÃO LTDA | contratação de empresa especializada para instalação de 07 (sete) apa… | R$ 51.275,35 | 08/01/2027 | 63 |
| 2026004078 | RIO SEGURANÇA | SAUDAVEL SABOR DOCES E SALGADOS LTDA | Contratação de buffet para atender aos eventos do Instituto de Segura… | R$ 49.970,00 | 09/01/2027 | 64 |
| 2026008274 | RIO SEGURANÇA | INSPER INSTITUTO DE ENSINO E PESQUISA | O objeto do processo é a contratação de instituição especializada par… | R$ 185.000,00 | 16/01/2027 | 71 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026006739 | RIO SEGURANÇA | ASSOCIACAO BRASILEIRA DE EDITORES CIENTIFICOS | Afiliação do ISP à Associação Brasileira de Editores Científicos (ABE… | R$ 1.164,00 | 19/03/2027 | 133 |
| 2025008430 | SESP | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Essa contratação se fundamenta na necessidade de garantir a eficácia,… | R$ 28.238,40 | 26/03/2027 | 140 |
| 2025006432 | SESP | INSTITUTO ITER S/A | Contratação de pessoa jurídica especializada em treinamento na área d… | R$ 518.000,00 | 23/04/2027 (PNCP) | 168 |
| 2024009783 | SESP | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação direta para Contratação de empresa especializada para pre… | R$ 141.557,40 | 30/04/2027 | 175 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024008794 | SESP | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Contratação de empresa especializada na prestação de serviço de Apoio… | R$ 4.535.040,00 | 04/11/2025 | -367 |
| 2024005649 | SESP | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Contratação de empresa para o fornecimento de solução tecnológica de … | R$ 2.301.535,00 | 04/08/2025 | -459 |
| 2025004568 | RIO SEGURANÇA | PBC ADMINISTRADORA DE BENS S/A | Locação de sala comercial (um pavimento inteiro - quinto andar) em ed… | R$ 1.320.000,00 | 26/06/2026 (PNCP) | -133 |
| 2025002699 | SESP | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Contratação de prestação de serviços de implementação, gerenciamento … | R$ 1.039.840,10 | 27/06/2026 (PNCP) | -132 |
| 2024002216 | SESP | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | Adesão à Ata de Registro de Preço nº 006/2023 - Pregão Eletrônico RP … | R$ 801.716,26 | 05/11/2025 | -366 |
| 2025005163 | SESP | PPN TECNOLOGIA E INFORMÁTICA LTDA | Aquisição de microcomputadores (desktops) e computadores portáteis (n… | R$ 722.955,00 | 10/12/2025 (PNCP) | -331 |
| 2024005570 | SESP | QUANTUM13 SOLUCOES EM TECNOLOGIA LTDA | fornecimento de ativos de rede, composto de hardware e software de ge… | R$ 320.018,65 | 04/12/2024 | -702 |
| 2024002603 | SESP | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Adesão à Ata de Registro de Preço de prestação de serviços de Agência… | R$ 293.750,00 | 06/05/2025 | -549 |
| 2024003927 | RIO SEGURANÇA | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Serviços de Agenciamento deViagens | R$ 225.000,00 | 08/06/2026 | -151 |
| 2025005741 | RIO SEGURANÇA | LIGHT SERVICOS DE ELETRICIDADE SA | FORNECIMENTO DE ENERGIA ELETRICA,DESCRIÇÃO: CONTRATACAO DE EMPRESA PA… | R$ 204.000,00 | 03/10/2026 | -34 |
| 2025008405 | RIO SEGURANÇA | ALE & DAN SERVIÇOS, CONSERVAÇÃO E LIMPEZA LT… | Contratação de empresa prestadora de serviço de limpeza, higienização… | R$ 124.996,80 | 03/11/2026 | -3 |
| 2025008379 | RIO SEGURANÇA | DECO PISOS REFORMAS E REVESTIMENTOS LTDA | FORNECIMENTO E INSTALAÇÃO DE PISO VINÍLICO NA SEDE DO INSTITUTO DE SE… | R$ 112.595,00 | 20/11/2025 | -351 |
| 2022001391 | RIO SEGURANÇA | CLARO S/A (FILIAL) | Contratação de serviço de acesso à internet (INFOVIA 3.0) - ConectaRJ… | R$ 85.320,00 | 10/03/2025 | -606 |
| 2025008220 | RIO SEGURANÇA | SAUDAVEL SABOR DOCES E SALGADOS LTDA | SERVICOS DE BUFFET,DESCRIÇÃO: CONTRATACAO DE EMPRESA ESPECIALIZADA NA… | R$ 51.870,00 | 21/03/2026 | -230 |
| 2025009563 | RIO SEGURANÇA | BIRDLOG SERVICOS E COMERCIO LTDA | Contratação de empresa especializada no SERVICOS DE CARPINTARIA,DESCR… | R$ 42.900,00 | 11/03/2026 | -240 |
| 2026000113 | SESP | M.T.L. COMERCIO E REPRESENTAÇÃO LTDA | Aquisição, na modalidade Dispensa de Licitação, em sua forma eletrôni… | R$ 42.150,10 | 02/09/2026 | -65 |
| 2025009372 | RIO SEGURANÇA | FAST DECOR OBRAS, REFORMAS E CONSTRUÇÕES LTD… | Rodapés de poliestireno 480 5 cm de altura, cor branco, para 1.092,71… | R$ 32.781,57 | 11/03/2026 | -240 |
| 2026000884 | SESP | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | Contratação de empresa especializada na prestação de serviço de aquis… | R$ 26.000,00 | 18/04/2026 | -202 |
| 2025009227 | RIO SEGURANÇA | ART INTEGRA LTDA | Objeto é a aquisição de equipamentos para Estúdio de gravação, para o… | R$ 19.039,00 | 11/03/2026 | -240 |
| 2025008342 | RIO SEGURANÇA | BLUEPOINT COMÉRCIO E SERVIÇOS EM TI LTDA | Aquisição de equipamentos de rede (switches e roteador) a fim de rees… | R$ 18.941,00 | 20/11/2025 | -351 |
| 2025008357 | RIO SEGURANÇA | 55.096.997 BHEATRIZ CAMPOS DE OLIVEIRA | Aquisição de equipamentos de rede (switches e roteador) a fim de rees… | R$ 17.160,00 | 20/11/2025 | -351 |
| 2025008215 | RIO SEGURANÇA | CAMBRAIA MATERIAIS DE CONSTRUÇÃO LTDA | SERVIÇOS DE FORNECIMENTO E INSTALAÇÃO DE BANCADAS GRANITO CORUMBÁ E C… | R$ 13.517,00 | 07/01/2026 | -303 |
| 2024009903 | SESP | A2M COMERCIO E SERVICOS LTDA | Contratação é a aquisição de equipamentos eletrodomésticos para atend… | R$ 13.000,00 | 25/10/2025 | -377 |
| 2025009295 | RIO SEGURANÇA | RPAM SERVIÇOS E EQUIPAMENTOS LTDA | Objeto é a aquisição de equipamentos para Estúdio de gravação, para o… | R$ 11.029,00 | 11/03/2026 | -240 |
| 2024009904 | SESP | SEGBRASIL COMERCIO E SERVICOS LTDA | Contratação é a aquisição de equipamentos eletrodomésticos para atend… | R$ 10.719,00 | 25/10/2025 | -377 |
| 2024007789 | SESP | MIAMI-DADE POLICE DEPARTMENT (FEIN 59-600057… | contratação de empresa especializada para a capacitação dos servidore… | R$ 10.313,85 | 20/12/2024 | -686 |
| 2025010479 | RIO SEGURANÇA | ACANTO SOLUÇÕES INTEGRADAS DE BENS E SERVIÇO… | Aquisição de Teleprompter Profissional. | R$ 7.061,64 | 06/04/2026 | -214 |
| 2025004628 | RIO SEGURANÇA | BUYSOFT DO BRASIL LTDA (MATRIZ) | Aquisição de licença de software ADOBE CLOUD FOR TEAMS por 01 (um ano… | R$ 5.578,00 | 26/06/2026 | -133 |
| 2024007023 | SESP | INSTITUTO BRASILEIRO DE DIREITO ADMINISTRATI… | Contratação por INEXIGIBILIDADE, para prestação de serviços de empres… | R$ 5.100,00 | 29/06/2025 | -495 |
| 2025009300 | RIO SEGURANÇA | TEJO PARTICIPAÇÕES E SOLUÇÕES EMPRESARIAIS L… | Objeto é a aquisição de equipamentos para Estúdio de gravação, para o… | R$ 3.519,00 | 11/03/2026 | -240 |

_Registros mais antigos (provável falta de baixa no SIGA): 73, R$ 93,3 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026004752 | SESP | SIG SAUER INC | Viabilizar a aquisição de carabinas, conforme especificações e quanti… | R$ 57.362.567,17 | 16/06/2027 (PNCP) | 222 |
| 2025008053 | SESP | VERT ANALYTICS LTDA. | Aquisição de licença perpétua de Solução de Inteligência analítica in… | R$ 13.127.701,95 | 03/11/2027 | 362 |
| 2026003169 | SESP | RIKE IS INTELIGÊNCIA DE SOFTWARE LTDA | Contratação de empresa especializada para prestação de serviços de so… | R$ 3.998.304,72 | 11/05/2027 (PNCP) | 186 |
| 2026004534 | SESP | REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | Contratação de prestação de serviços de locação de veículos de repres… | R$ 2.592.000,00 | 22/12/2029 (PNCP) | 1142 |
| 2025005904 | SESP | AVANTE MARKETING E LOGÍSTICA LTDA | Contratação de serviço para a locação de veículos automotores novos d… | R$ 1.136.058,48 | 03/09/2028 (PNCP) | 667 |
| 2025007646 | RIO SEGURANÇA | IMAGEM GEOSISTEMAS E COMÉRCIO LTDA | ArcGIS Enterprise Professional Plus1 (um) Licenciamento perpétuo de u… | R$ 921.865,01 | 30/09/2027 (PNCP) | 328 |
| 2026004690 | SESP | PLUXEE BENEFICIOS BRASIL S.A. | Contratação de empresa especializada para prestação de serviços de ad… | R$ 779.984,40 | 16/10/2027 | 344 |
| 2025004112 | RIO SEGURANÇA | PLUXEE BENEFICIOS BRASIL S.A. | Contratação de empresa especializada na prestação de serviços de emis… | R$ 775.944,00 | 05/10/2027 | 333 |
| 2013009582 | SESEG | PREMIERSEG INDÚSTRIA E COMERCIO LTDA . - EPP | Aquisição de 1.000 Kits de Traje Antitumulto/trauma | R$ 663.990,00 | — |  |
| 2026007424 | RIO SEGURANÇA | CENTRO DE ESTUDOS E PESQUISA E DESENVOLVIMEN… | O objeto do processo é a contratação de serviço de consultoria técnic… | R$ 556.437,60 | 08/01/2027 (PNCP) | 63 |
| 2025002299 | SESP | CS BRASIL FROTAS S.A. | contratação de serviços de locação de veículos de serviço e de veícul… | R$ 533.313,81 | 25/08/2028 | 658 |
| 2025006432 | SESP | INSTITUTO ITER S/A | Contratação de pessoa jurídica especializada em treinamento na área d… | R$ 518.000,00 | 23/04/2027 (PNCP) | 168 |
| 2025006028 | RIO SEGURANÇA | CS BRASIL FROTAS S.A. | Locação de 04 (quatro) veículos tipo sedan compacto, flex, com quatro… | R$ 426.651,05 | 08/08/2028 | 641 |
| 2025011013 | RIO SEGURANÇA | ZOOM TECNOLOGIA LTDA | Aquisição de Servidores (Equipamentos de TIC) para atender as necessi… | R$ 421.752,41 | 30/12/2026 | 54 |
| 2025010011 | SESP | ELOAR SERVIÇOS DE COMUNICAÇÃO E MARKETING LT… | 3.1.1 Contratação de empresa especializada na prestação de serviços g… | R$ 415.000,00 | — |  |
| 2026008459 | RIO SEGURANÇA | MGS CLEAN SOLUÇÕES E SERVIÇOS LTDA | Contratação de prestação dos serviços de limpeza, higienização e cons… | R$ 395.643,75 | 03/05/2029 | 909 |
| 2026004533 | SESP | INSPECT INTELIGENCIA E TECNOLOGIA LTDA | Viabilizar a Aquisição de licença do software de reconhecimento facia… | R$ 289.739,66 | 11/09/2027 | 309 |
| 2025003667 | RIO SEGURANÇA | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | Contratação de agente de integração para intermediar a realização de … | R$ 245.738,88 | 17/09/2027 | 315 |
| 2025009741 | RIO SEGURANÇA | MICRO BIT INFORMATICA LTDA | Aquisição de equipamentos de informática, desntre os quais estaçõees … | R$ 195.000,00 | 11/12/2026 | 35 |
| 2024008911 | SESP | AVANTE MARKETING E LOGÍSTICA LTDA | O objeto do presente procedimento é a contratação de empresa especial… | R$ 189.343,08 | — |  |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| SIG SAUER INC | 1 | R$ 57.362.567,17 |
| VERT ANALYTICS LTDA. | 1 | R$ 13.127.701,95 |
| RIKE IS INTELIGÊNCIA DE SOFTWARE LTDA | 1 | R$ 3.998.304,72 |
| REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | 1 | R$ 2.592.000,00 |
| PLUXEE BENEFICIOS BRASIL S.A. | 2 | R$ 1.555.928,40 |
| AVANTE MARKETING E LOGÍSTICA LTDA | 2 | R$ 1.325.401,56 |
| CS BRASIL FROTAS S.A. | 2 | R$ 959.964,86 |
| IMAGEM GEOSISTEMAS E COMÉRCIO LTDA | 1 | R$ 921.865,01 |
| PREMIERSEG INDÚSTRIA E COMERCIO LTDA . - EPP | 1 | R$ 663.990,00 |
| CENTRO DE ESTUDOS E PESQUISA E DESENVOLVIMENTO TECNOLOGICO … | 1 | R$ 556.437,60 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2016003739 | DIGITRO TECNOLOGIA S.A | R$ 3.258.927,53 | R$ 2.990.177,08 | R$ 268.750,45 |
| 2017003810 | CLARO S/A | R$ 13.572,83 | R$ 6.031,07 | R$ 7.541,76 |
| 2017003400 | R MORAES AGÊNCIA DE TURISMO EIRELI | R$ 312.414,75 | R$ 309.693,79 | R$ 2.720,96 |
| 2016003209 | ALMA ARQUITETURA E CONSTRUÇÃO EIRELI(MATRIZ) | R$ 120.020,49 | R$ 117.605,99 | R$ 2.414,50 |
| 2018000838 | SEGURADORA LÍDER DOS CONSÓRCIOS DO SEGURO DP… | R$ 8.829,96 | R$ 8.784,41 | R$ 45,55 |
| 2016002706 | DEPARTAMENTO DE TRANSITO DO DISTRITO FEDERAL | R$ 2.497,50 | R$ 2.483,18 | R$ 14,32 |

## 11. Unidades incluídas neste dossiê
- FISED - FUNDO EST INVEST AÇÕES SEG PUB DES SOC
- RIO SEGURANÇA - Instituto de Segurança Pública - ISP
- SESEG - SECRETARIA DE ESTADO DE SEGURANÇA
- SESP - SECRETARIA DE ESTADO DE SEGURANCA PUBLICA

## 12. Conjuntos de dados abertos da secretaria
- Boletins Internos SESP (atualizado 2026-08-28): [Boletins Internos SESP - 2024 ZIP](https://dadosabertos.rj.gov.br/dataset/a29fcb1f-945d-4d05-a634-2cf027e55932/resource/d3cbaf25-0ad9-4ca6-b54f-155312974895/download/2024.zip), [Boletins Internos SESP - 2025 ZIP](https://dadosabertos.rj.gov.br/dataset/a29fcb1f-945d-4d05-a634-2cf027e55932/resource/d153bce1-040a-4c86-b89b-7545ef8f7866/download/2025.zip), [Boletins Internos SESP - 2026 1º Semest… ZIP](https://dadosabertos.rj.gov.br/dataset/a29fcb1f-945d-4d05-a634-2cf027e55932/resource/34d2cf58-4a85-467e-8f05-94a0259593e8/download/2026.zip)
- COOGEP - Pessoal e Cargos da SESP (atualizado 2026-08-26): [PESSOAL E CARGOS.csv CSV](https://dadosabertos.rj.gov.br/dataset/1f51fb20-9f79-4fd7-b5e2-eae4acee83a5/resource/aae9fff8-7cc4-4c6e-a7a4-8fe2eb2ccf7f/download/pessoal-e-cargos_v2.csv)
- SUBEXEC - Acordos e Convênios (atualizado 2026-08-26): [Acordos e Convênios XLS](https://dadosabertos.rj.gov.br/dataset/59bddae6-cd71-4c06-9661-6aec760b42a7/resource/bcb9365f-5615-496a-8763-c643fc5d26ec/download/acordos-e-convenios.xlsx)
- OUVI - Relatórios SESP de Ouvidoria e Transparência (atualizado 2026-08-26): [Relatório 1º Trimestre Ouvidoria SESP -… PDF](https://www.rj.gov.br/seguranca/sites/default/files/Arquivos_pagina/Relatorio_1%C2%BA_Trimestre_de_Gestao_com_capa.pdf), [Relatório 2º Trimestre Ouvidoria SESP -… PDF](https://www.rj.gov.br/seguranca/sites/default/files/Arquivos_pagina/Relat%C3%B3rio%202%20%C2%BA%20Trimestre%20de%20Gest%C3%A3o.pdf), [Relatório 3º Trimestre Ouvidoria SESP -… PDF](https://www.rj.gov.br/seguranca/sites/default/files/Arquivos_pagina/Relat%C3%B3rio%203%C2%BA%20Trimestre%20de%20Gest%C3%A3o.docx.pdf), [Relatório de Gestão Anual da Ouvidoria … PDF](https://dadosabertos.rj.gov.br/dataset/2a1d54ea-0e58-428f-9869-bd4ab5bcffd2/resource/938f1b5b-b401-405c-a8ca-17660df1fbeb/download/relatorio-de-gestao-anual-da-ouvidoria-da-sesp-2025.pdf)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 5 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

- A Secretaria de Estado de Segurança Pública é apresentada como protagonista do planejamento estadual de reocupação territorial, com a Grande Jacarepaguá indicada como área-piloto; o plano prevê articulação entre segurança, justiça, políticas sociais e infraestrutura. [Ofício GPGJ nº 0610](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/Oficio_GPGJ_0610.pdf)
- Há uma pendência de acompanhamento: ofício da ENASP, de 07 de novembro de 2025, solicita regulamentação conjunta com a SESP sobre comunicação de ocorrências, mas as fontes não informam se a regulamentação foi editada. [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf)
- Em 28 de outubro de 2026, as investigações das mortes de 117 pessoas na Operação Contenção continuavam em andamento; segundo a Secretaria, haviam sido concluídas até então somente as investigações dos cinco policiais mortos. [Diário do Grande ABC — Operação Contenção](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao)
- O governador eleito confirmou que manterá uma Secretaria de Segurança e adotará comando unificado das polícias Civil e Militar, mas os nomes dos responsáveis ainda não haviam sido anunciados em 3 de novembro de 2026. [G1 — Secretariado de Douglas Ruas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml)

##### Alertas vermelhos

- **Investigações em curso:** as apurações das outras 117 mortes da Operação Contenção permaneciam abertas em 28 de outubro de 2026; a Secretaria informou 242 depoimentos colhidos, 553 laudos produzidos e analisados e outros 105 exames ainda a realizar. [Diário do Grande ABC — Operação Contenção](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao)
- O Ofício nº 97/2025/ENASP pediu ao MP-RJ atualização sobre os encaminhamentos relativos à ADPF 635 e listou, como medidas a implementar segundo a decisão do STF, regulamentações conjuntas com a Secretaria de Segurança Pública do Rio de Janeiro para a comunicação imediata de ocorrências de letalidade e vitimização policiais e de casos de homicídio consumado de agentes de segurança e de mortes decorrentes de intervenção policial, entre outros procedimentos. O documento não informa se houve resposta ou implementação. [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf)

##### Contratos e serviços críticos

- **Nada encontrado nas fontes consultadas** sobre números de contratos, fornecedores, valores, vigências ou riscos de interrupção de serviços contratados pela SESP. [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf) [MPRJ — Reunião sobre câmeras corporais](https://www.mprj.mp.br/visualizar?noticiaId=243402) [G1 — Secretariado de Douglas Ruas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml)
- A política de câmeras corporais estava em discussão para regulamentação em reunião promovida pela SESP em 07 de outubro de 2026, com participação do GAESP/MPRJ; a fonte não informa contratos, cronograma de implantação ou situação de fornecimento dos equipamentos. [MPRJ — Reunião sobre câmeras corporais](https://www.mprj.mp.br/visualizar?noticiaId=243402)
- O Programa de Assistência à Saúde Mental das polícias Civil e Militar foi regulamentado pela Resolução Conjunta SESP/SEPOL/SEPM nº 18, de 23 de março de 2026, que prevê serviço psicossocial permanente e contínuo, protocolos, avaliação pós-incidente crítico, sigilo, capacitações e análise de dados; as fontes não confirmam o nível atual de oferta ou sua continuidade operacional. [Ofício GPGJ nº 0610](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/Oficio_GPGJ_0610.pdf)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- **TCE-RJ:** nada encontrado nas fontes consultadas sobre decisões, auditorias, determinações ou processos do Tribunal relacionados à SESP. [MPRJ — Reunião sobre câmeras corporais](https://www.mprj.mp.br/visualizar?noticiaId=243402) [Diário do Grande ABC — Operação Contenção](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao)
- **MPRJ/ENASP:** o Ofício nº 97/2025/ENASP solicita regulamentação conjunta sobre comunicação imediata ao Ministério Público de ocorrências de letalidade e vitimização policial, homicídios de agentes no exercício ou em decorrência da função, mortes decorrentes de intervenção policial, inquéritos e procedimentos de corregedorias; a fonte não confirma a edição da regulamentação. [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf)
- **Operação Contenção:** segundo nota da Secretaria reproduzida pela reportagem, as apurações das mortes estavam a cargo da Polícia Civil e do MPRJ e continuavam em andamento, exceto as investigações dos cinco policiais mortos, que já haviam sido concluídas. [Diário do Grande ABC — Operação Contenção](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao)
- **Judiciário:** as fontes mencionam a ADPF 635 e um plano estadual apresentado ao STF, mas não detalham ações judiciais, decisões pendentes ou prazos específicos contra a SESP. [Ofício GPGJ nº 0610](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/Oficio_GPGJ_0610.pdf) [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf)

##### Riscos de apagão administrativo

- **Nada encontrado nas fontes consultadas** que confirme risco de interrupção de serviços, crise de caixa, dívidas, contratos prestes a vencer ou descontinuidade operacional da SESP. [MPRJ — Reunião sobre câmeras corporais](https://www.mprj.mp.br/visualizar?noticiaId=243402) [Diário do Grande ABC — Operação Contenção](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao) [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf)
- A notícia de 3 de novembro de 2026 informa que o novo governo começará em janeiro de 2027 e que os nomes responsáveis pela área de segurança ainda seriam anunciados, mas não apresenta detalhes de uma transição específica da Secretaria. [G1 — Secretariado de Douglas Ruas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml)
- Para reduzir incerteza nos primeiros 90 dias, solicitar à Secretaria inventário de contratos e vencimentos, mapa de serviços críticos e seus planos de continuidade, situação financeira e relação de recomendações ou processos de controle; esses dados não aparecem nas fontes consultadas. [MPRJ — Reunião sobre câmeras corporais](https://www.mprj.mp.br/visualizar?noticiaId=243402) [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf)

##### Fatos recentes

- Em 07 de outubro de 2026, o GAESP/MPRJ participou de discussão promovida pela SESP sobre a regulamentação da política pública de câmeras corporais; a participação foi apresentada como contribuição do Ministério Público no âmbito do controle externo da atividade policial. [MPRJ — Reunião sobre câmeras corporais](https://www.mprj.mp.br/visualizar?noticiaId=243402)
- Em 28 de outubro de 2026, a Secretaria informou que as investigações das 117 mortes da Operação Contenção prosseguiam na Delegacia de Homicídios da Capital. Nos últimos 12 meses, foram colhidos 242 depoimentos e produzidos e analisados 553 laudos, e ainda seriam realizados outros 105 exames. [Diário do Grande ABC — Operação Contenção](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao)
- Em 03 de novembro de 2026, o governador eleito Douglas Ruas confirmou que manterá uma Secretaria de Segurança, com as polícias Civil e Militar subordinadas ao secretário em modelo de comando unificado; os nomes ainda seriam anunciados. [G1 — Secretariado de Douglas Ruas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml)
- O Ofício GPGJ nº 0610 está datado de 11 de maio de 2026 e relata que o Estado indicou a Grande Jacarepaguá como área-piloto para o plano de reocupação territorial, com previsão de participação social no Gabinete Integrado de Gestão Territorial. [Ofício GPGJ nº 0610](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/Oficio_GPGJ_0610.pdf)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)

- Solicitar relação completa de contratos da SESP, com objeto, fornecedor, valor, vigência, aditivos, pagamentos pendentes e riscos de descontinuidade, pois esses dados não foram encontrados nas fontes consultadas. [MPRJ — Reunião sobre câmeras corporais](https://www.mprj.mp.br/visualizar?noticiaId=243402) [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf)
- Solicitar decisões, auditorias, recomendações e processos do TCE-RJ que afetem a Secretaria, pois nada sobre esses itens foi encontrado nas fontes consultadas. [MPRJ — Reunião sobre câmeras corporais](https://www.mprj.mp.br/visualizar?noticiaId=243402) [Diário do Grande ABC — Operação Contenção](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao)
- Solicitar o status da regulamentação pedida pela ENASP em 2025, incluindo eventual ato conjunto, responsáveis e fluxo de comunicação ao MPRJ, pois o ofício fornecido registra a solicitação, mas não seu desfecho. [Ofício nº 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf)
- Solicitar situação atual, cronograma e resultados das investigações das mortes da Operação Contenção, pois a informação disponível tem como referência a publicação de 28 de outubro de 2026. [Diário do Grande ABC — Operação Contenção](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao)
- Solicitar dados de execução e continuidade do Pro-Saúde Mental e da política de câmeras corporais, incluindo cobertura, capacidade operacional, protocolos vigentes e necessidades de contratação, pois as fontes descrevem normas e discussões, mas não comprovam o nível atual de implementação. [Ofício GPGJ nº 0610](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/Oficio_GPGJ_0610.pdf) [MPRJ — Reunião sobre câmeras corporais](https://www.mprj.mp.br/visualizar?noticiaId=243402)
- Solicitar plano de transição da SESP, organograma atualizado, responsáveis por serviços e contratos e agenda dos primeiros 90 dias, pois a notícia sobre o governo eleito não detalha a transição da Secretaria. [G1 — Secretariado de Douglas Ruas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml)

##### Fontes consultadas
1. [ PDF  OFÍCIO - Conselho Nacional do Ministério Público](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/Oficio_GPGJ_0610.pdf) — 2026-09-15
2. [GAESP/MPRJ discute acesso direto a dados da Polícia Civil, comunicação de operações policiais e regras para câ](https://www.mprj.mp.br/visualizar?noticiaId=243402) — 2026-11-05
3. [ONG internacional aponta falhas na investigação da Operação Contenção - Diário do Grande ABC](https://www.dgabc.com.br/rodadadepalestras/Noticia/4365507/ong-internacional-aponta-falhas-na-investigacao-da-operacao-contencao) — 2026-11-05
4. [OFÍCIO n° 97/2025/ENASP](https://www.cnmp.mp.br/portal/images/Presidencia/adpf-635/documentos/SEI_1257464_Oficio_97.pdf) — 2026-09-18
5. [Douglas Ruas apresenta primeiros nomes do secretariado no ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml) — 2026-11-03


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2025009740 (MARC COMÉRCIO DE MATERIAIS TECNOLOGIA E…) vence em 25/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2026007468 (A4 GRAFICA E EDITORA LTDA) vence em 10/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025009720 (ACANTO SOLUÇÕES INTEGRADAS DE BENS E SE…) vence em 11/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2025009739 (HIGH LEVEL COMERCIAL LTDA) vence em 11/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025009741 (MICRO BIT INFORMATICA LTDA) vence em 11/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2024008794 (EXTREME DIGITAL CONSULTORIA E REPRESENT…, R$ 4,5 mi) consta 'Ativo' no SIGA com fim em 04/11/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2024005649 (EVERY TI TECNOLOGIA & INOVAÇÃO LTDA, R$ 2,3 mi) consta 'Ativo' no SIGA com fim em 04/08/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2025004568 (PBC ADMINISTRADORA DE BENS S/A, R$ 1,3 mi) consta 'Ativo' no SIGA com fim em 26/06/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2025002699 (TRIVALE INSTITUICAO DE PAGAMENTO LTDA, R$ 1,0 mi) consta 'Ativo' no SIGA com fim em 27/06/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2024002216 (PRIME CONSULTORIA E ASSESSORIA EMPRESAR…, R$ 0,8 mi) consta 'Ativo' no SIGA com fim em 05/11/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
