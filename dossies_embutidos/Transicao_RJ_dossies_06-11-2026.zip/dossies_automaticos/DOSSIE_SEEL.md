# Dossiê de transição — Secretaria de Estado de Esporte, Lazer e Juventude (SEEL)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/seel)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 315 | R$ 182.416.832,01 |
| Com vigência futura (válidos no SIGA) | 25 | R$ 21.021.166,77 |
| até 30 dias | 1 | R$ 190.552,85 |
| até 60 dias | 0 | R$ 0,00 |
| até 90 dias | 0 | R$ 0,00 |
| até 180 dias | 9 | R$ 12.017.800,69 |
| vencido no SIGA | 290 | R$ 161.395.665,24 |
| sem data | 1 | R$ 269.460,00 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 45,9 mi / R$ 31,9 mi / R$ 37,6 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Mais 1 contratos menores (R$ 0,2 mi) vencem em até 30 dias — ver seção 3.
- 10 contratos (R$ 12,2 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 30 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 10,6 mi); 0 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 260 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 150,8 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Concentração: FOREVER SPORTS HOLDING S.A. detém 43% do valor vigente (1 contratos).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2023003829 | SUDERJ | BRS SUPRIMENTOS CORPORATIVOS S/A | Contratação de serviços continuados de OUTSOURCING para operação de a… | R$ 190.552,85 | 25/11/2026 | 19 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026001086 | SEELJE | COMPANHIA DISTRIBUIDORA DE GAS DO RIO DE JAN… | Prestação de serviços de fornecimento de gás para atender o Parque Aq… | R$ 892.786,87 | 27/02/2027 (PNCP) | 113 |
| 2026001087 | SEELJE | AMPLA ENERGIA E SERVIÇOS S/A | contratação de empresa para a prestação de serviços de fornecimento d… | R$ 224.276,41 | 27/02/2027 | 113 |
| 2026001088 | SEELJE | AGUAS DO RIO 4 SPE S.A | Prestação de serviços de fornecimento de água e esgotamento sanitário… | R$ 28.039,81 | 27/02/2027 | 113 |
| 2026001089 | SEELJE | AGUAS DE NITEROI S/A | Prestação de serviços de fornecimento de água e esgotamento sanitário… | R$ 858.043,80 | 27/02/2027 (PNCP) | 113 |
| 2026001090 | SEELJE | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação de empresa para a prestação deserviços de fornecimento de… | R$ 162.205,45 | 27/02/2027 | 113 |
| 2026001091 | SEELJE | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação de empresa para a prestação deserviços de fornecimento de… | R$ 52.569,01 | 27/02/2027 | 113 |
| 2026001092 | SEELJE | LIGHT SERVICOS DE ELETRICIDADE SA | Prestação de serviços de fornecimento deenergia elétrica, por rede pú… | R$ 437.167,46 | 27/02/2027 | 113 |
| 2022003760 | SEELJE | CLARO S/A (FILIAL) | LOTE II Rede IP Internet Simétrica, para o Backbone da Rede Governo R… | R$ 362.711,88 | 10/03/2027 | 124 |
| 2026001695 | SEELJE | FOREVER SPORTS HOLDING S.A. | Contratação da empresa FOREVER SPORTS HOLDING S.A. para fornecimento … | R$ 9.000.000,00 | 13/03/2027 (PNCP) | 127 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2023009002 | SEELJE | CONQUISTA VIGILANCIA E SEGURANCA PATRIMONIAL… | Contratação de empresa especialiada na prestação de serviços de vigil… | R$ 2.587.227,22 | 23/10/2025 | -379 |
| 2021003057 | SEELJE | SUCESSO EMPREENDIMENTOS E PARTICIPAÇÕES LTDA | Locação de imóvel da sede administrativa, localizada na Avenida Presi… | R$ 1.531.401,27 | 01/07/2025 | -493 |
| 2024002305 | SEELJE | TECHDOG SOLUÇÕES DE INTERNET LTDA | Prestação de serviços de tecnologia da informação com fornecimento de… | R$ 1.419.952,80 | 01/04/2026 | -219 |
| 2023008851 | SUDERJ | RC CARD SOLUCOES EM PAGAMENTOS LTDA | Contratação de empresa especialiada em fornecimento de valealimentaçã… | R$ 975.000,00 | 30/11/2024 | -706 |
| 2025001975 | SEELJE | COMPANHIA DISTRIBUIDORA DE GAS DO RIO DE JAN… | Contratação de empresa para a prestação de serviços de fornecimento d… | R$ 684.470,77 | 28/03/2026 (PNCP) | -223 |
| 2025001974 | SEELJE | LIGHT SERVICOS DE ELETRICIDADE SA | Prestação de serviços de fornecimento de energia elétrica, por rede p… | R$ 415.767,07 | 28/03/2026 | -223 |
| 2024004045 | SEELJE | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Contratação de pessoa jurídica especializada na prestação de Serviços… | R$ 408.000,00 | 07/05/2026 | -183 |
| 2024003908 | SEELJE | LIGHT SERVICOS DE ELETRICIDADE SA | Prestação de serviços de fornecimento de energia elétrica para atende… | R$ 384.000,00 | 20/06/2025 | -504 |
| 2025006867 | SUDERJ | REI DAS ÁGUAS GUARDIÃO GUARDIÕES LTDA | Contratação emergencial de serviços de guarda vidas e manutenção de p… | R$ 330.720,00 | 25/08/2026 | -73 |
| 2025001968 | SEELJE | AGUAS DE NITEROI S/A | Prestação de serviços de fornecimento de Água e Esgotamento Sanitário. | R$ 271.017,79 | 28/03/2026 | -223 |
| 2025001973 | SEELJE | AMPLA ENERGIA E SERVIÇOS S/A | Contratação de empresa para a prestação de serviços de fornecimento d… | R$ 241.278,64 | 28/03/2026 | -223 |
| 2024003833 | SEELJE | AGUAS DE NITEROI S/A | O presente Termo de Referência visa subsidiar a contratação de empres… | R$ 216.571,26 | 24/06/2025 | -500 |
| 2025001971 | SEELJE | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação de empresa para a prestação de serviços de fornecimento d… | R$ 175.343,44 | 28/03/2026 | -223 |
| 2024003906 | SEELJE | LIGHT SERVICOS DE ELETRICIDADE SA | Fornecimento de energia elétrica junto a Concessionária Light Serviço… | R$ 168.000,00 | 12/06/2025 | -512 |
| 2024007209 | SUDERJ | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Adesão à Ata de Registro de Preços nº 0001/2024 para contratação de a… | R$ 160.000,00 | 02/09/2025 | -430 |
| 2023007372 | SEELJE | BRS SUPRIMENTOS CORPORATIVOS S/A | Prestação de serviços continuados de outsourcing para operação de alm… | R$ 148.210,00 | 01/09/2026 | -66 |
| 2024010323 | SEELJE | RC CARD SOLUCOES EM PAGAMENTOS LTDA | empresa especializada na prestação de serviços de emissão e entrega d… | R$ 140.640,00 | 12/12/2025 | -329 |
| 2021007262 | SUDERJ | CLARO S/A (FILIAL) | CONTRATACAO DE LINK DE DADOS REDE IP GOVERNO - INFOVIA | R$ 85.320,00 | 30/11/2024 | -706 |
| 2024003907 | SEELJE | LIGHT SERVICOS DE ELETRICIDADE SA | Prestação de serviços de fornecimento de energia elétrica para atende… | R$ 48.641,34 | 09/10/2025 | -393 |
| 2025001977 | SEELJE | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação de empresa para a prestação de serviços de fornecimento d… | R$ 47.300,39 | 17/04/2026 | -203 |
| 2025001976 | SEELJE | AGUAS DO RIO 4 SPE S.A | Prestação de serviços de fornecimento de Água e Esgotamento Sanitário… | R$ 29.668,85 | 28/03/2026 | -223 |
| 2023010082 | SEELJE | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Prestação de Serviços de Guarda Documental | R$ 25.657,80 | 05/12/2025 | -336 |
| 2024003905 | SEELJE | AGUAS DO RIO 4 SPE S.A | Prestação de serviços de fornecimento de Água e Esgotamento Sanitário… | R$ 22.800,00 | 27/05/2025 | -528 |
| 2025001578 | SEELJE | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | Custeio do valor da taxa de inscrição de 03 (três) servidores para o … | R$ 18.000,00 | 12/04/2025 | -573 |
| 2024009464 | SEELJE | PRODUTOP COMERCIAL LTDA | Aquisição de materiais de limpeza | R$ 15.484,48 | 02/04/2025 | -583 |
| 2024009462 | SEELJE | PRODUTOP COMERCIAL LTDA | Aquisição de materiais de limpeza | R$ 13.504,08 | 02/04/2025 | -583 |
| 2025008329 | SEELJE | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | Capacitação dos servidores atuantes em áreasligadas à realização de p… | R$ 12.360,00 | 12/11/2025 | -359 |
| 2024008372 | SEELJE | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | Capacitação dos servidores atuantes em áreas ligadas à realização de … | R$ 11.780,00 | 30/11/2024 | -706 |
| 2025007175 | SEELJE | VICTORIA MILLER DOS SANTOS 15113431761 | Aquisição de Materiais de Copa para a Secretaria de Estado Esporte e … | R$ 6.316,20 | 11/12/2025 | -330 |
| 2024007128 | SUDERJ | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Confecção de 5.000 (cinco mil) folhetos com o objetivo de informar so… | R$ 3.500,00 | 31/12/2024 | -675 |

_Registros mais antigos (provável falta de baixa no SIGA): 260, R$ 150,8 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026001695 | SEELJE | FOREVER SPORTS HOLDING S.A. | Contratação da empresa FOREVER SPORTS HOLDING S.A. para fornecimento … | R$ 9.000.000,00 | 13/03/2027 (PNCP) | 127 |
| 2022004640 | SEELJE | FUNDAÇÃO SANTA CABRINI | Prestação de serviços à Secretaria de Estado de Esporte e Lazer ¿ SEE… | R$ 1.398.479,92 | 23/06/2027 | 229 |
| 2026008117 | SUDERJ | PLUXEE BENEFICIOS BRASIL S.A. | Contratação de empresa especializada para confecção, fornecimento e a… | R$ 1.352.000,00 | 30/09/2027 | 328 |
| 2023006057 | SEELJE | FUNDAÇÃO SANTA CABRINI | Prestação de serviços aos aparelhos desportivos do Parque Aquático Jú… | R$ 1.193.404,48 | 24/07/2027 | 260 |
| 2023001389 | SEELJE | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Serviços de gestão de abastecimento e fornecimento de combustíveis | R$ 1.059.743,58 | 13/02/2028 | 464 |
| 2026001086 | SEELJE | COMPANHIA DISTRIBUIDORA DE GAS DO RIO DE JAN… | Prestação de serviços de fornecimento de gás para atender o Parque Aq… | R$ 892.786,87 | 27/02/2027 (PNCP) | 113 |
| 2026001089 | SEELJE | AGUAS DE NITEROI S/A | Prestação de serviços de fornecimento de água e esgotamento sanitário… | R$ 858.043,80 | 27/02/2027 (PNCP) | 113 |
| 2024006627 | SEELJE | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Fornecimento de solução tecnológica de apoio na adequação às obrigaçõ… | R$ 740.736,00 | 19/08/2027 | 286 |
| 2024009727 | SEELJE | CS BRASIL FROTAS S.A. | Contratação de empresa especializada no fornecimento dos serviços del… | R$ 701.539,20 | 03/12/2027 | 392 |
| 2026002732 | SUDERJ | AVANTE MARKETING E LOGÍSTICA LTDA | Prestação de serviços de locação de veículos de serviço e utilitários… | R$ 542.440,08 | 16/04/2029 | 892 |
| 2026001792 | SUDERJ | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | Prestação de serviços de gestão do abastecimento, por meio de sistema… | R$ 472.792,32 | 16/04/2029 | 892 |
| 2026001092 | SEELJE | LIGHT SERVICOS DE ELETRICIDADE SA | Prestação de serviços de fornecimento deenergia elétrica, por rede pú… | R$ 437.167,46 | 27/02/2027 | 113 |
| 2022003760 | SEELJE | CLARO S/A (FILIAL) | LOTE II Rede IP Internet Simétrica, para o Backbone da Rede Governo R… | R$ 362.711,88 | 10/03/2027 | 124 |
| 2024009280 | SEELJE | LOCADORA GRILLO E RIBEIRO LTDA | Contratação de empresa especializada no fornecimento dos serviços del… | R$ 330.324,61 | 02/12/2027 | 391 |
| 2022006855 | SEELJE | DADY ILHA SOLUCOES INTEGRADAS LTDA | Contratação de empresa especializada no fornecimento de solução conti… | R$ 302.671,68 | 09/09/2027 | 307 |
| 2026004132 | SUDERJ | COMPANHIA ULTRAGAZ S.A. | Contratação de empresa especializada para o fornecimento contínuo de … | R$ 269.460,00 | — |  |
| 2026001087 | SEELJE | AMPLA ENERGIA E SERVIÇOS S/A | contratação de empresa para a prestação de serviços de fornecimento d… | R$ 224.276,41 | 27/02/2027 | 113 |
| 2025005553 | SUDERJ | CBD BOLHETE DIGITAL S/A | Contratação de empresa especializada para fornecimento, recarga e ges… | R$ 204.720,00 | 29/04/2028 | 540 |
| 2023003829 | SUDERJ | BRS SUPRIMENTOS CORPORATIVOS S/A | Contratação de serviços continuados de OUTSOURCING para operação de a… | R$ 190.552,85 | 25/11/2026 | 19 |
| 2026001090 | SEELJE | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação de empresa para a prestação deserviços de fornecimento de… | R$ 162.205,45 | 27/02/2027 | 113 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| FOREVER SPORTS HOLDING S.A. | 1 | R$ 9.000.000,00 |
| FUNDAÇÃO SANTA CABRINI | 2 | R$ 2.591.884,40 |
| PLUXEE BENEFICIOS BRASIL S.A. | 1 | R$ 1.352.000,00 |
| TRIVALE INSTITUICAO DE PAGAMENTO LTDA | 1 | R$ 1.059.743,58 |
| COMPANHIA DISTRIBUIDORA DE GAS DO RIO DE JANEIRO-CEG | 1 | R$ 892.786,87 |
| AGUAS DE NITEROI S/A | 1 | R$ 858.043,80 |
| EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | 1 | R$ 740.736,00 |
| CS BRASIL FROTAS S.A. | 1 | R$ 701.539,20 |
| LIGHT SERVICOS DE ELETRICIDADE SA | 3 | R$ 651.941,92 |
| AVANTE MARKETING E LOGÍSTICA LTDA | 1 | R$ 542.440,08 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2018001987 | T&S LOCAÇÃO DE MÃO DE OBRA EM GERAL - EIRELI | R$ 262.563,06 | R$ 80.009,64 | R$ 182.553,42 |
| 2018003450 | L. F. L. MOREIRA - COMERCIO E SERVIÇOS - EPP | R$ 1.112.186,35 | R$ 1.008.943,12 | R$ 103.243,23 |
| 2016002214 | INNOVATION TECHNOLOGY LTDA - ME | R$ 516.996,00 | R$ 415.269,40 | R$ 101.726,60 |
| 2022004800 | AGUAS DE NITEROI S/A | R$ 162.667,69 | R$ 61.320,78 | R$ 101.346,91 |
| 2016000641 | CLR INFORMATICA LTDA | R$ 78.440,00 | R$ 0,00 | R$ 78.440,00 |
| 2016000412 | DATA CORPORE SERVICOS DE TELECOMUNICACOES E … | R$ 429.259,80 | R$ 375.245,13 | R$ 54.014,67 |
| 2021003057 | SUCESSO EMPREENDIMENTOS E PARTICIPAÇÕES LTDA | R$ 351.551,24 | R$ 317.728,92 | R$ 33.822,32 |
| 2019001375 | R MORAES AGÊNCIA DE TURISMO EIRELI | R$ 298.813,22 | R$ 265.562,10 | R$ 33.251,12 |
| 2021004608 | CS BRASIL FROTAS S.A. | R$ 53.587,08 | R$ 21.694,20 | R$ 31.892,88 |
| 2022001980 | INSTITUTO NEGOCIOS PUBLICOS ESTUDOS E PESQUI… | R$ 24.551,12 | R$ 0,00 | R$ 24.551,12 |
| 2016004840 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 20.474,30 | R$ 0,00 | R$ 20.474,30 |
| 2019005947 | ESPORTE GLOBAL COMERCIO DE ARTIGOS ESPORTIVO… | R$ 17.090,20 | R$ 0,00 | R$ 17.090,20 |
| 2023000060 | COMPANHIA ULTRAGAZ S.A. | R$ 45.752,00 | R$ 30.372,99 | R$ 15.379,01 |
| 2019006164 | FRAMOT BAZAR E UTILIDADES LTDA | R$ 12.903,00 | R$ 0,00 | R$ 12.903,00 |
| 2022006484 | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | R$ 56.407,22 | R$ 43.765,87 | R$ 12.641,35 |
| 2022004036 | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | R$ 28.553,76 | R$ 16.227,18 | R$ 12.326,58 |
| 2022006855 | DADY ILHA SOLUCOES INTEGRADAS LTDA | R$ 22.458,00 | R$ 13.474,80 | R$ 8.983,20 |
| 2021007031 | FUNDAÇÃO CENTRO ESTADUAL DE ESTATÍSTICAS, PE… | R$ 8.500,00 | R$ 0,00 | R$ 8.500,00 |
| 2019002934 | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | R$ 275.685,76 | R$ 267.680,56 | R$ 8.005,20 |
| 2023001389 | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | R$ 39.438,15 | R$ 32.062,80 | R$ 7.375,35 |

## 11. Unidades incluídas neste dossiê
- SEELJE - SEC DE EST  ESPORTE, LAZER E JUVENTUDE
- SUDERJ - SUPERINTENDÊNCIA DE DESPORTOS DO ESTADO DO RJ

## 12. Conjuntos de dados abertos da secretaria
- Lei de  Incentivo ao Esporte -Transparência - Projetos Incentivados (atualizado 2026-03-09): [Lei de Incentivo CSV](https://dadosabertos.rj.gov.br/dataset/4e3ab1dc-4448-4404-941c-7442ebaefab8/resource/a4edbbb0-596f-4a5d-be1a-1397998a32aa/download/transparencia-lie-2.csv)
- Termo de Colaboração Técnica - (atualizado 2025-12-03): [SEI_65549036_Termo_de_Parceria.pdf PDF](https://dadosabertos.rj.gov.br/dataset/9e68cb6b-1216-4361-91a9-89e1f9c9d81c/resource/943450be-8f3a-4e45-b533-92ac38e72be6/download/sei_65549036_termo_de_parceria.pdf)
- Lista dos Contemplados Bolsa Atleta 2025 (atualizado 2025-12-03): [LISTA_FINAL_PÓS_RECURSO_DIÁRIO_OFICIAL_… PDF](https://dadosabertos.rj.gov.br/dataset/6cbcd7e1-1bcf-4190-b17d-5f855cf0c045/resource/735a31ff-4750-4edc-b5ae-194b2e2aac0f/download/lista_final_pos_recurso_diario_oficial_2025_0.xlsx)
- Publicação Diario Oficial Bolsa Atleta Pre liminar (atualizado 2025-12-03): [Resultado preliminar BARJ 2025.pdf PDF](https://dadosabertos.rj.gov.br/dataset/63c05347-2af6-4697-8c4c-56de9247811b/resource/549e1a6f-010c-47af-87fc-0e608c32264a/download/resultado-preliminar-barj-2025.pdf)
- Homologação de resultado - Projeto Esporte ativo - D.O (atualizado 2025-09-18): [HOMOLOGAÇÃO RESULTADO FINAL.pdf PDF](https://dadosabertos.rj.gov.br/dataset/e1f059ab-89d8-430e-83d1-79f66a34b7db/resource/695afee5-8dd6-41e8-8e54-0218a99aa699/download/homologacao-resultado-final.pdf)
- TERMO DE COLABORAÇÃO ASSINADO E PUBLICADO NO DOERJ em anexo nos arquivos abaixo (atualizado 2025-09-18): [15 - Anexo_VII___Declaracao_de_Contrapa… PDF](https://dadosabertos.rj.gov.br/dataset/3dc202d2-eccf-4c35-a516-d38a7450b140/resource/8a56a6b5-fa5c-460a-b6f9-d796da1a7075/download/15-anexo_vii___declaracao_de_contrapartida.pdf)
- Termo de Colaboração Técnica 02 (atualizado 2025-09-18): [SEI_65551301_Termo_de_Parceria.pdf PDF](https://dadosabertos.rj.gov.br/dataset/72613f4a-b499-47f2-b002-87494b02152e/resource/8413f346-5a8e-4fc4-a43d-20c9178b8231/download/sei_65551301_termo_de_parceria.pdf)
- EDITAL DO BOLSA ATLETA 2024 (atualizado 2025-09-18): [SEI_77909136_Edital_de_Selecao_5.pdf PDF](https://dadosabertos.rj.gov.br/dataset/522d70e8-532b-4324-aa6d-e2cc443e793c/resource/c7582d9e-8474-4625-9c7f-34da9730c01a/download/sei_77909136_edital_de_selecao_5.pdf)
- Projetos analisados no CAP. (atualizado 2025-09-18): [Projetos Incentivados CSV](https://dadosabertos.rj.gov.br/dataset/040bb741-a453-4066-ba99-a9b7fb4cd785/resource/34687e71-345e-4504-b219-1d49775d1228/download/projetos-incentivados.pdf)
- Planilha de Ratificação 2023 (atualizado 2025-09-18): [PLANILHA DE RETIFICAÇÃO.pdf PDF](https://dadosabertos.rj.gov.br/dataset/9eaa7aab-519d-4738-9798-4a4571d04dff/resource/8a1970d8-6bdc-452f-92b6-f0f2b2b3d957/download/planilha-de-retificacao.pdf)
- Resultado Preliminar Bolsa Atleta 2023 (atualizado 2025-09-18): [ResultadoPreliminar.pdf PDF](https://dadosabertos.rj.gov.br/dataset/ff10d749-0443-40e8-9d07-f2ed6d942a88/resource/fc88c91c-b9ce-49fc-9f47-cf9201bf2c30/download/resultadopreliminar.pdf)
- TERMO DE FOMENTO GYMNASIADE (atualizado 2025-09-18): [IOERJTraceableFile64aecc43d5aba (1).pdf PDF](https://dadosabertos.rj.gov.br/dataset/16c1732d-92e5-4174-9582-e73d40e84fc7/resource/fa29326a-cddb-4a5d-b35c-7fd173c7590a/download/ioerjtraceablefile64aecc43d5aba-1.pdf)
- Ata do resultado Final Lote 03 (atualizado 2025-09-18): [4.ATA RESULTADO FINAL CP 3_2021_RJ_LOTE… PDF](https://dadosabertos.rj.gov.br/dataset/3e87bf06-1110-4b41-9227-b952e0d8c21e/resource/524a8aa7-35ac-4d91-b1ee-ebeebfcf970f/download/4.ata-resultado-final-cp-3_2021_rj_lote-3_0.pdf)
- Edital de Convocação RJ em Movimento Lote 03 (atualizado 2025-09-18): [1.EDITAL DE CONVOCAÇÃO RJ EM MOVIMENTO … PDF](https://dadosabertos.rj.gov.br/dataset/198ac491-8818-46a7-8da0-0a30bebe5062/resource/c11be77c-d1dc-45b6-b027-ee971fcf73b1/download/1.edital-de-convocacao-rj-em-movimento-lote-3_0.pdf)
- Ata Resultado Final RJ Lote 02 (atualizado 2025-09-18): [4. ATA RESULTADO FINAL CP 2_2021_RJ_LOT… PDF](https://dadosabertos.rj.gov.br/dataset/33f51c1b-3fe9-430a-bec7-4deb7c976e92/resource/88fa77e1-2ad3-442e-b2c1-d3429706daf8/download/4.-ata-resultado-final-cp-2_2021_rj_lote-2.pdf)
- RJ Edital de Convocação de chamamento Público RJ em Movimento Lote 02 (atualizado 2025-09-18): [1.EDITAL DE CONVOCAÇÃO RJ EM MOVIMENTO … PDF](https://dadosabertos.rj.gov.br/dataset/8f484441-1e99-470f-9d34-86116e4bf1c6/resource/9bd5f2b8-623a-4422-97e1-9d2caa37bd63/download/1.edital-de-convocacao-rj-em-movimento-lote-2.pdf)
- RJ EM Movimento Resultado Final das Proposta Lote 01 (atualizado 2025-09-18): [ATA 1 lote.rtf_ (1).doc PDF](https://dadosabertos.rj.gov.br/dataset/3d8ce9f0-75c1-44fa-b95d-7e847d5ac5c4/resource/f68ff9b8-cf6a-4ca4-a87a-2c0eb3fbab9d/download/ata-1-lote.rtf_-1.doc)
- Termo de Cooperação (atualizado 2025-09-18): [SEI_65552599_Termo_de_Parceria.pdf PDF](https://dadosabertos.rj.gov.br/dataset/5cd7a1a7-4c3c-4a1d-a21a-183c7c84fc14/resource/04f6af67-90d4-4382-bf4a-ee0d5ab98941/download/sei_65552599_termo_de_parceria.pdf)
- Termo de Cooperação (atualizado 2025-09-18): [º SEI-300001/001598/2023 XML](https://dadosabertos.rj.gov.br/dataset/cf6fb9e8-f9fb-4839-a38a-a8e5be6b20b8/resource/1306fabc-fea1-40f3-9166-15a97cccac00/download/sei_65552644_termo_de_parceria.pdf)
- EXTRATO DE TERMO - Projeto esporte ativo (atualizado 2025-09-18): [extrato lote 4.pdf PDF](https://dadosabertos.rj.gov.br/dataset/6b4813e4-9574-4ec5-80d6-56f8ef055299/resource/b33e9404-e600-41da-8c64-5448323de5b8/download/extrato-lote-4.pdf)
- Termo de cooperação (atualizado 2025-09-18): [SEI_65553034_Termo_de_Parceria.pdf PDF](https://dadosabertos.rj.gov.br/dataset/432a6205-8be5-436a-94df-ef72f4841af9/resource/77cf4990-28fb-4634-aaae-51a71534593e/download/sei_65553034_termo_de_parceria.pdf)
- PREGÃO ELETRÔNICO Nº 001/2024 R1 (atualizado 2025-09-18): [Anexo_V__Laudo_de_avaliacao.pdf PDF](https://dadosabertos.rj.gov.br/dataset/871b367a-4cdd-4071-a5fa-4ca8b7f0cb54/resource/9a4a1a4e-510c-4480-8f24-56f626d06386/download/anexo_v__laudo_de_avaliacao.pdf)
- Edital Bolsa Atleta 2025 (atualizado 2025-09-10): [EDITAL BARJ 2025.pdf PDF](https://dadosabertos.rj.gov.br/dataset/a39ca7cf-fe25-4e17-b12e-dff886f7a3a3/resource/417be310-68bc-49fe-98f1-eb5357877b57/download/edital-barj-2025.pdf)
- Termo de Cooperação - Publicacão D.O (atualizado 2025-09-10): [extrato lote 5.pdf PDF](https://dadosabertos.rj.gov.br/dataset/be4c6b8a-7c7a-475a-bc06-ee08a3f44ebc/resource/8e93b288-c9a2-4248-a702-91c11de3dbb5/download/extrato-lote-5.pdf)
- Execução do Projeto Esporte Ativo - D.O (atualizado 2025-09-10): [extrato lote 4.pdf PDF](https://dadosabertos.rj.gov.br/dataset/636ce656-b6e7-450d-95cc-4fc1d8c1862a/resource/9e7968db-7cf6-4a0e-a852-ebb9baeec765/download/extrato-lote-4.pdf)
- Projeto Esporte Ativo - Publiacação D.O (atualizado 2025-09-10): [extrato lote 3.pdf PDF](https://dadosabertos.rj.gov.br/dataset/8c955d67-268c-4182-88db-b2f93a201996/resource/e3f2d16e-d25d-4bb0-ae03-dfab16b6e576/download/extrato-lote-3.pdf)
- Termo de Colaboração Projeto Esporte Ativo (atualizado 2025-09-10): [extrato lote 2.pdf PDF](https://dadosabertos.rj.gov.br/dataset/634dc19f-ddd0-4132-a8fc-0ea6b6cc1747/resource/94509674-e315-4bb1-9a81-ed8a99b8bf45/download/extrato-lote-2.pdf)
- Publicação 1 -  EXTRATO DE TERMO  I N S T R U M E N TO : Termo de Colaboração nº 02/2023 (CONVERJ nº  828). (atualizado 2025-09-10): [Extrato Lote 1.pdf PDF](https://dadosabertos.rj.gov.br/dataset/3b5a2383-673c-4e1f-a3f7-940bcadaaf49/resource/d9dd1c5e-28cb-4725-bca9-c5cdc6163b58/download/extrato-lote-1.pdf)
- HOMOLOGAÇÃO DE RESULTADO FINAL (atualizado 2025-09-09): [HOMOLOGAÇÃO RESULTADO FINAL.pdf CSV](https://dadosabertos.rj.gov.br/dataset/614f2c4a-2b0b-49d2-8d17-3a3559955dc7/resource/88457909-9938-46f0-a0fd-6c441cdd3093/download/homologacao-resultado-final.pdf)
- Termo de Colaboração (atualizado 2025-09-09): [14 - Anexo_VI___TERMO_DE_COLABORACAO.pdf PDF](https://dadosabertos.rj.gov.br/dataset/f74a9c15-2930-432e-93db-35d3159021b7/resource/2aab6f6e-11f6-4f55-904d-8a1e29f63430/download/14-anexo_vi___termo_de_colaboracao.pdf)
- PLANO DE TRABALHO  Projeto Ativo (atualizado 2025-09-09): [7 - Anexo_IV___Plano_de_Trabalho_Lote_1… PDF](https://dadosabertos.rj.gov.br/dataset/186687ca-9a82-4904-9e7b-08f43bf44204/resource/cbfbbcf7-c597-4f0e-a708-44d13becf93b/download/7-anexo_iv___plano_de_trabalho_lote_1___100_nucleos__1_.pdf)
- TERMO DE COLABORAÇÃO ASSINADO E PUBLICADO NO DOERJ (atualizado 2025-09-09): [Esporte Ativo PDF](https://dadosabertos.rj.gov.br/dataset/c16993de-a2e6-4e9d-9ca5-fdc86e480384/resource/135ed456-36a3-4d22-ac23-cd0fa403e3d1/download/1-sei_55558067_edital_de_chamamento_publico.pdf)
- ORIENTAÇÕES ESTRUTURANTES (atualizado 2025-09-09): [3 - Orientacoes_Estruturantes (1).pdf PDF](https://dadosabertos.rj.gov.br/dataset/a0fa1f86-bd26-468e-bb20-f267ffe1e394/resource/1252b666-2a76-4f92-ba3f-152bb5f275d5/download/3-orientacoes_estruturantes-1.pdf)
- Diretriz - Esporte Ativo (atualizado 2025-09-09): [2 - DIRETRIZ (1).pdf PDF](https://dadosabertos.rj.gov.br/dataset/2ebccf1d-babc-4329-9c9f-b6ddae78dc1c/resource/0d65a10a-f6a7-41bd-9593-60e6915842d8/download/2-diretriz-1.pdf)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 7 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

A apuração do TCE-RJ sobre a compra de materiais esportivos da WR Calçados Eireli tem dano potencial calculado em R$ 1.938.853,26 e ainda não foi julgada definitivamente. [Farra das bolas](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/)

Há parcerias e programas relevantes a confirmar quanto à execução e continuidade: o Projeto Esporte Ativo 02 prevê 600 núcleos e R$ 92.133.900,72, enquanto o Termo de Fomento nº 18/2025 prevê seis meses de execução da Casa do Torcedor. [Edital do Projeto Esporte Ativo 02](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/Edital%20de%20Chamamento%20P%C3%BAblico%2003%20de%202025.pdf) [Termo de Fomento nº 18/2025](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/SEI_121816818_Termo_de_Parceria.pdf)

Reportagem de outubro informa que estava em análise uma possível fusão das pastas de Turismo, Esportes e Eventos, sem registrar decisão final. [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)

As fontes consultadas não permitem confirmar a situação atual dos contratos, a continuidade dos serviços, nem a existência de ações do MPRJ ou processos judiciais ligados à Secretaria. [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml) [Diário Oficial — orçamento da SEEL](https://cj.estrategia.com/portal/wp-content/uploads/2026/05/18092944/diarioOficial-2.pdf)

##### Alertas vermelhos

- **Apuração do TCE-RJ sobre materiais esportivos:** a área técnica apontou falhas na pesquisa de preços, ausência de comprovação da vantagem de aderir à ata e inconsistências nos quantitativos; o Tribunal estimou dano potencial de R$ 1.938.853,26, sem que a fonte registre julgamento definitivo. [Farra das bolas](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/)
- **Possível fusão de secretarias:** a reorganização de Turismo, Esportes e Eventos estava em avaliação técnica e administrativa, segundo fontes próximas ao governador eleito; a reportagem não afirma que a fusão foi aprovada. [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)
- **Parcerias de grande escala:** o edital do Esporte Ativo 02 prevê R$ 92.133.900,72 para três lotes, mas esclarece que a homologação não gera direito à celebração da parceria e que a formalização depende de requisitos, incluindo dotação orçamentária e publicação do extrato. [Edital do Projeto Esporte Ativo 02](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/Edital%20de%20Chamamento%20P%C3%BAblico%2003%20de%202025.pdf)
- **Prazo da Casa do Torcedor:** o Termo de Fomento nº 18/2025 prevê seis meses de vigência e execução, mas as informações fornecidas não permitem confirmar quando o prazo começou nem se houve prorrogação ou encerramento. [Termo de Fomento nº 18/2025](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/SEI_121816818_Termo_de_Parceria.pdf)

##### Contratos e serviços críticos

- **Materiais esportivos — WR Calçados Eireli:** contratação por adesão a uma ata de registro de preços do Cindesp, com valor previsto de R$ 13,9 milhões; foram pagos cerca de R$ 4,18 milhões, pois apenas parte dos produtos foi entregue, e a fonte não informa número do contrato nem vigência. [Farra das bolas](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/)
- A compra incluía bolas de basquete por até R$ 438 cada, e a apuração do TCE-RJ decorreu de representação do então deputado estadual Flávio Serafini, motivada por reportagens sobre possível sobrepreço. [Farra das bolas](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/)
- **Projeto Esporte Ativo 02:** o edital prevê 600 núcleos em três lotes e valor total disponibilizado de R$ 92.133.900,72; em fevereiro de 2026, foram homologados os resultados finais, com ECOS classificada em primeiro lugar no lote 1, Instituto Realizando o Futuro no lote 2 e Movimento Cultural Social no lote 3. [Edital do Projeto Esporte Ativo 02](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/Edital%20de%20Chamamento%20P%C3%BAblico%2003%20de%202025.pdf) [Resultado final do Projeto Esporte Ativo 02](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/IOERJTraceableFile698df88e6774d.pdf)
- A documentação fornecida não confirma a celebração dos termos de colaboração, o início das atividades, os repasses realizados ou o número de núcleos efetivamente em operação; o edital condiciona a parceria a etapas posteriores à homologação. [Edital do Projeto Esporte Ativo 02](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/Edital%20de%20Chamamento%20P%C3%BAblico%2003%20de%202025.pdf) [Resultado final do Projeto Esporte Ativo 02](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/IOERJTraceableFile698df88e6774d.pdf)
- **Casa do Torcedor — Agência Facilitadora para Investimentos Culturais – ONG África:** o Termo de Fomento nº 18/2025 prevê R$ 326.802,00, vigência de seis meses, seis oficinas para até 200 pessoas e 100 vagas para aulas de boxe e judô; a fonte não informa o estado atual da execução nem eventual prorrogação. [Termo de Fomento nº 18/2025](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/SEI_121816818_Termo_de_Parceria.pdf)
- **Orçamento publicado em maio de 2026:** o Decreto nº 50.292, de 15 de maio de 2026, registra orçamento atualizado de R$ 157.682.066 e limite disponível para empenho de R$ 150.024.306 para a SEEL; esses valores são os publicados no decreto e não demonstram, por si só, o saldo disponível em 06/11/2026. [Diário Oficial — orçamento da SEEL](https://cj.estrategia.com/portal/wp-content/uploads/2026/05/18092944/diarioOficial-2.pdf)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- **TCE-RJ — WR Calçados Eireli:** em sessão de 1º de julho, sem ano especificado na fonte, o plenário aprovou por unanimidade a citação da empresa para apresentar defesa ou ressarcir o dano potencial apontado; o ressarcimento poderá ser solidário com outros responsáveis se as irregularidades forem confirmadas ao final da apuração. [Farra das bolas](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/)
- O Tribunal adiou a análise das defesas de Gutemberg de Paula Fonseca, Marco Aurélio Paes e Daniel Oliveira Ribeiro para que os envolvidos sejam analisados na mesma fase processual; também cancelou o certificado de revelia de Gutemberg, cuja defesa foi apresentada fora do prazo, para que seus argumentos fossem examinados junto aos das demais partes. [Farra das bolas](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/)
- Após a manifestação da empresa, o processo deveria retornar à área técnica do TCE-RJ e, depois, ao Ministério Público de Contas antes do julgamento definitivo; as fontes fornecidas não atualizam se essas etapas ocorreram. [Farra das bolas](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/)
- **MPRJ e Judiciário:** nada encontrado nas fontes consultadas sobre ações do MPRJ ou processos judiciais referentes à Secretaria; as fontes também não relatam ação do Ministério Público estadual relacionada à compra de materiais esportivos. [Farra das bolas](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/) [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)

##### Riscos de apagão administrativo

- **Continuidade da estrutura:** a possibilidade de fusão de Turismo, Esportes e Eventos estava em estudo em outubro de 2026, mas a fonte não apresenta decisão, cronograma, desenho organizacional ou plano de transição. [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)
- **Continuidade dos serviços:** as fontes não informam interrupção ou risco de interrupção de serviços; também não confirmam a execução atual dos núcleos do Esporte Ativo 02 nem da Casa do Torcedor. [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml) [Edital do Projeto Esporte Ativo 02](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/Edital%20de%20Chamamento%20P%C3%BAblico%2003%20de%202025.pdf) [Termo de Fomento nº 18/2025](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/SEI_121816818_Termo_de_Parceria.pdf)
- **Rotinas de monitoramento:** a Resolução SEEL nº 492, de 26 de março de 2026, designou comissão de monitoramento e avaliação para parceria no processo SEI-300001/000079/2026; a fonte não identifica, no trecho fornecido, o objeto da parceria nem informa se há pendências de acompanhamento. [Resolução SEEL nº 492 e ata da CAP](https://print.cge.rj.gov.br/uploads/short-url/fqy5QKyfg1tgQxFWx7Kj7QDzV4K.pdf)
- **Transição de contratos e passivos:** nada encontrado nas fontes consultadas sobre atrasos administrativos, dívidas, crise de fornecimento ou passivos gerais da Secretaria. [Diário Oficial — orçamento da SEEL](https://cj.estrategia.com/portal/wp-content/uploads/2026/05/18092944/diarioOficial-2.pdf) [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)

##### Fatos recentes

- Em 14/10/2026, reportagem registrou que a equipe do governador eleito Douglas Ruas estudava possíveis mudanças na segurança pública e uma eventual fusão das pastas de Turismo, Esportes e Eventos; a viabilidade técnica e administrativa ainda estava em avaliação. [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)
- Em 12/02/2026, foi publicado o resultado final do chamamento do Projeto Esporte Ativo 02, com classificação das organizações por lote; o edital esclarece que a homologação não garante a celebração da parceria. [Resultado final do Projeto Esporte Ativo 02](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/IOERJTraceableFile698df88e6774d.pdf) [Edital do Projeto Esporte Ativo 02](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/Edital%20de%20Chamamento%20P%C3%BAblico%2003%20de%202025.pdf)
- Em 27/03/2026, foi publicado documento que contém a Resolução SEEL nº 492, datada de 26/03/2026, designando comissão de monitoramento e avaliação para uma parceria no processo SEI-300001/000079/2026; o documento também contém ata da reunião da CAP realizada em 26/03, com decisões sobre projetos esportivos. [Resolução SEEL nº 492 e ata da CAP](https://print.cge.rj.gov.br/uploads/short-url/fqy5QKyfg1tgQxFWx7Kj7QDzV4K.pdf)
- O orçamento publicado em maio de 2026 registrou R$ 157.682.066 de orçamento atualizado e R$ 150.024.306 de limite disponível para empenho para a SEEL. [Diário Oficial — orçamento da SEEL](https://cj.estrategia.com/portal/wp-content/uploads/2026/05/18092944/diarioOficial-2.pdf)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)

- Solicitar a relação atualizada de contratos, termos de colaboração e fomento, atas de registro de preços, saldos, pagamentos, vigências, aditivos, gestores e fiscais, pois as fontes não apresentam um inventário atualizado da carteira contratual da Secretaria. [Diário Oficial — orçamento da SEEL](https://cj.estrategia.com/portal/wp-content/uploads/2026/05/18092944/diarioOficial-2.pdf) [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)
- Solicitar o processo completo da compra da WR Calçados Eireli, incluindo contrato e vigência, entregas, pagamentos, pesquisa de preços e andamento atualizado da apuração no TCE-RJ; esses detalhes não constam integralmente nas informações fornecidas. [Farra das bolas](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/)
- Solicitar a situação de formalização, repasses, cronograma, metas e operação dos três lotes do Projeto Esporte Ativo 02, pois as fontes registram o edital e a homologação, mas não comprovam a execução atual. [Edital do Projeto Esporte Ativo 02](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/Edital%20de%20Chamamento%20P%C3%BAblico%2003%20de%202025.pdf) [Resultado final do Projeto Esporte Ativo 02](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/IOERJTraceableFile698df88e6774d.pdf)
- Solicitar a data de publicação e início da vigência, eventuais aditivos, prestações de contas e situação atual do Termo de Fomento nº 18/2025 da Casa do Torcedor, pois a fonte informa prazo de seis meses, mas não permite confirmar se a parceria está vigente ou encerrada. [Termo de Fomento nº 18/2025](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/SEI_121816818_Termo_de_Parceria.pdf)
- Solicitar o saldo orçamentário e financeiro atualizado para 06/11/2026, a execução por programa e fonte, restos a pagar, obrigações pendentes e projeção até 01/01/2027, pois o documento disponível apresenta valores do Decreto nº 50.292, de 15/05/2026. [Diário Oficial — orçamento da SEEL](https://cj.estrategia.com/portal/wp-content/uploads/2026/05/18092944/diarioOficial-2.pdf)
- Solicitar a decisão ou estudo mais recente sobre eventual fusão de secretarias, com impactos em estrutura, competências, pessoal, contratos, sistemas e continuidade de serviços; a reportagem consultada informa apenas que a possibilidade estava em análise. [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)
- Solicitar certidões e relatório consolidado de processos no TCE-RJ, MPRJ e Judiciário, além de respostas a recomendações e determinações de controle, pois as fontes consultadas não oferecem panorama completo dessas pendências. [Farra das bolas](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/) [Ruas começa transição](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)

##### Fontes consultadas
1. [Farra das bolas: TCE-RJ aponta superfaturamento de R$ 1,9 milhão ...](https://temporealrj.com/tce-superfaturamento-materiais-esportivos/) — 2026-07-25
2. [Ruas começa transição de governo estudando mudanças na ...](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml) — 2026-10-14
3. [ PDF  Á - RJ Gov](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/IOERJTraceableFile698df88e6774d.pdf) — 2026-04-27
4. [Á](https://print.cge.rj.gov.br/uploads/short-url/fqy5QKyfg1tgQxFWx7Kj7QDzV4K.pdf) — 2026-06-10
5. [Diario Oficial](https://cj.estrategia.com/portal/wp-content/uploads/2026/05/18092944/diarioOficial-2.pdf) — 2026-08-20
6. [EDITAL DE CHAMAMENTO PÚBLICO Nº 03/2025](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/Edital%20de%20Chamamento%20P%C3%BAblico%2003%20de%202025.pdf) — 2026-01-15
7. [termo de fomento nº 18/2025](https://www.rj.gov.br/esporte/sites/default/files/arquivos-paginas/SEI_121816818_Termo_de_Parceria.pdf) — 2026-05-20


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2023003829 (BRS SUPRIMENTOS CORPORATIVOS S/A) vence em 25/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2023009002 (CONQUISTA VIGILANCIA E SEGURANCA PATRIM…, R$ 2,6 mi) consta 'Ativo' no SIGA com fim em 23/10/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
4. Contrato 2021003057 (SUCESSO EMPREENDIMENTOS E PARTICIPAÇÕES…, R$ 1,5 mi) consta 'Ativo' no SIGA com fim em 01/07/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
5. Contrato 2024002305 (TECHDOG SOLUÇÕES DE INTERNET LTDA, R$ 1,4 mi) consta 'Ativo' no SIGA com fim em 01/04/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
6. Contrato 2023008851 (RC CARD SOLUCOES EM PAGAMENTOS LTDA, R$ 1,0 mi) consta 'Ativo' no SIGA com fim em 30/11/2024: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
7. Contrato 2025001975 (COMPANHIA DISTRIBUIDORA DE GAS DO RIO D…, R$ 0,7 mi) consta 'Ativo' no SIGA com fim em 28/03/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
9. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
10. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
11. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
12. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
