# Dossiê de transição — Secretaria de Estado das Cidades (SECID)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/secid)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 147 | R$ 3.228.252.500,16 |
| Com vigência futura (válidos no SIGA) | 57 | R$ 1.975.635.927,81 |
| até 30 dias | 6 | R$ 45.577.441,91 |
| até 60 dias | 8 | R$ 336.090.635,37 |
| até 90 dias | 5 | R$ 246.301.799,53 |
| até 180 dias | 23 | R$ 779.813.274,07 |
| vencido no SIGA | 90 | R$ 1.252.616.572,36 |
| sem data | 1 | R$ 39.782,89 |
| Fornecedores em recuperação judicial | 10 | R$ 290.228.649,86 |
| Emergenciais vigentes | 5 | R$ 13.220.871,43 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 278,2 mi / R$ 12,3 mi / R$ 10,8 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2025005434 (NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA) vence em 07/11/2026 — 1 dias — R$ 22.232.496,64. Objeto: CONTRATAÇÃO DE EMPRESAESPECIALIZADA PARA EXECUÇÃO DE SERVIÇOS COMUNS DEENGENHAR…
- Contrato 2025006297 (NOVACAP ENGENHARIA, INDÚSTRIA E COMÉRCIO LTDA.) vence em 21/11/2026 — 15 dias — R$ 8.260.631,23. Objeto: REGISTRO DE PREÇOS para eventual e futura contratação de empresa especializada …
- Contrato 2025007416 (RIVALL ENGENHARIA LTDA) vence em 23/11/2026 — 17 dias — R$ 6.774.793,37. Objeto: A ação proposta para a demanda é composta pelas CONTRATAÇÃO DE EMPRESA ESPECIAL…
- Contrato 2025002097 (CIVILPORT ENGENHARIA LTDA.) vence em 01/12/2026 — 25 dias — R$ 5.184.777,28. Objeto: A ação proposta para a demanda é composta pelas CONTRATAÇÃO DE EMPRESA ESPECIAL…
- Contrato 2025009691 (DIMENSIONAL ENGENHARIA LTDA) vence em 03/12/2026 — 27 dias — R$ 3.024.643,38. Objeto: O presente TERMO DE REFERÊNCIA foi elaborado a partir da viabilidade técnica e …
- Contrato 2023000622 (UNIÃO NORTE FLUMINENSE ENGENHARIA E COMÉRCIO LTDA.) vence em 08/12/2026 — 32 dias — R$ 287.270.164,81. Objeto: IMPLANTAÇÃO DE CORREDOR SELETIVO PARA ÔNIBUS - TIPO MUVI (MOBILIDADE URBANA VER…
- Contrato 2025006853 (NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA) vence em 16/12/2026 — 40 dias — R$ 15.361.022,81. Objeto: REGISTRO DE PREÇOS para eventual e futura contratação de empresa Especializada …
- Contrato 2026000098 (FABMIX CONCRETOS LTDA) vence em 10/01/2027 — 65 dias — R$ 61.695.367,59. Objeto: Serviços contínuos de conservação, manutenção e restauração, com pavimentos ríg…
- Contrato 2025005644 (F P VIEIRA ENGENHARIA LTDA) vence em 02/02/2027 — 88 dias — R$ 174.740.216,76. Objeto: CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA ELABORAÇÃO DE PROJETO EXECUTIVO E EXE…
- Mais 1 contratos menores (R$ 0,1 mi) vencem em até 30 dias — ver seção 3.
- 40 contratos (R$ 1.399,3 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 47 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 806,5 mi); 8 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 43 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 446,2 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Fornecedor em recuperação judicial: CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO JUDICIAL — 2 contrato(s), R$ 91,5 mi, último fim 08/03/2027.
- 5 contratações emergenciais vigentes (R$ 13,2 mi). Verificar prazo máximo legal (1 ano, Lei 14.133 art. 75 VIII) e licitação substitutiva.

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025005434 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | CONTRATAÇÃO DE EMPRESAESPECIALIZADA PARA EXECUÇÃO DE SERVIÇOS COMUNS … | R$ 22.232.496,64 | 07/11/2026 (PNCP) | 1 |
| 2025006297 | SECID | NOVACAP ENGENHARIA, INDÚSTRIA E COMÉRCIO LTD… | REGISTRO DE PREÇOS para eventual e futura contratação de empresa espe… | R$ 8.260.631,23 | 21/11/2026 (PNCP) | 15 |
| 2025007416 | SECID | RIVALL ENGENHARIA LTDA | A ação proposta para a demanda é composta pelas CONTRATAÇÃO DE EMPRES… | R$ 6.774.793,37 | 23/11/2026 (PNCP) | 17 |
| 2025002097 | SECID | CIVILPORT ENGENHARIA LTDA. | A ação proposta para a demanda é composta pelas CONTRATAÇÃO DE EMPRES… | R$ 5.184.777,28 | 01/12/2026 (PNCP) | 25 |
| 2025009386 | SECID | LECARD ADMNISTRADORA DE CARTÕES LTDA | O presente Termo de Referência se destina à contratação de empresa es… | R$ 100.100,00 | 02/12/2026 | 26 |
| 2025009691 | SECID | DIMENSIONAL ENGENHARIA LTDA | O presente TERMO DE REFERÊNCIA foi elaborado a partir da viabilidade … | R$ 3.024.643,38 | 03/12/2026 (PNCP) | 27 |
| 2024009998 | SECID | INTEGRAL CONSTRUÇÃO E LOGÍSTICA EMPRESARIAL … | CONTRATAÇÃO DE EMPRESAESPECIALIZADA PARAELABORAÇÃO DE PROJETOEXECUTIV… | R$ 9.518.925,83 | 07/12/2026 (PNCP) | 31 |
| 2023000622 | SECID | UNIÃO NORTE FLUMINENSE ENGENHARIA E COMÉRCIO… | IMPLANTAÇÃO DE CORREDOR SELETIVO PARA ÔNIBUS - TIPO MUVI (MOBILIDADE … | R$ 287.270.164,81 | 08/12/2026 (DOERJ) | 32 |
| 2025006853 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | REGISTRO DE PREÇOS para eventual e futura contratação de empresa Espe… | R$ 15.361.022,81 | 16/12/2026 (PNCP) | 40 |
| 2025005678 | SECID | MEGA ENGENHARIA EIRELI | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NO RAMO DE ENGENHARIA E/OU ARQUI… | R$ 9.595.316,52 | 24/12/2026 (PNCP) | 48 |
| 2023010940 | SECID | CS BRASIL FROTAS S.A. | A Contratação de empresa para locação de veículos sem motorista e sem… | R$ 4.896.012,24 | 26/12/2026 | 50 |
| 2026006930 | SECID | FABMIX CONCRETOS LTDA | OBRAS DE REFORÇO ESTRUTURAL DA PONTE BARCELLOS MARTINS,NO MUNICÍPIO D… | R$ 3.608.355,09 | 29/12/2026 (PNCP) | 53 |
| 2025009855 | SECID | MEGA ENGENHARIA EIRELI | A ação proposta para a demanda é composta pela CONTRATAÇÃO DEEMPRESA … | R$ 1.290.249,86 | 30/12/2026 (PNCP) | 54 |
| 2025007689 | SECID | STRONG SERVIÇOS E AGENCIAMENTO DE MÃO DE OBR… | A ação proposta para a demanda é composta pela CONTRATAÇÃO DE EMPRESA… | R$ 4.550.588,22 | 31/12/2026 (PNCP) | 55 |
| 2026000098 | FDRM-RJ | FABMIX CONCRETOS LTDA | Serviços contínuos de conservação, manutenção e restauração, com pavi… | R$ 61.695.367,59 | 10/01/2027 (PNCP) | 65 |
| 2026000240 | SECID | DIMENSIONAL ENGENHARIA LTDA | A presente Ata tem por objeto o registro de preços para a eventual CO… | R$ 2.371.171,05 | 29/01/2027 (PNCP) | 84 |
| 2026001121 | SECID | NEW CONSTRUÇÕES E SERVIÇOS LTDA | CONTRATAÇÃO DEEMPRESA ESPECIALIZADA PARA ELABORAÇÃO DE PROJETOEXECUTI… | R$ 1.855.044,13 | 29/01/2027 (PNCP) | 84 |
| 2026001233 | SECID | CTESA CONSTRUÇÕES LTDA. | A ação proposta para a demanda é composta pela CONTRATAÇÃO DEEMPRESA … | R$ 5.640.000,00 | 29/01/2027 (PNCP) | 84 |
| 2025005644 | SECID | F P VIEIRA ENGENHARIA LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA ELABORAÇÃO DE PROJETO EXECU… | R$ 174.740.216,76 | 02/02/2027 | 88 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026001983 | FDRM-RJ | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | Serviço Contínuo de Conservação, Manutenção e Restauração, em trechos… | R$ 78.932.571,63 | 07/02/2027 (PNCP) | 93 |
| 2026006635 | SECID | LASC ENGENHARIA E GEOTECNIA LTDA | Realização de serviços de CONTRATAÇÃO EMERGENCIAL DE EMPRESA ESPECIAL… | R$ 940.792,65 | 10/02/2027 (PNCP) | 96 |
| 2026001532 | SECID | SVG CONSTRUÇÕES E CONSULTORIA LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA ELABORAÇÃO DE PROJETO EXECU… | R$ 1.647.608,57 | 16/02/2027 (PNCP) | 102 |
| 2025010096 | SECID | ORIENTE CONSTRUÇÃO CIVIL LTDA | CONTRATAÇÃO DEEMPRESA ESPECIALIZADA PARA EXECUÇÃO DE OBRA DE DUPLICAÇ… | R$ 47.992.437,01 | 27/02/2027 (PNCP) | 113 |
| 2025008169 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | 2.1. REGISTRO DE PREÇOS para eventual e futura contratação de empresa… | R$ 74.758.211,87 | 03/03/2027 (PNCP) | 117 |
| 2025008194 | SECID | F P VIEIRA ENGENHARIA LTDA | REGISTRO DE PREÇOS para eventual e futura contratação de empresa espe… | R$ 157.497.113,93 | 03/03/2027 (PNCP) | 117 |
| 2025008201 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | 2.1. REGISTRO DE PREÇOS para eventual e futura contratação de empresa… | R$ 92.543.748,25 | 03/03/2027 (PNCP) | 117 |
| 2025008219 | SECID | CONSTRUTORA JM LTDA | SERVIÇOS COMUNS DE ENGENHARIA, SENDO ESSES A RECUPERAÇÃO DE PAVIMENTA… | R$ 73.900.068,62 | 03/03/2027 (PNCP) | 117 |
| 2025008224 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | 2.1. REGISTRO DE PREÇOS para eventual e futura contratação de empresa… | R$ 74.930.032,15 | 03/03/2027 (PNCP) | 117 |
| 2025008229 | SECID | NOVACAP ENGENHARIA, INDÚSTRIA E COMÉRCIO LTD… | SERVIÇOS COMUNS DE ENGENHARIA, SENDO ESSES ARECUPERAÇÃO DE PAVIMENTAÇ… | R$ 61.383.047,18 | 03/03/2027 (PNCP) | 117 |
| 2025008230 | SECID | UNIÃO NORTE FLUMINENSE ENGENHARIA E COMÉRCIO… | 2.1. REGISTRO DE PREÇOS para eventual e futura contratação de empresa… | R$ 65.363.849,86 | 03/03/2027 (PNCP) | 117 |
| 2025001518 | SECID | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM EXECUÇÃO DE OBRAS DE CONTENÇÃ… | R$ 12.616.946,16 | 08/03/2027 (PNCP) | 122 |
| 2026001429 | SECID | GEO AMBIENTAL EMPREENDIMENTOS LTDA | O objeto do presente procedimento é a contratação de empresa para loc… | R$ 3.367.775,20 | 10/03/2027 (PNCP) | 124 |
| 2026001529 | SECID | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | CARÁTER EMERGENCIAL LOTE 8 - REGIÃO CENTRO SUL | R$ 2.728.488,00 | 23/03/2027 (PNCP) | 137 |
| 2026001509 | SECID | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | caráter emergencial - LOTE 4 | R$ 3.298.680,00 | 24/03/2027 (PNCP) | 138 |
| 2026001511 | SECID | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | Solicitação de apoio emergencial  evento chuvoso extremo e ocorrênci… | R$ 2.954.230,78 | 24/03/2027 (PNCP) | 138 |
| 2026002102 | SECID | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | O objeto do presente procedimento é a contratação de empresa para loc… | R$ 2.049.568,89 | 24/03/2027 (PNCP) | 138 |
| 2026002103 | SECID | DRAGMAQ ENGENHARIA LTDA | O objeto do presente procedimento é a contratação de empresa para loc… | R$ 290.160,00 | 24/03/2027 | 138 |
| 2026002104 | SECID | DIMENSIONAL ENGENHARIA LTDA | O presente TERMO DE REFERÊNCIA foi elaborado a partir da viabilidade … | R$ 7.883.010,16 | 24/03/2027 (PNCP) | 138 |
| 2026002105 | SECID | DIMENSIONAL ENGENHARIA LTDA | O objeto do presente procedimento é a contratação de empresa para loc… | R$ 2.993.577,95 | 24/03/2027 (PNCP) | 138 |
| 2026001510 | SECID | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | caráter emergencial | R$ 3.298.680,00 | 26/03/2027 (PNCP) | 140 |
| 2025006383 | SECID | MMS PINOVA EQUIPAMENTOS E INSTALACOES ESPORT… | A ação proposta para a demanda é fruto de um Convênio nº 960188/2024,… | R$ 1.255.000,00 | 12/04/2027 (PNCP) | 157 |
| 2025004493 | SECID | CONSTRUTORA JM LTDA | O presente TERMO DE REFERÊNCIA foi elaborado a partir da viabilidade … | R$ 7.187.675,19 | 14/04/2027 (PNCP) | 159 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2023001703 | SECID | F P VIEIRA ENGENHARIA LTDA | Realização de serviços de pavimentação asfáltica, drenagem pluvial e … | R$ 252.225.720,44 | 21/05/2026 (DOERJ) | -169 |
| 2022009355 | SECID | CONSTRUTORA METROPOLITANA S.A. | DRENAGEM, PAVIMENTAÇÃO E REUBARNIZAÇÃO DA AV. 22 DE MAIO NO MUNICÍPIO… | R$ 248.749.950,11 | 25/05/2026 (DOERJ) | -165 |
| 2024006725 | SECID | F P VIEIRA ENGENHARIA LTDA | Realiação de serviços de ELABORAÇÃO DE PROJETO EXECUTIVO E EXECUÇÃO D… | R$ 130.105.162,67 | 21/08/2025 | -442 |
| 2024004988 | SECID | INFRATECH ENGENHARIA LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA ELABORAÇÃO DE PROJETO EXECU… | R$ 44.001.808,52 | 26/07/2025 | -468 |
| 2025003592 | SECID | EMPRESA FLUMINENSE DE SERVIÇOS EIRELI-EPP | EXECUÇÃO DE OBRAS DE DRENAGEM PAVIMENTAÇÃO SINALIZAÇÃO VIÁRIA E ILUMI… | R$ 25.045.765,38 | 12/06/2026 | -147 |
| 2025007346 | FDRM-RJ | SISTEMATECH INFORMÁTICA EIRELI | Contratação de empresa especializada na prestação de serviços voltado… | R$ 19.871.777,60 | 05/08/2026 | -93 |
| 2025002545 | SECID | OMEGA CONSTRUTORA E SERVIÇOS LTDA | A ação proposta para a demanda é composta pela CONTRATAÇÃO DE EMPRESA… | R$ 13.512.600,10 | 19/05/2026 (PNCP) | -171 |
| 2023004506 | FDRM-RJ | T.C.R.E. ENGENHARIA LTDA | é a contratação de serviços de assessoria técnica ao Instituto Rio Me… | R$ 10.327.466,58 | 19/09/2025 | -413 |
| 2024003111 | SECID | INTEGRAL CONSTRUÇÃO E LOGÍSTICA EMPRESARIAL … | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA EXECUÇÃO DE OBRAS EMERGENCI… | R$ 9.713.866,40 | 29/04/2025 (PNCP) | -556 |
| 2024007304 | FDRM-RJ | ORIENTE CONSTRUÇÃO CIVIL LTDA | SERVIÇO DE RESTAURAÇÃO DO PAVIMENTO COM ASFALTO BORRACHA NAS RUAS ALB… | R$ 9.113.605,00 | 29/09/2025 (PNCP) | -403 |
| 2025002881 | SECID | CIVILPORT ENGENHARIA LTDA. | A ação proposta para a demanda é composta pelas CONTRATAÇÃO DE EMPRES… | R$ 6.252.104,44 | 03/11/2026 (PNCP) | -3 |
| 2025004099 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | REGISTRO DE PREÇOS para eventual e futura contratação de empresa espe… | R$ 5.676.369,52 | 11/09/2026 (PNCP) | -56 |
| 2025004026 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | 2.1. REGISTRO DE PREÇOS para eventual e futura contratação de empresa… | R$ 5.656.117,72 | 11/09/2026 (PNCP) | -56 |
| 2024004326 | RIO METRÓPOLE | ALVO SOLUCOES EMPRESARIAIS E SERVICOS DE APO… | contratação de pessoa jurídica especializada para a prestação de serv… | R$ 4.598.099,99 | 12/04/2025 | -573 |
| 2023010944 | SECID | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | O presente tem por escopo a contratação de empresa especialiada na pr… | R$ 3.109.118,40 | 26/06/2025 | -498 |
| 2023010047 | SECID | CCN ADMINISTRAÇÃO E LOCAÇÃO DE BENS LTDA. | O presente Termo de Referência tem por objetivo descrever a prestação… | R$ 2.941.522,20 | 29/05/2026 | -161 |
| 2025005362 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | CONTRATAÇÃO DE EMPRESAESPECIALIZADA PARA EXECUÇÃO DE SERVIÇOS COMUNS … | R$ 2.721.890,20 | 24/07/2026 (PNCP) | -105 |
| 2023010361 | FDRM-RJ | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | Contratação de empresa especialiada na prestação de serviços de imple… | R$ 2.506.702,65 | 11/12/2025 | -330 |
| 2025009677 | SECID | SVG CONSTRUÇÕES E CONSULTORIA LTDA | A ação proposta para a demanda é composta pela CONTRATAÇÃO DEEMPRESA… | R$ 1.022.845,10 | 29/10/2026 (PNCP) | -8 |
| 2024003380 | SECID | A B COMPUTACAO - IMPORTACAO E EXPORTACAO LTD… | Contratação de empresa especialiada na prestação de serviço de locaçã… | R$ 874.080,00 | 09/05/2025 | -546 |
| 2025005889 | SECID | NASCIMENTO&GALVÃO CONSTRUTORA LTDA EPP | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA ELABORAÇÃO DE PROJETO EXECU… | R$ 794.956,83 | 05/11/2026 (PNCP) | -1 |
| 2024004327 | RIO METRÓPOLE | ALVO SOLUCOES EMPRESARIAIS E SERVICOS DE APO… | contratação de pessoa jurídica especializada para a prestação de serv… | R$ 699.000,00 | 12/06/2025 | -512 |
| 2022008439 | FDRM-RJ | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Serviços de gestão do abastecimento, com utilização de solução tecnol… | R$ 640.600,00 | 30/04/2025 | -555 |
| 2022005359 | FDRM-RJ | CS BRASIL FROTAS S.A. | prestação de serviços, comuns e contínuos, de locação de veículos aut… | R$ 544.852,80 | 01/02/2025 | -643 |
| 2025000647 | SECID | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | O presente TERMO DE REFERÊNCIA foi elaborado a partir da viabilidade … | R$ 499.800,00 | 11/02/2026 | -268 |
| 2025000648 | SECID | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | O presente TERMO DE REFERÊNCIA foi elaborado a partir da viabilidade … | R$ 499.800,00 | 11/02/2026 | -268 |
| 2025001235 | SECID | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | presente TERMO DE REFERÊNCIA foi elaborado a partir da viabilidade té… | R$ 499.738,36 | 27/02/2026 | -252 |
| 2025001241 | SECID | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | O presente TERMO DE REFERÊNCIA foi elaborado a partir da viabilidade … | R$ 499.738,36 | 16/04/2026 | -204 |
| 2025000633 | SECID | DRAGMAQ ENGENHARIA LTDA | O presente TERMO DE REFERÊNCIA foi elaborado a partir da viabilidade … | R$ 499.680,00 | 11/02/2026 | -268 |
| 2025000650 | SECID | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | O presente TERMO DE REFERÊNCIA foi elaborado a partir da viabilidade … | R$ 499.656,00 | 11/02/2026 | -268 |

_Registros mais antigos (provável falta de baixa no SIGA): 43, R$ 446,2 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2023000622 | SECID | UNIÃO NORTE FLUMINENSE ENGENHARIA E COMÉRCIO… | IMPLANTAÇÃO DE CORREDOR SELETIVO PARA ÔNIBUS - TIPO MUVI (MOBILIDADE … | R$ 287.270.164,81 | 08/12/2026 (DOERJ) | 32 |
| 2025005644 | SECID | F P VIEIRA ENGENHARIA LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA ELABORAÇÃO DE PROJETO EXECU… | R$ 174.740.216,76 | 02/02/2027 | 88 |
| 2025008194 | SECID | F P VIEIRA ENGENHARIA LTDA | REGISTRO DE PREÇOS para eventual e futura contratação de empresa espe… | R$ 157.497.113,93 | 03/03/2027 (PNCP) | 117 |
| 2025008390 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | REGISTRO DE PREÇOS para eventual e futura contratação de empresa espe… | R$ 148.399.761,60 | 14/07/2027 | 250 |
| 2025008209 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | A contratação de empresa especializada na prestação de SERVIÇOS COMUN… | R$ 112.396.522,07 | 14/07/2027 | 250 |
| 2025008201 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | 2.1. REGISTRO DE PREÇOS para eventual e futura contratação de empresa… | R$ 92.543.748,25 | 03/03/2027 (PNCP) | 117 |
| 2025007577 | SECID | OMEGA CONSTRUTORA E SERVIÇOS LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM EXECUÇÃO DE OBRAS DE DRENAGEM… | R$ 81.762.505,43 | 29/08/2027 | 296 |
| 2026001983 | FDRM-RJ | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | Serviço Contínuo de Conservação, Manutenção e Restauração, em trechos… | R$ 78.932.571,63 | 07/02/2027 (PNCP) | 93 |
| 2025008224 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | 2.1. REGISTRO DE PREÇOS para eventual e futura contratação de empresa… | R$ 74.930.032,15 | 03/03/2027 (PNCP) | 117 |
| 2025008169 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | 2.1. REGISTRO DE PREÇOS para eventual e futura contratação de empresa… | R$ 74.758.211,87 | 03/03/2027 (PNCP) | 117 |
| 2025008219 | SECID | CONSTRUTORA JM LTDA | SERVIÇOS COMUNS DE ENGENHARIA, SENDO ESSES A RECUPERAÇÃO DE PAVIMENTA… | R$ 73.900.068,62 | 03/03/2027 (PNCP) | 117 |
| 2025008230 | SECID | UNIÃO NORTE FLUMINENSE ENGENHARIA E COMÉRCIO… | 2.1. REGISTRO DE PREÇOS para eventual e futura contratação de empresa… | R$ 65.363.849,86 | 03/03/2027 (PNCP) | 117 |
| 2026000098 | FDRM-RJ | FABMIX CONCRETOS LTDA | Serviços contínuos de conservação, manutenção e restauração, com pavi… | R$ 61.695.367,59 | 10/01/2027 (PNCP) | 65 |
| 2025008229 | SECID | NOVACAP ENGENHARIA, INDÚSTRIA E COMÉRCIO LTD… | SERVIÇOS COMUNS DE ENGENHARIA, SENDO ESSES ARECUPERAÇÃO DE PAVIMENTAÇ… | R$ 61.383.047,18 | 03/03/2027 (PNCP) | 117 |
| 2024003853 | FDRM-RJ | FABMIX CONCRETOS LTDA | SERVIÇOS DE RESTAURAÇÃO, MANUTENÇÃO, CONSERVAÇÃO COM MELHORIAS DA MOB… | R$ 57.725.485,78 | 26/06/2027 | 232 |
| 2025010096 | SECID | ORIENTE CONSTRUÇÃO CIVIL LTDA | CONTRATAÇÃO DEEMPRESA ESPECIALIZADA PARA EXECUÇÃO DE OBRA DE DUPLICAÇ… | R$ 47.992.437,01 | 27/02/2027 (PNCP) | 113 |
| 2025007446 | SECID | CONSTRUTORA METROPOLITANA S.A. | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA ELABORAÇÃO DE PROJETO EXECU… | R$ 45.637.517,22 | 27/06/2027 | 233 |
| 2026000386 | SECID | CONSTRUTORA AXIAL LTDA | Contratação de empresa especializada para ELABORAÇÃO DE PROJETO EXECU… | R$ 36.489.879,53 | 25/12/2027 | 414 |
| 2026001374 | SECID | FW EMPREENDIMENTOS IMOBILIARIOS E CONSTRUCOE… | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NO RAMO DE ENGENHARIA E/OU ARQUI… | R$ 28.446.000,00 | 01/10/2027 | 329 |
| 2025005434 | SECID | NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | CONTRATAÇÃO DE EMPRESAESPECIALIZADA PARA EXECUÇÃO DE SERVIÇOS COMUNS … | R$ 22.232.496,64 | 07/11/2026 (PNCP) | 1 |

## 7. Fornecedores em recuperação judicial
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026001983 | FDRM-RJ | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | Serviço Contínuo de Conservação, Manutenção e Restauração, em trechos… | R$ 78.932.571,63 | 07/02/2027 (PNCP) | 93 |
| 2023008674 | SECID | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | ELABORAÇÃO DE PROJETO EXECUTIVO E OBRAS DE DRENAGEM PLUVIAL, PAVIMENT… | R$ 46.139.599,82 | 24/10/2024 | -743 |
| 2023006720 | SECID | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | ELABORAÇÃO DE PROJETO EXECUTIVO E OBRAS DE DRENAGEM PLUVIAL, PAVIMENT… | R$ 41.437.913,38 | 24/08/2024 | -804 |
| 2022007433 | SECID | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | Elaboração de Projeto Executivo e execução de serviços de obras de pa… | R$ 34.224.554,47 | 04/07/2023 | -1221 |
| 2023000627 | SECID | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | SERVIÇO COMUM DE ENGENHARIA PARA RECUPERAÇÃO ASFÁLTICA E SINALIZAÇÃO … | R$ 30.870.280,38 | 11/09/2024 | -786 |
| 2022006109 | SECID | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | ELABORAÇÃO DE PROJETO EXECUTIVO E OBRAS DE DRENAGEM PLUVIAL, PAVIMENT… | R$ 23.234.356,37 | 15/12/2023 | -1057 |
| 2022006209 | SECID | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA PROJETO EXECUTIVO E EXECUÇÃ… | R$ 12.765.448,59 | 19/07/2024 | -840 |
| 2025001518 | SECID | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM EXECUÇÃO DE OBRAS DE CONTENÇÃ… | R$ 12.616.946,16 | 08/03/2027 (PNCP) | 122 |
| 2022005626 | SECID | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | REVESTIMENTO ASFÁLTICO DAS ESTRADAS DE ACESSO DAS COMUNIDADES DO CÓRR… | R$ 6.826.495,14 | 31/05/2024 | -889 |
| 2022004104 | SECID | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA EXECUÇÃO DE OBRAS DE PAVIME… | R$ 3.180.483,92 | 15/02/2023 | -1360 |

## 8. Contratações emergenciais vigentes
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026001509 | SECID | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | caráter emergencial - LOTE 4 | R$ 3.298.680,00 | 24/03/2027 (PNCP) | 138 |
| 2026001510 | SECID | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | caráter emergencial | R$ 3.298.680,00 | 26/03/2027 (PNCP) | 140 |
| 2026001511 | SECID | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | Solicitação de apoio emergencial  evento chuvoso extremo e ocorrênci… | R$ 2.954.230,78 | 24/03/2027 (PNCP) | 138 |
| 2026001529 | SECID | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | CARÁTER EMERGENCIAL LOTE 8 - REGIÃO CENTRO SUL | R$ 2.728.488,00 | 23/03/2027 (PNCP) | 137 |
| 2026006635 | SECID | LASC ENGENHARIA E GEOTECNIA LTDA | Realização de serviços de CONTRATAÇÃO EMERGENCIAL DE EMPRESA ESPECIAL… | R$ 940.792,65 | 10/02/2027 (PNCP) | 96 |

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA | 8 | R$ 549.343.116,87 |
| UNIÃO NORTE FLUMINENSE ENGENHARIA E COMÉRCIO LTDA. | 2 | R$ 352.634.014,67 |
| F P VIEIRA ENGENHARIA LTDA | 2 | R$ 332.237.330,69 |
| FABMIX CONCRETOS LTDA | 3 | R$ 123.029.208,46 |
| CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO JUDICIAL | 2 | R$ 91.549.517,79 |
| CONSTRUTORA JM LTDA | 3 | R$ 83.659.971,80 |
| OMEGA CONSTRUTORA E SERVIÇOS LTDA | 1 | R$ 81.762.505,43 |
| NOVACAP ENGENHARIA, INDÚSTRIA E COMÉRCIO LTDA. | 2 | R$ 69.643.678,41 |
| CONSTRUTORA AXIAL LTDA | 2 | R$ 57.415.013,13 |
| ORIENTE CONSTRUÇÃO CIVIL LTDA | 1 | R$ 47.992.437,01 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2023002126 | ENGECONSULT - CONSULTORES TÉCNICOS LTDA | R$ 801.818,22 | R$ 0,00 | R$ 801.818,22 |
| 2022006209 | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | R$ 3.159.780,31 | R$ 2.801.359,39 | R$ 358.420,92 |
| 2022007433 | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | R$ 1.483.484,84 | R$ 1.349.855,28 | R$ 133.629,56 |
| 2022006109 | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | R$ 1.650.185,22 | R$ 1.549.497,66 | R$ 100.687,56 |
| 2022005627 | RC VIEIRA ENGENHARIA LTDA | R$ 1.560.531,07 | R$ 1.502.881,63 | R$ 57.649,44 |
| 2023004506 | T.C.R.E. ENGENHARIA LTDA | R$ 1.549.119,89 | R$ 1.508.842,77 | R$ 40.277,12 |
| 2022004104 | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | R$ 447.459,31 | R$ 412.078,38 | R$ 35.380,93 |
| 2022004181 | FUNDAÇÃO SANTA CABRINI | R$ 6.657,00 | R$ 0,00 | R$ 6.657,00 |

## 11. Unidades incluídas neste dossiê
- FDRM-RJ - Fundo de Desenv. da Região Metropolitana do RJ
- RIO METRÓPOLE - Instituto Rio Metrópole
- SECID - SECRETARIA DE ESTADO DAS CIDADES

## 12. Conjuntos de dados abertos da secretaria
- Conferências Municipais das Cidades (atualizado 2026-01-29): [Realização das Conferências Municipais CSV](https://dadosabertos.rj.gov.br/dataset/fa1fe23a-ec6e-4398-b29b-8940ab4fafd2/resource/44b273ec-1bda-438e-bf22-63f60df75711/download/realizacao-das-conferencias-municipais.csv), [Cartilha Conferências Municipais PDF](https://dadosabertos.rj.gov.br/dataset/fa1fe23a-ec6e-4398-b29b-8940ab4fafd2/resource/1061946c-3c9d-4c4d-9d7d-950500e19a76/download/cartilha-conferencias-municipais.pdf)
- 6ª Conferência Estadual das Cidades (atualizado 2026-01-29): [Delegados Eleitos na 6ª Conferência Est… PDF](https://dadosabertos.rj.gov.br/dataset/30a5ed22-64c7-40d7-a2a1-725438c8acb4/resource/fb882eab-be7e-4b47-b46b-f3c32084553b/download/delegados-eleitos-6-conferencia-estadual-das-cidades.pdf), [Delegados Eleitos na 6ª Conferência Est… CSV](https://dadosabertos.rj.gov.br/dataset/30a5ed22-64c7-40d7-a2a1-725438c8acb4/resource/aa49624c-7bcc-49d6-aa20-a14945c881f9/download/delegados-eleitos-6-conferencia-estadual-das-cidades.csv), [Conselheiros Eleitos e Indicados na 6ª … PDF](https://dadosabertos.rj.gov.br/dataset/30a5ed22-64c7-40d7-a2a1-725438c8acb4/resource/cdb3eebd-cc96-4c54-be09-2cc21a786bdb/download/conselheiros-eleitos-e-indicados-6-conferencia-estadual-das-cidades.pdf), [Conselheiros Eleitos e Indicados na 6ª … CSV](https://dadosabertos.rj.gov.br/dataset/30a5ed22-64c7-40d7-a2a1-725438c8acb4/resource/94d21267-10ce-4edb-a382-762883ea1f90/download/conselheiros-eleitos-e-indicados-6-conferencia-estadual-das-cidades.csv)
- Programa Governo Presente nas Cidades (atualizado 2025-12-19): [PGPC - Projetos em Execução / 4º Trimes… CSV](https://dadosabertos.rj.gov.br/dataset/398e221d-0497-459f-bba6-4332f1c4e42b/resource/462a4d94-7b8c-4f01-85b1-df2775b57843/download/projetos-em-execucao-4-trimestre-de-2025.csv), [PGPC - Projetos em Execução / 4º Trimes… PDF](https://dadosabertos.rj.gov.br/dataset/398e221d-0497-459f-bba6-4332f1c4e42b/resource/de8cad86-5983-45b2-868a-3ae11da789ac/download/projetos-em-execucao-4-trimestre-de-2025.pdf), [PGPC - Projetos em Licitação / 4º Trime… CSV](https://dadosabertos.rj.gov.br/dataset/398e221d-0497-459f-bba6-4332f1c4e42b/resource/35a04553-a378-4260-bfb2-c37bc53520da/download/projetos-em-licitacao-4-trimestre-de-2025.csv), [PGPC - Projetos em Licitação / 4º Trime… PDF](https://dadosabertos.rj.gov.br/dataset/398e221d-0497-459f-bba6-4332f1c4e42b/resource/0ec60970-7b3b-427c-9790-09f64ba64d83/download/projetos-em-licitacao-4-trimestre-de-2025.pdf)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 6 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

- O TCE-RJ concedeu tutela provisória relativa a contratos da Secretaria das Cidades derivados do Pregão Eletrônico nº 002/2024, apontando indícios de falhas de planejamento, diagnósticos estruturais posteriores às autorizações e aditivos elevados; a decisão impôs restrições à execução e a novos aditivos. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- Há duas apurações que devem ser acompanhadas separadamente: uma fiscalização do TCE-RJ sobre contratos de pavimentação e investigações do MPRJ sobre suspeitas relacionadas a contratos da gestão anterior; os apontamentos não equivalem a comprovação de ilícitos. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/) [G1: auditorias de R$ 2,6 bilhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/09/18/governo-do-rj-mp-auditorias-suspeitas-de-irregularidades.ghtml) [G1: investigação sobre patrimônio](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/01/mprj-investiga-crescimento-patrimonial-de-empresas-ligadas-a-douglas-ruas.ghtml)
- As fontes não esclarecem o estágio atual de execução dos contratos, a situação dos serviços, os pagamentos pendentes ou a continuidade das restrições do TCE-RJ em 06/11/2026; esses dados devem ser obtidos antes da posse. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/) [O Globo: suspensão por 30 dias](https://oglobo.globo.com/rio/noticia/2026/04/17/governador-em-exercicio-suspende-licitacoes-e-contratos-das-secretarias-de-cidades-obras-e-do-der-por-30-dias-no-rio.ghtml)

##### Alertas vermelhos

- **Controle externo:** 13 contratos do Pregão Eletrônico nº 002/2024, inicialmente somados em R$ 520,1 milhões, passaram a R$ 744,9 milhões após aditivos, aumento líquido informado de R$ 224,8 milhões, ou 43,23%; o TCE-RJ apontou acréscimos acima do limite de 25% em diversos contratos e concedeu tutela provisória. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- **Execução e medição:** segundo a fiscalização, em 119 trechos os diagnósticos estruturais foram registrados depois das autorizações de serviço; em outros sete trechos, em Itaperuna, Varre-Sai e Italva, os serviços teriam sido executados sem ordem de serviço prévia. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- **Investigações:** o MPRJ investiga suspeitas de organização criminosa, peculato, lavagem de dinheiro, crimes licitatórios e possível contratação fraudulenta relacionadas a contratos da gestão anterior; a reportagem informa que a investigação tramita sob sigilo e não afirma que as suspeitas tenham sido comprovadas. [G1: investigação sobre patrimônio](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/01/mprj-investiga-crescimento-patrimonial-de-empresas-ligadas-a-douglas-ruas.ghtml)
- **Aditivos e planejamento:** a auditoria citada pelo G1 identificou, em um contrato da Secretaria das Cidades, aumento de cerca de R$ 45,3 milhões sobre o valor inicial de R$ 99,7 milhões, passando a R$ 144,9 milhões, ou 45,4%; a auditoria apontou que o percentual superava o limite de 25% previsto na Lei de Licitações. [G1: auditorias de R$ 2,6 bilhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/09/18/governo-do-rj-mp-auditorias-suspeitas-de-irregularidades.ghtml)
- **Sem evidência de interrupção, mas com situação desconhecida:** as fontes consultadas não informam paralisações, atrasos ou risco concreto de interrupção dos serviços da Secretaria; também não informam se as restrições da tutela provisória seguem vigentes em 06/11/2026. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/) [O Globo: suspensão por 30 dias](https://oglobo.globo.com/rio/noticia/2026/04/17/governador-em-exercicio-suspende-licitacoes-e-contratos-das-secretarias-de-cidades-obras-e-do-der-por-30-dias-no-rio.ghtml)

##### Contratos e serviços críticos

- Os contratos decorrentes do Pregão Eletrônico nº 002/2024 tinham valor inicial total informado de R$ 663,6 milhões e destinavam-se à recuperação de pavimentação asfáltica, calçadas e sinalização viária; a matéria não identifica as empresas contratadas nem a vigência dos contratos. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- Em 13 contratos alterados por aditivos, o valor agregado passou de R$ 520,1 milhões para R$ 744,9 milhões; a fonte também informa que vários acréscimos individuais ficaram entre 43,52% e 49,86%. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- O TCE-RJ apontou inclusão de serviços diferentes dos originalmente contratados — entre eles reconstrução de base e sub-base, escavação de vala e imprimação — e considerou insuficientes os elementos apresentados pela Secretaria para justificar os acréscimos. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- Planilhas da Secretaria relacionaram 126 trechos em três contratos, totalizando 55,7 quilômetros e R$ 42,6 milhões em pagamentos; a fiscalização também registrou que os laudos técnicos não foram apresentados ao processo. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- A decisão registrou pendências documentais relativas ao Contrato nº 023/2025, que recebeu aditivo de R$ 2 milhões, e à origem dos valores atualizados informados para os contratos nº 031/2025 e nº 032/2025. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- O TCE-RJ determinou que a Secretaria se abstenha de emitir ordens de serviço sem diagnóstico estrutural prévio, executar intervenções quando esse diagnóstico indicar insuficiência da solução contratada e celebrar aditivos com itens novos estranhos ao objeto. A matéria também informa que a Secretaria deve se abster de firmar novos contratos com base nas atas do Pregão Eletrônico nº 002/2024 sem identificar previamente as vias e comprovar, por diagnóstico, que a solução contratada é adequada. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- Uma auditoria distinta examinou contratos da Secretaria que somam cerca de R$ 702 milhões, firmados por consórcios liderados pela FP Vieira Engenharia; a fonte não informa o número total, os períodos de vigência ou o status atual desses contratos. [G1: auditorias de R$ 2,6 bilhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/09/18/governo-do-rj-mp-auditorias-suspeitas-de-irregularidades.ghtml)
- Em abril de 2026, decreto suspendeu por 30 dias as contratações do DER e também as da Secretaria das Cidades. Pedidos de autorização para processos licitatórios ligados a necessidades específicas — em especial contratos administrativos com prazo a expirar nos dois meses seguintes ou situações emergenciais — deveriam ser encaminhados à Casa Civil para avaliação e eventual aval do governador em exercício; a fonte não esclarece se houve impactos operacionais nem se existe medida equivalente vigente. [O Globo: suspensão por 30 dias](https://oglobo.globo.com/rio/noticia/2026/04/17/governador-em-exercicio-suspende-licitacoes-e-contratos-das-secretarias-de-cidades-obras-e-do-der-por-30-dias-no-rio.ghtml)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- **TCE-RJ:** a decisão monocrática que concedeu tutela provisória foi assinada em 14/10/2026 pelo conselheiro substituto Christiano Lacerda Ghuerren; as fontes fornecidas não trazem decisão posterior, julgamento definitivo ou informação sobre eventual recurso. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- **Auditorias do governo:** o Executivo informou ter concluído 30 auditorias sobre contratos de pelo menos R$ 2,6 bilhões celebrados durante a gestão de Cláudio Castro e encaminhado os relatórios ao MPRJ; esse total abrange contratos da gestão estadual e não é apresentado como exclusivo da Secretaria das Cidades. [G1: auditorias de R$ 2,6 bilhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/09/18/governo-do-rj-mp-auditorias-suspeitas-de-irregularidades.ghtml)
- **MPRJ e PGR:** a investigação sobre suspeitas relacionadas a contratos da Secretaria começou após denúncia anônima; a portaria de instauração do Procedimento Investigatório Criminal é de 15/07/2026. Como a apuração envolve o deputado federal Altineu Côrtes, o MPRJ encaminhou o caso à PGR, que deveria avaliar se havia elementos para investigar o parlamentar. [G1: auditorias de R$ 2,6 bilhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/09/18/governo-do-rj-mp-auditorias-suspeitas-de-irregularidades.ghtml) [G1: investigação sobre patrimônio](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/01/mprj-investiga-crescimento-patrimonial-de-empresas-ligadas-a-douglas-ruas.ghtml)
- **Judiciário:** a reportagem de 01/10/2026 informa que o processo tramita sob sigilo no Tribunal de Justiça do Rio, mas não relata decisão judicial de mérito ou medidas judiciais específicas. [G1: investigação sobre patrimônio](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/01/mprj-investiga-crescimento-patrimonial-de-empresas-ligadas-a-douglas-ruas.ghtml)
- **Contraditório:** Douglas Ruas declarou defender a atuação dos órgãos de controle e afirmou ter tranquilidade quanto aos atos de sua gestão; Altineu Côrtes negou ilícitos e alegou perseguição política. As reportagens registram que as apurações estavam em curso e não comprovavam, por si só, irregularidade ou crime. [G1: auditorias de R$ 2,6 bilhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/09/18/governo-do-rj-mp-auditorias-suspeitas-de-irregularidades.ghtml) [G1: investigação sobre patrimônio](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/01/mprj-investiga-crescimento-patrimonial-de-empresas-ligadas-a-douglas-ruas.ghtml)

##### Riscos de apagão administrativo

- Nada encontrado nas fontes consultadas que confirme risco de interrupção de serviços, paralisação de obras ou atraso de execução na Secretaria das Cidades; a fiscalização do TCE-RJ, porém, registra trechos executados sem ordem prévia e fragilidades de planejamento, o que exige conferência operacional e documental. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/) [O Globo: suspensão por 30 dias](https://oglobo.globo.com/rio/noticia/2026/04/17/governador-em-exercicio-suspende-licitacoes-e-contratos-das-secretarias-de-cidades-obras-e-do-der-por-30-dias-no-rio.ghtml)
- A suspensão de 30 dias decretada em abril de 2026 é um fato histórico, não evidência de suspensão vigente em novembro; as fontes não informam quais licitações ou contratos da Secretaria foram retomados, autorizados como exceção ou permaneceram pendentes. [O Globo: suspensão por 30 dias](https://oglobo.globo.com/rio/noticia/2026/04/17/governador-em-exercicio-suspende-licitacoes-e-contratos-das-secretarias-de-cidades-obras-e-do-der-por-30-dias-no-rio.ghtml)
- As fontes não apresentam dados sobre dívidas da Secretaria, restos a pagar, passivos com fornecedores, folha, quadro de pessoal, sistemas administrativos ou capacidade de fiscalização dos contratos; esses itens não podem ser avaliados com o material disponível. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/) [O Globo: suspensão por 30 dias](https://oglobo.globo.com/rio/noticia/2026/04/17/governador-em-exercicio-suspende-licitacoes-e-contratos-das-secretarias-de-cidades-obras-e-do-der-por-30-dias-no-rio.ghtml)

##### Fatos recentes

- Em 18/09/2026, foi noticiado que o governo enviou ao TCE-RJ pelo menos 17 auditorias internas da CGE realizadas ao longo de 2026, embora o pedido do Tribunal se referisse a informações sobre projetos específicos. [CBN: auditorias enviadas ao TCE-RJ](https://cbn.globo.com/politica/analise/2026/09/18/governo-do-rj-envia-auditorias-ao-tce-e-aponta-irregularidades-em-diversas-areas-do-estado.ghtml)
- Em 18/09/2026, o G1 informou que as 30 auditorias estaduais sobre contratos de pelo menos R$ 2,6 bilhões foram encaminhadas ao MPRJ para aprofundamento das apurações. [G1: auditorias de R$ 2,6 bilhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/09/18/governo-do-rj-mp-auditorias-suspeitas-de-irregularidades.ghtml)
- Em 01/10/2026, o G1 informou que o MPRJ investigava suspeitas envolvendo empresas ligadas a Douglas Ruas e contratos da Secretaria; o procedimento estava sob sigilo e as suspeitas não eram apresentadas como comprovadas. [G1: investigação sobre patrimônio](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/01/mprj-investiga-crescimento-patrimonial-de-empresas-ligadas-a-douglas-ruas.ghtml)
- Em 14/10/2026, o TCE-RJ concedeu tutela provisória relativa aos contratos de pavimentação da Secretaria e determinou restrições à emissão de ordens de serviço, à execução de intervenções e à celebração de determinados aditivos. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)

##### Lacunas da pesquisa

- Solicitar à Secretaria a relação integral dos contratos vigentes e encerrados associados ao Pregão Eletrônico nº 002/2024, com empresas, valores originais e atualizados, aditivos, prazos, saldos, medições, pagamentos, ordens de serviço e situação de execução, pois esses dados não aparecem integralmente nas fontes consultadas. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- Solicitar cópia integral da decisão e do processo do TCE-RJ, a confirmação de sua vigência e cumprimento, a situação de recursos e as providências adotadas para os contratos nº 023/2025, nº 031/2025 e nº 032/2025, cujas pendências são mencionadas na matéria. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- Solicitar os diagnósticos estruturais, laudos, ordens de serviço e registros de medição dos 126 trechos mencionados, incluindo documentação dos sete trechos executados sem ordem prévia e esclarecimentos sobre os 119 diagnósticos posteriores às autorizações. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/)
- Solicitar à CGE, ao GSI e à Secretaria o conjunto de auditorias que alcance a SECID, as respostas dos gestores, os encaminhamentos ao MPRJ e à PGR e a situação atual das apurações; as fontes não detalham o estágio atual nem o resultado dessas providências. [CBN: auditorias enviadas ao TCE-RJ](https://cbn.globo.com/politica/analise/2026/09/18/governo-do-rj-envia-auditorias-ao-tce-e-aponta-irregularidades-em-diversas-areas-do-estado.ghtml) [G1: auditorias de R$ 2,6 bilhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/09/18/governo-do-rj-mp-auditorias-suspeitas-de-irregularidades.ghtml) [G1: investigação sobre patrimônio](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/01/mprj-investiga-crescimento-patrimonial-de-empresas-ligadas-a-douglas-ruas.ghtml)
- Solicitar inventário de serviços e obras em andamento, contratos emergenciais, prazos próximos ao vencimento, compromissos financeiros e riscos de descontinuidade, pois as fontes não informam situação operacional atual, dívidas ou passivos da Secretaria. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/) [O Globo: suspensão por 30 dias](https://oglobo.globo.com/rio/noticia/2026/04/17/governador-em-exercicio-suspende-licitacoes-e-contratos-das-secretarias-de-cidades-obras-e-do-der-por-30-dias-no-rio.ghtml)
- Solicitar a relação de licitações afetadas pelo decreto de suspensão de abril de 2026 e a documentação das autorizações, retomadas ou cancelamentos, pois as fontes não informam o destino dos processos após o período de 30 dias. [O Globo: suspensão por 30 dias](https://oglobo.globo.com/rio/noticia/2026/04/17/governador-em-exercicio-suspende-licitacoes-e-contratos-das-secretarias-de-cidades-obras-e-do-der-por-30-dias-no-rio.ghtml)
- Nada encontrado nas fontes consultadas sobre ações judiciais de mérito contra contratos da Secretaria, decisões definitivas, dívidas, restos a pagar, passivos trabalhistas, quadro de pessoal ou capacidade administrativa; solicitar confirmação formal desses itens à Secretaria e à Procuradoria-Geral do Estado. [TCE-RJ: contratos de R$ 663 milhões](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/) [G1: investigação sobre patrimônio](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/01/mprj-investiga-crescimento-patrimonial-de-empresas-ligadas-a-douglas-ruas.ghtml)

##### Fontes consultadas
1. [Governo do RJ envia auditorias ao TCE e aponta irregularidades em diversas áreas do estado](https://cbn.globo.com/politica/analise/2026/09/18/governo-do-rj-envia-auditorias-ao-tce-e-aponta-irregularidades-em-diversas-areas-do-estado.ghtml) — 2026-09-18
2. [TCE-RJ aponta irregularidades em contratos de R$ 663 milhões da ...](https://www.tribunanf.com.br/tce-rj-aponta-irregularidades-em-contratos-de-r-663-milhoes-da-secretaria-das-cidades-e-impoe-restricoes/) — 2026-10-14
3. [Contratos do Governo do RJ: auditorias de R$ 2,6 bi vão ao MP   G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/09/18/governo-do-rj-mp-auditorias-suspeitas-de-irregularidades.ghtml) — 2026-09-18
4. [ACÓRDÃO Nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026) — 2026-07-06
5. [Douglas Ruas: MPRJ investiga patrimônio de empresas do ... - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/01/mprj-investiga-crescimento-patrimonial-de-empresas-ligadas-a-douglas-ruas.ghtml) — 2026-10-01
6. [Governador em exercício suspende licitações e contratos das ...](https://oglobo.globo.com/rio/noticia/2026/04/17/governador-em-exercicio-suspende-licitacoes-e-contratos-das-secretarias-de-cidades-obras-e-do-der-por-30-dias-no-rio.ghtml) — 2026-04-17


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2025005434 (NOVA ORIENTE CONSTRUÇÃO CIVIL LTDA) vence em 07/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2025006297 (NOVACAP ENGENHARIA, INDÚSTRIA E COMÉRCI…) vence em 21/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025007416 (RIVALL ENGENHARIA LTDA) vence em 23/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2025002097 (CIVILPORT ENGENHARIA LTDA.) vence em 01/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025009386 (LECARD ADMNISTRADORA DE CARTÕES LTDA) vence em 02/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2023001703 (F P VIEIRA ENGENHARIA LTDA, R$ 252,2 mi) consta 'Ativo' no SIGA com fim em 21/05/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2022009355 (CONSTRUTORA METROPOLITANA S.A., R$ 248,7 mi) consta 'Ativo' no SIGA com fim em 25/05/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2024006725 (F P VIEIRA ENGENHARIA LTDA, R$ 130,1 mi) consta 'Ativo' no SIGA com fim em 21/08/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2024004988 (INFRATECH ENGENHARIA LTDA, R$ 44,0 mi) consta 'Ativo' no SIGA com fim em 26/07/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2025003592 (EMPRESA FLUMINENSE DE SERVIÇOS EIRELI-E…, R$ 25,0 mi) consta 'Ativo' no SIGA com fim em 12/06/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Qual é o plano de contingência para o contrato 2026001983 com CONSTRUTORA LYTORANEA LTDA - EM RECUPER… (em recuperação judicial)? Garantia contratual está válida?
13. Qual é o plano de contingência para o contrato 2023008674 com CONSTRUTORA LYTORANEA LTDA - EM RECUPER… (em recuperação judicial)? Garantia contratual está válida?
14. Qual é o plano de contingência para o contrato 2023006720 com CONSTRUTORA LYTORANEA LTDA - EM RECUPER… (em recuperação judicial)? Garantia contratual está válida?
15. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
16. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
17. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
18. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
19. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
