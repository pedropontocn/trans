# Dossiê de transição — Órgãos autônomos, controle e agências reguladoras (AUTONOMOS)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** não se aplica
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/autonomos)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 2067 | R$ 898.452.374,08 |
| Com vigência futura (válidos no SIGA) | 164 | R$ 269.933.820,11 |
| até 30 dias | 17 | R$ 1.452.985,12 |
| até 60 dias | 12 | R$ 5.885.576,52 |
| até 90 dias | 12 | R$ 11.003.321,50 |
| até 180 dias | 19 | R$ 15.792.023,43 |
| vencido no SIGA | 1903 | R$ 628.518.553,97 |
| sem data | 6 | R$ 636.036,02 |
| Fornecedores em recuperação judicial | 7 | R$ 1.750.729,58 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 347,4 mi / R$ 330,3 mi / R$ 272,0 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Mais 17 contratos menores (R$ 1,5 mi) vencem em até 30 dias — ver seção 3.
- 55 contratos (R$ 28,9 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 450 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 111,1 mi); 1 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 1453 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 517,4 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- 1 contrato(s) 'Ativo' com data de fim inválida no SIGA (R$ 0,0 mi), ex.: 2012001752 (03/05/2102). Corrigir o cadastro e informar a vigência real.
- Concentração: PLUXEE BENEFICIOS BRASIL S.A. detém 35% do valor vigente (1 contratos).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025000113 | AGENERSA | ASSOCIACAO FACULDADE INSTITUTO UNIVERSITARIO… | O presente Termo de Referência tem por objetivo descrever a contrataç… | R$ 370.435,00 | 06/11/2026 | 0 |
| 2026008317 | AGENERSA | INOVE TREINAMENTOS E CAPACITACAO LTDA | Trata-se da participação de 05 servidores desta Agência Reguladora no… | R$ 8.670,00 | 06/11/2026 | 0 |
| 2026006367 | FACI | LEC EDUCAÇÃO E PESQUISA LTDA | Participação de 1 (um) servidor da Controladoria Geral do Estado do R… | R$ 4.470,00 | 08/11/2026 | 2 |
| 2026008551 | FACI | INSTITUTO DOS AUDITORES INTERNOS DO BRASIL | Contratação de 3 (três) inscrições para participação dos servidores a… | R$ 7.500,00 | 08/11/2026 | 2 |
| 2026007450 | FACI | OPEN TREINAMENTOS EMPRESARIAIS E EDITORA LTD… | Contratação de 02 (duas) inscrições para participação de servidores d… | R$ 3.780,00 | 09/11/2026 | 3 |
| 2024007342 | PGE | FUNDAÇÃO GETULIO VARGAS | Custeio do curso MESTRADO ACADÊMICO EM DIREITO DA REGULAÇÃO, para a i… | R$ 97.896,00 | 11/11/2026 | 5 |
| 2025006799 | AGENERSA | PORTO SEGURO CIA DE SEGUROS GERAIS | O presente Termo de Referência tem por objetivo descrever a contrataç… | R$ 1.302,89 | 12/11/2026 | 6 |
| 2023009442 | AGETRANSP | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Aquisição de Certificados Digitais | R$ 2.050,00 | 14/11/2026 | 8 |
| 2026007400 | CGE | INSTITUTO DOS AUDITORES INTERNOS DO BRASIL | Contratação de 03 (três) inscrições para participação de servidores d… | R$ 7.500,00 | 14/11/2026 | 8 |
| 2024008820 | AGETRANSP | FUNDAÇÃO GETULIO VARGAS | Realização de Concurso AGETRANSP. | R$ 299.300,00 | 17/11/2026 | 11 |
| 2026007607 | AGENERSA | RPAM SERVIÇOS E EQUIPAMENTOS LTDA | Aquisição de 02 (dois) smartphones à prova de explosão com certificaç… | R$ 31.920,00 | 18/11/2026 | 12 |
| 2026007679 | AGENERSA | M&M EVENTOS LTDA | Trata-se da participação de 04 (quatro) servidores no evento Máximídi… | R$ 20.400,00 | 18/11/2026 | 12 |
| 2026008846 | AGENERSA | BANCO BRADESCO S/A | O objeto do presente termo de referência consiste na análise da viabi… | R$ 20.478,12 | 18/11/2026 | 12 |
| 2022008299 | AGENERSA | BUYSOFT DO BRASIL LTDA (MATRIZ) | Contratação de 01 (uma) subscrição da Suíte Adobe Creative Cloud por … | R$ 21.983,56 | 21/11/2026 | 15 |
| 2026005601 | AGENERSA | ASSOCIAÇÃO BRASILEIRA DE AGÊNCIAS DE REGULAÇ… | Contratação de inscrições de 05 (cinco) servidores no curso/evento T… | R$ 52.000,00 | 30/11/2026 | 24 |
| 2026005470 | FUNPERJ | VIRTUS COMERCIO DE MOVEIS EIRELI | Aquisição de mobiliário, para o Prédio Sede da PGE e para o Centro Cu… | R$ 258.499,79 | 01/12/2026 | 25 |
| 2021007591 | AGENERSA | CLARO S/A | O objeto engloba a prestação de serviços de Rede IP Internet Simétric… | R$ 244.799,76 | 05/12/2026 | 29 |
| 2025000695 | PGE | FACULDADE TREVISAN | Curso MBA em Perícia Contábil | R$ 46.644,96 | 12/12/2026 | 36 |
| 2026007423 | FACI | LEC EDUCAÇÃO E PESQUISA LTDA | Inscrição de três servidores para o curso online de Compliance Antico… | R$ 12.069,00 | 13/12/2026 | 37 |
| 2024010118 | PGE | HERTIE SCHOOL | Custeio de participação no curso de Mestrado Executivo em Administraç… | R$ 147.160,50 | 15/12/2026 | 39 |
| 2024010581 | AGENERSA | RAIOT RIO LTDA | O presente Termo de Referência tem por objetivo descrever a contrataç… | R$ 636.405,36 | 19/12/2026 (PNCP) | 43 |
| 2025006269 | AGETRANSP | RIOPAR PARTICIPAÇÕES S/A | Contratação direta, por inexigibilidade de licitação, para a prestaçã… | R$ 722.206,56 | 19/12/2026 (PNCP) | 43 |
| 2026008904 | FACI | LEC EDUCAÇÃO E PESQUISA LTDA | contratação de 3 (três) inscrições para participação de servidores da… | R$ 12.069,00 | 19/12/2026 | 43 |
| 2026008964 | FACI | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | Contratação de 1 (UMA) inscrição para participação de servidor da Con… | R$ 7.330,00 | 25/12/2026 | 49 |
| 2023010937 | AGETRANSP | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Contratação de empresa para o fornecimento de solução tecnológica | R$ 4.097.435,00 | 27/12/2026 | 51 |
| 2026008968 | FACI | VALERIOTE CURSOS, CONSULTORIA GESTÃO E EMPRE… | Contratação de 1 (UMA) inscrição para participação de servidor da Con… | R$ 3.500,00 | 27/12/2026 | 51 |
| 2025011024 | AGETRANSP | PPN TECNOLOGIA E INFORMÁTICA LTDA | AQUISIÇÃO DE SOLUÇÃO DE FIREWALL. | R$ 10.486,14 | 30/12/2026 | 54 |
| 2026004783 | FUNPERJ | ESTUDIO NNOS ARQUITETURA E PRODUÇÕES ARTÍSTI… | Contratação de serviço especializado visando à produção e execução da… | R$ 175.000,00 | 02/01/2027 | 57 |
| 2026008962 | FACI | CONNECTON MARKETING DE EVENTOS LTDA-ME | Contratação de 3 (TRÊS) inscrição(ões) para participação de servidor(… | R$ 15.270,00 | 04/01/2027 | 59 |
| 2026008970 | FACI | INFOCO-RH LTDA | Contratação de 2 (DUAS) inscrições para participação de servidores da… | R$ 7.380,00 | 06/01/2027 | 61 |
| 2025000094 | FUNPERJ | CONTRATOSGOV SISTEMAS LTDA | Contratação de assinatura da ferramenta gerencial denominada CONTRATO… | R$ 139.780,00 | 07/01/2027 | 62 |
| 2025002028 | FUNPERJ | DB2 ENGENHARIA LTDA | O Projeto Básico tem por objetivo a contratação de empresa especializ… | R$ 6.914.406,91 | 08/01/2027 (PNCP) | 63 |
| 2026007012 | FACI | INSTITUTO BRASILEIRO DE DIREITO ADMINISTRATI… | Contratação de 10 (Dez) inscrições para participação de servidores da… | R$ 22.500,00 | 09/01/2027 | 64 |
| 2026001434 | CGE | INSTITUTO DOS AUDITORES INTERNOS DO BRASIL | Contribuições Associativas Anuais corporativas do Instituto dos Audit… | R$ 6.875,00 | 12/01/2027 | 67 |
| 2025009399 | AGENERSA | FUNDAÇÃO DE DESENVOLVIMENTO DE TECNOPOLIS FU… | Os estudos a serem contratados têm como objetivo garantir o assessora… | R$ 808.829,79 | 13/01/2027 (PNCP) | 68 |
| 2024009659 | AGENERSA | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | O presente Termo de Referência tem por objetivo descrever a contrataç… | R$ 2.525.689,60 | 17/01/2027 (PNCP) | 72 |
| 2026007675 | FACI | INSTITUTO DOS AUDITORES INTERNOS DO BRASIL | Contratação de 01 (uma) inscrição para participação de servidor da Co… | R$ 6.750,00 | 18/01/2027 | 73 |
| 2025010555 | FUNPERJ | AXA SEGUROS S/A | Contratação de seguros para os imóveis da PGE, dentre os quais estão … | R$ 48.000,00 | 22/01/2027 | 77 |
| 2026006666 | FACI | INSTITUTO DOS AUDITORES INTERNOS DO BRASIL | Contratação de 3 (três) inscrições para participação de servidores da… | R$ 20.250,00 | 24/01/2027 | 79 |
| 2026005667 | AGENERSA | ESAFI - ESCOLA DE ADMINISTRAÇÃO E TREINAMENT… | Contratação de inscrições de 01 (um) servidor no curso/evento Gestão… | R$ 4.790,00 | 31/01/2027 | 86 |
| 2023000003 | AGENERSA | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação de empresa para prestação de serviço de Hospedagem em Ser… | R$ 498.070,20 | 03/02/2027 | 89 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000331 | FACI | OWL 4TECH LTDA | Contratação de solução integrada para a expansão da plataforma i2, co… | R$ 543.889,46 | 09/02/2027 (PNCP) | 95 |
| 2025000969 | FUNPERJ | ALL ELETRO COMÉRCIO DE ELETRÔNICOS LTDA | Contratação de empresa especializada em Solução de Gerenciamento e Or… | R$ 28.240,00 | 18/02/2027 | 104 |
| 2023000937 | AGENERSA | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | O objetivo do presente termo é a contratação da Imprensa Oficial do E… | R$ 1.568.160,00 | 03/03/2027 | 117 |
| 2025010972 | AGETRANSP | FUNDAÇÃO GETULIO VARGAS | Contratação de empresa especializada em assinatura de um banco de dad… | R$ 20.843,43 | 05/03/2027 | 119 |
| 2026000665 | FACI | CNS NACIONAL DE SERVIÇOS LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇOS DE APOI… | R$ 369.300,00 | 10/03/2027 | 124 |
| 2026005984 | PGE | ALUMNI COPPEAD ASSOCIAÇÃO DOS ALUNOS DO INST… | custeio da participação do i. Procurador do Estado RODRIGO DE OLIVEIR… | R$ 12.900,00 | 10/03/2027 | 124 |
| 2026000990 | FACI | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | É objeto da presente contratação direta a aquisição de licença do tip… | R$ 6.667,00 | 11/03/2027 | 125 |
| 2026001640 | FACI | FULL HOUSE BUFFET PRODUÇÕES E EVENTOS LTDA | Contratação de empresa especializada na prestação de Serviço de Buffe… | R$ 412.460,00 | 12/03/2027 | 126 |
| 2024006625 | AGENERSA | FUNDAÇÃO EUCLIDES DA CUNHA DE APOIO INSTITUC… | Constitui objeto do presente termo de referência a contratação de con… | R$ 993.794,87 | 13/03/2027 (PNCP) | 127 |
| 2026002082 | FUNPERJ | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | LOTE I - Contratação de subscrições de softwares Red Hat, com garanti… | R$ 1.699.748,00 | 19/03/2027 (PNCP) | 133 |
| 2026002086 | FUNPERJ | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | LOTE I - Contratação de subscrições de softwares Red Hat, com garanti… | R$ 4.068.750,00 | 19/03/2027 (PNCP) | 133 |
| 2025003063 | AGENERSA | TW-SOLUTIONS TELECOMUNICACOES LTDA | Contratação de empresa especializada na prestação de serviços contínu… | R$ 51.084,00 | 27/03/2027 | 141 |
| 2026002145 | FACI | TOP MIX COMÉRCIO E SERVIÇOS LTDA | Aquisição de equipamentos considerados essenciais para atender as dem… | R$ 562.500,00 | 27/03/2027 (PNCP) | 141 |
| 2026009251 | AGENERSA | ASSOCIAÇÃO BRASILEIRA DE AGÊNCIAS DE REGULAÇ… | O objeto do presente termo de referência consiste na análise da viabi… | R$ 192.360,00 | 29/03/2027 | 143 |
| 2026002543 | FACI | QMS DO BRASIL SERVIÇOS DE CERTIFICAÇÃO LTDA … | O presente Termo de Referência tem por objetivo estabelecer as condiç… | R$ 34.100,00 | 07/04/2027 | 152 |
| 2026000538 | AGENERSA | FUNDAÇÃO EUCLIDES DA CUNHA DE APOIO INSTITUC… | Contratação de instituição, para prestar assessoria e apoio técnico à… | R$ 2.066.538,46 | 17/04/2027 (PNCP) | 162 |
| 2026001347 | AGENERSA | ASSOCIAÇÃO BRASILEIRA DE AGÊNCIAS DE REGULAÇ… | Pagamento da anuidade da Associação Brasileira de Agências Reguladora… | R$ 33.450,00 | 22/04/2027 | 167 |
| 2026002968 | AGENERSA | AGUAS DO RIO 4 SPE S.A | Contratação direta, por inexigibilidade de licitação, para o serviço … | R$ 27.238,21 | 22/04/2027 | 167 |
| 2026002895 | PGE | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Contratação do serviço de reserva, emissão e entrega de bilhetes de p… | R$ 3.100.000,00 | 27/04/2027 (PNCP) | 172 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2020000203 | FUNPERJ | LIGHT SERVICOS DE ELETRICIDADE SA | Fornecimento de energia no edifício-sede e unidades regionais, observ… | R$ 12.323.145,60 | 31/12/2024 | -675 |
| 2022007526 | AGENERSA | ALOINFO COMERCIO, TECNOLOGIA SERVIÇOS E LOCA… | Contratação de empresa especializada na prestação de serviços continu… | R$ 9.749.821,67 | 12/10/2025 | -390 |
| 2024000336 | AGENERSA | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | O presente Termo de Referência tem por objetivo descrever a contrataç… | R$ 9.091.940,00 | 31/01/2026 | -279 |
| 2020003084 | FUNPERJ | DECISION SERVICOS DE TECNOLOGIA DA INFORMACA… | Contratação de empresa especializada para fornecimento de equipamento… | R$ 6.949.999,99 | 14/07/2025 | -480 |
| 2025004411 | AGENERSA | FUNDAÇÃO GETULIO VARGAS | Contratação de instituição de pesquisa, ensino ou desenvolvimento ins… | R$ 5.000.000,00 | 11/08/2026 (PNCP) | -87 |
| 2023000112 | AGENERSA | FOCO SERVIÇOS TERCEIRIZADOS LTDA | Contratação de empresa especialiada com dedicação exclusiva de mão de… | R$ 4.967.903,78 | 17/01/2026 | -293 |
| 2021003938 | FUNPERJ | ULTRAPEL LOCAÇÃO E SERVIÇOS LTDA | Contratação de empresa especializada para a prestação de serviços de … | R$ 4.220.000,00 | 22/08/2025 | -441 |
| 2023010797 | AGETRANSP | ARS TECNOLOGIA SERVICOS E CONSULTORIA LTDA | Contratação de empresa especialiada no licenciamento de plataforma de… | R$ 4.122.159,00 | 20/12/2024 | -686 |
| 2024005043 | FUNPERJ | SOFTWARE AG BRASIL INFORMATICA E SERVIÇOS LT… | Contratação do upgrade das licenças de uso dos processadores do tipo … | R$ 3.273.390,92 | 28/06/2025 (PNCP) | -496 |
| 2024003001 | PGE | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | prestação de serviços de agenciamento de viagens na forma do Termo de… | R$ 3.100.000,00 | 06/05/2026 | -184 |
| 2025007194 | FUNPERJ | DRIVE A INFORMÁTICA | Aquisição de um SERVIDOR para processamento de Inteligência Artificia… | R$ 2.914.600,00 | 16/03/2026 (PNCP) | -235 |
| 2024005835 | FUNPERJ | TRANSEGURTEC TECNOLOGIA EM SERVIÇOS LTDA. | Contratação de empresa especializada na prestação dos serviços de pre… | R$ 2.837.952,35 | 27/07/2026 (PNCP) | -102 |
| 2025004922 | CGE | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | 1.1 O objeto da presente licitação é o Registro de Preços para a pres… | R$ 2.788.500,00 | 15/07/2026 (PNCP) | -114 |
| 2021006500 | AGETRANSP | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | Contratação de serviço de fornecimento de vale refeição/alimentação. | R$ 2.051.706,00 | 25/11/2025 | -346 |
| 2025000045 | FUNPERJ | LIDER CONSTRUÇÃO E SERVIÇOS LTDA | Contratação de empresa especializada na prestação de serviços de natu… | R$ 2.039.995,24 | 27/02/2026 (PNCP) | -252 |
| 2024003688 | AGETRANSP | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | Contratação de serviços de gestão do abastecimento, com utilização de… | R$ 1.925.326,00 | 14/11/2025 | -357 |
| 2020000209 | FUNPERJ | AMPLA ENERGIA E SERVIÇOS S/A | Fornecimento de energia em unidades administrativas desta Procuradori… | R$ 1.688.162,40 | 31/12/2024 | -675 |
| 2025003355 | AGENERSA | RAIOT RIO LTDA | Contratação emergencial de Apoio Técnico e Operacional - Serviço de C… | R$ 1.633.675,20 | 23/05/2026 (PNCP) | -167 |
| 2022008859 | AGENERSA | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Contratação de empresa de prestação de serviços de agenciamento de vi… | R$ 1.615.587,02 | 17/11/2024 | -719 |
| 2024004845 | AGENERSA | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | A prestação de serviços de Agência de Viagens, engloba os serviços de… | R$ 1.590.000,00 | 03/07/2026 | -126 |
| 2020000680 | DPGE | KTREE PENSO TECNOLOGIA DA INFORMAÇÃO LTDA. | Trata-se de procedimento administrativo para contratação de pessoa ju… | R$ 1.300.000,00 | 14/08/2025 | -449 |
| 2024007103 | AGENERSA | FUNDAÇÃO GETULIO VARGAS | Tem por objeto a contratação de instituição de ensino superior para m… | R$ 1.123.200,00 | 29/07/2026 (PNCP) | -100 |
| 2024009527 | AGENERSA | SAFE CONVERSÃO DIGITAL LTDA | Contratação de pessoa jurídica especializada para prestação de serviç… | R$ 1.120.000,00 | 03/07/2026 | -126 |
| 2026001283 | FUNPERJ | SOLIDEZ SERVICOS INTEGRADOS LTDA | Prestação de serviços de natureza continuada de manutenção predial na… | R$ 1.006.747,00 | 27/08/2026 (PNCP) | -71 |
| 2024007163 | FACI | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Contratação de empresa especializada na prestação de serviço de Apoio… | R$ 944.800,00 | 26/08/2025 | -437 |
| 2024006468 | AGENERSA | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Contratação de empresa para o fornecimento de solução tecnológica de … | R$ 828.828,30 | 02/03/2026 | -249 |
| 2024010433 | AGETRANSP | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Prestação dos serviços de publicação de matérias legais da AGETRANSP … | R$ 679.800,00 | 06/01/2026 (PNCP) | -304 |
| 2020000132 | FUNPERJ | CONDOMINIO DO EDIFICIO TOWER 2000 | Taxa condominial do imóvel ocupado pela 1ª Procuradoria Regional de N… | R$ 632.542,20 | 31/12/2024 | -675 |
| 2023000555 | AGETRANSP | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Contratação de prestação de serviços de gestão do abastecimento com u… | R$ 615.490,00 | 01/08/2025 | -462 |
| 2025009252 | FUNPERJ | NESHOP COMERCIO DE PEÇAS E COMPONENTES ELETR… | Aquisição EMERGENCIAL de peças de reposição e equipamentos para o sis… | R$ 587.300,00 | 08/02/2026 (PNCP) | -271 |

_Registros mais antigos (provável falta de baixa no SIGA): 1453, R$ 517,4 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025009346 | FUNPERJ | PLUXEE BENEFICIOS BRASIL S.A. | A prestação de serviços de emissão, entrega e administração de meios … | R$ 94.770.000,00 | 01/12/2027 | 390 |
| 2022007931 | AGENERSA | FUNDAÇÃO INSTITUTO DE PESQUISAS ECONOMICAS F… | Contratação de Assessoria Técnica Especializada para atuar como VERIF… | R$ 62.844.612,77 | 30/11/2027 | 389 |
| 2025002600 | AGENERSA | ACADEMIA BRASILEIRA DE LETRAS | Prestação de serviço de locação de espaço físico com estrutura adequa… | R$ 11.339.595,60 | 15/05/2030 | 1286 |
| 2026008851 | AGETRANSP | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada para a prestação de serviços con… | R$ 9.190.818,00 | 03/11/2028 | 728 |
| 2026006801 | FACI | VR BENEFICIOS E SERVICOS DE PROCESSAMENTO IN… | Registro de Preços para prestação dos serviços de emissão, entrega e … | R$ 9.115.440,00 | 24/08/2027 | 291 |
| 2025002028 | FUNPERJ | DB2 ENGENHARIA LTDA | O Projeto Básico tem por objetivo a contratação de empresa especializ… | R$ 6.914.406,91 | 08/01/2027 (PNCP) | 63 |
| 2026003703 | AGENERSA | NORTESUL TRANSPORTES E SERVICOS LTDA | Contratação de Apoio Técnico e Operacional - Serviço de Condutores e … | R$ 5.448.521,88 | 15/05/2029 | 921 |
| 2015006153 | FUNPERJ | EDUARDO LIRA PROPRIEDADES IMOBILIÁRIAS EIRELI | Aquisição de Imóvel Comercial localizado no 3º pavimento do Edifício … | R$ 4.800.000,00 | 21/08/2050 | 8689 |
| 2026006174 | FUNPERJ | ENGEMAR SERVIÇOS DE ENGENHARIA EIRELI | Contratação de empresa especializada na prestação de serviços de natu… | R$ 4.154.688,20 | 28/08/2028 | 661 |
| 2023010937 | AGETRANSP | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Contratação de empresa para o fornecimento de solução tecnológica | R$ 4.097.435,00 | 27/12/2026 | 51 |
| 2026002086 | FUNPERJ | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | LOTE I - Contratação de subscrições de softwares Red Hat, com garanti… | R$ 4.068.750,00 | 19/03/2027 (PNCP) | 133 |
| 2026005288 | FUNPERJ | BRAVO ASSESSORIA E SERVICOS EMPRESARIAIS LTDA | Contratação de prestação de serviços de copeiragem, de natureza contí… | R$ 3.869.851,68 | 24/08/2028 | 657 |
| 2026002895 | PGE | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Contratação do serviço de reserva, emissão e entrega de bilhetes de p… | R$ 3.100.000,00 | 27/04/2027 (PNCP) | 172 |
| 2024009659 | AGENERSA | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | O presente Termo de Referência tem por objetivo descrever a contrataç… | R$ 2.525.689,60 | 17/01/2027 (PNCP) | 72 |
| 2025005704 | FUNPERJ | AIR TIME ENGENHARIA E INSTALAÇOES LTDA | Prestação de serviços contínuos de operação, manutenção preventiva, c… | R$ 2.110.375,18 | 01/08/2027 | 268 |
| 2025001296 | AGENERSA | CS BRASIL FROTAS S.A. | Locação de veículos de serviços, sem fornecimento de condutores e sem… | R$ 2.090.826,16 | 10/09/2028 | 674 |
| 2026000538 | AGENERSA | FUNDAÇÃO EUCLIDES DA CUNHA DE APOIO INSTITUC… | Contratação de instituição, para prestar assessoria e apoio técnico à… | R$ 2.066.538,46 | 17/04/2027 (PNCP) | 162 |
| 2026001888 | FUNPERJ | ULTRAPEL LOCAÇÃO E SERVIÇOS LTDA | Contratação de empresa especializada para prestação de serviços de ou… | R$ 1.999.922,40 | 16/04/2029 | 892 |
| 2026006140 | FUNPERJ | ELEVADORES OTIS LTDA | Contratação de empresa especializada na prestação de serviços técnico… | R$ 1.943.583,00 | 03/09/2031 | 1762 |
| 2026002082 | FUNPERJ | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | LOTE I - Contratação de subscrições de softwares Red Hat, com garanti… | R$ 1.699.748,00 | 19/03/2027 (PNCP) | 133 |

## 7. Fornecedores em recuperação judicial
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2018001564 | FUNPERJ | MYRIAD - TECNOLOGIA E INFORMAÇÃO S/A - EM RE… | Contratação de empresa especializada na prestação de serviços de guar… | R$ 783.700,56 | 03/04/2020 | -2408 |
| 2016001419 | FUNPERJ | MYRIAD - TECNOLOGIA E INFORMAÇÃO S/A - EM RE… | Contratação de empresa especializada na prestação de serviços de guar… | R$ 748.100,00 | 10/04/2018 | -3132 |
| 2020001958 | FUNPERJ | MYRIAD - TECNOLOGIA E INFORMAÇÃO S/A - EM RE… | Contratação de empresa especializada na prestação de serviços de guar… | R$ 107.611,89 | 03/07/2020 | -2317 |
| 2020003198 | FUNPERJ | MYRIAD - TECNOLOGIA E INFORMAÇÃO S/A - EM RE… | Contratação de empresa especializada na prestação de serviços de guar… | R$ 71.741,26 | 03/09/2020 | -2255 |
| 2019002809 | FUNPERJ | MYRIAD - TECNOLOGIA E INFORMAÇÃO S/A - EM RE… | Contratação de empresa especializada na prestação de serviços de guar… | R$ 17.644,91 | 03/04/2020 | -2408 |
| 2019001606 | FUNPERJ | MYRIAD - TECNOLOGIA E INFORMAÇÃO S/A - EM RE… | Contratação de empresa especializada na prestação de serviços de guar… | R$ 13.167,76 | 03/04/2020 | -2408 |
| 2020003162 | FUNPERJ | MYRIAD - TECNOLOGIA E INFORMAÇÃO S/A - EM RE… | Contratação de empresa especializada na prestação de serviços de guar… | R$ 8.763,20 | 03/09/2020 | -2255 |

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| PLUXEE BENEFICIOS BRASIL S.A. | 1 | R$ 94.770.000,00 |
| FUNDAÇÃO INSTITUTO DE PESQUISAS ECONOMICAS FIPE | 1 | R$ 62.844.612,77 |
| ACADEMIA BRASILEIRA DE LETRAS | 1 | R$ 11.339.595,60 |
| LECARD ADMNISTRADORA DE CARTÕES LTDA | 1 | R$ 9.190.818,00 |
| VR BENEFICIOS E SERVICOS DE PROCESSAMENTO INSTITUICAO DE PA… | 1 | R$ 9.115.440,00 |
| DB2 ENGENHARIA LTDA | 1 | R$ 6.914.406,91 |
| EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES LTDA | 3 | R$ 6.803.860,00 |
| NORTESUL TRANSPORTES E SERVICOS LTDA | 1 | R$ 5.448.521,88 |
| EDUARDO LIRA PROPRIEDADES IMOBILIÁRIAS EIRELI | 1 | R$ 4.800.000,00 |
| ENGEMAR SERVIÇOS DE ENGENHARIA EIRELI | 1 | R$ 4.154.688,20 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2020001469 | RIOFORTE VIGILANCIA E SEGURANÇA PRIVADA LTDA | R$ 11.673.277,59 | R$ 4.999.074,00 | R$ 6.674.203,59 |
| 2020000203 | LIGHT SERVICOS DE ELETRICIDADE SA | R$ 7.748.538,62 | R$ 3.217.527,64 | R$ 4.531.010,98 |
| 2018004618 | RIO DE JANEIRO SERVICOS E COMERCIO LTDA ME | R$ 7.167.042,90 | R$ 3.631.223,84 | R$ 3.535.819,06 |
| 2018006696 | RIOFORTE VIGILANCIA E SEGURANÇA PRIVADA LTDA | R$ 6.164.144,71 | R$ 2.861.947,41 | R$ 3.302.197,30 |
| 2020003161 | SOFTWARE AG BRASIL INFORMATICA E SERVIÇOS LT… | R$ 6.420.769,46 | R$ 3.178.851,26 | R$ 3.241.918,20 |
| 2020004908 | SOLAR SERVICOS E ADMINISTRACAO DE MAO DE OBR… | R$ 3.858.027,86 | R$ 1.436.461,52 | R$ 2.421.566,34 |
| 2021002897 | SOFTWARE AG BRASIL INFORMATICA E SERVIÇOS LT… | R$ 3.489.250,91 | R$ 1.349.244,43 | R$ 2.140.006,48 |
| 2017002690 | ULTRAPEL LOCAÇÃO E SERVIÇOS LTDA | R$ 9.261.664,47 | R$ 7.127.559,28 | R$ 2.134.105,19 |
| 2020004593 | B7 EMPREENDIMENTOS LTDA | R$ 2.405.452,25 | R$ 967.857,12 | R$ 1.437.595,13 |
| 2019004650 | EMPRESA BRASILEIRA DE CORREIOS E TELÉGRAFOS | R$ 1.526.188,46 | R$ 163.495,72 | R$ 1.362.692,74 |
| 2018006727 | FOCO ASN 2010 SERVIÇOS GERAIS LTDA | R$ 2.444.721,11 | R$ 1.146.210,74 | R$ 1.298.510,37 |
| 2019001008 | MONTE CRISTO COMERCIO E SERVIÇOS TÉCNICOS EI… | R$ 2.378.195,71 | R$ 1.123.613,07 | R$ 1.254.582,64 |
| 2020002305 | FUTURE TECHNOLOGIES INFORMÁTICA LTDA. | R$ 3.340.542,85 | R$ 2.100.022,07 | R$ 1.240.520,78 |
| 2020000213 | FUTURE TECHNOLOGIES INFORMÁTICA LTDA. | R$ 2.996.048,44 | R$ 1.867.632,54 | R$ 1.128.415,90 |
| 2019007134 | FOCO ASN 2010 SERVIÇOS GERAIS LTDA | R$ 1.954.241,01 | R$ 960.828,32 | R$ 993.412,69 |
| 2018005014 | EMPRESA BRASILEIRA DE CORREIOS E TELÉGRAFOS | R$ 1.462.232,04 | R$ 471.414,60 | R$ 990.817,44 |
| 2016000083 | BEST VIGILANCIA E SEGURANÇA LTDA | R$ 6.877.890,18 | R$ 5.986.602,87 | R$ 891.287,31 |
| 2018003007 | SOFTWARE AG BRASIL INFORMATICA E SERVIÇOS LT… | R$ 3.249.810,35 | R$ 2.480.737,53 | R$ 769.072,82 |
| 2020001702 | MONTE CRISTO COMERCIO E SERVIÇOS TÉCNICOS EI… | R$ 1.330.713,00 | R$ 561.724,69 | R$ 768.988,31 |
| 2017005308 | FUNDAÇÃO COORDENAÇÃO DE PROJETOS, PESQUISAS … | R$ 2.527.270,50 | R$ 1.780.860,00 | R$ 746.410,50 |

## 11. Unidades incluídas neste dossiê
- AGENERSA - AG REGUL ENERGIA E SANEAMENTO DO EST RJ
- AGETRANSP - Agência Reg Ser Púb Trans Aqua Fer Met Ro
- CGE - CONTROLADORIA GERAL DO ESTADO DO RJ
- DPGE - DEFENSORIA PÚBLICA GERAL DO ESTADO
- FACI - FUNDO DE APRIMORAMENTO CONTROLE INTERNO
- FUNDEP - FUNDO ESPECIAL DO DEPÓSITO PUBLICO
- FUNPERJ - FUNDO ESPECIAL DA PROCURADORIA GERAL DO ERJ
- PGE - PROCURADORIA GERAL DO ESTADO

## 12. Conjuntos de dados abertos da secretaria
- Nenhum conjunto encontrado no portal.

## 13. Pesquisa aprofundada (web, com citações)
_Não executada. Defina PERPLEXITY_API_KEY e rode novamente._

## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2025000113 (ASSOCIACAO FACULDADE INSTITUTO UNIVERSI…) vence em 06/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2026008317 (INOVE TREINAMENTOS E CAPACITACAO LTDA) vence em 06/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2026006367 (LEC EDUCAÇÃO E PESQUISA LTDA) vence em 08/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2026008551 (INSTITUTO DOS AUDITORES INTERNOS DO BRA…) vence em 08/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2026007450 (OPEN TREINAMENTOS EMPRESARIAIS E EDITOR…) vence em 09/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2020000203 (LIGHT SERVICOS DE ELETRICIDADE SA, R$ 12,3 mi) consta 'Ativo' no SIGA com fim em 31/12/2024: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2022007526 (ALOINFO COMERCIO, TECNOLOGIA SERVIÇOS E…, R$ 9,7 mi) consta 'Ativo' no SIGA com fim em 12/10/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2024000336 (GREEN CARD S/A REFEIÇÕES COMERCIO E SER…, R$ 9,1 mi) consta 'Ativo' no SIGA com fim em 31/01/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2020003084 (DECISION SERVICOS DE TECNOLOGIA DA INFO…, R$ 6,9 mi) consta 'Ativo' no SIGA com fim em 14/07/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2025004411 (FUNDAÇÃO GETULIO VARGAS, R$ 5,0 mi) consta 'Ativo' no SIGA com fim em 11/08/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Qual é o plano de contingência para o contrato 2018001564 com MYRIAD - TECNOLOGIA E INFORMAÇÃO S/A - … (em recuperação judicial)? Garantia contratual está válida?
13. Qual é o plano de contingência para o contrato 2016001419 com MYRIAD - TECNOLOGIA E INFORMAÇÃO S/A - … (em recuperação judicial)? Garantia contratual está válida?
14. Qual é o plano de contingência para o contrato 2020001958 com MYRIAD - TECNOLOGIA E INFORMAÇÃO S/A - … (em recuperação judicial)? Garantia contratual está válida?
15. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
16. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
17. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
18. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
19. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
