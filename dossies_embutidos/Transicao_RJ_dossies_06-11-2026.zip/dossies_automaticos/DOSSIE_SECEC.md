# Dossiê de transição — Secretaria de Estado de Cultura e Economia Criativa (SECEC)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/secec)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 2444 | R$ 551.334.659,99 |
| Com vigência futura (válidos no SIGA) | 448 | R$ 101.751.574,62 |
| até 30 dias | 82 | R$ 16.534.526,94 |
| até 60 dias | 101 | R$ 7.620.380,90 |
| até 90 dias | 31 | R$ 6.858.787,45 |
| até 180 dias | 63 | R$ 11.307.829,52 |
| vencido no SIGA | 1996 | R$ 449.583.085,37 |
| sem data | 22 | R$ 2.129.222,62 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 79,6 mi / R$ 43,5 mi / R$ 39,0 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2026004492 (FP AUDIO EIRELI) vence em 10/11/2026 — 4 dias — R$ 1.250.000,00. Objeto: Contratação de empresa especializada para prestação de serviço de sonorização e…
- Contrato 2024009026 (FUNDAÇÃO GETULIO VARGAS) vence em 17/11/2026 — 11 dias — R$ 8.000.000,00. Objeto: Contratação direta de instituição para prestação de serviços de desenvolvimento…
- Mais 80 contratos menores (R$ 7,3 mi) vencem em até 30 dias — ver seção 3.
- 246 contratos (R$ 37,3 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 1320 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 306,3 mi); 5 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 676 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 143,2 mi): provável falta de baixa no SIGA (risco de controle, não de execução).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026003422 | FUNARJ | GMK LTDA | Destina-se a contratação do Grupo Musical KARAMETADE, em apresentação… | R$ 90.000,00 | 06/11/2026 | 0 |
| 2026003516 | FUNARJ | CINE & TEATRO PRODUÇÕES LTDA - ME | Contratação do ator Alexandre Lino com o espetáculo ``O Porteiro`` pa… | R$ 60.000,00 | 06/11/2026 | 0 |
| 2025009171 | FUNARJ | FENIX PRODUÇÕES ARTISTÍCAS LTDA | A FUNARJ, no contínuo propósito de democratizar o acesso à arte e cul… | R$ 5.900,00 | 07/11/2026 | 1 |
| 2026003529 | FUNARJ | LUX EMPREENDIMENTOS CULTURAIS LTDA | Apresentação do artista LEO JAIME, a ser realizada no teatro João Cae… | R$ 70.000,00 | 07/11/2026 | 1 |
| 2026003530 | FUNARJ | OUTRO LUGAR PRODUCOES LTDA | Contratação artística da banda Detonautas para o Projeto Giro Cultura… | R$ 120.000,00 | 07/11/2026 | 1 |
| 2026003543 | FUNARJ | DUAS PAIXÕES PRODUÇÕES PROMOÇÕES EVENTOS EIR… | Contratação do Grupo Bokaloka para a realização de show ao vivo como … | R$ 65.000,00 | 07/11/2026 | 1 |
| 2026003544 | FUNARJ | V.F. PRODUCOES E EVENTOS ARTISTICOS LTDA - ME | Contratação do(a) cantor João Gabriel para a realização de uma aprese… | R$ 70.000,00 | 07/11/2026 | 1 |
| 2026007378 | FUNARJ | GOLD 120 PRODUCOES E EVENTOS EIRELI | Contratação do artista TIEE para o Projeto Fim de Tarde | R$ 60.000,00 | 09/11/2026 | 3 |
| 2025009233 | FUNARJ | ARMAZEM COMPANHIA DE TEATRO LTDA | Contratação da empresa especializada para a realização da montagem e … | R$ 20.000,00 | 10/11/2026 | 4 |
| 2025009281 | FUNARJ | BEATRIZ MAGALHÃES CAPARICA | Contratação artística da Caravana Alucinada  Cia Teatro Independente | R$ 9.375,00 | 10/11/2026 | 4 |
| 2026004492 | FUNARJ | FP AUDIO EIRELI | Contratação de empresa especializada para prestação de serviço de son… | R$ 1.250.000,00 | 10/11/2026 (PNCP) | 4 |
| 2026004497 | FUNARJ | IANNACONI NEVES AUDIO LTDA | Contratação de empresa especializada para prestação de serviço de son… | R$ 289.814,15 | 10/11/2026 | 4 |
| 2026007480 | FUNARJ | MARIANA RAMALHO PRODUCAO MUSICAL LTDA | Contratação da banda Bloody Mary, para a realização de apresentação, … | R$ 18.000,00 | 11/11/2026 | 5 |
| 2026003576 | FUNARJ | DGE ENTERTAINMENT LTDA | Contratação do cantor Thiago Pantaleão para a realização de show ao v… | R$ 20.000,00 | 12/11/2026 | 6 |
| 2026003620 | FUNARJ | ROSIMEIRE MARIA DE PAIVA 03460817690 | Contratação artística da cantora Gisele Nascimento para o Projeto Gir… | R$ 70.000,00 | 12/11/2026 | 6 |
| 2026003622 | FUNARJ | ROSIMEIRE MARIA DE PAIVA 03460817690 | Contratação da artista Michelle Nascimento | R$ 70.000,00 | 13/11/2026 | 7 |
| 2025009462 | FUNARJ | GRUPO ANONIMO DE TEATRO | Contratação da empresa GRUPO ANONIMO DE TEATRO, detentora dos direito… | R$ 15.000,00 | 14/11/2026 | 8 |
| 2026003677 | FUNARJ | LBR COMPANY PRODUCOES LTDA | Contratação da cantora Joanna para a realização de shows ao vivo como… | R$ 120.000,00 | 14/11/2026 | 8 |
| 2026003734 | FUNARJ | CRIATIVE MUSIC LTDA | Contratação do artista Luã Freitas para o Projeto Giro Cultural. | R$ 70.000,00 | 14/11/2026 | 8 |
| 2026003784 | FUNARJ | PRODUTORA ARTISTICA VIP LTDA | Contratação da cantora Victoria Gaby para realização de apresentação … | R$ 80.000,00 | 14/11/2026 | 8 |
| 2026007458 | FUNARJ | OUTRO LUGAR PRODUCOES LTDA | Contratação do(a) banda DETONAUTAS para a realização de show ao vivo … | R$ 60.000,00 | 14/11/2026 | 8 |
| 2026007515 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | A contratação da banda Rebanhão Projeto Giro Cultural | R$ 40.000,00 | 14/11/2026 | 8 |
| 2026007516 | FUNARJ | I.ML. LEITE PRODUCOES ARTISTICAS ME | Contratação artística de ISABELLA TAVIANI para o Projeto Giro Cultura… | R$ 42.000,00 | 14/11/2026 | 8 |
| 2026007526 | FUNARJ | ALEX KERTH FERNANDES 09015207720 | Contratação da Banda Radial 80 para o Projeto Giro Cultural, FUNARJ | R$ 15.000,00 | 14/11/2026 | 8 |
| 2026007527 | FUNARJ | RW PRODUÇÕES ARTÍSTICAS LTDA | Contratação do artista Biafra para a realização de apresentação music… | R$ 60.000,00 | 14/11/2026 | 8 |
| 2026007528 | FUNARJ | MOREIRA MOTTA PRODUCOES E ENTRETENIMENTO LTDA | Contratação artística da banda Catedral para o Projeto Giro Cultural. | R$ 45.000,00 | 14/11/2026 | 8 |
| 2026007529 | FUNARJ | PEDETERESA PRODUCAO CULTURAL LTDA | contratação do Pede Tereza, para a realização de uma apresentação art… | R$ 16.000,00 | 14/11/2026 | 8 |
| 2026007540 | FUNARJ | FNL ESTRUTURAS E SERVIÇOS LTDA | contratação do cantor Ed Parango, para a realização de uma apresentaç… | R$ 10.000,00 | 14/11/2026 | 8 |
| 2026007567 | FUNARJ | LUMA P.C.AGUIAR LACERDA PRODUÇÃO | contratação do Frank Aguiar, para a realização de show ao vivo, no Pr… | R$ 100.000,00 | 15/11/2026 | 9 |
| 2026007577 | FUNARJ | CEU MUSIC PRODUÇÕES ARTÍSTICAS LTDA | Contratação do cantor Samuel Messias para o Projeto Giro Cultural | R$ 80.000,00 | 15/11/2026 | 9 |
| 2026007585 | FUNARJ | RABIN PRODUCOES ARTISTICAS | Contratação do artista Fábio Rabin, Projeto Giro Cultural FUNARJ. | R$ 29.820,00 | 15/11/2026 | 9 |
| 2026007633 | FUNARJ | BRAVUS PRODUCOES ARTISTICAS LTDA | A contratação do cantor Glauco Zulo, Projeto Giro Cultural, promovido… | R$ 40.000,00 | 16/11/2026 | 10 |
| 2024009026 | FEC | FUNDAÇÃO GETULIO VARGAS | Contratação direta de instituição para prestação de serviços de desen… | R$ 8.000.000,00 | 17/11/2026 (PNCP) | 11 |
| 2026007697 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | O cantor Alex Gonzaga | R$ 46.000,00 | 17/11/2026 | 11 |
| 2023009288 | FMIS | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação de serviço de correio eletrônico email incluindo infraest… | R$ 15.422,40 | 18/11/2026 | 12 |
| 2026003317 | FUNARJ | CAJU PARA BAIXO PRODUCOES ARTISTICAS LTDA | Contratação da banda Caju pra Baixo para a realização de apresentação… | R$ 72.400,00 | 18/11/2026 | 12 |
| 2026007674 | FUNARJ | BRISA RECORDS PRODUTORA LTDA | Contratação da artista MARIANA AYDAR, Projeto Fim de Tarde, FUNARJ | R$ 60.000,00 | 18/11/2026 | 12 |
| 2026003833 | FUNARJ | JOAO JOSE PISTUM NETTO | Contratação artística do cantor Thiago Martins para o Projeto Giro Cu… | R$ 80.000,00 | 19/11/2026 | 13 |
| 2026007678 | FUNARJ | CESARIO RAMOS BASTOS 10342453769 | A contratação do artista Cesário Ramos, para a realização de um show … | R$ 10.000,00 | 21/11/2026 | 15 |
| 2026007762 | FUNARJ | OITO INFINITO PRODUCOES LTDA | Contratação artistica do Humorista, Matheus Ceará, nome artístico de … | R$ 40.000,00 | 21/11/2026 | 15 |
| 2026008884 | FMIS | EDITORA ARTHÉMAN E PRODUÇÕES CULTURAIS LTDA | Apoio à Casa MIS em Paraty, com o objetivo de atender às demandas ins… | R$ 70.000,00 | 21/11/2026 | 15 |
| 2025003396 | FUNARJ | CIG PRODUCOES E EVENTOS LTDA - ME | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVICOS DE LOCA… | R$ 985.537,50 | 22/11/2026 (PNCP) | 16 |
| 2026007926 | FUNARJ | LET`S GIG SERVICOS DE PRODUCAO CULTURAL E AG… | A contratação do grupo FAT FAMILY | R$ 60.000,00 | 23/11/2026 | 17 |
| 2026007927 | FUNARJ | LBR COMPANY PRODUCOES LTDA | Contratação artística do cantor Samuel Miranda para o Projeto Giro Cu… | R$ 40.000,00 | 23/11/2026 | 17 |
| 2026007928 | FUNARJ | BEATCARIOCA PRODUCOES ARTISTICAS EIRELI - EPP | Contratação do artista NICO REZENDE para a realização de apresentação… | R$ 60.000,00 | 23/11/2026 | 17 |
| 2026007930 | FUNARJ | RODRIGO BERNARDO DE LARA | Contratação do artista Sérgio Mallandro para a realização de show ao … | R$ 60.000,00 | 23/11/2026 | 17 |
| 2026007941 | FUNARJ | RW PRODUÇÕES ARTÍSTICAS LTDA | Contratação artística do cantor Biafra para o Projeto Giro Cultural. | R$ 60.000,00 | 24/11/2026 | 18 |
| 2026007971 | FUNARJ | 39.441.730 LUIZ OTAVIO DE ALMEIDA CORREA | Contratação do artista Otávio Almeida para a realização de apresentaç… | R$ 12.000,00 | 24/11/2026 | 18 |
| 2026007947 | FUNARJ | CEU MUSIC PRODUÇÕES ARTÍSTICAS LTDA | Contratação da Pamela Oliveira é uma artista gospel brasileira para o… | R$ 20.000,00 | 25/11/2026 | 19 |
| 2026003948 | FUNARJ | DGE ENTERTAINMENT LTDA | Contratação artística da cantora Lourena para o Projeto Giro Cultural. | R$ 20.000,00 | 25/11/2026 | 19 |
| 2026006812 | FUNARJ | 262 VIDEO LOCADORA, PRODUCOES E SERVICOS GER… | A Contratação do artista MARCOS SABINO | R$ 70.000,00 | 25/11/2026 | 19 |
| 2026008004 | FUNARJ | DOZE PRODUCOES CINEMATOGRAFICAS AUDIOVISUAIS… | Destina-se a contratação da empresa Doze Produções Cinematográficas A… | R$ 80.000,00 | 25/11/2026 | 19 |
| 2024009404 | FUNARJ | TOKIO MARINE SEGURADORA SA | Destina-se a contratação de empresa especializada em prestação de ser… | R$ 699.185,09 | 26/11/2026 (PNCP) | 20 |
| 2026003991 | FUNARJ | OUTRO LUGAR PRODUCOES LTDA | A presente contratação refere-se à prestação de serviço artístico, co… | R$ 120.000,00 | 27/11/2026 | 21 |
| 2025009843 | FUNARJ | FIMPRA SERVIÇOS DE DEDETIZAÇÃO LTDA | Constitui o objeto deste termo de referência a prestação serviços de … | R$ 7.000,00 | 28/11/2026 | 22 |
| 2025009852 | FUNARJ | FELIPE HAIUT SOARES | Destina-se a contratação da empresa FELIPE HAIUT SOARES para apresent… | R$ 10.000,00 | 28/11/2026 | 22 |
| 2026004186 | FUNARJ | AMANDA ALVES PRODUÇÕES LTDA | Contratação da cantora Amanda Alves para a realização de apresentação… | R$ 45.000,00 | 28/11/2026 | 22 |
| 2026004203 | FUNARJ | PRODUTORA ARTISTICA VIP LTDA | Contratação da cantora Victoria Gaby para a realização de apresentaçã… | R$ 160.000,00 | 28/11/2026 | 22 |
| 2026004207 | FUNARJ | LUMA P.C.AGUIAR LACERDA PRODUÇÃO | Contratação do artista Frank Aguiar, para a realização de show ao viv… | R$ 80.000,00 | 28/11/2026 | 22 |
| 2026008068 | FUNARJ | INSTITUTO SOM E MOVIMENTO - ISM | Destina-se a contratação da dupla sertaneja Humberto e Ronaldo em ate… | R$ 290.000,00 | 28/11/2026 | 22 |
| 2026004266 | FUNARJ | LBR COMPANY PRODUCOES LTDA | Destina-se a contratação do artista cantor Gospel SAMUEL MIRANDA, em … | R$ 120.000,00 | 29/11/2026 | 23 |
| 2026006102 | FUNARJ | ATTITUDE PC LTDA | Contratação da cantora Gabby Moura | R$ 120.000,00 | 30/11/2026 | 24 |
| 2026008110 | FUNARJ | TIAGO GUILHERME BERNARDO SANTOS DA SILVA | contratação do cantor Tiaguinho Silva, para a realização de show ao v… | R$ 10.000,00 | 30/11/2026 | 24 |
| 2023009145 | SECEC | FUNDAÇÃO SANTA CABRINI | Prestação de serviços à Secretaria de Estado de Cultura e Economia Cr… | R$ 351.172,80 | 01/12/2026 | 25 |
| 2025009671 | SECEC | CROWN SERVIÇOS DE ELEVADORES LTDA | Contratação de empresa especializada para prestação de serviços de mo… | R$ 496.000,00 | 01/12/2026 | 25 |
| 2025009673 | SECEC | CROWN SERVIÇOS DE ELEVADORES LTDA | Contratação de empresa especializada para prestação de serviços de mo… | R$ 42.900,00 | 01/12/2026 | 25 |
| 2026003785 | FUNARJ | AMANDA ALVES PRODUÇÕES LTDA | Contratação da cantora Amanda Alves para a realização de uma apresent… | R$ 45.000,00 | 01/12/2026 | 25 |
| 2026003894 | FUNARJ | JAIR PRODUCOES EVENTOS E TURISMO LTDA | Contratação do Cantor Gospel WAGUINHO em atendimento ao Projeto GIRO … | R$ 40.000,00 | 01/12/2026 | 25 |
| 2026004189 | FUNARJ | VCF MUSIC PRODUCOES ARRTISSTICAS LTDA | Contratação do artista Vitão para a realização de um show ao vivo com… | R$ 60.000,00 | 01/12/2026 | 25 |
| 2026004250 | FUNARJ | LBR COMPANY PRODUCOES LTDA | Contratação do artista ELOI OLIVEIRA | R$ 80.000,00 | 01/12/2026 | 25 |
| 2026003970 | FUNARJ | PRODUTORA ARTISTICA VIP LTDA | Contratação da cantora Victoria Gaby | R$ 80.000,00 | 02/12/2026 | 26 |
| 2026004325 | FUNARJ | EVALDO MARCIO PINTO | O presente Termo de Referência tem por objetivo a contratação de serv… | R$ 70.000,00 | 02/12/2026 | 26 |
| 2026004365 | FUNARJ | MENDES MUSIC PRODUÇÕES LTDA | A Contratação da cantora Raylane Mendes- | R$ 40.000,00 | 02/12/2026 | 26 |
| 2026007083 | FUNARJ | ADRIANO RIBEIRO PRODUCOES ARTISTICAS LTDA | Contratação do cantor Adriano Ribeiro para realização apresentação ar… | R$ 35.000,00 | 02/12/2026 | 26 |
| 2026008238 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | contratação do artista ÁLVARO TITO, para a realização de 1 show no Te… | R$ 40.000,00 | 02/12/2026 | 26 |
| 2026005224 | FUNARJ | PEDETERESA PRODUCAO CULTURAL LTDA | A contratação do artista PedeTereza. | R$ 16.000,00 | 03/12/2026 | 27 |
| 2026007348 | FUNARJ | AMANDA ALVES PRODUÇÕES LTDA | A contratação da cantora AMANDA ALVES para o Projeto Giro Cultural | R$ 45.000,00 | 04/12/2026 | 28 |
| 2026008347 | FUNARJ | EVALDO MARCIO PINTO | Contratação do musico Samuel Eleotério Projeto Giro Cultural | R$ 70.000,00 | 06/12/2026 | 30 |
| 2026002941 | FUNARJ | PRODUTORA ARTISTICA VIP LTDA | Contratação da cantora Victoria Gabi, para a realização de shows ao v… | R$ 180.000,00 | 06/12/2026 | 30 |
| 2026004436 | FUNARJ | PRODUTORA ARTISTICA VIP LTDA | Contratação da cantora Victoria Gabi, em atendimento ao Projeto Giro … | R$ 60.000,00 | 06/12/2026 | 30 |
| 2026005269 | FUNARJ | V.F. PRODUCOES E EVENTOS ARTISTICOS LTDA - ME | Contratação do artista João Gabriel, em atendimento ao Projeto GIRO C… | R$ 70.000,00 | 06/12/2026 | 30 |
| 2026008333 | FUNARJ | PRODUTORA ARTISTICA VIP LTDA | Apresentação artística, da cantora Victória Gabi, no Município de São… | R$ 80.000,00 | 06/12/2026 | 30 |
| 2026005310 | FUNARJ | ACAUA PRODUTORA LIMITADA | Contratação da artista ELBA RAMALHO, para a realização de um show ao … | R$ 70.000,00 | 07/12/2026 | 31 |
| 2026008378 | FUNARJ | NON STOP PRODUCOES S/A | Destina-se a contração da empresa NON STOP PRODUÇÕES S/A, para aprese… | R$ 150.000,00 | 07/12/2026 | 31 |
| 2026004205 | FUNARJ | GOLD 120 PRODUCOES E EVENTOS EIRELI | Contratação do(a) artista SUEL para a realização de um show ao vivo c… | R$ 60.000,00 | 08/12/2026 | 32 |
| 2026004387 | FUNARJ | ADRIANO RIBEIRO PRODUCOES ARTISTICAS LTDA | Contrtação do artista Adriano Ribeiro para a realização de shows ao v… | R$ 105.000,00 | 08/12/2026 | 32 |
| 2026008420 | FUNARJ | BRAZUK PRODUÇÕES LTDA | A contratação por inexigibilidade visa garantir a realização de apres… | R$ 60.000,00 | 08/12/2026 | 32 |
| 2025010054 | FTMRJ | LECARD ADMNISTRADORA DE CARTÕES LTDA | FORNECIMENTO DE VALE ALIMENTACAO - DESCRIÇÃO: CONTRATACAO DE EMPRESA … | R$ 328.490,50 | 09/12/2026 | 33 |
| 2026004437 | FUNARJ | RICO MUSIC PRODUCAO ARTISTICA LTDA | contratação do(a) artista Sami Rico | R$ 80.000,00 | 09/12/2026 | 33 |
| 2026005416 | FUNARJ | Z.7.PRODUÇÕES AUDIOVISUAIS LTDA | Contratação do grupo Roda de Samba Balaio Bom para a realização de 01… | R$ 20.000,00 | 09/12/2026 | 33 |
| 2026005492 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | Contratação da empresa Agência Cristã Serviços Artísticos Ltda, para … | R$ 100.000,00 | 09/12/2026 | 33 |
| 2026007365 | FUNARJ | ALEX KERTH FERNANDES 09015207720 | Contratação da Banda Radial 80 para o Projeto Giro Cultural | R$ 15.000,00 | 09/12/2026 | 33 |
| 2026004516 | FUNARJ | JOÃO PEDRO QUENTAL FERREIRA 02912940737 | Destina-se a contratação do artista PEDRO QUENTAL em atendimento ao P… | R$ 14.370,00 | 10/12/2026 | 34 |
| 2026005581 | FUNARJ | PRODUZO SHOWS E EVENTOS LTDA | Contratação da banda Uns E Outros | R$ 50.000,00 | 10/12/2026 | 34 |
| 2026005583 | FUNARJ | V.F. PRODUCOES E EVENTOS ARTISTICOS LTDA - ME | Contratação da empresa V.F. Produções e Eventos Artísticos Ltda para … | R$ 70.000,00 | 10/12/2026 | 34 |
| 2026004557 | FUNARJ | TABETRON PRODUÇÕES ARTÍSTICAS LTDA | Contratação do palhaço Topetão | R$ 40.619,34 | 11/12/2026 | 35 |
| 2026006270 | FUNARJ | IM PRODUCOES ARTISTICAS E ENTRETENIMENTO LTDA | Contratação artística de Ícaro Moraes para o Projeto Giro Cultural. | R$ 40.000,00 | 11/12/2026 | 35 |
| 2026006352 | FUNARJ | 39.441.730 LUIZ OTAVIO DE ALMEIDA CORREA | Contratação do cantor Otavio Almeida para o Projeto Giro Cultural | R$ 10.000,00 | 11/12/2026 | 35 |
| 2026003223 | FUNARJ | RW PRODUÇÕES ARTÍSTICAS LTDA | Apresentação do cantor Elymar Santos, a ser realizada no teatro Casa … | R$ 60.000,00 | 12/12/2026 | 36 |
| 2026004141 | FUNARJ | DT PRODUÇÕES ARTISTICAS LTDA | Destina-se a contratação do artista PAPATINHO, em atendimento ao Proj… | R$ 48.000,00 | 12/12/2026 | 36 |
| 2026004386 | FUNARJ | GOLD 120 PRODUCOES E EVENTOS EIRELI | Contratação do cantor Tiee para a realização de shows ao vivo como pa… | R$ 120.000,00 | 12/12/2026 | 36 |
| 2026004501 | FUNARJ | TIE GASPARINETTI BIRAL - ME | O objeto da presente contratação consiste na prestação de serviço art… | R$ 20.000,00 | 12/12/2026 | 36 |
| 2026008451 | FUNARJ | FEYJAO PRODUCOES E REPRESENTACOES LTDA | Destina-se a contratação da empresa Feyjao Produções e Representações… | R$ 40.000,00 | 13/12/2026 | 37 |
| 2026008543 | FUNARJ | LET`S GIG SERVICOS DE PRODUCAO CULTURAL E AG… | Destina-se a contratação da empresa LET`S GIG Serviços de Produção Cu… | R$ 60.000,00 | 13/12/2026 | 37 |
| 2026008593 | FUNARJ | TABETRON PRODUÇÕES ARTÍSTICAS LTDA | Destina-se a contratação do palhaço Topetão em atendimento ao projeto… | R$ 70.919,34 | 13/12/2026 | 37 |
| 2026008600 | FUNARJ | RODRIGO BERNARDO DE LARA | Contratação do artista Yuri Marçal para a realização de show como par… | R$ 20.000,00 | 13/12/2026 | 37 |
| 2025010486 | FUNARJ | LECARD ADMNISTRADORA DE CARTÕES LTDA | Destina-se a contratação da empresa LECARD ADMINISTRADORA DE CARTÕES … | R$ 266.500,00 | 15/12/2026 | 39 |
| 2026005148 | FMIS | EDITORA ARTHÉMAN E PRODUÇÕES CULTURAIS LTDA | contratação de empresa especializada na produção de livro | R$ 5.000,00 | 15/12/2026 | 39 |
| 2026004741 | FUNARJ | CINE & TEATRO PRODUÇÕES LTDA - ME | Contratação do ator Alexandre Lino com o espetáculo ``O Porteiro``, p… | R$ 20.000,00 | 16/12/2026 | 40 |
| 2026005695 | FUNARJ | ÃRRÃ PRODUÇÕES LTDA EPP | Contratação artística de Nina Tomsic Villas para o Projeto Nosso Teat… | R$ 25.000,00 | 16/12/2026 | 40 |
| 2026005696 | FUNARJ | 65 736 606 GUIGA PONTES GOUVÊA CAMARATE | Contratação da atriz Guiga Camarate | R$ 12.500,00 | 16/12/2026 | 40 |
| 2026005698 | FUNARJ | CINELARI PRODUCOES ARTISTICAS LTDA. | Contratação da empresa CINELARI PRODUÇÕES ARTÍSTICAS LTDA para aprese… | R$ 43.750,00 | 16/12/2026 | 40 |
| 2026005699 | FUNARJ | PRODUÇÃO CULTURAL INTERBALLET LTDA | Contratação de LILIAN DA SILVA SANTIAGO para Nosso Teatro: O Beijo no… | R$ 150.000,00 | 16/12/2026 | 40 |
| 2026005701 | FUNARJ | LAURA DE CASTRO PRODUÇÕES ARTÍSTICAS LTDA | Contratação artística de Laura de Castro D`Azevedo para o projeto ``N… | R$ 12.500,00 | 16/12/2026 | 40 |
| 2026005702 | FUNARJ | ALCIDES BARBOSA FIGUEIREDO JUNIOR 02174357429 | Contratação artística de Alcides Barbosa Figueiredo Junior para o Pro… | R$ 12.500,00 | 16/12/2026 | 40 |
| 2026005703 | FUNARJ | PEDRO HENRIQUE DE FRANCA FERNANDES DA SILVA … | profissional Pedro França, para atuar na função de Ator para o Projet… | R$ 22.500,00 | 16/12/2026 | 40 |
| 2026005706 | FUNARJ | ANDRE MATTOS PRODUCOES ARTISTICAS LTDA | Contratação do Ator André de Mello Tavares de Mattos, conhecido artis… | R$ 43.750,00 | 16/12/2026 | 40 |
| 2026005710 | FUNARJ | ABRAMUS ASSOCIACAO BRASILEIRA DE MUSICA E AR… | Destina-se a contratação da empresa ABRAMUS - Associação Brasileira d… | R$ 75.000,00 | 16/12/2026 | 40 |
| 2026005711 | FUNARJ | F.D PRODUCOES ARTISTICAS LIMITADA | Contratação artística de Fernanda Cristina Machado Dias para o projet… | R$ 15.000,00 | 16/12/2026 | 40 |
| 2026005716 | FUNARJ | ARTES & OFICIOS PRODUCOES CULTURAIS E ARTIST… | Contratação artística de Cida Ferreira para o Projeto ``Nosso Teatro:… | R$ 111.250,00 | 16/12/2026 | 40 |
| 2026005725 | FUNARJ | DANIELA CAVANELLAS - ARTE E CULTURA LTDA | Contratação da profissional Daniela Bicalho Cavanellas, em artes Dani… | R$ 7.500,00 | 16/12/2026 | 40 |
| 2026005728 | FUNARJ | A SALES CULTURAL E AUDIOVISUAL LTDA | Contratação artística de ATY SALES para o projeto ``Nosso Teatro: O B… | R$ 150.000,00 | 16/12/2026 | 40 |
| 2026008735 | FUNARJ | EVOLUTION PRODUTORA DE EVENTOS LTDA | Realização de 01 (uma) apresentação artística, da banda Raça Negra, n… | R$ 300.000,00 | 16/12/2026 | 40 |
| 2026008788 | FUNARJ | JOSE JORGE DE ASSIS | contratação do artista AYRTON MONTARROYOS, para a realização de show … | R$ 35.000,00 | 16/12/2026 | 40 |
| 2026008796 | FUNARJ | L S DA CUNHA ARTES INTEGRADAS | Contratação por inexigibilidade da profissional Larissa Siqueira da C… | R$ 30.000,00 | 16/12/2026 | 40 |
| 2026008805 | FUNARJ | GUTEMBERG MONTEIRO DA SILVA 65722485772 | contratação da dupla JULINHO MARASSI E GUTEMBERG, para a realização d… | R$ 12.000,00 | 16/12/2026 | 40 |
| 2026004656 | FUNARJ | BRUNO CAVALCANTE HANNA | A contratação da artista PAULA LIMA | R$ 60.000,00 | 17/12/2026 | 41 |
| 2026004780 | FUNARJ | EZEQUIAS GUEDES DO NASCIMENTO LTDA | contratação do cantor Mattos Nascimento, para a realização de 3 (três… | R$ 120.000,00 | 17/12/2026 | 41 |
| 2026005693 | FUNARJ | EDUARDO STERBLITCH PRODUÇOES ARTITISCAS LTDA | Contratação do profissional Luiz Eduardo Steirblich Pháscoa, em arte … | R$ 43.750,00 | 17/12/2026 | 41 |
| 2026005712 | FUNARJ | BRAZUK PRODUÇÕES LTDA | Contratação musical do Grupo grupo Sambô para projeto Giro Cultural | R$ 60.000,00 | 17/12/2026 | 41 |
| 2026005714 | FUNARJ | 46.839.711 ERICA AFONSO FIGUEIREDO DE CARVAL… | Contratação da da cantora Erica Carvalho | R$ 30.000,00 | 17/12/2026 | 41 |
| 2026005737 | FUNARJ | AQUELA CIA PRODUÇÕES ARTÍSTICAS LTDA | Contratação da empresa Aquela CIA Produções Artísticas Ltda para cont… | R$ 43.750,00 | 17/12/2026 | 41 |
| 2026005738 | FUNARJ | EKA PRODUCOES ARTISTICAS LTDA | Contratação do profissional Ernani Moraes. Ator para o projeto ``Noss… | R$ 43.750,00 | 17/12/2026 | 41 |
| 2026005751 | FUNARJ | CASA FORTE PRODUÇÕES ARTISTICAS LTDA. | contratação da profissional Luisa Cavendish Arraes, conhecida artisti… | R$ 43.750,00 | 17/12/2026 | 41 |
| 2026005762 | FUNARJ | EZEQUIAS GUEDES DO NASCIMENTO LTDA | Contratação artística de Mattos Nascimento para o Projeto Giro Cultur… | R$ 60.000,00 | 17/12/2026 | 41 |
| 2026005800 | FUNARJ | ARTES & OFICIOS PRODUCOES CULTURAIS E ARTIST… | Contratação do profissional Claudio Roberto da Silva, para atuar na f… | R$ 42.001,40 | 17/12/2026 | 41 |
| 2026003684 | FUNARJ | ROSIMEIRE MARIA DE PAIVA 03460817690 | Contratação artística da cantora Michelle Nascimento para o Projeto G… | R$ 70.000,00 | 18/12/2026 | 42 |
| 2026004873 | FUNARJ | A3B EMPREENDIMENTOS ARTISITICOS LTDA | Contratação do cantor Buchecha para a realização de apresentação cult… | R$ 110.000,00 | 19/12/2026 | 43 |
| 2026004893 | FUNARJ | SPK PRODUÇÕES ARTÍSTICAS | Contratação artística do cantor Leandro Sapucahy para o Projeto Giro … | R$ 60.000,00 | 19/12/2026 | 43 |
| 2026008789 | FUNARJ | ACAUA PRODUTORA LIMITADA | contratação da cantora ELBA RAMALHO, para a realização de 1 (um) show… | R$ 70.000,00 | 19/12/2026 | 43 |
| 2026008804 | FUNARJ | PORTUGAL PRODUÇÕES ARTÍSTICAS LTDA | Contratação do artista DIOGO PORTUGAL para a realização de apresentaç… | R$ 60.000,00 | 19/12/2026 | 43 |
| 2026008854 | FUNARJ | PRODUTORA ARTISTICA VIP LTDA | Destina-se a contratação da empresa Produtora Artística Vip Ltda, par… | R$ 60.000,00 | 19/12/2026 | 43 |
| 2026008855 | FUNARJ | ADRIANO RIBEIRO PRODUCOES ARTISTICAS LTDA | Contratação do artista ADRIANO RIBEIRO - Giro Cultural. | R$ 70.000,00 | 19/12/2026 | 43 |
| 2026008870 | FUNARJ | I.ML. LEITE PRODUCOES ARTISTICAS ME | Destina-se a contratação da artista ISABELLA TAVIANI, em atendimento … | R$ 42.000,00 | 19/12/2026 | 43 |
| 2026008872 | FUNARJ | DUAS VOZES PRODUÇOES ARTISTICAS LTDA | Contratação do artista Márcio Gomes | R$ 40.000,00 | 19/12/2026 | 43 |
| 2026008875 | FUNARJ | RAUL MARTINS DE SOUZA RAMOS 14850225764 | Contratação do artista Samuel Eleoterio. | R$ 19.800,00 | 19/12/2026 | 43 |
| 2026004941 | FUNARJ | ELEVA PRODUCOES ARTISTICAS LTDA | Contratação da empresa ELEVA PRODUÇÕES ARTÍSTICAS LTDA para apresenta… | R$ 40.000,00 | 20/12/2026 | 44 |
| 2026004942 | FUNARJ | ANDERSON MOREIRA DAUMAS | Contratação da empresa DAUMAS PRODUÇÕES LTDA, para apresentação do ar… | R$ 60.000,00 | 20/12/2026 | 44 |
| 2026004943 | FUNARJ | 46.839.711 ERICA AFONSO FIGUEIREDO DE CARVAL… | Contratação artística de Érica Carvalho para o Projeto Giro Cultural. | R$ 30.000,00 | 20/12/2026 | 44 |
| 2026004944 | FUNARJ | LALAIA PRODUCOES DE AUDIO E VIDEO LTDA | Contratação da empresa LALAIÁ PRODUÇÕES DE ÁUDIO E VÍDEO LTDA, para a… | R$ 55.000,00 | 20/12/2026 | 44 |
| 2026008702 | FUNARJ | ELEVA PRODUCOES ARTISTICAS LTDA | Contratação da artista AMANDA AMADO para o Projeto Fim de Tarde | R$ 35.000,00 | 20/12/2026 | 44 |
| 2026004317 | FUNARJ | AMANDA ALVES PRODUÇÕES LTDA | Contratação da cantora Amanda Alves. | R$ 45.000,00 | 22/12/2026 | 46 |
| 2026005686 | FUNARJ | ASSOCIAÇÃO CARIOCA DE PRESTADORES DE SERVIÇO… | Contratação da cantora Cristina Braga | R$ 105.000,00 | 22/12/2026 | 46 |
| 2026005905 | FUNARJ | ROD SAN PRODUCOES ARTISTICAS E CULTURAIS LTDA | Contratação da empresa ROD SAN PRODUÇÕES ARTÍSTICAS E CULTURAIS LTDA … | R$ 35.000,00 | 22/12/2026 | 46 |
| 2026005916 | FUNARJ | AGÊNCIA ARTÍSTICA E ESPORTIVA ROCHA LTDA | Contratação da banda Swing e Simpatia para a apresentação artística, … | R$ 60.000,00 | 22/12/2026 | 46 |
| 2026007808 | FUNARJ | A SALES CULTURAL E AUDIOVISUAL LTDA | Destina-se a contratação da empresa A SALES CULTURAL E AUDIO VISUAL p… | R$ 80.000,00 | 22/12/2026 | 46 |
| 2026005913 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | Contratação da banda Novo Som para a realização de show ao vivo no Mu… | R$ 100.000,00 | 23/12/2026 | 47 |
| 2026005057 | FUNARJ | LBR COMPANY PRODUCOES LTDA | Contratação do cantor Samuel Miranda projeto ``GIRO CULTURAL`` | R$ 120.000,00 | 24/12/2026 | 48 |
| 2026005062 | FUNARJ | PRODUTORA ARTISTICA VIP LTDA | Contratação da artista Victoria Gabi para o projeto Projeto Giro Cult… | R$ 160.000,00 | 25/12/2026 | 49 |
| 2026002912 | FUNARJ | LEA MENDONÇA - PRODUÇÕES ARTÍSTICAS LTDA | Contratação da cantora Léa Mendonça, espetáculo e será parte integran… | R$ 68.710,32 | 27/12/2026 | 51 |
| 2026008883 | FUNARJ | PRODUTORA ARTISTICA VIP LTDA | Contratação da cantora Victória Gabi Projeto Giro Cultural | R$ 120.000,00 | 27/12/2026 | 51 |
| 2026006907 | FEC | YDREAMS ENTERTAINMENT LTDA | Contratação da produção, execução, montagem, manutenção, suporte espe… | R$ 592.000,00 | 28/12/2026 (PNCP) | 52 |
| 2026007476 | FUNARJ | PRODUZO SHOWS E EVENTOS LTDA | A contratação do cantor Dalto. | R$ 70.000,00 | 29/12/2026 | 53 |
| 2026008887 | FUNARJ | IM PRODUCOES ARTISTICAS E ENTRETENIMENTO LTDA | Contratação do artista ÍCARO MORAES - Giro Cultural. | R$ 80.000,00 | 29/12/2026 | 53 |
| 2026008888 | FUNARJ | PRODUTORA ARTISTICA VIP LTDA | Destina-se a contratação da artista Victória Gabi, em atendimento ao … | R$ 60.000,00 | 29/12/2026 | 53 |
| 2026009179 | FUNARJ | PERFORMANCE MUSIC DISTRIBUIDORA LTDA | Contratação da banda THE FEVERS para o Projeto Fim de Tarde. | R$ 60.000,00 | 29/12/2026 | 53 |
| 2026009203 | FUNARJ | LBR COMPANY PRODUCOES LTDA | Contratação do cantor Samuel Miranda | R$ 60.000,00 | 29/12/2026 | 53 |
| 2026003387 | FUNARJ | GMK LTDA | Contratação do(a) grupo KARAMETADE, para a realização de apresentaçõe… | R$ 90.000,00 | 31/12/2026 | 55 |
| 2026004520 | FUNARJ | DAVID BRAZIL COMUNICAÇÕES LTDA | Contratação do artista David Brasil | R$ 120.000,00 | 31/12/2026 | 55 |
| 2026005028 | FUNARJ | DE FELIPPES FILMES E PRODUÇÕES LTDA | Contratação da empresa DE FELIPPES FILMES E PRODUÇÕES LTDA, para apre… | R$ 140.000,00 | 31/12/2026 | 55 |
| 2026005912 | FUNARJ | ELZA RIBEIRO PRODUÇÕES LTDA. | A necessidade da contratação da artista RITA BENNEDITTO visa atender … | R$ 50.000,00 | 31/12/2026 | 55 |
| 2026006101 | FUNARJ | LEANDRO DA COSTA CUNHA | Contratação do espetáculo de humor ``ESCOLINHAZINHA | R$ 76.000,00 | 31/12/2026 | 55 |
| 2026005226 | FUNARJ | BRAZUK PRODUÇÕES LTDA | contratação do grupo Sambô para o Projeto Giro Cultural. | R$ 60.000,00 | 02/01/2027 | 57 |
| 2026004388 | FUNARJ | AB COMUNICACAO E ARTE EMPREENDIMENTOS EIRELI | Contratação do cantor Toni Garrido | R$ 120.000,00 | 03/01/2027 | 58 |
| 2026009175 | FUNARJ | JAIR PRODUCOES EVENTOS E TURISMO LTDA | A Contratação do grupo Chega mais pra Cristo | R$ 80.000,00 | 03/01/2027 | 58 |
| 2026009180 | FUNARJ | JAIR PRODUCOES EVENTOS E TURISMO LTDA | Consiste na realização de 01 (uma) apresentação artística, do cantor … | R$ 20.000,00 | 03/01/2027 | 58 |
| 2026009181 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | Contratação do cantor Carlinhos Félix | R$ 40.000,00 | 04/01/2027 | 59 |
| 2026009202 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | Apresentação artística, do cantor Carlinhos Félix, no Município de It… | R$ 40.000,00 | 04/01/2027 | 59 |
| 2026009253 | FUNARJ | CEU MUSIC PRODUÇÕES ARTÍSTICAS LTDA | contratação do cantor Samuel Messias, para a realização de 01 apresen… | R$ 80.000,00 | 04/01/2027 | 59 |
| 2026009297 | FUNARJ | TIAGO GUILHERME BERNARDO SANTOS DA SILVA | A contratação do cantor gospel Tiaguinho Silva Projeto Giro Cultural. | R$ 10.000,00 | 04/01/2027 | 59 |
| 2026001417 | FUNARJ | NOVO TRACO PUBLICIDADE E PROPAGANDA LTDA | A contratação do curador Rafaello Ramundo é fundamental para a garant… | R$ 282.720,00 | 05/01/2027 | 60 |
| 2026009324 | FUNARJ | SOUZA&SOUZA ARTE E CULTURA LTDA | Contratação do espetáculo ``AS MARIAS DE BELÉM DO PARÁ  SOMOS TODOS … | R$ 205.000,00 | 05/01/2027 | 60 |
| 2026009336 | FUNARJ | FAMILIA LIMA PRODUCOES LTDA | Contratação artística, do cantor Adriano Lima em artes (Adriano Gospe… | R$ 20.000,00 | 05/01/2027 | 60 |
| 2026003518 | FUNARJ | BEATCARIOCA PRODUCOES ARTISTICAS EIRELI - EPP | Contratação do artista Nico Rezende para o Projeto Giro Cultural | R$ 120.000,00 | 06/01/2027 | 61 |
| 2026004218 | FUNARJ | OS LEMOS PRODUTORA DE EVENTOS LTDA | Destina-se a contratação do Canto Evandro Mesquita em atendimento ao … | R$ 110.000,00 | 06/01/2027 | 61 |
| 2026005704 | FUNARJ | SELVÁTICA AÇÕES ARTÍSTICAS LTDA | Contratação da empresa Selvática Ações Artísticas Ltda para apresenta… | R$ 15.000,00 | 06/01/2027 | 61 |
| 2026005707 | FUNARJ | A AMERICA LATINA PRODUÇÕES ARTISTICAS LTDA | Contratação artística do ator Vinicius Teixeira para o Projeto ``Noss… | R$ 12.500,00 | 06/01/2027 | 61 |
| 2026001500 | FUNARJ | ARTES & OFICIOS PRODUCOES CULTURAIS E ARTIST… | A contratação dos serviços cenotécnicos do profissional Claudio Rober… | R$ 143.000,00 | 09/01/2027 | 64 |
| 2026001696 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | A contratação da banda Novo Som. | R$ 80.000,00 | 12/01/2027 | 67 |
| 2026001799 | FUNARJ | L S DA CUNHA ARTES INTEGRADAS | Contratação da profissional Larissa Siqueira da Cunha, conhecida arti… | R$ 150.000,00 | 13/01/2027 | 68 |
| 2026005419 | FUNARJ | RSS PRODUÇÕES ARTÍSTICAS LTDA | Contratação do grupo Pique Novo | R$ 60.000,00 | 13/01/2027 | 68 |
| 2026004771 | FUNARJ | M.F.A.G - PRODUCAO ARTISTICA LTDA | Contratação do grupo Bom Gosto para a realização de apresentações mus… | R$ 120.000,00 | 14/01/2027 | 69 |
| 2026004953 | FUNARJ | MONIQUE CAVALCANTI DE SOUZA | Contratação da artista muralista Gugie Cavalcanti | R$ 15.000,00 | 14/01/2027 | 69 |
| 2026005119 | FUNARJ | MOREIRA MOTTA PRODUCOES E ENTRETENIMENTO LTDA | A Contratação do artista Kim | R$ 80.000,00 | 14/01/2027 | 69 |
| 2026005417 | FUNARJ | MOREIRA MOTTA PRODUCOES E ENTRETENIMENTO LTDA | Contratação artística da banda Catedral para o Projeto Giro Cultural. | R$ 65.000,00 | 14/01/2027 | 69 |
| 2026005652 | FUNARJ | RW PRODUÇÕES ARTÍSTICAS LTDA | Destina-se a contratação do cantor BIAFRA em atendimento ao Projeto G… | R$ 120.000,00 | 14/01/2027 | 69 |
| 2026005709 | FUNARJ | PRODUTORA ARTISTICA VIP LTDA | Contratação artística de Victoria Gabi para o Projeto Giro Cultural. | R$ 80.000,00 | 16/01/2027 | 71 |
| 2026003356 | FUNARJ | LBR COMPANY PRODUCOES LTDA | Contratação artística da cantora Joanna para o Projeto Giro Cultural. | R$ 60.000,00 | 20/01/2027 | 75 |
| 2026003685 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | Contratação do cantor Alex Gonzaga | R$ 80.000,00 | 21/01/2027 | 76 |
| 2026003688 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | Contratação do cantor Alex Gonzaga para a realização de shows ao vivo… | R$ 80.000,00 | 21/01/2027 | 76 |
| 2026004219 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | Contratação do cantor Carlinhos Félix para a realização de shows ao v… | R$ 80.000,00 | 21/01/2027 | 76 |
| 2026004221 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | A contratação do cantor Carlinhos Félix . | R$ 80.000,00 | 21/01/2027 | 76 |
| 2026005801 | FUNARJ | CRIOLO BRANCO PRODUÇÕES E EVENTOS LTDA | Contratação artística de Almirzinho para o Projeto Fim de Tarde. | R$ 60.000,00 | 21/01/2027 | 76 |
| 2026001989 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | Neste contexto, a escolha por Álvaro Tito se deu em razão da qualidad… | R$ 80.000,00 | 23/01/2027 | 78 |
| 2026002153 | FUNARJ | OFICINA DIGITAL PRODUÇÕES MARKETING E AGENCI… | Contratação artistica do cantor Sergio Lopes para o Projeto Giro Cult… | R$ 80.000,00 | 25/01/2027 | 80 |
| 2026007672 | FTMRJ | FULL FIRE COMERCIO E INSTALACOES DE COMBATE … | Contratação de empresa especializada para execução de serviços de tra… | R$ 123.173,21 | 29/01/2027 | 84 |
| 2026008181 | FUNARJ | TRAMPO PRODUÇÕES CULTURAIS LTDA | contratação da empresa trampo produções para realização do espetáculo… | R$ 80.000,00 | 31/01/2027 | 86 |
| 2025008827 | FUNARJ | VIGILIA BRASIL SERVIÇOS LTDA | Destina-se a contratação de empresa especializada em prestação de ser… | R$ 4.245.944,84 | 03/02/2027 (PNCP) | 89 |
| 2026000100 | FUNARJ | ATAC ASSISTENCIA TECNICA EM AR CONDICIONADO … | Trata-se de serviço a serem executados no piso da plateia inferior na… | R$ 345.919,40 | 03/02/2027 | 89 |
| 2026004229 | FUNARJ | CHITA PRODUCOES E EDICOES MUSICAIS LTDA | Contratação do cantor Chico Cesar para a realização de show ao vivo c… | R$ 120.000,00 | 03/02/2027 | 89 |
| 2026004831 | FUNARJ | W.F.A. EVENTOS SOCIEDADE SIMPLES LTDA | Contratação do cantor Bruno Diegues para a realização de uma apresent… | R$ 60.000,00 | 03/02/2027 | 89 |
| 2026004952 | FUNARJ | AGÊNCIA CRISTÃ SERVIÇOS ARTÍSTICOS  LTDA | Contratação da banda Novo Som para a realização de show ao vivo com o… | R$ 65.000,00 | 03/02/2027 | 89 |
| 2026009267 | FUNARJ | DANIELA CAVANELLAS - ARTE E CULTURA LTDA | Consiste na prestação de serviço artístico especializado, por meio da… | R$ 8.250,00 | 03/02/2027 | 89 |
| 2026004829 | FUNARJ | FAMILIA LIMA PRODUCOES LTDA | Contratação do artista Adriano Gospel Funk para o projeto Giro Cultur… | R$ 40.000,00 | 04/02/2027 | 90 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026005007 | FUNARJ | DE FELIPPES FILMES E PRODUÇÕES LTDA | Contratação da empresa DE FELIPPES FILMES E PRODUCOES LTDA para apres… | R$ 175.000,00 | 11/02/2027 | 97 |
| 2026002827 | FUNARJ | FINO TOM PRODUCOES E EVENTOS LTDA | Contratação do artista Vivy e Nathan para o Projeto Giro Cultural | R$ 160.000,00 | 14/02/2027 | 100 |
| 2026004894 | FUNARJ | MARIA DE FATIMA FAFA DE BELEM PALHA DE FIGUE… | Contratação da artista FAFÁ DE BELÉM | R$ 70.000,00 | 17/02/2027 | 103 |
| 2026008781 | FUNARJ | CABB ENGENHARIA LTDA | Contratação a prestação de serviços de engenharia especial, destinado… | R$ 949.073,00 | 17/02/2027 (PNCP) | 103 |
| 2026006811 | FUNARJ | PAGODEIRA EMPREENDIMENTOS ARTISTICOS LTDA | Contratação da cantora Marvvila, para a realização de show ao vivo, n… | R$ 100.000,00 | 24/02/2027 | 110 |
| 2026003329 | FUNARJ | DOZE PRODUCOES CINEMATOGRAFICAS AUDIOVISUAIS… | Contratação do cantor Thiago Cordeiro para a realização de apresentaç… | R$ 40.000,00 | 28/02/2027 | 114 |
| 2026001441 | FUNARJ | DANIELA CAVANELLAS - ARTE E CULTURA LTDA | O objeto da presente contratação consiste na prestação de serviço art… | R$ 60.000,00 | 06/03/2027 | 120 |
| 2023001033 | SECEC | HADDAD RENT A CAR LOCADORA LTDA | Contratação de empresa especialiada na prestação de serviços de locaç… | R$ 388.800,00 | 09/03/2027 | 123 |
| 2026001458 | FUNARJ | VOLEIO PRODUÇÕES ARTÍSTICAS LTDA. | O objeto da contratação é para serviços de diretora de produção Elisa… | R$ 400.000,00 | 09/03/2027 | 123 |
| 2024001448 | FTMRJ | RIOPAR PARTICIPAÇÕES S/A | SERVICO DE FORNECIMENTO/RECARGA VALE TRANSPORTE,DESCRIÇÃO: AQUISICAO … | R$ 1.103.155,20 | 11/03/2027 (PNCP) | 125 |
| 2026004438 | FUNARJ | PRMUSIC PRODUÇÕES ARTÍSTICAS LTDA | Contratação do cantor PAULO RICARDO, para a realização de 2 shows ao … | R$ 160.000,00 | 11/03/2027 | 125 |
| 2026004439 | FUNARJ | PRMUSIC PRODUÇÕES ARTÍSTICAS LTDA | A Contratação do artista PAULO RICARDO | R$ 160.000,00 | 11/03/2027 | 125 |
| 2026001717 | FUNARJ | NITIREN PRODUCOES ARTISTICAS LTDA | Contratação do espetáculo Cauby, uma Paixão, protagonizado pelo con… | R$ 105.000,00 | 12/03/2027 | 126 |
| 2026003525 | FUNARJ | JOSE JORGE DE ASSIS | A contratação da cantora Ceiça Moreno | R$ 60.000,00 | 13/03/2027 | 127 |
| 2025006384 | FUNARJ | GENTE SEGURADORA S.A. | Contratação direta, por dispensa de licitação, de seguro automotivo c… | R$ 3.358,00 | 15/03/2027 | 129 |
| 2026003248 | FUNARJ | GOSPEL SOUL PRODUCAO MUSICAL LTDA | Contratação do cantor Marcos Goes para a realização de apresentações … | R$ 160.000,00 | 15/03/2027 | 129 |
| 2025005526 | FMIS | CBD BOLHETE DIGITAL S/A | Contratação de empresa especializada na concessão de Vale-Transporte … | R$ 17.000,00 | 20/03/2027 | 134 |
| 2026001713 | FUNARJ | SENHOR DOS CUPINS LTDA | A presente contratação refere-se à prestação de serviços continuados,… | R$ 425.713,56 | 20/03/2027 | 134 |
| 2025000558 | FMIS | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Contratação Serviços de Publicação de Matérias no Diário Oficial - IO… | R$ 692,00 | 24/03/2027 | 138 |
| 2025004524 | FMIS | ZIEVO TECNOLOGIA LTDA | Contratação de Empresa Prestadora de Serviço Web Rádio e Website. | R$ 839,16 | 24/03/2027 | 138 |
| 2025004717 | FMIS | PORTO SEGURO CIA DE SEGUROS GERAIS | Renovação do Seguro Patrimonial | R$ 5.066,06 | 24/03/2027 | 138 |
| 2025005501 | FMIS | HERMES PRODUÇÕES EM EVENTOS LTDA | Contratação de empresa especializada na prestação de serviços de buff… | R$ 62.725,00 | 24/03/2027 | 138 |
| 2025007839 | FMIS | IBS FIRE SOLUÇÕES CONTRA INCÊNDIO LTDA | Contratação de empresa especializada para prestação de serviços de re… | R$ 1.960,00 | 24/03/2027 | 138 |
| 2025007920 | FMIS | INSET MAX - IM MANUTENCAO PREDIAL LTDA | Contratação de empresa especializada na prestação de serviços de Desc… | R$ 12.700,00 | 24/03/2027 | 138 |
| 2025008046 | FMIS | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Pagamento anual do domínio mis.rj.gov.br exercício 2025 | R$ 102,31 | 24/03/2027 | 138 |
| 2025008305 | FMIS | LIMPER LIMPEZA DE CISTERNA E CAIXA D`AGUA LT… | Serviços de limpeza e higienização dos reservatórios de água. | R$ 1.810,00 | 24/03/2027 | 138 |
| 2026000363 | FMIS | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação de empresa especializada em fornecimento de energia elétr… | R$ 86.400,00 | 24/03/2027 | 138 |
| 2026000459 | FMIS | AGUAS DO RIO 4 SPE S.A | Contratação de empresa especializada em fornecimento de água e esgoto… | R$ 32.400,00 | 24/03/2027 | 138 |
| 2026000501 | FMIS | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Contratação de empresa especializada em serviços de pesquisas para Fu… | R$ 18.000,00 | 24/03/2027 | 138 |
| 2026000511 | FMIS | COMITÊ BRASILEIRO DO CONSELHO INTERNACIONAL … | Anuidade do Conselho Internacional de Museus  ICOM 2026 | R$ 2.476,00 | 24/03/2027 | 138 |
| 2026003690 | FUNARJ | CHITA PRODUCOES E EDICOES MUSICAIS LTDA | Contratação do cantor, Chico César. | R$ 60.000,00 | 28/03/2027 | 142 |
| 2026002570 | FTMRJ | INSTITUTO AVALIA DE INOVAÇÃO EM AVALIAÇÃO E … | CONTRATAÇÃO DEPESSOA JURÍDICAESPECIALIZADA NAPRESTAÇÃO DESERVIÇOS TÉC… | R$ 1.430.000,00 | 01/04/2027 (PNCP) | 146 |
| 2025001564 | FTMRJ | PORTO SEGURO CIA DE SEGUROS GERAIS | Contratação de prestação de serviço de seguro total para os caminhões… | R$ 6.662,07 | 02/04/2027 | 147 |
| 2025002209 | FUNARJ | STUDIO BRAS ARTES GRAFICAS LTDA | Destina-se a contratação de empresa especializada em prestação de ser… | R$ 525.000,00 | 07/04/2027 (PNCP) | 152 |
| 2026002700 | FUNARJ | GERIR COMÉRCIO E SERVIÇOS DE REFRIGERAÇÃO EI… | Limpeza, higienização e desinfecção dos dutos de ar condicionado dos … | R$ 59.000,00 | 09/04/2027 | 154 |
| 2023002170 | FMIS | BRS SUPRIMENTOS CORPORATIVOS S/A | SERVICOS DE OUTSOURCING PARA OPERACAO DE ALMOXARIFADO VIRTUAL IN COMP… | R$ 100.000,00 | 13/04/2027 | 158 |
| 2026002704 | FUNARJ | ELEVADORES IVIMAIA LTDA - EPP | Destina-se a contratação de empresa especializada em prestação de ser… | R$ 93.600,00 | 15/04/2027 | 160 |
| 2026008708 | FUNARJ | PETRA ENGENHARIA E SERVICOS LTDA | Prestação dos serviços de fornecimento e instalação de sistema de pro… | R$ 107.452,32 | 16/04/2027 | 161 |
| 2026002954 | FUNARJ | 65 736 606 GUIGA PONTES GOUVÊA CAMARATE | Contratação da Atriz Guiga Camarate Teatro Gláucio Gill para o Espet… | R$ 3.000,00 | 17/04/2027 | 162 |
| 2026002955 | FUNARJ | LOROZA PRODUCOES LTDA | Contratação de prestação de serviços artísticos de Luiza Loroza, arti… | R$ 6.000,00 | 17/04/2027 | 162 |
| 2026002956 | FUNARJ | WESLEY MAY DA SILVA | Contratação de prestação de serviços artísticos de Wesley May, artist… | R$ 6.000,00 | 17/04/2027 | 162 |
| 2026002957 | FUNARJ | CARAMINHOLAS FIGURINOS E PRODUCOES ARTISTICA… | Contratação da artista Fernanda Garcia, credenciada por meio do Edita… | R$ 18.000,00 | 17/04/2027 | 162 |
| 2026002958 | FUNARJ | 58.034.852 VINICIUS ROCHA RESENDE | A contratação do artista Vinícius Rocha | R$ 6.000,00 | 17/04/2027 | 162 |
| 2026002959 | FUNARJ | RÔMULO VIEIRA CHINDELAR 05740244765 | Contratação do do Dramaturgo Rômulo Chindelar | R$ 7.000,00 | 17/04/2027 | 162 |
| 2026002960 | FUNARJ | DAS B ARQUITETURA E EMPREENDIMENTOS ARTÍSTIC… | Contratação da artista Kátia Bronstein, credenciada por meio do Edita… | R$ 12.000,00 | 17/04/2027 | 162 |
| 2026002961 | FUNARJ | AVANTE PORTES PRODUCOES ARTISTICAS LTDA | A contratação do artista Frederico Santiago | R$ 4.000,00 | 17/04/2027 | 162 |
| 2026002962 | FUNARJ | 53.777.599 ANDRE RIBEIRO POYART | Contratação de André Poyart, artista credenciado no Edital de Chamame… | R$ 6.000,00 | 17/04/2027 | 162 |
| 2026002963 | FUNARJ | DUAS MIL PRODUCOES ARTISTICAS LTDA | Contratação da artista Stella Miranda, credenciada por meio do Edital… | R$ 12.000,00 | 17/04/2027 | 162 |
| 2026002964 | FUNARJ | YASMIN LIMA FERREIRA RODRIGUES 06008026390 | Contratação de Yasmin Lima, artista credenciado no Edital de Chamamen… | R$ 6.000,00 | 17/04/2027 | 162 |
| 2026002965 | FUNARJ | NOVELLO PRODUÇÕES ARTÍSTICAS EIRELI ME | Contratação do artista, Vitor Novello para o Projeto Cabaré do Gláuci… | R$ 6.000,00 | 17/04/2027 | 162 |
| 2026002966 | FUNARJ | ANTELLO & SHIMURA PRODUÇÕES ARTÍSTICAS LTDA | Contratação de prestação de serviços artísticos, decorrente de creden… | R$ 12.000,00 | 17/04/2027 | 162 |
| 2026002967 | FUNARJ | 50.162.750 ERIKA CRISTINA BERNARDO FARIA | A contratação de Bernardo Poeta | R$ 3.000,00 | 17/04/2027 | 162 |
| 2026002993 | FUNARJ | 49500738 BRUNA SARAIVA MELO | Contratação da artista Bruna Saraiva, credenciada por meio do Edital … | R$ 4.000,00 | 17/04/2027 | 162 |
| 2026002995 | FUNARJ | TRECO PRODUÇÕES ARTISTICAS LTDA | Contratação do Diretor Artístico Cesar Augusto para o Espetáculo Caba… | R$ 12.000,00 | 17/04/2027 | 162 |
| 2024002942 | FMIS | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Contratação de empresa especializada em confecção de Certificado Digi… | R$ 300,00 | 18/04/2027 | 163 |
| 2026007147 | FEC | COOKIE EDITORIAL LTDA | Aquisição de diversos títulos de livros impressos para compor o acerv… | R$ 474.689,42 | 22/04/2027 | 167 |
| 2026007173 | FEC | KMB DISTRIBUIDORA E COMÉRCIO DE LIVROS LTDA | Aquisição de diversos títulos de livros impressos para compor o acerv… | R$ 50.699,91 | 22/04/2027 | 167 |
| 2026007169 | FEC | EDITORA E DISTRIBUIDORA MOTIVOS LTDA | Aquisição de diversos títulos de livros impressos para compor o acerv… | R$ 296.979,60 | 23/04/2027 | 168 |
| 2026007175 | FEC | INTERBOOK LTDA. EPP | Aquisição de diversos títulos de livros impressos para compor o acerv… | R$ 18.300,00 | 23/04/2027 | 168 |
| 2026003170 | FUNARJ | ESTUDIO NNOS ARQUITETURA E PRODUÇÕES ARTÍSTI… | Destina-se a contratação de empresa especializada em prestação de ser… | R$ 533.200,00 | 29/04/2027 (PNCP) | 174 |
| 2025002485 | FTMRJ | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARAPRESTAÇÃO DE SERVIÇOS DE ADM… | R$ 349.676,40 | 30/04/2027 | 175 |
| 2026003280 | FUNARJ | LEANDRO DA COSTA CUNHA | A contratação do artista Andre Lucas. | R$ 38.000,00 | 03/05/2027 | 178 |
| 2026003342 | FEC | FERREIRAS UP SERVICOS LTDA | Contratação de empresa especializada na prestação de serviços de difu… | R$ 2.278.999,50 | 05/05/2027 (PNCP) | 180 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000347 | FUNARJ | LIGA INDEPENDENTE DAS ESCOLAS DE SAMBA DO RI… | Destina-se a celebração de contrato de incentivo financeiro ao Projet… | R$ 40.000.000,00 | 28/07/2026 (PNCP) | -101 |
| 2025000464 | FUNARJ | LIGA INDEPENDENTE DAS ESCOLAS DE SAMBA DO RI… | Destina-se a celebração de contrato de incentivo financeiro ao Projet… | R$ 40.000.000,00 | 04/12/2025 (PNCP) | -337 |
| 2025001353 | FUNARJ | LIGA INDEPENDENTE DO GRUPO A - RIO DE JANEIRO | Destina-se a cobrir despesa com a celebração de contrato de incentivo… | R$ 16.000.000,00 | 06/08/2025 (PNCP) | -457 |
| 2026000938 | FUNARJ | LIGA INDEPENDENTE DO GRUPO A - RIO DE JANEIRO | Destina-se como apoio financeiro como incentivo cultural ao carnaval … | R$ 16.000.000,00 | 27/08/2026 (PNCP) | -71 |
| 2025002915 | FUNARJ | BONUS TRACK ENTRETENIMENTO LTDA | Destina-se a cobrir despesa com o plano de incentivo/patrocínio ao ev… | R$ 15.000.000,00 | 02/07/2025 (PNCP) | -492 |
| 2025005386 | SECEC | VIGAFORT VIGILANCIA E SEGURANÇA LTDA | Contratação de empresa especializada na prestação de serviços continu… | R$ 6.103.982,23 | 08/08/2026 (PNCP) | -90 |
| 2023011052 | SECEC | WES EMPREENDIMENTOS E SERVIÇOS LTDA | Prestação de serviços a ser contratada pela Secretaria de Estado de C… | R$ 4.228.497,67 | 04/01/2025 | -671 |
| 2025001377 | FUNARJ | SUPERLIGA CARNAVALESCA DO BRASIL | Destina-se a cobrir despesa com a celebração de contrato de incentivo… | R$ 4.000.000,00 | 06/08/2025 (PNCP) | -457 |
| 2026000939 | FUNARJ | SUPERLIGA CARNAVALESCA DO BRASIL | Destina-se ao patrocínio cultural voltado à organização dos desfiles … | R$ 4.000.000,00 | 26/08/2026 (PNCP) | -72 |
| 2025005377 | FUNARJ | EDITORA GLOBO S/A | Trata-se de Incentivo/Patrocínio para realização do evento musical ``… | R$ 3.500.000,00 | 28/10/2025 (PNCP) | -374 |
| 2025004939 | FUNARJ | BR 101 CONSTRUÇÕES SINGULARES LTDA | Destina-se a contratação de empresa para prestação de serviços de man… | R$ 2.917.033,80 | 14/07/2026 (PNCP) | -115 |
| 2025002673 | FEC | STAGE PARTICIPAÇÕES LTDA. | Contratação de empresa especializada na realização de reparo do siste… | R$ 2.885.473,98 | 05/09/2026 (PNCP) | -62 |
| 2024005527 | FUNARJ | FERREIRAS UP SERVICOS LTDA | Contratação de empresa especializada na prestação de serviços de: dif… | R$ 2.849.999,99 | 26/05/2026 (PNCP) | -164 |
| 2024007182 | SECEC | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | Contratação de agente de integração especializado, conforme previsto … | R$ 2.838.163,20 | 24/09/2025 (PNCP) | -408 |
| 2025002603 | SECEC | FLF COMERCIO DE EQUIPAMENTOS CINEMATOGRAFICO… | : Contratação de empresas especializadas nofornecimento de equipament… | R$ 2.599.000,00 | 03/08/2025 (PNCP) | -460 |
| 2025005811 | SECEC | ARKCON CONSTRUTORA E INCORPORADORA LTDA | contratação de empresa especializada para a Continuidade da Construçã… | R$ 2.593.210,10 | 15/06/2026 (PNCP) | -144 |
| 2025002617 | FUNARJ | FP AUDIO EIRELI | Destina-se a contratação de empresa especializada em prestação de ser… | R$ 2.364.000,00 | 28/10/2026 (PNCP) | -9 |
| 2025005018 | FEC | PISOSSUL CONSTRUÇÃO INDUSTRIA E COMERCIO DE … | Aquisição de pisos flutuantes modulares, desmontáveis e portáteis, es… | R$ 2.148.000,00 | 21/11/2025 (PNCP) | -350 |
| 2025002695 | FEC | SERVIÇO NACIONAL DE APRENDIZAGEM COMERCIAL -… | CAPACITACAO E TREINAMENTO DE PESSOAL,DESCRICAO: CONTRATACAO DE EMPRES… | R$ 1.940.108,73 | 14/08/2026 (PNCP) | -84 |
| 2023001519 | SECEC | BRS SUPRIMENTOS CORPORATIVOS S/A | Serviços continuados de outsourcing para operação de almoxarifado vir… | R$ 1.598.024,27 | 03/04/2026 | -217 |
| 2024007778 | FEC | CINE TEATRO SHOPPING SAO PEDRO LTDA | Contratação de empresa exibidora que ficará responsável pela operacio… | R$ 1.440.000,00 | 17/10/2026 (PNCP) | -20 |
| 2024007676 | FUNARJ | LEDPRO EVENTOS EIRELI | Destina-se a contratação de empresa especializada em prestação de ser… | R$ 1.346.579,52 | 01/01/2026 (PNCP) | -309 |
| 2025005092 | FEC | TAPECARIA FLAVIENSE LTDA 01444685000128 | Contratação de serviço especializado na confecção de cortina de boca … | R$ 1.286.000,00 | 20/07/2026 (PNCP) | -109 |
| 2026002538 | SECEC | GONCALVES DE CASTRO ASSESSORIA COMERCIAL LTDA | Participação da Secretaria Estadual deCultura e Economia Criativa, at… | R$ 1.219.875,00 | 05/07/2026 (PNCP) | -124 |
| 2024009035 | FEC | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Contratação de Empresa Especializada para a Prestação de Serviços de … | R$ 1.172.969,20 | 07/11/2025 | -364 |
| 2025006311 | FEC | CONSTRUPOWER ENGENHARIA LTDA | O presente tem por objetivo a contratação de empresa especializada na… | R$ 1.148.000,00 | 26/09/2026 (PNCP) | -41 |
| 2025004076 | FEC | SINDICATO NACIONAL DOS EDITORES DE LIVROS | Contratação de serviços técnicos especializados para a emissão de car… | R$ 1.031.143,34 | 08/08/2025 (PNCP) | -455 |
| 2025006802 | FUNARJ | TRÁFEGO MARKETING CULTURAL LTDA. | Destina-se a cobrir despesa com o apoio a 17ª Edição à Festa Internac… | R$ 1.000.000,00 | 02/11/2025 (PNCP) | -369 |
| 2022001459 | SECEC | CLARO S/A (FILIAL) | Adesão à Ata de Registro de Preços nº 0001/2021 do Pregão Eletrônico … | R$ 946.915,56 | 10/03/2025 | -606 |
| 2025000547 | FUNARJ | TABETRON PRODUÇÕES ARTÍSTICAS LTDA | a contratação inclui o fornecimento e aparatos circenses, que enrique… | R$ 934.244,82 | 10/02/2026 (PNCP) | -269 |

_Registros mais antigos (provável falta de baixa no SIGA): 676, R$ 143,2 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026005347 | SECEC | ELITE TURISTICA LTDA | Pregão Eletrônico para a contratação daprestação dos serviços contínu… | R$ 12.978.000,00 | 31/07/2027 | 267 |
| 2024009026 | FEC | FUNDAÇÃO GETULIO VARGAS | Contratação direta de instituição para prestação de serviços de desen… | R$ 8.000.000,00 | 17/11/2026 (PNCP) | 11 |
| 2026008800 | SECEC | OTONI SEGURANÇA E SERVIÇOS LTDA | Contratação contínua de serviços de Vigilância Patrimonial armada e d… | R$ 5.871.086,88 | 21/10/2027 | 349 |
| 2026005348 | SECEC | SIBELLY TRANSPORTES LTDA | Pregão Eletrônico para a contratação daprestação dos serviços contínu… | R$ 4.318.974,00 | 10/07/2027 | 246 |
| 2025008827 | FUNARJ | VIGILIA BRASIL SERVIÇOS LTDA | Destina-se a contratação de empresa especializada em prestação de ser… | R$ 4.245.944,84 | 03/02/2027 (PNCP) | 89 |
| 2025008776 | FTMRJ | TERA BUSINESS SOLUCOES E SERVICOS LTDA | Contratação de empresa prestadora de serviço continuado de limpeza, d… | R$ 4.089.690,00 | 10/11/2028 | 735 |
| 2025007803 | FTMRJ | ANRX ENGENHARIA E SOLUCOES LTDA | SERVICO DE MANUTENCAO EM SISTEMA DE REFRIGERACAO - DESCRIÇÃO: CONTRAT… | R$ 2.491.999,92 | 30/09/2027 | 328 |
| 2026003342 | FEC | FERREIRAS UP SERVICOS LTDA | Contratação de empresa especializada na prestação de serviços de difu… | R$ 2.278.999,50 | 05/05/2027 (PNCP) | 180 |
| 2025004308 | FTMRJ | INSTITUTO SOCIAL SE LIGA | Contratação de empresa especializada em prestação de serviço de Vigia… | R$ 2.219.000,00 | 18/06/2027 | 224 |
| 2024007302 | FMIS | LECARD ADMNISTRADORA DE CARTÕES LTDA | Prorrogação do prazo de vigência por mais 12 (doze) meses, com renúnc… | R$ 2.124.960,00 | 11/09/2027 | 309 |
| 2026006742 | FUNARJ | J J PEREIRA MAQUINAS E EQUIPAMENTOS | Locação e operação de unidade móvel multifuncional tipo carreta palco… | R$ 1.864.800,00 | 26/08/2027 | 293 |
| 2024008317 | SECEC | CS BRASIL FROTAS S.A. | CONTRATAÇÃO DE SERVIÇOS DE LOCAÇÃO DE VEÍCULOS DE SERVIÇOS E VEÍCULOS. | R$ 1.841.342,68 | 03/11/2027 | 362 |
| 2025006594 | FEC | PRIMASOFT INFORMATICA LTDA | : Contratação de empresa especializada paralicença de uso (prazo dete… | R$ 1.549.077,32 | 09/09/2027 | 307 |
| 2025007985 | SECEC | FJS FORNECIMENTO DE ALIMENTOS EIRELI | Aquisição de material de nutrição complementar denominado Kit Lanche… | R$ 1.549.003,68 | 10/10/2027 | 338 |
| 2025003372 | FEC | CINE TEATRO SHOPPING SAO PEDRO LTDA | Contratação de empresa exibidora que ficará responsável pela operacio… | R$ 1.440.000,00 | 23/05/2027 | 198 |
| 2026000202 | FEC | WELLINGTON CARDOSO DA LUZ CINEMAS LTDA | Contratação de empresa exibidora que ficará responsável pela operacio… | R$ 1.440.000,00 | 22/04/2028 | 533 |
| 2026005577 | SECEC | PONTA DO CEU URBANIZAÇÃO CONSTRUÇÕES & PAISA… | Contratação de empresa especializada na prestação de serviços continu… | R$ 1.433.000,00 | 31/07/2027 | 267 |
| 2026002570 | FTMRJ | INSTITUTO AVALIA DE INOVAÇÃO EM AVALIAÇÃO E … | CONTRATAÇÃO DEPESSOA JURÍDICAESPECIALIZADA NAPRESTAÇÃO DESERVIÇOS TÉC… | R$ 1.430.000,00 | 01/04/2027 (PNCP) | 146 |
| 2026004492 | FUNARJ | FP AUDIO EIRELI | Contratação de empresa especializada para prestação de serviço de son… | R$ 1.250.000,00 | 10/11/2026 (PNCP) | 4 |
| 2024001448 | FTMRJ | RIOPAR PARTICIPAÇÕES S/A | SERVICO DE FORNECIMENTO/RECARGA VALE TRANSPORTE,DESCRIÇÃO: AQUISICAO … | R$ 1.103.155,20 | 11/03/2027 (PNCP) | 125 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| ELITE TURISTICA LTDA | 1 | R$ 12.978.000,00 |
| FUNDAÇÃO GETULIO VARGAS | 1 | R$ 8.000.000,00 |
| OTONI SEGURANÇA E SERVIÇOS LTDA | 1 | R$ 5.871.086,88 |
| SIBELLY TRANSPORTES LTDA | 1 | R$ 4.318.974,00 |
| VIGILIA BRASIL SERVIÇOS LTDA | 1 | R$ 4.245.944,84 |
| TERA BUSINESS SOLUCOES E SERVICOS LTDA | 1 | R$ 4.089.690,00 |
| LECARD ADMNISTRADORA DE CARTÕES LTDA | 3 | R$ 2.719.950,50 |
| ANRX ENGENHARIA E SOLUCOES LTDA | 1 | R$ 2.491.999,92 |
| FERREIRAS UP SERVICOS LTDA | 1 | R$ 2.278.999,50 |
| INSTITUTO SOCIAL SE LIGA | 1 | R$ 2.219.000,00 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2017004404 | T&S LOCAÇÃO DE MÃO DE OBRA EM GERAL - EIRELI | R$ 13.125.204,50 | R$ 9.829.851,04 | R$ 3.295.353,46 |
| 2022001011 | CONSREFOR SERVIÇOIS MANUTENÇÃO E CONSTRUÇÕES… | R$ 238.341,94 | R$ 0,00 | R$ 238.341,94 |
| 2019002583 | RIVAN CONSTRUTORA LTDA | R$ 1.609.859,30 | R$ 1.388.716,05 | R$ 221.143,25 |
| 2021002151 | SOUZA & PERES COMERCIO E REPRESENTACOES EIRE… | R$ 1.222.852,08 | R$ 1.048.444,41 | R$ 174.407,67 |
| 2022001334 | GONCALVES DE CASTRO ASSESSORIA COMERCIAL LTDA | R$ 120.200,00 | R$ 0,00 | R$ 120.200,00 |
| 2022006343 | PROTAQUE SEGURANÇA E VIGILANCIA - EIRELI | R$ 1.926.934,21 | R$ 1.855.434,21 | R$ 71.500,00 |
| 2019004171 | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | R$ 981.954,08 | R$ 910.599,31 | R$ 71.354,77 |
| 2017000387 | FEDERACAO DAS EMPRESAS DE TRANSPORTE DE PASS… | R$ 1.859.400,55 | R$ 1.792.610,41 | R$ 66.790,14 |
| 2019004900 | PROVAC TERCEIRIZAÇÃO DE MÃO DE OBRA LTDA. | R$ 906.684,96 | R$ 842.810,61 | R$ 63.874,35 |
| 2022000776 | LIGHT SERVICOS DE ELETRICIDADE SA | R$ 513.060,83 | R$ 454.877,03 | R$ 58.183,80 |
| 2020001392 | DE SÁ CONSTRUÇÕES E SERVIÇOS LTDA | R$ 977.864,92 | R$ 920.519,08 | R$ 57.345,84 |
| 2021004630 | DE SÁ CONSTRUÇÕES E SERVIÇOS LTDA | R$ 1.153.492,17 | R$ 1.101.076,86 | R$ 52.415,31 |
| 2019001551 | SECRETARIA MUNICIPAL DE FAZENDA | R$ 147.238,16 | R$ 96.545,08 | R$ 50.693,08 |
| 2017003115 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 49.560,47 | R$ 1.700,15 | R$ 47.860,32 |
| 2021006843 | DADY ILHA SOLUCOES INTEGRADAS LTDA | R$ 60.695,66 | R$ 33.053,35 | R$ 27.642,31 |
| 2018004102 | STANDER COMÉRCIO SERVIÇOS DE REFRIGERAÇÃO LT… | R$ 897.008,00 | R$ 875.008,00 | R$ 22.000,00 |
| 2018001591 | LOCAL SOLUTION QUALITY LTDA - EPP | R$ 19.519,88 | R$ 0,00 | R$ 19.519,88 |
| 2019002778 | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | R$ 551.078,20 | R$ 532.984,13 | R$ 18.094,07 |
| 2018005888 | MAR E FIRE EQUIP. E PROT. CONTRA INCÊNDIO LT… | R$ 17.000,00 | R$ 0,00 | R$ 17.000,00 |
| 2021006811 | EMPRESA BRASILEIRA DE ENGENHARIA E COMÉRCIO … | R$ 93.210,00 | R$ 78.870,00 | R$ 14.340,00 |

## 11. Unidades incluídas neste dossiê
- FCFB - FUNDAÇÃO CASA FRANÇA BRASIL
- FEC - Fundo Estadual da Cultura
- FMIS - FUNDAÇÃO MUSEU DA IMAGEM E DO SOM
- FTMRJ - FUNDAÇÃO TEATRO MUNICIPAL DO RIO DE JANEIRO
- FUNARJ - FUND ANITA MANTUANO DE ARTES DO EST DO RJ
- SECEC - Sec de Estado de Cultura e Econ Criativa

## 12. Conjuntos de dados abertos da secretaria
- ESTAGIÁRIOS 2026 (atualizado 2026-10-21): [DADOS ESTAGIARIOS 2026_jan a abril .xlsx](https://dadosabertos.rj.gov.br/dataset/5e5b3922-2c0f-4414-bf40-39c1a4c76a76/resource/37926b3b-726c-41d0-978e-186bdb47dc44/download/dados-estagiarios-2026_jan_abril.xlsx), [ESTAGIÁRIOS-2026-MAIO XLSX](https://dadosabertos.rj.gov.br/dataset/5e5b3922-2c0f-4414-bf40-39c1a4c76a76/resource/dc49dc0b-dcb7-4a10-a7ff-2d96a70c16eb/download/dados-estagiarios-2026_maio.xlsx), [DADOS ESTAGIÁRIOS 2026_JUNHO.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/5e5b3922-2c0f-4414-bf40-39c1a4c76a76/resource/69f9be67-9311-4397-b1c0-598eff45e405/download/dados-estagiarios-2026_junho.xlsx), [DADOS ESTAGIÁRIOS 2026_JULHO.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/5e5b3922-2c0f-4414-bf40-39c1a4c76a76/resource/f2d199a4-5bfb-40b1-b911-99cbda2931a7/download/dados-estagiarios-2026_julho.xlsx)
- Contratação de Empresa para Prestação de Serviços de Jardinagem (atualizado 2026-09-29): [Lista de Funcionários do Contrato de Ja… XLSX](https://dadosabertos.rj.gov.br/dataset/ce0c9ce2-59e9-4437-ad75-55eff3867dbb/resource/8c26303c-54c5-422b-8f05-b901c743b476/download/efetivo-secec-08.2026.xlsx)
- Contratação de Empresa de Prestação de Serviços de Jardinagem - Quantitativo de Terceirizados (atualizado 2026-04-22): [Funcionários terceirizados prestadores … XLSX](https://dadosabertos.rj.gov.br/dataset/d56307ff-cf3b-424b-9cee-5423092da1fb/resource/4a25aa5f-9744-4798-bf60-e1b689fa53d8/download/ieva_dados_abertos_quantitativo_23.xlsx), [Funcionários terceirizados prestadores … .xlsx](https://dadosabertos.rj.gov.br/dataset/d56307ff-cf3b-424b-9cee-5423092da1fb/resource/c650884b-787e-4e3d-99f8-6d5c89c1829c/download/ieva_dados_abertos_quantitativo_24.xlsx), [Funcionários terceirizados prestadores … .xlsx](https://dadosabertos.rj.gov.br/dataset/d56307ff-cf3b-424b-9cee-5423092da1fb/resource/ed5367b8-a42a-4be8-8e43-41479f3cbbb7/download/ieva_dados_abertos_quantitativo_25.xlsx)
- Terceirizado Fundação Santa Cabrini 2023 a 2025 (atualizado 2026-04-22): [FSC 2023.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/2bb8a236-dbc1-472f-a1a8-e83ee108beac/resource/f1ba8fca-808c-4b41-a876-9b95c5b0e878/download/fsc-2023.xlsx), [FSC 2024.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/2bb8a236-dbc1-472f-a1a8-e83ee108beac/resource/70f3ccc4-17f9-4e77-a927-4d47cb9ea5a0/download/fsc-2024.xlsx), [FSC 2025.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/2bb8a236-dbc1-472f-a1a8-e83ee108beac/resource/cf9da140-f029-469d-8675-a2cfefd85f0c/download/fsc-2025.xlsx)
- Terceirizados Fundação Santa Cabrini de 2026 (atualizado 2026-04-22): [FSC jan-fev 2026.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/5ef1fae8-ca11-4b48-a085-4a948c6a82c6/resource/e6885fdf-83c9-4748-9575-82064cb4700b/download/fsc-2026.xlsx)
- ESTAGIÁRIOS 2023 a 2025 (atualizado 2026-04-22): [ ](https://dadosabertos.rj.gov.br/dataset/003624d0-12c7-4b86-ae7b-0e2b95e77c00/resource/1108f4d6-4b26-4c49-b30f-21a1762f1889/download/___), [DADOS ESTAGIARIOS 2023 .xlsx](https://dadosabertos.rj.gov.br/dataset/003624d0-12c7-4b86-ae7b-0e2b95e77c00/resource/3d77c569-6a43-4686-8e7f-4e1fd7f56eeb/download/dados-estagiarios-2023.xlsx), [DADOS ESTAGIARIOS 2024 .xlsx](https://dadosabertos.rj.gov.br/dataset/003624d0-12c7-4b86-ae7b-0e2b95e77c00/resource/6fd587db-0ebf-4d02-8af9-5e282f62c8d9/download/dados-estagiarios-2024.xlsx), [DADOS ESTAGIARIOS 2025 .xlsx](https://dadosabertos.rj.gov.br/dataset/003624d0-12c7-4b86-ae7b-0e2b95e77c00/resource/41c631ff-44ae-421f-92cb-17b4ce7028ae/download/dados-estagiarios-2025.xlsx)
- Terceirizados Vigaforte 2025 (atualizado 2026-04-22): [VIGAFORTE 2025.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/f15eba8f-89dc-4ade-991e-f3dbc12d10de/resource/7a79a0ef-2e48-4706-9750-223794f408b3/download/vigaforte-2025.xlsx)
- Terceirizados MGS - 2023 a 2025 (atualizado 2026-04-22): [Terceirizados MGS - 2023 XLSX](https://dadosabertos.rj.gov.br/dataset/4649752a-a435-4214-8932-524bc19ae495/resource/988116ec-b8b8-419b-97da-0bc4005f5d68/download/mgs2023.xlsx), [terceirizados mgs 24 XLSX](https://dadosabertos.rj.gov.br/dataset/4649752a-a435-4214-8932-524bc19ae495/resource/8b7c6867-e336-43d5-a7d7-f4de7560fbe0/download/mgs2024.xlsx)
- Terceirizados Protaque 2023 até 2025 (atualizado 2026-04-22): [Terceirizados Protaque 23 XLSX](https://dadosabertos.rj.gov.br/dataset/1b320cad-db2b-423a-a230-6593d3e742e3/resource/d0058692-7e0b-4dd1-a530-83bf1a0fe36a/download/protaque-2023.xlsx), [Terceirizados Protaque 24 XLSX](https://dadosabertos.rj.gov.br/dataset/1b320cad-db2b-423a-a230-6593d3e742e3/resource/d00185a4-75f3-471a-9694-9011201d986d/download/protaque-2024.xlsx), [Terceirizados Protaque 25 XLSX](https://dadosabertos.rj.gov.br/dataset/1b320cad-db2b-423a-a230-6593d3e742e3/resource/ae333fa6-253a-4f8e-b241-429d777bccbb/download/protaque-2025.xlsx)
- Terceirizados MGS 2026 (atualizado 2026-04-22): [terceirizados mgs 26 XLSX](https://dadosabertos.rj.gov.br/dataset/4d6627a6-4f0e-481a-b476-79b8f14ddabd/resource/94f717c3-9bb3-4c6f-9504-f0e032103d81/download/___)
- Terceirizados Tapevas 2023 até 2025 (atualizado 2026-04-22): [tapevas 2023.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/a8ccfdb2-b775-4b0f-880e-b418fc8bd2be/resource/6b14c497-8b24-4b36-ab2a-0d5d9e91f69d/download/tapevas-2023.xlsx), [tapevas 2024 (1).xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/a8ccfdb2-b775-4b0f-880e-b418fc8bd2be/resource/5c40f3c0-b871-47d9-a529-4510e3d46ba1/download/tapevas-2024-1.xlsx), [tapevas 2025.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/a8ccfdb2-b775-4b0f-880e-b418fc8bd2be/resource/87b4c848-4d89-4881-8a04-a96ad72a9c0a/download/tapevas-2025.xlsx)
- Terceirizados Vigafort 2026 (atualizado 2026-04-22): [Terceirizados Vigafort 2026 XLSX](https://dadosabertos.rj.gov.br/dataset/2023b3eb-b8f8-42f5-ae7e-867d0cb51e01/resource/7fcf1e36-3d60-4b05-9660-6e7dbd59941e/download/vigaforte-2026.xlsx)
- ACORDO DE COOPERAÇÃO TÉCNICA SEM REPASSE FINANCEIRO (atualizado 2026-04-22): [ACT com a ONG Viver em Crescimento Cent… PDF](https://dadosabertos.rj.gov.br/dataset/7355430d-990f-4697-bd2e-3d625304aa67/resource/8d4bc591-3796-4926-9d41-293db8b6a60a/download/act-secec-ong-viver-em-crescimento.pdf), [ACT SECEC UNIRIO PDF](https://dadosabertos.rj.gov.br/dataset/7355430d-990f-4697-bd2e-3d625304aa67/resource/9cc28507-d51f-420a-991e-1a1a34a97dfc/download/act-secec-unirio.pdf), [ACT REDE WEB MUSEUS.pdf PDF](https://dadosabertos.rj.gov.br/dataset/7355430d-990f-4697-bd2e-3d625304aa67/resource/8bece830-b269-4bf6-8adf-afded59ba445/download/act-rede-web-museus.pdf), [ACT IBRAM SECEC.pdf PDF](https://dadosabertos.rj.gov.br/dataset/7355430d-990f-4697-bd2e-3d625304aa67/resource/e6e8859f-c5a9-48ac-9845-799cea18d893/download/act-ibram-secec.pdf)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 6 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo
A prioridade imediata é acompanhar a reestruturação do quadro da SECEC e o concurso público: a notícia do STF publicada em 19/10/2026 informa que foram suspensos os efeitos da decisão do TJRJ pelo tempo necessário às providências, limitado a 12 meses, e que há risco de continuidade dos serviços se houver exonerações sem substituição por efetivos. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)
O MPRJ ajuizou ação civil pública questionando a composição do quadro, descrita como 16 servidores efetivos e 336 cargos em comissão; essa é uma alegação no processo, não uma conclusão definitiva aqui documentada. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)
Há uma janela iminente do programa Cultura em Dia, de 9 a 23/11/2026, para regularização de pendências de proponentes de projetos culturais; as fontes não atribuem essas dívidas à Secretaria. [Programa Cultura em Dia](https://cultura.rj.gov.br/governo-do-estado-lanca-programa-cultura-em-dia-para-regularizacao-de-pendencias-de-projetos-culturais/)
As fontes consultadas não detalham contratos, decisões do TCE-RJ ou resultados/conclusões das auditorias listadas, limitando a avaliação de riscos financeiros e de controle. [Auditorias da SECEC](https://cultura.rj.gov.br/auditorias/)

##### Alertas vermelhos
- **Quadro de pessoal e reestruturação:** o MPRJ apontou desproporção entre 16 servidores efetivos e 336 cargos em comissão; segundo notícia do STJ, o MPRJ também sustentou que 132 comissionados não exerceriam funções de direção, chefia ou assessoramento, alegação que deve ser tratada como posição do autor da ação. [STJ mantém exoneração de 20%](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx)
- **Situação judicial atual:** em 19/10/2026, a notícia do STF informou a suspensão dos efeitos da decisão do TJRJ pelo prazo necessário às providências da Secretaria, limitado a 12 meses contados da publicação da decisão do tribunal estadual; a fonte não informa nessa síntese a data de publicação usada para iniciar a contagem. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)
- **Concurso e reorganização:** a fonte do STF informa a necessidade de planejamento, concurso público e adequação orçamentária; uma notícia de 19/10/2026 prevê edital em 2027, mas registra que banca, vagas, escolaridade e cargo estavam a definir. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/) [Concurso Secec RJ](https://concursos.estrategia.com/portal/concurso-secec-rj/)
- **Janela imediata para proponentes:** a adesão ao Cultura em Dia ocorre das 9h de 9/11 às 18h de 23/11/2026; o procedimento prevê prazos de até dois dias úteis para envio de documentos pelo proponente após o comunicado e para análise pela equipe responsável. [Programa Cultura em Dia](https://cultura.rj.gov.br/governo-do-estado-lanca-programa-cultura-em-dia-para-regularizacao-de-pendencias-de-projetos-culturais/)

##### Contratos e serviços críticos
Nada encontrado nas fontes consultadas sobre números, empresas, valores ou vigências de contratos da SECEC. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/) [STJ mantém exoneração de 20%](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx)
O Estado alegou no STJ que a exoneração de cerca de 67 comissionados poderia comprometer atividades, interromper projetos e fechar equipamentos culturais em diferentes regiões, mas o presidente do STJ considerou genéricos e não comprovados concretamente os riscos apresentados pelo Estado. [STJ mantém exoneração de 20%](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx)
A decisão noticiada pelo STF posteriormente considerou que exonerações imediatas sem substituição por efetivos representavam risco concreto à continuidade das atividades administrativas e culturais, inclusive de fechamento de unidades em diversas regiões. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)
**MPRJ:** o Ministério Público ajuizou ação civil pública questionando a composição do quadro da SECEC. As notícias informam que havia 16 servidores efetivos e 336 cargos em comissão; segundo o MPRJ, 132 comissionados não exerceriam atribuições de direção, chefia e assessoramento. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/) [STJ mantém exoneração de 20%](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx)
**Judiciário:** o TJRJ inicialmente determinou a suspensão de 50% dos cargos em comissão e depois reduziu o percentual para 20%, determinando a exoneração dos ocupantes dos cargos correspondentes. Em 15/10/2026, o STJ manteve essa decisão. Em 19/10/2026, o STF noticiou a suspensão dos efeitos da decisão estadual pelo tempo necessário à reestruturação, limitado a 12 meses. [STJ mantém exoneração de 20%](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx) [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)
Um estudo preliminar de dimensionamento de pessoal, elaborado em janeiro de 2026, identificou déficit de servidores e 323 cargos vagos, segundo a notícia do STF. Nela, o Estado alegou que a medida poderia causar grave lesão à ordem pública por interferir na organização administrativa da secretaria; a notícia do STJ registra que o Estado alegou que as exonerações poderiam comprometer a continuidade das atividades. O ministro do STF, por sua vez, reconheceu risco concreto à continuidade dos serviços sem substituição por efetivos. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/) [STJ mantém exoneração de 20%](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx)
**TCE-RJ:** nada encontrado nas fontes consultadas sobre decisões do Tribunal de Contas do Estado do Rio de Janeiro. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/) [STJ mantém exoneração de 20%](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx)

##### Riscos de apagão administrativo
O risco de interrupção de atividades e fechamento de equipamentos culturais foi alegado pelo Estado no recurso ao STJ; naquela decisão, o presidente do tribunal afirmou que não havia prova concreta dos prejuízos alegados. [STJ mantém exoneração de 20%](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx)
Em decisão posteriormente noticiada pelo STF, foi reconhecido risco concreto à continuidade das atividades administrativas e culturais caso houvesse exoneração imediata de parcela significativa dos comissionados sem substituição por efetivos; a suspensão foi limitada a 12 meses para permitir providências. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)
As fontes não identificam quais unidades, projetos ou serviços específicos seriam afetados, nem apresentam plano de contingência da SECEC. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/) [STJ mantém exoneração de 20%](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx)

##### Fatos recentes
Em 04/11/2026, a SECEC anunciou o programa Cultura em Dia, com adesão de 9 a 23/11/2026 para proponentes com dívidas ou prestações de contas pendentes em mecanismos de fomento; o programa não representa perdão de dívidas nem reconhecimento automático de regularidade. [Programa Cultura em Dia](https://cultura.rj.gov.br/governo-do-estado-lanca-programa-cultura-em-dia-para-regularizacao-de-pendencias-de-projetos-culturais/)
A notícia do STF, publicada em 19/10/2026 e atualizada há duas semanas segundo a página, relata a suspensão temporária dos efeitos da decisão do TJRJ e a necessidade de reestruturação e concurso público. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/)
A página de auditorias lista PLANAT 2026 e documentos RANAT de 2022 a 2025 e PLANAT de 2023 a 2025 para o Fundo Estadual de Cultura e a Fundação Museu da Imagem e do Som, mas o material fornecido não descreve achados, recomendações ou providências corretivas. [Auditorias da SECEC](https://cultura.rj.gov.br/auditorias/)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)
- **Contratos:** nada encontrado nas fontes consultadas sobre número, objeto, contratada, valor, vigência, aditivos ou situação de execução; solicitar cadastro atualizado e relação de contratos críticos para a continuidade dos serviços. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/) [STJ mantém exoneração de 20%](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx)
- **TCE-RJ:** nada encontrado sobre decisões, auditorias ou determinações do Tribunal; solicitar processos, acórdãos, diligências e prazos pendentes. [STJ mantém exoneração de 20%](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx)
- **Auditorias:** a página lista PLANAT/RANAT, mas as fontes fornecidas não trazem o conteúdo dos relatórios, achados, responsáveis ou planos de ação; solicitar os documentos integrais e o acompanhamento das recomendações para FEC e FMIS. [Auditorias da SECEC](https://cultura.rj.gov.br/auditorias/)
- **Pessoal e ação judicial:** solicitar a íntegra das decisões, a data de publicação relevante para a contagem do prazo de 12 meses, a situação de cumprimento, o estudo de dimensionamento, o quadro atualizado e o cronograma de reestruturação e concurso, pois esses detalhes não estão integralmente documentados nas fontes fornecidas. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/) [Concurso Secec RJ](https://concursos.estrategia.com/portal/concurso-secec-rj/)
- **Pendências de fomento:** o Cultura em Dia trata de pendências de proponentes, mas a fonte não quantifica valores, número de casos ou impacto financeiro; ela descreve o fluxo de atendimento. Solicitar dados agregados, sem presumir que sejam dívidas da Secretaria. [Programa Cultura em Dia](https://cultura.rj.gov.br/governo-do-estado-lanca-programa-cultura-em-dia-para-regularizacao-de-pendencias-de-projetos-culturais/)
- **Continuidade dos serviços e transição:** nada encontrado sobre plano de contingência, mapa de serviços/unidades vulneráveis, atrasos atribuídos à SECEC, crise institucional ou medidas específicas para a transição de governo; solicitar esses registros à Secretaria. [STF dá prazo para reestruturação](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/) [Auditorias da SECEC](https://cultura.rj.gov.br/auditorias/)

##### Fontes consultadas
1. [Auditorias](https://cultura.rj.gov.br/auditorias/) — 2026-10-20
2. [STF dá prazo para que Secretaria de Cultura do RJ reestruture ...](https://noticias.stf.jus.br/postsnoticias/stf-da-prazo-para-que-secretaria-de-cultura-do-rj-adeque-quadro-de-servidores/) — 2026-11-05
3. [...](https://www.stj.jus.br/sites/portalp/paginas/comunicacao/noticias/2026/15102026-mantida-decisao-que-determinou-a-exoneracao-de-20--dos-comissionados-da-secretaria-de-cultura-do-rio.aspx) — 2026-10-31
4. [Concurso Secec RJ: comissão formada; edital previsto](https://concursos.estrategia.com/portal/concurso-secec-rj/) — 2026-10-19
5. [Governo do Estado lança programa Cultura em Dia para regularização de pendências de projetos culturais](https://cultura.rj.gov.br/governo-do-estado-lanca-programa-cultura-em-dia-para-regularizacao-de-pendencias-de-projetos-culturais/) — 2026-11-04
6. [STJ nega pedido do Rio e mantém 67 exonerações na Secretaria de Cultura](https://noticias.r7.com/brasilia/stj-nega-pedido-do-rio-e-mantem-67-exoneracoes-na-secretaria-de-cultura-15102026/) — 2026-10-15


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2026003422 (GMK LTDA) vence em 06/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2026003516 (CINE & TEATRO PRODUÇÕES LTDA - ME) vence em 06/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025009171 (FENIX PRODUÇÕES ARTISTÍCAS LTDA) vence em 07/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2026003529 (LUX EMPREENDIMENTOS CULTURAIS LTDA) vence em 07/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2026003530 (OUTRO LUGAR PRODUCOES LTDA) vence em 07/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2026000347 (LIGA INDEPENDENTE DAS ESCOLAS DE SAMBA …, R$ 40,0 mi) consta 'Ativo' no SIGA com fim em 28/07/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2025000464 (LIGA INDEPENDENTE DAS ESCOLAS DE SAMBA …, R$ 40,0 mi) consta 'Ativo' no SIGA com fim em 04/12/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2025001353 (LIGA INDEPENDENTE DO GRUPO A - RIO DE J…, R$ 16,0 mi) consta 'Ativo' no SIGA com fim em 06/08/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2026000938 (LIGA INDEPENDENTE DO GRUPO A - RIO DE J…, R$ 16,0 mi) consta 'Ativo' no SIGA com fim em 27/08/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2025002915 (BONUS TRACK ENTRETENIMENTO LTDA, R$ 15,0 mi) consta 'Ativo' no SIGA com fim em 02/07/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
