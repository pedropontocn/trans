# Dossiê de transição — Secretaria de Estado de Desenvolvimento Econômico, Indústria, Comércio e Serviços (SEDEICS)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/sedeics)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 908 | R$ 459.425.997,61 |
| Com vigência futura (válidos no SIGA) | 72 | R$ 108.732.493,96 |
| até 30 dias | 2 | R$ 250.102,31 |
| até 60 dias | 6 | R$ 2.098.272,89 |
| até 90 dias | 10 | R$ 14.780.006,71 |
| até 180 dias | 15 | R$ 25.689.817,99 |
| vencido no SIGA | 836 | R$ 350.693.503,65 |
| sem data | 5 | R$ 31.981.609,74 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 1 | R$ 1.879.823,94 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 144,9 mi / R$ 86,8 mi / R$ 80,4 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Mais 2 contratos menores (R$ 0,3 mi) vencem em até 30 dias — ver seção 3.
- 25 contratos (R$ 41,8 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 130 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 85,6 mi); 2 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 706 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 265,1 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- 3 contrato(s) 'Ativo' com data de fim inválida no SIGA (R$ 24,3 mi), ex.: 2018005065 (01/11/2123); 2021003139 (30/01/2124); 2021003140 (12/07/2071). Corrigir o cadastro e informar a vigência real.
- 1 contrato(s) com fim no PNCP anterior ao do SIGA, sem rescisão: 2024008397 (DIVERGÊNCIA: PNCP indica fim 03/11/2025, SIGA indica 22/01/2026; TERMO CLASSIFICADO COMO …). Confirmar no processo SEI.
- 1 contratações emergenciais vigentes (R$ 1,9 mi). Verificar prazo máximo legal (1 ano, Lei 14.133 art. 75 VIII) e licitação substitutiva.

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025009527 | JUCERJA | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Pagamento de anuidade, referente ao domínio ativo da JUCERJA jucerja… | R$ 102,31 | 17/11/2026 | 11 |
| 2025009787 | SEDEICS | DJ PRODUCOES E EVENTOS LTDA | Trata-se de contrato de patrocínio que tem como objeto o apoiofinance… | R$ 250.000,00 | 26/11/2026 | 20 |
| 2025010332 | SEDEICS | ESFERA BRASIL LTDA | O presente Termo de Referência tem por objeto a contratação de cota d… | R$ 2.000.000,00 | 08/12/2026 (PNCP) | 32 |
| 2026007446 | JUCERJA | INOVE TREINAMENTOS E CAPACITACAO LTDA | Inscrição de 04 (quatro) servidores da JUCERJA no curso A Nova Plani… | R$ 15.444,00 | 09/12/2026 | 33 |
| 2026007611 | JUCERJA | B E B COMERCIO DE MATERIAL ELETRICO E DE CON… | Aquisição de materiais elétricos, bem como a entrega do material, ass… | R$ 3.894,00 | 16/12/2026 | 40 |
| 2026007612 | JUCERJA | 63.806.444 FERNANDA GONCALVES | Aquisição de materiais elétricos, bem como a entrega do material, ass… | R$ 2.550,00 | 16/12/2026 | 40 |
| 2025010687 | JUCERJA | SOMPO SEGUROS S/A | Contratação de seguro predial e patrimonial, contra fogo/incêndio, ra… | R$ 20.000,00 | 18/12/2026 | 42 |
| 2023002231 | CODIN | BRS SUPRIMENTOS CORPORATIVOS S/A | CONTRATAÇÃO DA PRESTAÇÃO DE SERVIÇOS CONTÍNUOS DE OUTSOURCING PARA OP… | R$ 56.384,89 | 31/12/2026 | 55 |
| 2025010697 | SEDEICS | LECARD ADMNISTRADORA DE CARTÕES LTDA | A presente contratação tem por objetivo a contratação de empresa espe… | R$ 86.450,00 | 06/01/2027 | 61 |
| 2026000338 | JUCERJA | WEBJUR PROCESSAMENTO DE DADOS LTDA EPP | Contratação de prestação de serviço especializado de acompanhamento d… | R$ 1.200,00 | 26/01/2027 | 81 |
| 2025010983 | JUCERJA | R8 SOLUÇÕES EIRELI | PRESTAÇÃO DE SERVIÇOS DE LIMPEZA, CONFORME TERMO DE REFERÊNCIA. | R$ 2.000.000,23 | 27/01/2027 (PNCP) | 82 |
| 2025010994 | JUCERJA | NORTESUL TRANSPORTES E SERVICOS LTDA | PRESTAÇÃO DE SERVIÇO DE COPEIRAGEM, CONFORME TERMO DE REFERÊNCIA. | R$ 590.000,00 | 27/01/2027 (PNCP) | 82 |
| 2024000344 | JUCERJA | BRS SUPRIMENTOS CORPORATIVOS S/A | Adesão à Ata de Registro de Preços nº 002/2023, referente a contrataç… | R$ 498.231,62 | 28/01/2027 | 83 |
| 2026000440 | SEDEICS | MULTIPLAR ENGENHARIA E LOCACOES LTDA | Contratação, por meio de patrocínio, da Cota Master do evento ``Rio q… | R$ 1.000.000,00 | 29/01/2027 (PNCP) | 84 |
| 2026008881 | SEDEICS | LIGHT SERVICOS DE ELETRICIDADE SA | Despesas com fornecimento de energia elétrica  Light  antiga sede d… | R$ 28.313,92 | 29/01/2027 | 84 |
| 2026000438 | SEDEICS | OPEN BRASIL PROMOÇÔES E EVENTOS LTDA | O presente Termo de Referência tem por objeto a contratação de cota d… | R$ 8.616.000,00 | 02/02/2027 (PNCP) | 88 |
| 2026009275 | JUCERJA | VEENT EMPREENDIMENTOS EMPRESARIAIS LTDA | Contratação emergencial de empresa especializada na prestação de serv… | R$ 1.879.823,94 | 03/02/2027 (PNCP) | 89 |
| 2025002260 | JUCERJA | FUNDAÇÃO GETULIO VARGAS | 1 (uma) inscrição do servidor Bruno Pimentel Moreira, Chefe da Área d… | R$ 79.987,00 | 04/02/2027 | 90 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000653 | JUCERJA | NP TECNOLOGIA E GESTAO DE DADOS LTDA | Aquisição de assinatura para acesso a serviço de consulta a Banco de … | R$ 12.750,00 | 09/02/2027 | 95 |
| 2026000820 | JUCERJA | EMPRESA BRASILEIRA DE CORREIOS E TELÉGRAFOS | Contratação de produtos e serviços por meio de Pacote de Serviços dos… | R$ 180.000,00 | 19/02/2027 | 105 |
| 2026008116 | SEDEICS | AGUAS DO RIO 4 SPE S.A | O objeto do processo consiste na prestação contínua dos serviços de f… | R$ 7.680,02 | 28/02/2027 | 114 |
| 2024000863 | JUCERJA | GRUPO IBMEC EDUCACIONAL LTDA | Inscrição de servidora em programa de mestrado oferecido pela institu… | R$ 63.988,00 | 13/03/2027 | 127 |
| 2025001680 | JUCERJA | GAPPO ELEVADORES, PROJETOS E CONSULTORIA TÉC… | Contratação de serviços técnicos especializados para identificação e … | R$ 35.500,00 | 17/03/2027 | 131 |
| 2023008946 | JUCERJA | INSTITUTO BRASILEIRO DE ADMINISTRAÇÃO MUNICI… | Contratação de organiação da sociedade civil sem fins lucrativos para… | R$ 24.371.779,57 | 31/03/2027 | 145 |
| 2026002468 | JUCERJA | JSRC GNV SEGURANÇA CONTRA INCÊNDIO LTDA | Prestação de serviço para recarga de extintores de incêndio, visando … | R$ 3.500,00 | 31/03/2027 | 145 |
| 2026002540 | JUCERJA | CONSORCIO LPM-7LAN | Contratação de empresa especializada, através de adesão à ATA nº 0004… | R$ 818.900,86 | 06/04/2027 (PNCP) | 151 |
| 2026002605 | JUCERJA | LACUNA SOFTWARE LTDA | Contratação de licenciamento perpétuo da Lacuna PKI Suite, Página de … | R$ 59.300,00 | 06/04/2027 | 151 |
| 2025002392 | JUCERJA | FUNDAÇÃO GETULIO VARGAS | 1 (uma) inscrição do servidor ocupante do cargo de Procurador Adjunto… | R$ 38.035,00 | 10/04/2027 | 155 |
| 2026002791 | JUCERJA | GOSHME SOLUÇÕES PARA A INTERNET LTDA | Contratação da assinatura da plataforma online Jusbrasil, com o objet… | R$ 7.917,30 | 10/04/2027 | 155 |
| 2025002569 | JUCERJA | AOVS SISTEMA DE INFORMATICA S.A | Contratação de 7 (Sete) licenças na plataforma de ensino ALURA. | R$ 19.950,00 | 15/04/2027 | 160 |
| 2026002815 | JUCERJA | FEDERAÇÃO NACIONAL DE JUNTAS COMERCIAIS FENA… | Pagamento de anuidade de 2026 - Federação Nacional de Juntas Comercia… | R$ 12.887,68 | 16/04/2027 | 161 |
| 2026003018 | JUCERJA | ZENITE INFORMAÇÃO E CONSULTORIA S.A. | Contratação dos serviços (i) de Orientação por Escrito em Licitação … | R$ 18.142,00 | 16/04/2027 | 161 |
| 2025005061 | SEDEICS | GPBR PARTICIPACOES LTDA | Prestação de serviços de acesso à plataforma WELLHUB, através de web … | R$ 39.487,56 | 17/04/2027 | 162 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024008414 | SEDEICS | INSTITUTO GLOBAL DE DESENVOLVIMENTO E SUSTEN… | A presente contratação visa a prestação de serviços de capacitação pa… | R$ 11.999.998,50 | 14/01/2026 (PNCP) | -296 |
| 2025006669 | JUCERJA | JM MAIS CENOGRAFIA E EVENTOS LTDA | Contratação de serviços técnicos especializados para execução da etap… | R$ 10.256.164,24 | 27/03/2026 (PNCP) | -224 |
| 2024008915 | JUCERJA | VIGILIA BRASIL SERVIÇOS LTDA | Contratação de empresa prestadora de serviços continuados de apoio té… | R$ 5.982.996,12 | 17/03/2026 (PNCP) | -234 |
| 2024008397 | SEDEICS | IBAP - INSTITUTO BRASILEIRO DE ADMINISTRAÇÃO… | O presente Termo de Referência tem por objeto a contratação de empres… | R$ 5.638.660,00 | 22/01/2026 (SIGA, diverge do PNCP) | -288 |
| 2025000295 | JUCERJA | CONSTRUTORA RJL 2 LTDA | Contratação de serviços comuns de engenharia para elaboração e desenv… | R$ 4.599.000,00 | 17/03/2026 (PNCP) | -234 |
| 2025008689 | JUCERJA | PROSOLUTION CONSULTORIA E SISTEMAS INFORMATI… | Prestação de serviços operacionais contemplando manutenção corretiva … | R$ 4.395.383,64 | 29/10/2026 (PNCP) | -8 |
| 2025007138 | SEDEICS | BRASITUR EVENTOS E TURISMO LTDA | Contratação de empresa especializada na prestação de serviços de apoi… | R$ 4.111.167,48 | 11/09/2026 (PNCP) | -56 |
| 2025005761 | SEDEICS | EDITORA A NOTICIA LTDA | Trata-se de contrato de patrocínio que tem como objeto o apoio financ… | R$ 4.004.733,20 | 31/07/2026 (PNCP) | -98 |
| 2022002819 | CODIN | GRUPO HOSPITALAR DO RIO DE JANEIRO LTDA (MAT… | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DOS SERVIÇOS DE PLA… | R$ 3.863.755,08 | 01/06/2025 | -523 |
| 2024007401 | SEDEICS | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | O presente certame tem por objetivo a contratação de agente de integr… | R$ 2.875.152,00 | 22/10/2026 (PNCP) | -15 |
| 2023004841 | JUCERJA | TELSINC COMERCIO DE EQUIPAMENTOS DE INFORMAT… | O objeto do presente pregão é a contratação de empresa especialiada n… | R$ 2.690.000,00 | 26/06/2026 | -133 |
| 2021002100 | CODIN | PLUXEE BENEFICIOS BRASIL S.A. | Contratação de empresa especializada na administração, gerenciamento,… | R$ 2.607.176,00 | 01/05/2025 | -554 |
| 2024006154 | JUCERJA | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Contratação de empresa para o fornecimento de solução tecnológica dea… | R$ 2.304.730,00 | 29/07/2025 | -465 |
| 2024008595 | JUCERJA | SISTEMATECH INFORMÁTICA EIRELI | Contratação de prestação de serviços de suporte operacional (UST) e t… | R$ 2.078.393,96 | 17/10/2025 | -385 |
| 2025006127 | SEDEICS | MMAR MONTAGENS EVENTOS E PROGRAMACAO VISUAL … | Trata-se de contrato de patrocínio que tem como objeto o apoio financ… | R$ 2.000.000,00 | 10/12/2025 (PNCP) | -331 |
| 2025003178 | SEDEICS | ESFERA BRASIL LTDA | Contrato de patrocínio que tem como objeto o apoio financeiro do Gove… | R$ 1.800.000,00 | 15/08/2026 (PNCP) | -83 |
| 2024008452 | JUCERJA | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | Contratação de empresa especializada na prestação do serviço de locaç… | R$ 1.776.568,08 | 14/10/2026 (PNCP) | -23 |
| 2024004154 | JUCERJA | PROSOLUTION CONSULTORIA E SISTEMAS INFORMATI… | Contratação direta para prestação dos serviços de manutenção, evoluçã… | R$ 1.434.600,00 | 27/05/2026 (PNCP) | -163 |
| 2023007589 | JUCERJA | WP SISTEMAS REPROGRAFICOS E IMPRESSAO LTDA E… | Contratação de empresa especialiada no fornecimento de serviço de out… | R$ 1.204.984,56 | 11/12/2025 | -330 |
| 2024004670 | JUCERJA | CONSTRUTORA RJL 2 LTDA | Contratação de empresa especializada na prestação de serviço de manut… | R$ 1.130.000,00 | 25/06/2025 (PNCP) | -499 |
| 2019003421 | CODIN | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | CONTRATAÇÃO DOS SERVIÇOS DE PIBLICAÇÃO DOS EXPEDIENTES DA CODIN NO DI… | R$ 1.080.000,00 | 11/11/2024 | -725 |
| 2025007069 | SEDEICS | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Contratação de empresa especializada na prestação de serviços de admi… | R$ 913.680,00 | 10/09/2026 (PNCP) | -57 |
| 2023000223 | JUCERJA | NTSEC SOLUÇÕES EM TELEINFORMÁTICA LTDA | Subscrição de licenças de software para solução Antivírus incluindo c… | R$ 670.014,72 | 12/01/2026 | -298 |
| 2024008432 | JUCERJA | BELFIRE SEGURANÇA CONTRA INCENDIO LTDA | Contratação de prestação de serviços de adequação de imóvel para inst… | R$ 649.900,00 | 13/10/2025 (PNCP) | -389 |
| 2023006560 | JUCERJA | CONSTRUTORA RJL 2 LTDA | Contratação de empresa especialiada naprestação de serviços de manute… | R$ 620.000,00 | 30/11/2024 | -706 |
| 2024004469 | JUCERJA | BRASVIP SEGURANCA PRIVADA LTDA | CONTRATAÇÃO DE PRESTAÇÃO DE SERVIÇO DE VIGILÂNCIA PATRIMONIAL ARMADA … | R$ 545.000,00 | 20/09/2025 (PNCP) | -412 |
| 2024003750 | JUCERJA | FUNDACAO PARA A INFANCIA E ADOLESCENCIA FIA/… | ACORDO DE COOPERAÇÃO ENTRE A JUCERJA E A FIA. | R$ 358.432,00 | 15/05/2026 | -175 |
| 2023009851 | JUCERJA | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | Prestação de serviços contínuos de gestão do abastecimento e fornecim… | R$ 287.820,00 | 26/05/2025 | -529 |
| 2024002598 | JUCERJA | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Contratação de empresa especializada na prestação de serviços de agen… | R$ 240.000,00 | 05/04/2025 | -580 |
| 2024002539 | CODIN | FEDERACAO DAS EMPRESAS DE TRANSPORTE DE PASS… | PAGAMENTOS MENSAIS DE FORNECIMENTO VALE TRANSPORTE DE CARTÃO MAGNÉTIC… | R$ 231.905,54 | 29/04/2025 | -556 |

_Registros mais antigos (provável falta de baixa no SIGA): 706, R$ 265,1 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2023008946 | JUCERJA | INSTITUTO BRASILEIRO DE ADMINISTRAÇÃO MUNICI… | Contratação de organiação da sociedade civil sem fins lucrativos para… | R$ 24.371.779,57 | 31/03/2027 | 145 |
| 2021003139 | CODIN | JABERPLAN CONSTRUTORA LTDA | LOCAÇÃO DE IMÓVEL SITUADO NO MUNICÍPIO DE CAMPOS DOS GOYTACAZES, PARA… | R$ 19.790.673,30 | — |  |
| 2026000438 | SEDEICS | OPEN BRASIL PROMOÇÔES E EVENTOS LTDA | O presente Termo de Referência tem por objeto a contratação de cota d… | R$ 8.616.000,00 | 02/02/2027 (PNCP) | 88 |
| 2014010961 | CODIN | RB 110 PARTICIPAÇÃO S/A | PAGAMENTO DO ALUGUEL DO IMÓVEL ONDE LOCALIZA-SE A SEDE DESTA CODIN | R$ 7.772.549,12 | 14/04/2042 | 5638 |
| 2026000090 | JUCERJA | INSTITUTO BRASILEIRO DE ADMINISTRAÇÃO MUNICI… | Contratação de Organização da Sociedade Civil, sem fins lucrativos, p… | R$ 7.643.646,00 | — |  |
| 2024000582 | JUCERJA | LIGHT SERVICOS DE ELETRICIDADE SA | FORNECIMENTO DE ENERGIA ELÉTRICA. | R$ 4.500.000,00 | 19/02/2029 | 836 |
| 2021003140 | CODIN | ALZIRA GAIA DA SILVA | LOCAÇÃO DE IMÓVEL SITUADO NO MUNICÍPIO DE SÃO JOÃO DA BARRA, PARA INS… | R$ 4.398.000,00 | — |  |
| 2026008389 | SEDEICS | PLUXEE BENEFICIOS BRASIL S.A. | Contratação de EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇOS DE ADMI… | R$ 3.510.000,00 | 07/10/2027 | 335 |
| 2026004980 | JUCERJA | LIBEX SERVIÇOS E LOCAÇÕES DE VEÍCULOS LTDA E… | Contratação de Apoio Técnico e Operacional - Serviço de Condutores, a… | R$ 3.140.000,00 | 01/01/2029 | 787 |
| 2024004406 | JUCERJA | CERTVS SOLUÇÕES INTEGRADAS LTDA | Contratação de empresa especializada na prestação de serviços continu… | R$ 2.699.985,00 | 14/06/2029 | 951 |
| 2025010983 | JUCERJA | R8 SOLUÇÕES EIRELI | PRESTAÇÃO DE SERVIÇOS DE LIMPEZA, CONFORME TERMO DE REFERÊNCIA. | R$ 2.000.000,23 | 27/01/2027 (PNCP) | 82 |
| 2025010332 | SEDEICS | ESFERA BRASIL LTDA | O presente Termo de Referência tem por objeto a contratação de cota d… | R$ 2.000.000,00 | 08/12/2026 (PNCP) | 32 |
| 2026004541 | JUCERJA | ATAC FIRE EXTINTORES COMERCIO E SERVIÇOS LTDA | Prestação de serviços de prevenção e combate à incêndio, evacuação de… | R$ 1.999.999,93 | 10/06/2027 | 216 |
| 2026009275 | JUCERJA | VEENT EMPREENDIMENTOS EMPRESARIAIS LTDA | Contratação emergencial de empresa especializada na prestação de serv… | R$ 1.879.823,94 | 03/02/2027 (PNCP) | 89 |
| 2024004390 | JUCERJA | EFATA COMERCIO & SERVIÇOS EIRELI | Contratação de empresa especializada para prestação de serviços de lo… | R$ 1.422.120,00 | 12/06/2029 | 949 |
| 2025003081 | SEDEICS | CS BRASIL FROTAS S.A. | Contratação de serviços de locação de veículos, para atender a estrut… | R$ 1.066.627,62 | 09/05/2028 | 550 |
| 2024008993 | JUCERJA | NEREIDA IT SERVICES EIRELI | Aquisição de ativos de rede para composição de solução de conectivida… | R$ 1.048.997,29 | 07/11/2029 | 1097 |
| 2026000440 | SEDEICS | MULTIPLAR ENGENHARIA E LOCACOES LTDA | Contratação, por meio de patrocínio, da Cota Master do evento ``Rio q… | R$ 1.000.000,00 | 29/01/2027 (PNCP) | 84 |
| 2024000586 | JUCERJA | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Despesa pela prestação de serviços de publicação de matérias no Diári… | R$ 950.000,00 | 19/02/2029 | 836 |
| 2024009186 | JUCERJA | 2R DATATEL TELEINFORMÁTICA LTDA | Renovação do licenciamento para subscrições e suporte do Next Generat… | R$ 942.280,00 | 12/11/2027 | 371 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026009275 | JUCERJA | VEENT EMPREENDIMENTOS EMPRESARIAIS LTDA | Contratação emergencial de empresa especializada na prestação de serv… | R$ 1.879.823,94 | 03/02/2027 (PNCP) | 89 |

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| INSTITUTO BRASILEIRO DE ADMINISTRAÇÃO MUNICIPAL | 2 | R$ 32.015.425,57 |
| JABERPLAN CONSTRUTORA LTDA | 1 | R$ 19.790.673,30 |
| OPEN BRASIL PROMOÇÔES E EVENTOS LTDA | 1 | R$ 8.616.000,00 |
| RB 110 PARTICIPAÇÃO S/A | 1 | R$ 7.772.549,12 |
| LIGHT SERVICOS DE ELETRICIDADE SA | 2 | R$ 4.528.313,92 |
| ALZIRA GAIA DA SILVA | 1 | R$ 4.398.000,00 |
| PLUXEE BENEFICIOS BRASIL S.A. | 1 | R$ 3.510.000,00 |
| LIBEX SERVIÇOS E LOCAÇÕES DE VEÍCULOS LTDA EPP(MATRIZ) | 1 | R$ 3.140.000,00 |
| CERTVS SOLUÇÕES INTEGRADAS LTDA | 1 | R$ 2.699.985,00 |
| R8 SOLUÇÕES EIRELI | 1 | R$ 2.000.000,23 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2020003653 | UNIVERSIDADE FEDERAL DO RIO DE JANEIRO | R$ 6.074.290,00 | R$ 2.794.390,00 | R$ 3.279.900,00 |
| 2017004977 | RIOFORTE VIGILANCIA E SEGURANÇA PRIVADA LTDA | R$ 7.304.550,69 | R$ 6.103.723,40 | R$ 1.200.827,29 |
| 2016005667 | 2R DATATEL TELEINFORMÁTICA LTDA | R$ 669.820,00 | R$ 21.230,00 | R$ 648.590,00 |
| 2021005598 | FOCO ASN 2010 SERVIÇOS GERAIS LTDA | R$ 1.623.289,07 | R$ 1.213.350,52 | R$ 409.938,55 |
| 2018002880 | VEENT EMPREENDIMENTOS EMPRESARIAIS LTDA | R$ 3.177.935,90 | R$ 2.832.375,78 | R$ 345.560,12 |
| 2018005961 | PROSOLUTION CONSULTORIA E SISTEMAS INFORMATI… | R$ 3.451.171,41 | R$ 3.142.700,61 | R$ 308.470,80 |
| 2020000042 | VEENT EMPREENDIMENTOS EMPRESARIAIS LTDA | R$ 3.139.836,55 | R$ 2.908.091,53 | R$ 231.745,02 |
| 2018001884 | PROJAM CONSTRUÇÕES E PROJETOS LTDA. | R$ 1.179.721,23 | R$ 977.704,89 | R$ 202.016,34 |
| 2019002526 | PROSOLUTION CONSULTORIA E SISTEMAS INFORMATI… | R$ 1.325.025,00 | R$ 1.197.487,50 | R$ 127.537,50 |
| 2018006282 | CETEST MINAS ENGENHARIA E SERVIÇO S/A | R$ 277.873,22 | R$ 180.987,55 | R$ 96.885,67 |
| 2016006322 | LIGHT SERVICOS DE ELETRICIDADE SA | R$ 59.082,01 | R$ 0,00 | R$ 59.082,01 |
| 2020000063 | CETEST RIO LTDA. | R$ 913.832,64 | R$ 862.441,74 | R$ 51.390,90 |
| 2020005722 | SISTEMATECH INFORMÁTICA EIRELI | R$ 3.266.978,76 | R$ 3.226.462,54 | R$ 40.516,22 |
| 2019002333 | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | R$ 503.270,81 | R$ 470.944,06 | R$ 32.326,75 |
| 2016001373 | NEWSCON TELEINFORMATICA LTDA - EPP | R$ 1.418.381,00 | R$ 1.390.613,75 | R$ 27.767,25 |
| 2020000217 | R MORAES AGÊNCIA DE TURISMO EIRELI | R$ 178.777,43 | R$ 157.302,45 | R$ 21.474,98 |
| 2022009714 | BRASIL FORTE VIGILÂNCIA E SEGURANÇA LTDA EPP | R$ 166.116,66 | R$ 146.182,66 | R$ 19.934,00 |
| 2018004459 | CHADA COMERCIO E SERVIÇOS LTDA | R$ 52.290,01 | R$ 33.420,01 | R$ 18.870,00 |
| 2019004564 | PROVAC TERCEIRIZAÇÃO DE MÃO DE OBRA LTDA. | R$ 66.258,53 | R$ 56.222,50 | R$ 10.036,03 |
| 2020005618 | 2R DATATEL TELEINFORMÁTICA LTDA | R$ 791.853,30 | R$ 783.547,80 | R$ 8.305,50 |

## 11. Unidades incluídas neste dossiê
- CODIN - COMP DE DESENV INDUSTRIAL DO ESTADO DO RJ
- FEMPO-FUNDO EST FOMENTO MICROC  PROD EMPREEDEDOR - FUNDO UPP EMPREENDEDOR
- JUCERJA - JUNTA COMERCIAL DO ESTADO DO RIO DE JANEIRO
- SEDEERI - Sec de Est de Dse Econ Emp e Rel Int
- SEDEICS - SEC DE EST DE DESENV ECONÔM INDU COMERC E SERV

## 12. Conjuntos de dados abertos da secretaria
- Nenhum conjunto encontrado no portal.

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 5 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

O Decreto nº 50.447, de 26 de agosto de 2026, renomeou a SEDEICSCTI como Secretaria de Estado de Desenvolvimento Econômico (SEDES) e consolidou sua estrutura, declarando que a reorganização não aumenta despesas. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf)

A pasta reúne competências antes distribuídas entre Desenvolvimento Econômico, Energia e Economia do Mar e Ciência, Tecnologia e Inovação, após incorporações formalizadas em atos de 2026. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf) [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/) [G1: extinção da Secretaria de Energia e Economia do Mar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml)

As fontes fornecidas não trazem inventário de contratos, valores orçamentários, interrupções de serviços, dívidas ou achados de controle relativos à pasta. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf) [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/) [G1: exonerações no Diário Oficial](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/27/exoneracoes-publicadas-diario-oficial-do-rj.ghtml)

A prioridade para a transição é confirmar a implementação da nova estrutura, a publicação do regimento interno, a situação atual do pessoal e a continuidade das atividades e dos recursos das unidades incorporadas. O decreto prevê a transferência de bens, acervo e servidores e determina a edição futura do regimento, mas não informa se essas medidas foram efetivadas. A matéria relata a exoneração dos ocupantes de cargos comissionados da extinta Secti e um pedido para manter os recursos orçamentários, sem esclarecer os desdobramentos. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf) [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/)

##### Alertas vermelhos

- **Indício de risco de coordenação, não comprovação de falha:** a incorporação reuniu áreas com competências e objetivos distintos; a deputada Dani Balbi criticou a concentração e pediu diálogo com a comunidade científica, preservação de recursos dos entes vinculados à antiga Secti e medidas para reduzir os efeitos de exonerações em massa. São preocupações e pedidos relatados, não constatações de interrupção ou perda de recursos. [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/)
- **Verificar o regimento interno:** o Decreto nº 50.447 determinou que o secretário o editasse por resolução em até 30 dias; as fontes não informam se a resolução foi publicada. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf)
- **Verificar a transição de gestão:** uma matéria noticiou a nomeação de Roberto Gomides para a pasta após período em que Guilherme Mercês respondia pelo expediente; as fontes não confirmam a situação atual da gestão. [Correio da Manhã: unificação das secretarias](https://www.correiodamanha.com.br/colunistas/correio-bastidores/2026/08/309036-couto-unifica-secretarias-de-desenvolvimento-economico-e-ciencia-tecnologia-e-inovacao-do-rj.html) [G1: extinção da Secretaria de Energia e Economia do Mar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml)

##### Contratos e serviços críticos

Nada encontrado nas fontes consultadas sobre contratos, fornecedores, vencimentos, passivos contratuais, serviços críticos ou risco de interrupção de serviços da Secretaria. [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/) [G1: extinção da Secretaria de Energia e Economia do Mar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [G1: exonerações no Diário Oficial](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/27/exoneracoes-publicadas-diario-oficial-do-rj.ghtml)

O decreto afirma que a reorganização ocorreu sem aumento de despesa, mas não apresenta valores, dotações, estimativas financeiras ou detalhamento de contratos. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

Nada encontrado nas fontes consultadas sobre decisões ou processos do TCE-RJ, ações do MPRJ, ações judiciais, determinações de controle ou irregularidades atribuídas à Secretaria. [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/) [G1: extinção da Secretaria de Energia e Economia do Mar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [G1: exonerações no Diário Oficial](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/27/exoneracoes-publicadas-diario-oficial-do-rj.ghtml)

O Decreto nº 50.447 cita os Decretos nº 50.391, de 21 de julho de 2026, e nº 50.413, de 5 de agosto de 2026, como atos anteriores de reorganização; as fontes não relatam contestações judiciais ou decisões de controle sobre esses atos. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf)

##### Riscos de apagão administrativo

- **Risco a verificar, não apagão confirmado:** a estrutura foi alterada por criação e extinção de unidades, mudanças de nomenclatura e subordinação. O decreto prevê critérios gerais para a transferência de servidores, mas não detalha a distribuição de equipes, processos ou sistemas em cada unidade. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf)
- **Dependência de regulamentação interna:** o decreto previu a edição do regimento interno em até 30 dias, mas não há informação nas fontes sobre seu cumprimento. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf)
- **Pessoal e continuidade:** uma reportagem relata pedido parlamentar de medidas para reduzir efeitos de exonerações em massa após a extinção da Secti; as fontes não quantificam exonerações nem demonstram impacto sobre serviços ou programas. [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/)
- **Competências concentradas:** a secretaria passou a reunir, entre outras, áreas de desenvolvimento econômico, energia e economia do mar, ciência, tecnologia e inovação; uma deputada classificou o arranjo como uma super secretaria, avaliação política que não comprova por si só incapacidade administrativa. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf) [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/)

##### Fatos recentes

- Em 21 de julho de 2026, o Decreto nº 50.391 formalizou a incorporação da Secretaria de Estado de Energia e Economia do Mar à área de Desenvolvimento Econômico; o ato foi retificado no Diário Oficial de 3 de agosto de 2026, segundo o Decreto nº 50.447. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf)
- O Decreto nº 50.413, de 5 de agosto de 2026, é citado como ato de reestruturação da área de Ciência, Tecnologia e Inovação e de Desenvolvimento Econômico; reportagem relatou pedido da deputada Dani Balbi para sua revogação e para diálogo com a comunidade científica. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf) [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/)
- O Decreto nº 50.447, de 26 de agosto de 2026, passou a denominar a pasta Secretaria de Estado de Desenvolvimento Econômico (SEDES), consolidou sua estrutura sem aumento de despesa e determinou a elaboração de regimento interno em até 30 dias. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf)
- Reportagem publicada em agosto informou que Roberto Gomides foi nomeado secretário e que Guilherme Mercês havia respondido pelo expediente nos dias anteriores; as fontes fornecidas não permitem confirmar a permanência ou alterações posteriores na titularidade. [Correio da Manhã: unificação das secretarias](https://www.correiodamanha.com.br/colunistas/correio-bastidores/2026/08/309036-couto-unifica-secretarias-de-desenvolvimento-economico-e-ciencia-tecnologia-e-inovacao-do-rj.html)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)

- Solicitar o organograma vigente e os atos de implementação da estrutura; confirmar a relação das unidades criadas e extintas e suas subordinações, conforme os anexos do decreto; e pedir o regimento interno e a comprovação de publicação da resolução prevista no prazo de 30 dias. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf)
- Solicitar relação de contratos, convênios, fornecedores, vigências, obrigações pendentes e serviços cuja continuidade dependa de providências nos primeiros 90 dias; nada disso é detalhado nas fontes consultadas. [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/) [G1: exonerações no Diário Oficial](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/27/exoneracoes-publicadas-diario-oficial-do-rj.ghtml)
- Solicitar orçamento, execução financeira, passivos, dotações e recursos destinados às áreas e aos entes vinculados incorporados; o decreto declara ausência de aumento de despesa, mas não apresenta valores, e a matéria sobre a Secti relata pedido de manutenção de recursos sem informar montantes. [Decreto nº 50.447/2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf) [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/)
- Solicitar posição atual de cargos de direção, lotação e movimentação de pessoal, exonerações, vacâncias e funções acumuladas, bem como medidas de continuidade das atividades; as fontes relatam transição de gestão e um pedido político relacionado a exonerações, mas não oferecem quadro atualizado. [Correio da Manhã: unificação das secretarias](https://www.correiodamanha.com.br/colunistas/correio-bastidores/2026/08/309036-couto-unifica-secretarias-de-desenvolvimento-economico-e-ciencia-tecnologia-e-inovacao-do-rj.html) [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/)
- Solicitar inventário de processos administrativos, judiciais e de controle relacionados às secretarias, incluindo demandas do TCE-RJ e do MPRJ. As fontes não apresentam esse inventário nem detalham procedimentos relativos às pastas; mencionam operações do MPRJ envolvendo o Instituto Rio Metrópole e Rafael Nobre, sem relacioná-las às secretarias. [Diário do Rio: pedido de revogação do decreto](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/) [G1: extinção da Secretaria de Energia e Economia do Mar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [G1: exonerações no Diário Oficial](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/27/exoneracoes-publicadas-diario-oficial-do-rj.ghtml)

##### Fontes consultadas
1. [��Á���](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/Decreto-Estadual-no-50.447-de-26.08.2026-SEDES.pdf) — 2026-08-29
2. [Deputada cobra revogação de decreto que extinguiu a ...](https://diariodorio.com/deputada-cobra-revogacao-de-decreto-que-extinguiu-a-secretaria-de-ciencia-e-tecnologia/) — 2026-08-06
3. [Couto extingue Secretaria de Energia e Economia do Mar   G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) — 2026-07-22
4. [Exonerações no Diário Oficial do RJ: Depósito Público e ... - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/27/exoneracoes-publicadas-diario-oficial-do-rj.ghtml) — 2026-07-27
5. [Couto unifica secretarias de Desenvolvimento Econômico e Ciência, Tecnologia e Inovação do RJ](https://www.correiodamanha.com.br/colunistas/correio-bastidores/2026/08/309036-couto-unifica-secretarias-de-desenvolvimento-economico-e-ciencia-tecnologia-e-inovacao-do-rj.html) — 2026-08-07


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2025009527 (PRODERJ - CENTRO DE TECNOLOGIA DE INFOR…) vence em 17/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2025009787 (DJ PRODUCOES E EVENTOS LTDA) vence em 26/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025010332 (ESFERA BRASIL LTDA) vence em 08/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2026007446 (INOVE TREINAMENTOS E CAPACITACAO LTDA) vence em 09/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2026007611 (B E B COMERCIO DE MATERIAL ELETRICO E D…) vence em 16/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2024008414 (INSTITUTO GLOBAL DE DESENVOLVIMENTO E S…, R$ 12,0 mi) consta 'Ativo' no SIGA com fim em 14/01/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2025006669 (JM MAIS CENOGRAFIA E EVENTOS LTDA, R$ 10,3 mi) consta 'Ativo' no SIGA com fim em 27/03/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2024008915 (VIGILIA BRASIL SERVIÇOS LTDA, R$ 6,0 mi) consta 'Ativo' no SIGA com fim em 17/03/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2024008397 (IBAP - INSTITUTO BRASILEIRO DE ADMINIST…, R$ 5,6 mi) consta 'Ativo' no SIGA com fim em 22/01/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2025000295 (CONSTRUTORA RJL 2 LTDA, R$ 4,6 mi) consta 'Ativo' no SIGA com fim em 17/03/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
