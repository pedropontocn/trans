# Dossiê de transição — Secretaria de Estado de Habitação de Interesse Social (SEHIS)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/sehis)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 316 | R$ 1.863.592.274,88 |
| Com vigência futura (válidos no SIGA) | 74 | R$ 286.703.779,96 |
| até 30 dias | 3 | R$ 764.453,99 |
| até 60 dias | 5 | R$ 26.844.880,72 |
| até 90 dias | 6 | R$ 23.042.942,24 |
| até 180 dias | 29 | R$ 147.745.146,33 |
| vencido no SIGA | 242 | R$ 1.576.888.494,92 |
| sem data | 1 | R$ 2.136,00 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 1.075,8 mi / R$ 334,6 mi / R$ 289,9 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2025010245 (CONSTRUTORA AUGUSTO VELLOSO S.A.) vence em 08/12/2026 — 32 dias — R$ 10.018.085,44. Objeto: EXECUÇÃO DE SERVIÇOS DE URBANIZAÇÃO(EXECUÇÃO DE CONSTRUÇÃO/RECUPERAÇÃO DE CALÇA…
- Contrato 2025010118 (FABMIX CONCRETOS LTDA) vence em 23/12/2026 — 47 dias — R$ 12.000.000,00. Objeto: EXECUÇÃO DE SERVIÇOS DE URBANIZAÇÃO (EXECUÇÃO DE CONSTRUÇÃO/RECUPERAÇÃO DE CALÇ…
- Mais 3 contratos menores (R$ 0,8 mi) vencem em até 30 dias — ver seção 3.
- 33 contratos (R$ 139,4 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 65 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 228,9 mi); 7 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 177 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 1.347,9 mi): provável falta de baixa no SIGA (risco de controle, não de execução).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026002737 | ITERJ | PAVIMAQ PAVIMENTAÇÃO E COMÉRCIO LTDA | Conforme indicado no TR. | R$ 518.020,92 | 25/11/2026 (PNCP) | 19 |
| 2026004370 | SEHIS | FABMIX CONCRETOS LTDA | serviços de urbanização (execução de construção/recuperação de calçad… | R$ 210.073,07 | 03/12/2026 | 27 |
| 2025009875 | SEHIS | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | CONTRATAÇÃO PRODERJ - EMAIL | R$ 36.360,00 | 05/12/2026 | 29 |
| 2025010245 | SEHIS | CONSTRUTORA AUGUSTO VELLOSO S.A. | EXECUÇÃO DE SERVIÇOS DE URBANIZAÇÃO(EXECUÇÃO DE CONSTRUÇÃO/RECUPERAÇÃ… | R$ 10.018.085,44 | 08/12/2026 (PNCP) | 32 |
| 2025010253 | SEHIS | CONSTRUTORA AUGUSTO VELLOSO S.A. | EXECUÇÃO DE SERVIÇOS DE URBANIZAÇÃO(EXECUÇÃO DE CONSTRUÇÃO/RECUPERAÇÃ… | R$ 3.001.650,28 | 08/12/2026 (PNCP) | 32 |
| 2025010477 | SEHIS | INSTITUTO DE ESTUDOS POLÍTICOS E SOCIAIS PAR… | O objeto deste processo é a contratação da empresa selecionada na Ata… | R$ 1.668.495,00 | 12/12/2026 (PNCP) | 36 |
| 2025010118 | SEHIS | FABMIX CONCRETOS LTDA | EXECUÇÃO DE SERVIÇOS DE URBANIZAÇÃO (EXECUÇÃO DE CONSTRUÇÃO/RECUPERAÇ… | R$ 12.000.000,00 | 23/12/2026 (PNCP) | 47 |
| 2025010895 | SEHIS | LECARD ADMNISTRADORA DE CARTÕES LTDA | O objeto deste Termo de Referência compreende a emissão e entrega, de… | R$ 156.650,00 | 29/12/2026 | 53 |
| 2026001706 | SEHIS | SERPEN SERVIÇOS E PROJETOS DE ENGENHARIA LTDA | CONTRATAÇÃO, PELA SECRETARIA DE ESTADO DE HABITAÇÃO DE INTERESSE SOCI… | R$ 834.416,97 | 11/01/2027 (PNCP) | 66 |
| 2025008195 | ITERJ | LUKES ENGENHARIA LTDA | Conforme disposto no TR. | R$ 1.351.179,62 | 20/01/2027 (PNCP) | 75 |
| 2026000505 | SEHIS | DIMENSIONAL ENGENHARIA LTDA | ADESÃO LOTE 01 ATA SRP Processo nº SEI-510001/000267/2024 - SECID SEI… | R$ 6.668.085,06 | 30/01/2027 (PNCP) | 85 |
| 2026000512 | SEHIS | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | ADESÃO LOTE 09 ATA SRP Processo nº SEI-510001/000267/2024 - SECID SEI… | R$ 3.564.467,64 | 30/01/2027 (PNCP) | 85 |
| 2026000513 | SEHIS | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | ADESÃO LOTE 06 ATA SRP Processo nº SEI-510001/000267/2024 - SECID SEI… | R$ 3.564.467,64 | 30/01/2027 (PNCP) | 85 |
| 2026000506 | SEHIS | DIMENSIONAL ENGENHARIA LTDA | ADESÃO LOTE 02 ATA SRP Processo nº SEI-510001/000267/2024 - SECID SEI… | R$ 7.060.325,31 | 02/02/2027 (PNCP) | 88 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000507 | SEHIS | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | ADESÃO LOTE 08 ATA SRP Processo nº SEI-510001/000267/2024 - SECID SEI… | R$ 3.270.000,00 | 05/02/2027 (PNCP) | 91 |
| 2026000508 | SEHIS | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | ADESÃO LOTE 03 ATA SRP Processo nº SEI-510001/000267/2024 - SECID SEI… | R$ 3.400.000,00 | 05/02/2027 (PNCP) | 91 |
| 2026000510 | SEHIS | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | ADESÃO LOTE 04 ATA SRP Processo nº SEI-510001/000267/2024 - SECID SEI… | R$ 3.400.000,00 | 05/02/2027 (PNCP) | 91 |
| 2026000514 | SEHIS | DRAGMAQ ENGENHARIA LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DOSERVIÇO DE LOCAÇÃ… | R$ 3.599.999,80 | 05/02/2027 (PNCP) | 91 |
| 2026006627 | SEHIS | FABMIX CONCRETOS LTDA | serviços de urbanização (execução deconstrução/recuperação de calçada… | R$ 613.620,79 | 21/02/2027 (PNCP) | 107 |
| 2026000974 | SEHIS | SERPEN SERVIÇOS E PROJETOS DE ENGENHARIA LTDA | SEI-490001/000505/2025 VIDE PROCESSO PUBLICO | R$ 872.215,81 | 25/02/2027 (PNCP) | 111 |
| 2026001137 | SEHIS | FABMIX CONCRETOS LTDA | EXECUÇÃO DE SERVIÇOS DE URBANIZAÇÃO(EXECUÇÃO DE CONSTRUÇÃO/RECUPERAÇÃ… | R$ 1.358.137,59 | 26/02/2027 (PNCP) | 112 |
| 2026001307 | SEHIS | OMG EMPREENDIMENTOS | SERVICOS DE LOCACAO DE MAQUINAS /EQUIPAMENTOS CONSTRUCAO,DESCRICAO: C… | R$ 5.883.604,47 | 04/03/2027 (PNCP) | 118 |
| 2026001191 | SEHIS | PROJEL ENGENHARIA ESPECIALIZADA LTDA | O objeto deste Termo de Referência é a execução do Projeto de Trabalh… | R$ 1.296.644,79 | 06/03/2027 (PNCP) | 120 |
| 2026001654 | SEHIS | AÇO FORTE DE MERITI IND METALURGICA E LOG LT… | Fornecimento e montagem de equipamentos permanentes | R$ 3.915.305,31 | 11/03/2027 (PNCP) | 125 |
| 2026001657 | SEHIS | AÇO FORTE DE MERITI IND METALURGICA E LOG LT… | Fornecimento e montagem de equipamentos permanentes | R$ 735.494,98 | 11/03/2027 (PNCP) | 125 |
| 2026001658 | SEHIS | AÇO FORTE DE MERITI IND METALURGICA E LOG LT… | Fornecimento e montagem de equipamentos permanentes | R$ 5.240.800,72 | 11/03/2027 (PNCP) | 125 |
| 2026001659 | SEHIS | AÇO FORTE DE MERITI IND METALURGICA E LOG LT… | Fornecimento e montagem de equipamentos permanentes | R$ 626.997,39 | 11/03/2027 (PNCP) | 125 |
| 2026001660 | SEHIS | AÇO FORTE DE MERITI IND METALURGICA E LOG LT… | Fornecimento e montagem de equipamentos permanentes | R$ 3.166.054,24 | 11/03/2027 (PNCP) | 125 |
| 2026001594 | SEHIS | INSTITUTO DE ESTUDOS POLÍTICOS E SOCIAIS PAR… | O objeto deste processo é a contratação daempresa selecionada na Ata … | R$ 92.449,40 | 13/03/2027 | 127 |
| 2026001607 | SEHIS | INSTITUTO DE ESTUDOS POLÍTICOS E SOCIAIS PAR… | O objeto deste processo é a contratação daempresa selecionada na Ata … | R$ 32.629,20 | 13/03/2027 | 127 |
| 2026001681 | SEHIS | INSTITUTO DE ESTUDOS POLÍTICOS E SOCIAIS PAR… | O objeto deste processo é a contratação daempresa selecionada na Ata … | R$ 1.575.059,28 | 13/03/2027 (PNCP) | 127 |
| 2025010152 | SEHIS | ABRE CONSTRUÇÕES LTDA | O presente Termo de Referência tem por objetivo a CONTRATAÇÃO, PELA S… | R$ 49.211.636,93 | 30/03/2027 (PNCP) | 144 |
| 2026002272 | SEHIS | INSTITUTO DE ESTUDOS POLÍTICOS E SOCIAIS PAR… | O objeto deste processo é a contratação daempresa selecionada na Ata … | R$ 489.438,00 | 01/04/2027 | 146 |
| 2026002303 | SEHIS | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | CONTRATAÇÃO DE SERVIÇOS DE HOSPEDAGEM EM SERVIDORES VIRTUAIS PRIVADOS… | R$ 399.002,64 | 06/04/2027 | 151 |
| 2026002576 | SEHIS | AÇO FORTE DE MERITI IND METALURGICA E LOG LT… | Fornecimento e montagem, sob demanda, deequipamentos permanentes para… | R$ 2.322.362,44 | 07/04/2027 (PNCP) | 152 |
| 2026002578 | SEHIS | AÇO FORTE DE MERITI IND METALURGICA E LOG LT… | Fornecimento e montagem, sob demanda, de equipamentos permanentes par… | R$ 2.498.086,33 | 07/04/2027 (PNCP) | 152 |
| 2026002580 | SEHIS | AÇO FORTE DE MERITI IND METALURGICA E LOG LT… | Fornecimento e montagem, sob demanda, de equipamentos permanentes par… | R$ 2.164.618,59 | 07/04/2027 (PNCP) | 152 |
| 2026002581 | SEHIS | AÇO FORTE DE MERITI IND METALURGICA E LOG LT… | Fornecimento e montagem, sob demanda, de equipamentos permanentes par… | R$ 1.327.105,70 | 07/04/2027 (PNCP) | 152 |
| 2026002582 | SEHIS | AÇO FORTE DE MERITI IND METALURGICA E LOG LT… | Fornecimento e montagem, sob demanda, de equipamentos permanentes par… | R$ 872.696,55 | 07/04/2027 (PNCP) | 152 |
| 2026002785 | SEHIS | JETON CONSTRUÇÕES LTDA | CONTRATAÇÃO, PELA SECRETARIA DE ESTADO DE HABITAÇÃO DE INTERESSE SOCI… | R$ 3.203.000,46 | 09/04/2027 (PNCP) | 154 |
| 2025001912 | SEHIS | MARENGE ENGENHARIA CONSTRUCOES E SERVICOS LT… | O presente Projeto Básico tem por objetivo a CONTRATAÇÃO DE EMPRESA P… | R$ 26.518.617,91 | 10/04/2027 (PNCP) | 155 |
| 2026002913 | SEHIS | INSTITUTO DE ESTUDOS POLÍTICOS E SOCIAIS PAR… | Contratação de empresa especializada para a execução do TTS, em conju… | R$ 9.535.376,89 | 15/04/2027 (PNCP) | 160 |
| 2026002324 | SEHIS | CONSTRUTORA AUGUSTO VELLOSO S.A. | serviços de urbanização (execução de construção/recuperação de calçad… | R$ 10.124.190,12 | 29/04/2027 (PNCP) | 174 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2022000255 | CEHAB | DYNATEST ENGENHARIA LTDA | Contratação de serviços técnicos contínuos especializados na área de … | R$ 43.182.614,53 | 24/01/2025 | -651 |
| 2024010002 | SEHIS | TCE EMPREENDIMENTOS ESPORTIVOS LTDA | CONSUMO ATA SRP 002/2024 SEHIS | R$ 37.998.137,02 | 11/08/2026 (PNCP) | -87 |
| 2025003726 | SEHIS | CONSTRUTORA SUMARÉ LTDA | O objeto da presente licitação é a Elaboração de Projeto Executivo e … | R$ 31.181.117,07 | 31/10/2026 (PNCP) | -6 |
| 2024008230 | CEHAB | GHS EMPREENDIMENTOS IMOBILIÁRIOS LTDA-EPP | Obras de recuperação das edificações multifamiliares que compõem o Co… | R$ 16.981.577,55 | 08/09/2025 | -424 |
| 2024004758 | SEHIS | MARENGE ENGENHARIA CONSTRUCOES E SERVICOS LT… | Contratação, EM CARÁTER EMERGENCIAL, de empresa para execução dos ser… | R$ 13.623.351,27 | 05/03/2026 (PNCP) | -246 |
| 2024008240 | CEHAB | EMPRESA FLUMINENSE DE SERVIÇOS EIRELI-EPP | Obras de infraestrutura constituídas de redes de esgoto, drenagem plu… | R$ 11.834.713,54 | 04/03/2026 | -247 |
| 2024008052 | CEHAB | PROCEC ENGENHARIA S/A | Obras de construção de uma ponte sobre o rio das Pedras, conforme des… | R$ 10.769.971,01 | 01/10/2025 (PNCP) | -401 |
| 2024008217 | CEHAB | CONPLAN EMPREENDIMENTOS E SERVIÇOS LTDA-ME | Implantação de infraestrutura de urbanização com execução de obras de… | R$ 9.042.222,08 | 07/05/2025 | -548 |
| 2024007222 | SEHIS | NATBRAS CONSTRUÇÕES E REFORMAS LTDA | O presente Termo de Referência tem por objetivo a CONTRATAÇÃO, PELA S… | R$ 8.068.062,20 | 01/09/2025 (PNCP) | -431 |
| 2024008051 | SEHIS | INSTITUTO DE ESTUDOS POLÍTICOS E SOCIAIS PAR… | Contratar empresa especializada para executar o trabalho técnico soci… | R$ 7.166.830,80 | 01/10/2026 (PNCP) | -36 |
| 2025009213 | SEHIS | FABMIX CONCRETOS LTDA | Serviços de urbanização (execução de construção/recuperação de calçad… | R$ 5.743.451,70 | 11/05/2026 (PNCP) | -179 |
| 2025000507 | CEHAB | ABADE FRANCO CONSTRUÇÃO CIVIL EIRELI | Obras de recuperação das edificações multifamiliares que compõem o Co… | R$ 4.832.984,38 | 22/11/2025 | -349 |
| 2024004761 | SEHIS | VITAL MESTRES CONSTRUÇÃO E MANUTENÇÃO PREDIA… | Contratação, EM CARÁTER EMERGENCIAL, de empresa para execução dos ser… | R$ 4.335.182,17 | 21/04/2025 (PNCP) | -564 |
| 2025001426 | SEHIS | ARKCON CONSTRUTORA E INCORPORADORA LTDA | Contratação de empresa especializada para EXECUÇÃO DAS OBRAS DE CONTE… | R$ 3.599.810,89 | 17/09/2025 (PNCP) | -415 |
| 2024008666 | CEHAB | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Identificar e analisar os cenários para o atendimento da demanda quec… | R$ 2.627.706,00 | 15/10/2025 | -387 |
| 2025007642 | SEHIS | FABMIX CONCRETOS LTDA | Contratação de serviços de Urbanização Execução de Construção/Recuper… | R$ 2.000.000,00 | 01/10/2026 (PNCP) | -36 |
| 2024001541 | CEHAB | VJV CONSULTORIA E CONSTRUCOES LTDA | Obras de reforma com reforço de 03 (três) muros de contenção e respec… | R$ 1.928.794,61 | 30/11/2024 | -706 |
| 2025006029 | SEHIS | INSTITUTO DE ESTUDOS POLÍTICOS E SOCIAIS PAR… | O objeto deste processo é a contratação da empresa selecionada na Ata… | R$ 1.668.495,00 | 11/01/2026 (PNCP) | -299 |
| 2022004113 | CEHAB | NAOMI SERVICE TRANSPORTES LTDA-ME | Locação de uma frota de 08 (oito) veículos automotores com 08 (oito) … | R$ 1.395.994,00 | 15/02/2026 | -264 |
| 2025006228 | SEHIS | FABMIX CONCRETOS LTDA | Contratação de serviços de Urbanização Execução de Construção/Recuper… | R$ 1.000.000,00 | 28/08/2026 (PNCP) | -70 |
| 2025007357 | SEHIS | CONSTRUTORA AUGUSTO VELLOSO S.A. | Contratação de serviços de UrbanizaçãoExecução de Construção/Recupera… | R$ 1.000.000,00 | 26/09/2026 (PNCP) | -41 |
| 2024004963 | SEHIS | LOCADORA DE VEÍCULOS CAXANGÁ LTDA | O presente termo tem por objetivo estabelecer as condições para prest… | R$ 939.000,00 | 14/08/2026 (PNCP) | -84 |
| 2022003873 | CEHAB | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Adesão à Ata de Registro de Preços nº 002/2022 - Prestação de Serviço… | R$ 785.685,00 | 02/06/2025 | -522 |
| 2024004964 | SEHIS | VELOZ TRANSRIO TRANSPORTE LTDA | O presente termo tem por objetivo estabelecer as condições para prest… | R$ 774.000,00 | 11/08/2026 (PNCP) | -87 |
| 2022004266 | CEHAB | SIMPRESS COMÉRCIO LOCAÇÃO E SERVIÇOS S/A | Locação de equipamentos de informática (microcomputadores e Notebooks… | R$ 588.819,51 | 27/03/2025 | -589 |
| 2025007921 | ITERJ | SANTOS BARRETO SERVIÇOS E REPAROS LTDA EPP | Reforma do Galpão Maria Romana | R$ 580.097,00 | 11/04/2026 (PNCP) | -209 |
| 2024008073 | SEHIS | LOGICA TECNOLOGIA LTDA EPP | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇO DE OUTSO… | R$ 524.424,00 | 29/08/2026 (PNCP) | -69 |
| 2023004545 | CEHAB | NTI BRASIL SOLUÇÕES DIGITAIS LTDA | Locação de licenças do Software AutoCad 2023 para desenvolvimento de … | R$ 441.400,00 | 18/06/2025 | -506 |
| 2024008336 | CEHAB | FUNDAÇÃO SANTA CABRINI | A prestação dos serviços de limpeza, com o fornecimento de insumos, a… | R$ 351.006,72 | 28/03/2026 | -223 |
| 2022000695 | CEHAB | DADY ILHA SOLUCOES INTEGRADAS LTDA | Prestação de serviços de solução continuada de impressão, cópia e dig… | R$ 339.388,80 | 03/01/2025 | -672 |

_Registros mais antigos (provável falta de baixa no SIGA): 177, R$ 1.347,9 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025010152 | SEHIS | ABRE CONSTRUÇÕES LTDA | O presente Termo de Referência tem por objetivo a CONTRATAÇÃO, PELA S… | R$ 49.211.636,93 | 30/03/2027 (PNCP) | 144 |
| 2025001912 | SEHIS | MARENGE ENGENHARIA CONSTRUCOES E SERVICOS LT… | O presente Projeto Básico tem por objetivo a CONTRATAÇÃO DE EMPRESA P… | R$ 26.518.617,91 | 10/04/2027 (PNCP) | 155 |
| 2025010925 | SEHIS | PREST RIO CONSTRUÇÕES E SERVIÇOS LTDA | ELABORAÇÃO DE PROJETO EXECUTIVO E EXECUÇÃO DAS OBRAS DE CONTENÇÃO DE … | R$ 25.859.051,57 | 27/12/2027 | 416 |
| 2025010896 | SEHIS | HYDRA ENGENHARIA E SANEAMENTO LTDA | Execução das Obras de Retenção de fluxo de Detritos - Barreira Sabo -… | R$ 20.551.524,55 | 17/10/2027 | 345 |
| 2025010118 | SEHIS | FABMIX CONCRETOS LTDA | EXECUÇÃO DE SERVIÇOS DE URBANIZAÇÃO (EXECUÇÃO DE CONSTRUÇÃO/RECUPERAÇ… | R$ 12.000.000,00 | 23/12/2026 (PNCP) | 47 |
| 2026002324 | SEHIS | CONSTRUTORA AUGUSTO VELLOSO S.A. | serviços de urbanização (execução de construção/recuperação de calçad… | R$ 10.124.190,12 | 29/04/2027 (PNCP) | 174 |
| 2025010245 | SEHIS | CONSTRUTORA AUGUSTO VELLOSO S.A. | EXECUÇÃO DE SERVIÇOS DE URBANIZAÇÃO(EXECUÇÃO DE CONSTRUÇÃO/RECUPERAÇÃ… | R$ 10.018.085,44 | 08/12/2026 (PNCP) | 32 |
| 2026002913 | SEHIS | INSTITUTO DE ESTUDOS POLÍTICOS E SOCIAIS PAR… | Contratação de empresa especializada para a execução do TTS, em conju… | R$ 9.535.376,89 | 15/04/2027 (PNCP) | 160 |
| 2026004567 | SEHIS | CONSTRUTORA AUGUSTO VELLOSO S.A. | EXECUÇÃO DE SERVIÇOS DE URBANIZAÇÃO (EXECUÇÃO DE CONSTRUÇÃO/RECUPERAÇ… | R$ 8.048.652,11 | 16/06/2027 | 222 |
| 2026000506 | SEHIS | DIMENSIONAL ENGENHARIA LTDA | ADESÃO LOTE 02 ATA SRP Processo nº SEI-510001/000267/2024 - SECID SEI… | R$ 7.060.325,31 | 02/02/2027 (PNCP) | 88 |
| 2026000505 | SEHIS | DIMENSIONAL ENGENHARIA LTDA | ADESÃO LOTE 01 ATA SRP Processo nº SEI-510001/000267/2024 - SECID SEI… | R$ 6.668.085,06 | 30/01/2027 (PNCP) | 85 |
| 2026001307 | SEHIS | OMG EMPREENDIMENTOS | SERVICOS DE LOCACAO DE MAQUINAS /EQUIPAMENTOS CONSTRUCAO,DESCRICAO: C… | R$ 5.883.604,47 | 04/03/2027 (PNCP) | 118 |
| 2026001658 | SEHIS | AÇO FORTE DE MERITI IND METALURGICA E LOG LT… | Fornecimento e montagem de equipamentos permanentes | R$ 5.240.800,72 | 11/03/2027 (PNCP) | 125 |
| 2026001654 | SEHIS | AÇO FORTE DE MERITI IND METALURGICA E LOG LT… | Fornecimento e montagem de equipamentos permanentes | R$ 3.915.305,31 | 11/03/2027 (PNCP) | 125 |
| 2026000514 | SEHIS | DRAGMAQ ENGENHARIA LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DOSERVIÇO DE LOCAÇÃ… | R$ 3.599.999,80 | 05/02/2027 (PNCP) | 91 |
| 2026000512 | SEHIS | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | ADESÃO LOTE 09 ATA SRP Processo nº SEI-510001/000267/2024 - SECID SEI… | R$ 3.564.467,64 | 30/01/2027 (PNCP) | 85 |
| 2026000513 | SEHIS | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | ADESÃO LOTE 06 ATA SRP Processo nº SEI-510001/000267/2024 - SECID SEI… | R$ 3.564.467,64 | 30/01/2027 (PNCP) | 85 |
| 2026000508 | SEHIS | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | ADESÃO LOTE 03 ATA SRP Processo nº SEI-510001/000267/2024 - SECID SEI… | R$ 3.400.000,00 | 05/02/2027 (PNCP) | 91 |
| 2026000510 | SEHIS | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | ADESÃO LOTE 04 ATA SRP Processo nº SEI-510001/000267/2024 - SECID SEI… | R$ 3.400.000,00 | 05/02/2027 (PNCP) | 91 |
| 2026006664 | SEHIS | AÇO FORTE DE MERITI IND METALURGICA E LOG LT… | Fornecimento e montagem, sob demanda, de equipamentos permanentes par… | R$ 3.310.222,86 | 24/08/2027 | 291 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| ABRE CONSTRUÇÕES LTDA | 1 | R$ 49.211.636,93 |
| AÇO FORTE DE MERITI IND METALURGICA E LOG LTDA | 21 | R$ 41.261.463,34 |
| CONSTRUTORA AUGUSTO VELLOSO S.A. | 4 | R$ 31.192.577,95 |
| MARENGE ENGENHARIA CONSTRUCOES E SERVICOS LTDA | 1 | R$ 26.518.617,91 |
| PREST RIO CONSTRUÇÕES E SERVIÇOS LTDA | 1 | R$ 25.859.051,57 |
| HYDRA ENGENHARIA E SANEAMENTO LTDA | 1 | R$ 20.551.524,55 |
| INSTITUTO DE ESTUDOS POLÍTICOS E SOCIAIS PARA MELHORIA DA Q… | 11 | R$ 20.401.127,31 |
| FABMIX CONCRETOS LTDA | 4 | R$ 14.181.831,45 |
| DIMENSIONAL ENGENHARIA LTDA | 2 | R$ 13.728.410,37 |
| CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | 3 | R$ 10.070.000,00 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2022002914 | VITAL MESTRES CONSTRUÇÃO E MANUTENÇÃO PREDIA… | R$ 7.589.901,21 | R$ 1.179.134,82 | R$ 6.410.766,39 |
| 2020002124 | CONSORCIO NOVA INFRA ITABORAI | R$ 34.363.107,69 | R$ 30.391.668,88 | R$ 3.971.438,81 |
| 2021005614 | EMPRESA FLUMINENSE DE SERVIÇOS EIRELI-EPP | R$ 10.597.541,10 | R$ 6.679.385,22 | R$ 3.918.155,88 |
| 2020002385 | ALPHA 3 CONSTRUTORA LTDA | R$ 16.688.326,90 | R$ 14.234.211,96 | R$ 2.454.114,94 |
| 2022006180 | COLI TRANSPORTES E SERVIÇOS LTDA | R$ 8.816.162,85 | R$ 6.819.319,22 | R$ 1.996.843,63 |
| 2020002086 | CONCRETO BELFORD ROXO EIRELI | R$ 28.428.825,65 | R$ 26.649.019,11 | R$ 1.779.806,54 |
| 2022002851 | VITAL MESTRES CONSTRUÇÃO E MANUTENÇÃO PREDIA… | R$ 1.728.805,05 | R$ 0,00 | R$ 1.728.805,05 |
| 2022003133 | INTER BLOCOS CONSTRUÇÕES E PROJETOS LTDA | R$ 1.445.159,64 | R$ 0,00 | R$ 1.445.159,64 |
| 2022006423 | MONTREBLANT CONSTRUTORA LTDA | R$ 3.234.327,87 | R$ 1.827.140,90 | R$ 1.407.186,97 |
| 2022004779 | F P VIEIRA ENGENHARIA LTDA | R$ 5.958.023,76 | R$ 4.553.926,16 | R$ 1.404.097,60 |
| 2022006258 | VJV CONSULTORIA E CONSTRUCOES LTDA | R$ 4.161.346,30 | R$ 2.791.659,96 | R$ 1.369.686,34 |
| 2022004857 | OMEGA CONSTRUTORA E SERVIÇOS LTDA | R$ 4.659.751,06 | R$ 3.350.547,97 | R$ 1.309.203,09 |
| 2022006319 | GEOLOGUS ENGENHARIA LTDA | R$ 32.604.708,43 | R$ 31.349.427,15 | R$ 1.255.281,28 |
| 2022003435 | JOA ENGENHARIA LTDA | R$ 2.212.353,93 | R$ 1.064.898,61 | R$ 1.147.455,32 |
| 2020002908 | HYDRA ENGENHARIA E SANEAMENTO LTDA | R$ 15.688.719,53 | R$ 14.619.899,75 | R$ 1.068.819,78 |
| 2022004344 | J AZEVEDO ENGENHARIA LTDA | R$ 1.781.958,23 | R$ 736.516,83 | R$ 1.045.441,40 |
| 2022003081 | CONSTRUTORA METROPOLITANA S.A. | R$ 802.347,10 | R$ 0,00 | R$ 802.347,10 |
| 2022003804 | C.W.R. CONSTRUÇÕES REFORMAS E COMÉRCIO LTDA | R$ 4.476.183,01 | R$ 3.723.333,06 | R$ 752.849,95 |
| 2020001216 | CMAX EMPREENDIMENTOS, CONCRETO E CONSTRUÇÃO … | R$ 10.052.444,65 | R$ 9.353.033,81 | R$ 699.410,84 |
| 2022006081 | CETOR MANUTENCAO PREDIAL LTDA ME | R$ 1.529.803,31 | R$ 924.431,77 | R$ 605.371,54 |

## 11. Unidades incluídas neste dossiê
- CEHAB - COMPANHIA ESTADUAL DE HABITAÇÃO DO RJ
- ITERJ - INSTIT DE TERRAS E CARTOGRAFIA DO EST DO RJ
- SEH - SECRETARIA DE ESTADO DE HABITAÇÃO
- SEHIS - Secretaria de Estado de Habitação de Interesse Social

## 12. Conjuntos de dados abertos da secretaria
- Nenhum conjunto encontrado no portal.

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 6 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

- A segunda etapa do Parque Ermitage, prevista para 500 apartamentos, teve a conclusão estimada para julho de 2027. O custo reportado passou de R$ 97 milhões para aproximadamente R$ 137 milhões após aditivos ao contrato. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- A licitação para quatro condomínios chegou a ser suspensa pelo TCE-RJ diante de indícios de direcionamento no edital, que deveria ser corrigido antes de o processo prosseguir. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- A documentação fornecida identifica o Contrato nº 051/2026, para projeto executivo e obras em 69 unidades habitacionais no Rio de Janeiro, mas não informa valor ou cronograma. [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf)
- As fontes não permitem confirmar dívida, risco iminente de interrupção de serviços ou ações judiciais. O texto do O Dia informa que foi encaminhado ao MPRJ e ao TCE-RJ um pedido para apurar os atrasos e o aumento dos valores, mas não esclarece se o MPRJ abriu ou concluiu uma apuração. Esses pontos precisam ser verificados com os órgãos competentes e, quando cabível, com a Secretaria. [Início — SEHIS](https://www.rj.gov.br/habitacao/) [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)

##### Alertas vermelhos

- **Atraso e aumento de custo no Parque Ermitage:** a obra, anunciada em 2011 com expectativa de entrega até o fim de 2012, teve a segunda etapa, de 500 apartamentos, adiada para julho de 2027; o contrato firmado em janeiro de 2024 por R$ 97 milhões teria sido elevado por aditivos para aproximadamente R$ 137 milhões, acréscimo superior a 40%. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- **Controle externo sobre licitação:** o TCE-RJ suspendeu a licitação dos quatro condomínios após identificar indícios de direcionamento no edital e determinar correções; a fonte não informa a data da decisão nem o estágio atual do procedimento. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- **Apuração solicitada, sem desfecho informado:** o vereador Pedro Duarte encaminhou pedido ao TCE-RJ e ao MPRJ para apurar atrasos sucessivos e aumento de valores no contrato; a fonte não relata decisão ou providência subsequente do MPRJ. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- **Atenção à continuidade administrativa:** a folha de fevereiro de 2026 registra 229 vínculos ativos na SEHIS, mas apenas 1 servidor efetivo/concursado, com média de idade de 67 anos e tempo de exercício de 44 anos; o dado recomenda conferência do quadro e das funções essenciais, mas não comprova, por si só, risco de paralisação. [Caderno de RH — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Caderno_de_RH-Fevereiro%202026_v2.pdf)

##### Contratos e serviços críticos

- **Contrato ligado ao Parque Ermitage:** a obra foi contratada em janeiro de 2024 por R$ 97 milhões e o valor teria alcançado aproximadamente R$ 137 milhões após aditivos; a fonte não informa número do contrato, nome da empresa, datas dos aditivos ou seus valores individuais. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- A Secretaria informou que a obra estava com aproximadamente 85% de execução, atribuiu a revisão do cronograma a “circunstâncias técnicas e operacionais” e passou a prever conclusão em julho de 2027; a fonte não apresenta cronograma físico-financeiro detalhado. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- **Contrato nº 051/2026:** celebrado com a CBC Construções Ltda. para elaborar o Projeto Executivo e executar obras de reforma e requalificação dos Condomínios Residenciais Santa Bárbara, Rogério e Sollar de Ville, no bairro Anchieta, município do Rio de Janeiro, totalizando 69 unidades habitacionais; a resolução designa gestora e fiscais para acompanhar a execução e emitir aceitação provisória e definitiva. [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf)
- A fonte do Contrato nº 051/2026 não informa valor, prazo de execução, estágio das obras ou datas previstas de entrega, itens a solicitar para avaliar exposição financeira e continuidade. [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf)
- **Contrato nº 013/2026:** extrato publicado em 14/04/2026 registra retificação/atualização da razão social da contratada para LC DIAS DE OLIVEIRA CONSTRUÇÃO E ARQUITETURA LTDA.; o ato informa que não houve alteração de prazo nem de valor, mas não descreve o objeto do contrato no conteúdo fornecido. [Extrato do Contrato nº 013/2026](https://www.rj.gov.br/seiop/sites/default/files/arquivos_pagina_basica/PED%20N%C2%BA%2039365.pdf)
- O secretário estadual informou em 2 de julho — sem indicação do ano no texto — que “boa parte das unidades” seria entregue ainda em 2026; não foram especificados número de unidades nem data de entrega. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- O TCE-RJ suspendeu a licitação dos quatro condomínios por identificar indícios de direcionamento no edital e determinar correções; as fontes não informam número do processo, teor integral da decisão, providências adotadas ou situação atual da licitação. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- O pedido de apuração encaminhado por Pedro Duarte ao TCE-RJ e ao MPRJ é uma solicitação de investigação, não uma conclusão de irregularidade; não há informação fornecida sobre resposta, procedimento instaurado ou resultado do MPRJ. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- **Judiciário:** nada encontrado nas fontes consultadas sobre ações judiciais relacionadas à SEHIS ou aos contratos mencionados. [Início — SEHIS](https://www.rj.gov.br/habitacao/) [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html) [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf)

##### Riscos de apagão administrativo

- O quadro informado para fevereiro de 2026 registra 229 vínculos ativos e 1 servidor efetivo/concursado na SEHIS; a fonte não detalha distribuição por área, cargos, vínculos temporários ou funções críticas. [Caderno de RH — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Caderno_de_RH-Fevereiro%202026_v2.pdf)
- A média de idade de 67 anos e o tempo médio de exercício de 44 anos referem-se ao único servidor efetivo/concursado informado, não ao conjunto dos vínculos ativos. [Caderno de RH — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Caderno_de_RH-Fevereiro%202026_v2.pdf)
- **Interrupção de serviços:** nada encontrado nas fontes consultadas que confirme risco iminente de paralisação de serviços da SEHIS; a documentação também não permite avaliar a continuidade das obras além dos atrasos reportados em Teresópolis. [Início — SEHIS](https://www.rj.gov.br/habitacao/) [Caderno de RH — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Caderno_de_RH-Fevereiro%202026_v2.pdf) [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- **Dívidas e passivos:** nada encontrado nas fontes consultadas sobre dívidas, restos a pagar, passivos judiciais ou compromissos financeiros vencidos da Secretaria. [Início — SEHIS](https://www.rj.gov.br/habitacao/) [Extrato do Contrato nº 013/2026](https://www.rj.gov.br/seiop/sites/default/files/arquivos_pagina_basica/PED%20N%C2%BA%2039365.pdf) [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf)
- O despacho do secretário de 22/10/2026 tornou sem efeito a publicação do extrato do Termo de Colaboração nº 001/2025 — CONVERJ nº 1437, realizada em 04/05/2026; a fonte não informa o motivo nem as consequências do ato, que devem ser esclarecidos na transição. [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf)

##### Fatos recentes

- Em 14/04/2026 foi publicado extrato relativo ao Contrato nº 013/2026, assinado em 10/04/2026, para atualizar/retificar a razão social da contratada, sem alteração de prazo ou valor. [Extrato do Contrato nº 013/2026](https://www.rj.gov.br/seiop/sites/default/files/arquivos_pagina_basica/PED%20N%C2%BA%2039365.pdf)
- Em fevereiro de 2026, a SEHIS registrava dispêndio mensal de folha de R$ 1,47 milhão e 229 vínculos ativos, conforme publicação mensal de março de 2026. [Caderno de RH — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Caderno_de_RH-Fevereiro%202026_v2.pdf)
- Em 23 de outubro de 2026, a Resolução SEHIS nº 110 designou a comissão de gestão e fiscalização do Contrato nº 051/2026; o documento também registra despacho do secretário de 22 de outubro de 2026 tornando sem efeito a publicação do extrato do Termo de Colaboração nº 001/2025, sem informar o motivo. [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf)
- Em 18/12/2025, a deputada Élika Takimoto informou ter elaborado emenda para aumentar em R$ 200 milhões as receitas da Secretaria, com objetivo de financiar contenção de encostas em habitações situadas em áreas de risco; a fonte não confirma aprovação ou execução da emenda. [ALERJ — emenda para contenção de encostas](https://www.alerj.rj.gov.br/Visualizar/Noticia/81935)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)

- Solicitar a relação integral de contratos vigentes, aditivos, valores pagos e a pagar, cronogramas físico-financeiros e responsáveis por contrato, pois as fontes disponíveis não apresentam um inventário contratual da SEHIS. [Início — SEHIS](https://www.rj.gov.br/habitacao/) [Extrato do Contrato nº 013/2026](https://www.rj.gov.br/seiop/sites/default/files/arquivos_pagina_basica/PED%20N%C2%BA%2039365.pdf) [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf)
- Solicitar o processo completo do contrato do Parque Ermitage, incluindo identificação da empresa, número do contrato, justificativas e datas dos aditivos, medições, pagamentos, cronograma atualizado e plano de entrega das unidades. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- Solicitar cópia da decisão do TCE-RJ sobre a licitação dos quatro condomínios, identificação do processo, correções exigidas e situação atual do certame, além de informação sobre eventual procedimento do MPRJ relacionado ao pedido de apuração. [O Dia — atraso em Teresópolis](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html)
- Solicitar valor, prazo, cronograma e estágio de execução do Contrato nº 051/2026, bem como objeto completo e situação atual do Contrato nº 013/2026, informações não detalhadas nos extratos fornecidos. [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf) [Extrato do Contrato nº 013/2026](https://www.rj.gov.br/seiop/sites/default/files/arquivos_pagina_basica/PED%20N%C2%BA%2039365.pdf)
- Solicitar justificativa, efeitos e situação do Termo de Colaboração nº 001/2025 — CONVERJ nº 1437, cuja publicação foi tornada sem efeito sem motivo informado na fonte. [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf)
- Solicitar quadro de pessoal atualizado por tipo de vínculo, área e função, plano de sucessão e identificação das atividades dependentes de servidores específicos, pois a publicação de RH fornece totais e médias, sem detalhamento funcional. [Caderno de RH — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Caderno_de_RH-Fevereiro%202026_v2.pdf)
- Solicitar posição de dívidas, restos a pagar, passivos judiciais, ações judiciais, serviços sob risco de interrupção e medidas de contingência, pois nada disso foi encontrado nas fontes consultadas. [Início — SEHIS](https://www.rj.gov.br/habitacao/) [Caderno de RH — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Caderno_de_RH-Fevereiro%202026_v2.pdf) [Resolução SEHIS nº 110/2026](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf)

##### Fontes consultadas
1. [Atraso de obras mantém vítimas da tragédia de 2011 sem moradia em Teresópolis   Teresópolis   O Dia](https://odia.ig.com.br/teresopolis/2026/07/7275993-atraso-de-obras-mantem-vitimas-da-tragedia-de-2011-sem-moradia-em-teresopolis.html) — 2026-07-11
2. [Foi](https://www.alerj.rj.gov.br/Visualizar/Noticia/81935) — 2026-10-27
3. [Início   Secretaria de Habitação de Interesse Social](https://www.rj.gov.br/habitacao/) — 2026-06-19
4. [ PDF  GESTÃO DOCUMENTAL - Governo do Estado do Rio de Janeiro](https://www.rj.gov.br/seiop/sites/default/files/arquivos_pagina_basica/PED%20N%C2%BA%2039365.pdf) — 2026-04-21
5. [��Á���](https://dhg1h5j42swfq.cloudfront.net/2026/10/27082505/comissao-der-rj.pdf) — 2026-10-28
6. [Edição nº 146](https://www.rj.gov.br/gesperj/sites/default/files/Caderno_de_RH-Fevereiro%202026_v2.pdf) — 2026-03-15


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2026002737 (PAVIMAQ PAVIMENTAÇÃO E COMÉRCIO LTDA) vence em 25/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2026004370 (FABMIX CONCRETOS LTDA) vence em 03/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025009875 (PRODERJ - CENTRO DE TECNOLOGIA DE INFOR…) vence em 05/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2025010245 (CONSTRUTORA AUGUSTO VELLOSO S.A.) vence em 08/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025010253 (CONSTRUTORA AUGUSTO VELLOSO S.A.) vence em 08/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2022000255 (DYNATEST ENGENHARIA LTDA, R$ 43,2 mi) consta 'Ativo' no SIGA com fim em 24/01/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2024010002 (TCE EMPREENDIMENTOS ESPORTIVOS LTDA, R$ 38,0 mi) consta 'Ativo' no SIGA com fim em 11/08/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2025003726 (CONSTRUTORA SUMARÉ LTDA, R$ 31,2 mi) consta 'Ativo' no SIGA com fim em 31/10/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2024008230 (GHS EMPREENDIMENTOS IMOBILIÁRIOS LTDA-E…, R$ 17,0 mi) consta 'Ativo' no SIGA com fim em 08/09/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2024004758 (MARENGE ENGENHARIA CONSTRUCOES E SERVIC…, R$ 13,6 mi) consta 'Ativo' no SIGA com fim em 05/03/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
