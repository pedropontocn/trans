# Dossiê de transição — Secretaria de Estado de Transporte e Mobilidade Urbana (SETRAM)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/setram)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 1361 | R$ 4.388.764.338,41 |
| Com vigência futura (válidos no SIGA) | 108 | R$ 2.254.257.042,17 |
| até 30 dias | 6 | R$ 3.234.569,13 |
| até 60 dias | 11 | R$ 9.596.637,21 |
| até 90 dias | 8 | R$ 75.086.682,72 |
| até 180 dias | 23 | R$ 14.591.110,40 |
| vencido no SIGA | 1253 | R$ 2.134.507.296,24 |
| sem data | 13 | R$ 2.448.636,89 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 2 | R$ 233.069,29 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 342,3 mi / R$ 202,4 mi / R$ 180,2 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2021007547 (CONSTRUTORA INTERNACIONAL LTDA) vence em 22/11/2026 — 16 dias — R$ 2.654.005,90. Objeto: Contratação de Serviço de Locação de Imóveis.
- Contrato 2025002339 (OMEGA CONSTRUTORA E SERVIÇOS LTDA) vence em 25/01/2027 — 80 dias — R$ 72.499.193,50. Objeto: CONTRATAÇÃO SEMI-INTEGRADA DE EMPRESAESPECIALIZADA PARA EXECUÇÃO DOS SERVIÇOS E…
- Mais 5 contratos menores (R$ 0,6 mi) vencem em até 30 dias — ver seção 3.
- 36 contratos (R$ 96,0 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 108 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 179,7 mi); 3 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 1145 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 1.954,8 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- 12 contrato(s) 'Ativo' com data de fim inválida no SIGA (R$ 2,2 mi), ex.: 2022002788 (31/03/8202); 2022002815 (26/06/3022); 2024000466 (20/10/2192). Corrigir o cadastro e informar a vigência real.
- 2 contratações emergenciais vigentes (R$ 0,2 mi). Verificar prazo máximo legal (1 ano, Lei 14.133 art. 75 VIII) e licitação substitutiva.
- Concentração: BK CONSULTORIA E SERVIÇOS LTDA detém 86% do valor vigente (1 contratos).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2023008379 | CODERTE | CS BRASIL FROTAS S.A. | Contratação de empresa especialiada na prestação de serviços de locaç… | R$ 442.243,23 | 12/11/2026 | 6 |
| 2026007420 | CENTRAL | FRAMOT BAZAR E UTILIDADES LTDA | Aquisição de materiais de expediente, compreendendo papel A4 e envelo… | R$ 8.240,00 | 16/11/2026 | 10 |
| 2021007547 | CODERTE | CONSTRUTORA INTERNACIONAL LTDA | Contratação de Serviço de Locação de Imóveis. | R$ 2.654.005,90 | 22/11/2026 | 16 |
| 2025008678 | CENTRAL | CONTATO DIÁRIO LTDA | Contratação de empresa para prestação do serviço de monitoramento (co… | R$ 1.080,00 | 25/11/2026 | 19 |
| 2025008873 | CENTRAL | UNIMAC UNIVERSO DAS MAQUINAS LTDA | Aquisição de Equipamentos de Proteção Individual (EPI´s) | R$ 85.000,00 | 25/11/2026 | 19 |
| 2025008875 | CENTRAL | ASTRAL COMERCIO DE MATERIAIS E EQUIPAMENTOS … | Aquisição de Equipamentos de Proteção Individual (EPI´s) | R$ 44.000,00 | 25/11/2026 | 19 |
| 2025009889 | DETRO-RJ | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | serviço de hospedagem em Servidores Virtuais Privados (VPS) | R$ 298.849,68 | 08/12/2026 | 32 |
| 2025001022 | CODERTE | BRK AMBIENTAL MACAÉ S.A | Despesas estimadas com o consumo de água e esgoto para o Exercício de… | R$ 73.972,15 | 11/12/2026 | 35 |
| 2025001021 | CODERTE | PRO LAGOS S/A | Despesas estimadas com o consumo de água para o Exercício 2025, do Te… | R$ 131.272,74 | 23/12/2026 | 47 |
| 2025010498 | CENTRAL | DMX SOLUCOES INTEGRADAS LTDA | Aquisição de materiais limpeza e Escritorio | R$ 109.898,00 | 23/12/2026 | 47 |
| 2024003250 | DETRO-RJ | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | Conversão Digital de documentos e serviços de Microfilme digital. | R$ 3.200.000,00 | 25/12/2026 | 49 |
| 2024003251 | DETRO-RJ | SAFE CONVERSÃO DIGITAL LTDA | Conversão Digital de documentos e serviços de Microfilme digital. | R$ 700.000,00 | 25/12/2026 | 49 |
| 2026007401 | DETRO-RJ | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Aquisição de 1 (uma) unidade de Certificado Digital e-CNPJ do tipo A3… | R$ 1.750,00 | 25/12/2026 | 49 |
| 2015000692 | RIOTRILHOS | LIGHT SERVICOS DE ELETRICIDADE SA | CONTRATAÇÃO SERVIÇO DE FORNECIMENTO DE ENERGIA ELÉTRICA, PARA ATENDER… | R$ 3.490.873,04 | 31/12/2026 | 55 |
| 2021007619 | RIOTRILHOS | AGUAS DO RIO 1 SPE S.A | Contratação de empresa para prestação de serviços técnicos especializ… | R$ 306.000,00 | 31/12/2026 | 55 |
| 2023000056 | DETRO-RJ | OI S/A | TELEFONIA FIXA | R$ 12.021,60 | 31/12/2026 | 55 |
| 2024002493 | CODERTE | TERMINAL GARAGEM MENEZES CÔRTES S/A | Locação do imóvel do Terminal Rodoviários de Passageiros, celebrado e… | R$ 1.272.000,00 | 31/12/2026 | 55 |
| 2025010605 | DETRO-RJ | INDUSTRIA GRAFICA BRASILEIRA LTDA | PRESTAÇÃO DE SERVIÇOS DE IMPRESSÃO E REPROGRAFIA CORPORATIVA PARA CON… | R$ 131.928,15 | 12/01/2027 | 67 |
| 2023010948 | CODERTE | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | Contratação de serviços de gestão de abastecimento com utiliação de s… | R$ 174.960,00 | 16/01/2027 | 71 |
| 2024000115 | CODERTE | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | Contratação de empresa especialiada no fornecimento de Crédito Alimen… | R$ 1.956.240,00 | 24/01/2027 (DOERJ) | 79 |
| 2025002339 | SETRANS | OMEGA CONSTRUTORA E SERVIÇOS LTDA | CONTRATAÇÃO SEMI-INTEGRADA DE EMPRESAESPECIALIZADA PARA EXECUÇÃO DOS … | R$ 72.499.193,50 | 25/01/2027 (PNCP) | 80 |
| 2025010976 | DETRO-RJ | ELOAR SERVIÇOS DE COMUNICAÇÃO E MARKETING LT… | Contratação de empresa para prestação de serviços gráficos diversos, … | R$ 49.500,00 | 26/01/2027 | 81 |
| 2025001018 | CODERTE | COMPANHIA ESTADUAL DE AGUAS E ESGOTOS-CEDAE | Despesas estimadas com o consumo de Água e Esgoto para o Exercício 20… | R$ 173.452,24 | 29/01/2027 | 84 |
| 2023001712 | CODERTE | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Tem como objeto a prestação de serviços de processamento de informaçõ… | R$ 15.508,82 | 30/01/2027 | 85 |
| 2026006763 | CENTRAL | RIKI METALÚRGICA LTDA | Aquisição de Carretilha | R$ 85.900,00 | 30/01/2027 | 85 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026003334 | CENTRAL | ALT & RAILTECO RAIL S/A | Contratação de Serviço de Instalação de Aros para as Rodas dos Bondes… | R$ 945.000,00 | 05/02/2027 (PNCP) | 91 |
| 2025001017 | CODERTE | AGUAS DO RIO 4 SPE S.A | Despesas estimadas com o consumo de Água e Esgoto para o Exercício 20… | R$ 3.004,41 | 09/02/2027 | 95 |
| 2024001101 | SETRANS | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Aquisição de serviço de certificado digital para a SETRAM/COOCONT, se… | R$ 300,00 | 27/02/2027 | 113 |
| 2024001104 | SETRANS | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Aquisição de serviço de renovação de certificado digital e visita téc… | R$ 300,00 | 27/02/2027 | 113 |
| 2024001173 | SETRANS | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Aquisição de serviço de renovação de certificado digital e visita téc… | R$ 300,00 | 27/02/2027 | 113 |
| 2025001246 | CODERTE | TROPICAL SOLUCOES INDUSTRIAIS LTDA | Contratação de empresa prestadora de serviço de limpeza, higienização… | R$ 3.808.924,20 | 05/03/2027 (PNCP) | 119 |
| 2026005450 | CENTRAL | COL - CENTRAL DE LOGISTICA LTDA | Cumprimento Provisório de Sentença nº 5097610-39.2022.4.02.5101/RJ, e… | R$ 2.870.000,10 | 07/03/2027 (PNCP) | 121 |
| 2022001522 | DETRO-RJ | CLARO S/A (FILIAL) | ATA 001/21 PRODERJ - INFOVIA CLARO | R$ 298.947,96 | 09/03/2027 | 123 |
| 2026006985 | FET | RIOCARD TECNOLOGIA DA INFORMAÇÃO S/A | Contratação emergencial de serviço comum, com fundamento no art. 75, … | R$ 0,01 | 29/03/2027 | 143 |
| 2026000686 | CODERTE | PRO LAGOS S/A | Despesas estimadas com o consumo de águapara o Exercício 2026, do Ter… | R$ 141.020,00 | 01/04/2027 | 146 |
| 2026000699 | CODERTE | STONE INSTITUICAO DE PAGAMENTO S.A | Apresentar todos os parâmetros necessários a contratação de empresa e… | R$ 32.762,40 | 01/04/2027 | 146 |
| 2026001155 | SETRANS | ALL ELETRO COMÉRCIO DE ELETRÔNICOS LTDA | Contratação de empresa especializada em Solução de Gerenciamento e Or… | R$ 7.970,00 | 06/04/2027 | 151 |
| 2026001491 | SETRANS | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | O presente Termo de Referência tem por objetivo descrever a contrataç… | R$ 31.518,84 | 06/04/2027 | 151 |
| 2026004199 | DETRO-RJ | PRIVINA PRESTAÇÃO DE SERVIÇOS LTDA - ME | Contratação emergencial de empresa especializada para a prestação de … | R$ 233.069,28 | 10/04/2027 | 155 |
| 2026000701 | CODERTE | RIO + SANEAMENTO BL3 S.A | Despesas estimadas de Água e Esgoto para o Ano de 2026, do Terminal R… | R$ 89.140,60 | 13/04/2027 | 158 |
| 2025001753 | DETRO-RJ | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Contratação de empresa especializada na prestação serviços em publica… | R$ 400.000,00 | 16/04/2027 | 161 |
| 2026008670 | CENTRAL | NEW LATHE TECHNOLOGIES LTDA | Contratação de Empresa especializada em reperfilamento com instalação… | R$ 149.000,00 | 20/04/2027 | 165 |
| 2026008972 | DETRO-RJ | ASSOCIACAO NACIONAL DE PESQUISA E ENSINO EM … | Contratação de cota de patrocínio, por inexigibilidade de licitação, … | R$ 20.000,00 | 20/04/2027 | 165 |
| 2026000689 | CODERTE | AGUAS DE NITEROI S/A | Despesas estimadas com o consumo de Água e Esgoto para o período de m… | R$ 173.100,00 | 22/04/2027 | 167 |
| 2026000703 | CODERTE | AMPLA ENERGIA E SERVIÇOS S/A | Despesas com o consumo de energia elétrica dos Terminais Rodoviários … | R$ 213.700,00 | 22/04/2027 | 167 |
| 2026000704 | CODERTE | LIGHT SERVICOS DE ELETRICIDADE SA | Despesas com o consumo de energia elétrica da Sede da CODERTE, da Áre… | R$ 158.840,00 | 22/04/2027 | 167 |
| 2022007572 | DETRO-RJ | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | TRIVALE ADMINISTRAÇÃO LTDA | R$ 4.966.362,60 | 28/04/2027 | 173 |
| 2026001745 | DETRO-RJ | TRANSVICTORIA MUDANCAS E GUARDA MOVEIS LTDA.… | Contratação de empresa(s) especializada(s)para a prestação de serviço… | R$ 47.850,00 | 29/04/2027 | 174 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2023009562 | CENTRAL | MPE ENGENHARIA E SERVIÇOS S/A | Elaboração de Projeto Executivo e Execução de Serviços complementares… | R$ 69.800.000,00 | 21/01/2025 | -654 |
| 2022005329 | SETRANS | FUNDAÇÃO DE APOIO À BIODIVERSIDADE SÃO FRANC… | contratação, para odesenvolvimento de estudos técnicos, no âmbito do … | R$ 25.898.234,35 | 13/12/2024 | -693 |
| 2018003087 | RIOTRILHOS | GRUPO HOSPITALAR DO RIO DE JANEIRO LTDA (MAT… | Contratação de empresa para prestar serviços de assistência médica ho… | R$ 19.972.848,00 | 08/02/2026 | -271 |
| 2024009240 | CENTRAL | NOTRE DAME INTERMÉDICA SAÚDE S.A. | Contratação de Plano de Saúde | R$ 7.654.920,00 | 13/11/2025 (PNCP) | -358 |
| 2023010649 | RIOTRILHOS | JGP CONSTRUTORA LTDA | CONTRATAÇÃO DE EMPRESA DE ENGENHARIA ESPECIALIZADAPARA EXECUÇÃO DE RE… | R$ 5.402.329,49 | 17/12/2024 | -689 |
| 2024002218 | SETRANS | FIRST DECISION TECNOLOGIAS INOVADORAS E INFO… | Prestação de serviços de suporte técnico especialiado em tecnologia d… | R$ 4.429.999,50 | 20/03/2025 | -596 |
| 2023010918 | CENTRAL | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | Contratação de Vale Refeição e Alimentação | R$ 4.322.640,00 | 01/01/2025 | -674 |
| 2024007097 | CENTRAL | ALT & RAILTECO RAIL S/A | Remobilização dos bondes 16, 17 e 18 | R$ 2.874.798,39 | 04/09/2025 (PNCP) | -428 |
| 2016001134 | RIOTRILHOS | FEDERACAO DAS EMPRESAS DE TRANSPORTE DE PASS… | Prestação de serviços de fornecimento de VALE TRANSPORTE para emprega… | R$ 2.820.000,00 | 31/12/2025 | -310 |
| 2022006625 | DETRO-RJ | 2R DATATEL TELEINFORMÁTICA LTDA | SERVIÇO INFRAESTRUTURA EM TECNOLOGIA DA INFORMAÇÃO | R$ 2.606.400,00 | 31/08/2026 | -67 |
| 2025000691 | CENTRAL | COMPANHIA PAULISTA DE TRENS METROPOLITANOS -… | Contratação da CPTM para elaborar estimativa orçamentária para presta… | R$ 2.496.043,72 | 16/08/2025 (PNCP) | -447 |
| 2025000190 | CENTRAL | UCHOA SEGURANÇA PRIVADA LTDA. | Contratação de Empresa Especializada em Vigilância Desarmada | R$ 2.461.756,08 | 17/01/2026 (PNCP) | -293 |
| 2023008249 | CENTRAL | FIEL SOLUCÕES PRÁTICAS LTDA | Contratação de Serviços de Condução de Bondes | R$ 2.319.998,42 | 20/10/2025 | -382 |
| 2022003615 | RIOTRILHOS | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | Contratação de empresa especializada para prestação de serviços de ad… | R$ 2.071.430,00 | 26/03/2025 | -590 |
| 2024004863 | CENTRAL | GRUPO HOSPITALAR DO RIO DE JANEIRO LTDA (MAT… | Plano dde Saúde | R$ 1.881.000,00 | 14/01/2025 (PNCP) | -661 |
| 2024006905 | CODERTE | PRIVINA PRESTAÇÃO DE SERVIÇOS LTDA - ME | Contratação de empresa prestadora de serviços de limpeza, higienizaçã… | R$ 1.828.173,48 | 11/03/2025 (PNCP) | -605 |
| 2026000733 | RIOTRILHOS | GRUPO HOSPITALAR DO RIO DE JANEIRO LTDA (MAT… | Contratação através de Dispensa de Licitação, em caráter emergencial,… | R$ 1.783.296,00 | 09/08/2026 (PNCP) | -89 |
| 2024004346 | CODERTE | ASSOCIAÇÃO NITEROIENSE DOS DEFICIENTES FISIC… | Contratação de associação de pessoas com deficiência, nos termos do a… | R$ 1.688.767,47 | 11/05/2026 (PNCP) | -179 |
| 2025010981 | CENTRAL | M. MACEDO LOCACAO DE MAO DE OBRA E SERVICOS … | Contratação Emergencial - Serviços de reparos do 3º, 4º e 5º andar | R$ 1.660.135,15 | 06/07/2026 (PNCP) | -123 |
| 2023005040 | SETRANS | REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | prestação de serviços a Ata de Registro de Preços para eventual contr… | R$ 1.483.200,00 | 12/06/2026 | -147 |
| 2020000102 | CENTRAL | COMPANHIA ESTADUAL DE AGUAS E ESGOTOS-CEDAE | CONTRATAÇÃO DE SERVIÇO DE FORNECIMENTO DE ÁGUA E COLETA DE ESGOTOS. | R$ 1.375.568,55 | 31/12/2024 | -675 |
| 2021007662 | CENTRAL | AGUAS DO RIO 4 SPE S.A | SERVICO DE FORNECIMENTO DE AGUA E COLETA DE ESGOTO,DESCRIÇÃO: contrat… | R$ 1.375.568,55 | 01/11/2026 | -5 |
| 2025002687 | CODERTE | LOWNDES E SONS S A ADM CORRETAGENS E REPRESE… | Despesas estimadas com Condomínio do 13º andar do TGMC. | R$ 861.456,82 | 05/05/2026 (PNCP) | -185 |
| 2024002727 | CODERTE | LOWNDES E SONS S A ADM CORRETAGENS E REPRESE… | Despesas Estimadas com Condomínio do 13º andar do TGMC. | R$ 789.783,82 | 31/03/2025 | -585 |
| 2024001675 | SETRANS | ITS TECNOLOGIA E INFORMAÇÃO LTDA | Tratase de contratação de 1 uma subscrição de licença do software SAP… | R$ 741.260,00 | 05/03/2025 | -611 |
| 2024001674 | SETRANS | FIRST DECISION TECNOLOGIAS INOVADORAS E INFO… | Tratase de contratação de 1 uma subscrição de licença do software SAP… | R$ 613.846,05 | 05/03/2025 | -611 |
| 2024000387 | CENTRAL | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | Contratação de Agente de Integração/Contratação de Vagas de estagiári… | R$ 498.900,00 | 21/02/2025 | -623 |
| 2023000049 | DETRO-RJ | OPPORTUNITY COMERCIO E SERVICOS EM GERAL LTDA | SERVIÇO DE LIMPEZA E COPERAGEM | R$ 497.877,00 | 01/01/2025 | -674 |
| 2023010843 | SETRANS | CS BRASIL FROTAS S.A. | Serviço de locação de veículos de forma a atender satisfatoriamente o… | R$ 412.800,00 | 21/12/2024 | -685 |
| 2023010579 | CENTRAL | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | Adesão a Ata de Registro de Preços para contratação de serviços de em… | R$ 380.000,00 | 15/12/2024 | -691 |

_Registros mais antigos (provável falta de baixa no SIGA): 1145, R$ 1.954,8 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025000205 | SETRANS | BK CONSULTORIA E SERVIÇOS LTDA | A PRESTAÇÃO DE SERVIÇO ESPECIAL QUE GARANTA O APOIO TÉCNICO NECESSÁRI… | R$ 1.947.629.746,44 | 02/07/2030 | 1334 |
| 2025002339 | SETRANS | OMEGA CONSTRUTORA E SERVIÇOS LTDA | CONTRATAÇÃO SEMI-INTEGRADA DE EMPRESAESPECIALIZADA PARA EXECUÇÃO DOS … | R$ 72.499.193,50 | 25/01/2027 (PNCP) | 80 |
| 2025008960 | SETRANS | OMEGA CONSTRUTORA E SERVIÇOS LTDA | CONTRATAÇÃO INTEGRADA DE EMPRESA ESPECIALIZADAPARA EXECUÇÃO DE OBRA E… | R$ 70.134.823,58 | 17/07/2027 | 253 |
| 2026002236 | RIOTRILHOS | GERIBELLO ENGENHARIA LTDA. | O Objeto da presente licitação é a seleção de empresa ou consórcio de… | R$ 39.814.576,04 | 22/06/2030 (PNCP) | 1324 |
| 2026007744 | DETRO-RJ | FUNDAÇÃO VALE DO RIO DOCE DE SEGURIDADE SOCI… | promover a contratação de objeto que satisfaça as necessidades do Dep… | R$ 22.269.290,58 | 25/09/2036 | 3611 |
| 2024004881 | DETRO-RJ | TCR CONSTRUTORA EIRELI | SERVIÇO DE REBOQUE LOTE 1, SERVIÇO DE REBOQUE LOTE 2, SERVIÇO DE REBO… | R$ 17.797.498,08 | 17/10/2027 | 345 |
| 2025010735 | DETRO-RJ | 2R DATATEL TELEINFORMÁTICA LTDA | serviço de locação de equipamento para a sustentação da infraestrutur… | R$ 7.028.605,35 | 12/01/2031 | 1528 |
| 2024005976 | DETRO-RJ | MOBILIZA FOR RENT LTDA | SERVIÇOS DE LOCAÇÃO DE VEÍCULOSCOM MOTORISTAS | R$ 6.589.999,08 | 23/07/2027 | 259 |
| 2025005103 | RIOTRILHOS | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | Contratação de empresa especializada na prestação de serviços de natu… | R$ 6.240.000,00 | 22/05/2027 | 197 |
| 2022007572 | DETRO-RJ | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | TRIVALE ADMINISTRAÇÃO LTDA | R$ 4.966.362,60 | 28/04/2027 | 173 |
| 2026004833 | SETRANS | DRATA ANALYTICS LTDA | Contratação de serviço técnico especializado de consultoria com uso d… | R$ 4.211.280,00 | 26/06/2027 | 232 |
| 2023008370 | DETRO-RJ | OFICINA ENGENHEIROS CONSULTORES ASSOCIADOS L… | Consultoria Técnica especialiada em Transporte Publico | R$ 4.129.979,61 | 15/09/2027 | 313 |
| 2025001246 | CODERTE | TROPICAL SOLUCOES INDUSTRIAIS LTDA | Contratação de empresa prestadora de serviço de limpeza, higienização… | R$ 3.808.924,20 | 05/03/2027 (PNCP) | 119 |
| 2015000692 | RIOTRILHOS | LIGHT SERVICOS DE ELETRICIDADE SA | CONTRATAÇÃO SERVIÇO DE FORNECIMENTO DE ENERGIA ELÉTRICA, PARA ATENDER… | R$ 3.490.873,04 | 31/12/2026 | 55 |
| 2023009175 | DETRO-RJ | DECLINK DESENVOLVIMENTO E CONSULTORIA DE INF… | SOLUÇÕES TECNOLÓGICAS DE COMPUTAÇÃO MÓVEL | R$ 3.482.160,00 | 31/10/2027 | 359 |
| 2026005048 | SETRANS | PLUXEE BENEFICIOS BRASIL S.A. | O presente Termo de Referência tem por objeto a contratação de empres… | R$ 3.432.000,00 | 25/06/2027 | 231 |
| 2025004618 | CENTRAL | RIOPAR PARTICIPAÇÕES S/A | Contratação por inexigibilidade de empresa especializada na concessão… | R$ 3.250.800,00 | 10/07/2030 | 1342 |
| 2023008272 | DETRO-RJ | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | FORNECIMENTO DE VALE REFEIÇÃO | R$ 3.201.066,00 | 10/10/2027 | 338 |
| 2024003250 | DETRO-RJ | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | Conversão Digital de documentos e serviços de Microfilme digital. | R$ 3.200.000,00 | 25/12/2026 | 49 |
| 2026005450 | CENTRAL | COL - CENTRAL DE LOGISTICA LTDA | Cumprimento Provisório de Sentença nº 5097610-39.2022.4.02.5101/RJ, e… | R$ 2.870.000,10 | 07/03/2027 (PNCP) | 121 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026004199 | DETRO-RJ | PRIVINA PRESTAÇÃO DE SERVIÇOS LTDA - ME | Contratação emergencial de empresa especializada para a prestação de … | R$ 233.069,28 | 10/04/2027 | 155 |
| 2026006985 | FET | RIOCARD TECNOLOGIA DA INFORMAÇÃO S/A | Contratação emergencial de serviço comum, com fundamento no art. 75, … | R$ 0,01 | 29/03/2027 | 143 |

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| BK CONSULTORIA E SERVIÇOS LTDA | 1 | R$ 1.947.629.746,44 |
| OMEGA CONSTRUTORA E SERVIÇOS LTDA | 2 | R$ 142.634.017,08 |
| GERIBELLO ENGENHARIA LTDA. | 1 | R$ 39.814.576,04 |
| FUNDAÇÃO VALE DO RIO DOCE DE SEGURIDADE SOCIAL - VALIA | 1 | R$ 22.269.290,58 |
| TCR CONSTRUTORA EIRELI | 1 | R$ 17.797.498,08 |
| GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | 3 | R$ 11.397.306,00 |
| 2R DATATEL TELEINFORMÁTICA LTDA | 1 | R$ 7.028.605,35 |
| MOBILIZA FOR RENT LTDA | 1 | R$ 6.589.999,08 |
| TRIVALE INSTITUICAO DE PAGAMENTO LTDA | 1 | R$ 4.966.362,60 |
| DECLINK DESENVOLVIMENTO E CONSULTORIA DE INFORMÁTICA LTDA | 2 | R$ 4.502.160,00 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2016001629 | PROVIDENCIA TELEFERICOS LTDA | R$ 24.769.834,44 | R$ 12.755.263,20 | R$ 12.014.571,24 |
| 2022006787 | CONSORCIO AERO ANGRA | R$ 11.048.496,35 | R$ 8.131.616,50 | R$ 2.916.879,85 |
| 2018003087 | GRUPO HOSPITALAR DO RIO DE JANEIRO LTDA (MAT… | R$ 8.953.614,74 | R$ 7.478.976,16 | R$ 1.474.638,58 |
| 2022009962 | L.PHILIPPE CONSTRUÇÕES EIRELI | R$ 9.551.105,66 | R$ 8.134.850,73 | R$ 1.416.254,93 |
| 2016000043 | PINI GROUP BRASIL LTDA | R$ 1.640.389,36 | R$ 1.155.744,57 | R$ 484.644,79 |
| 2016003683 | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | R$ 11.008.703,58 | R$ 10.547.743,62 | R$ 460.959,96 |
| 2020003177 | PRIVINA PRESTAÇÃO DE SERVIÇOS LTDA - ME | R$ 5.523.171,44 | R$ 5.079.615,04 | R$ 443.556,40 |
| 2019002739 | PRIVINA PRESTAÇÃO DE SERVIÇOS LTDA - ME | R$ 1.540.387,63 | R$ 1.152.054,61 | R$ 388.333,02 |
| 2016001430 | MODULO SECURITY SOLUTIONS S/A | R$ 3.002.190,09 | R$ 2.630.823,28 | R$ 371.366,81 |
| 2023004134 | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | R$ 1.229.481,39 | R$ 914.911,39 | R$ 314.570,00 |
| 2016001134 | FEDERACAO DAS EMPRESAS DE TRANSPORTE DE PASS… | R$ 3.204.603,23 | R$ 2.975.530,11 | R$ 229.073,12 |
| 2016002876 | MONITORE SEGURANÇA PATRIMONIAL EIRELI. | R$ 558.919,74 | R$ 379.040,26 | R$ 179.879,48 |
| 2021002665 | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | R$ 1.808.375,31 | R$ 1.637.235,84 | R$ 171.139,47 |
| 2018004195 | ENGE PRAT ENGENHARIA E SERVIÇOS LTDA | R$ 1.069.459,41 | R$ 935.242,28 | R$ 134.217,13 |
| 2020003165 | UP BRASIL ADMINISTRAÇÃO E SERVIÇOS LTDA | R$ 3.985.047,00 | R$ 3.860.505,00 | R$ 124.542,00 |
| 2016003141 | LUNAU E CORREA CONSULTORIA E SERVIÇOS LTDA -… | R$ 248.085,00 | R$ 129.004,20 | R$ 119.080,80 |
| 2021006788 | FIRST DECISION TECNOLOGIAS INOVADORAS E INFO… | R$ 409.375,89 | R$ 297.678,83 | R$ 111.697,06 |
| 2018004180 | ENGE PRAT ENGENHARIA E SERVIÇOS LTDA | R$ 754.359,48 | R$ 659.687,39 | R$ 94.672,09 |
| 2016003151 | BASE COMERCIO E SERVICOS TECNICOS LTDA | R$ 449.895,34 | R$ 355.305,10 | R$ 94.590,24 |
| 2016000465 | COMPANHIA ESTADUAL DE AGUAS E ESGOTOS-CEDAE | R$ 129.704,05 | R$ 40.061,13 | R$ 89.642,92 |

## 11. Unidades incluídas neste dossiê
- CENTRAL - COMP EST DE ENGENH DE TRANSPORTES E LOGÍSTICA
- CODERTE - COMP DE DESENV RODOV E TERMINAIS DO EST DO RJ
- CTC - CIA TRANSP COLET DO EST RJ-EM LIQUIDAÇÃO
- DETRO-RJ - DEP DE TRANSPORTES RODOVIÁRIOS DO EST DO RJ
- FET - FUNDO ESTADUAL DE TRANSPORTES
- RIOTRILHOS - COMP DE TRANSP SOBRE TRILHOS DO EST DO RJ
- SETRANS - SECRETARIA DE ESTADO DE TRANSPORTES

## 12. Conjuntos de dados abertos da secretaria
- Dados de Gratuidade (atualizado 2026-11-05): [TRANGR Detalhado Dicionário Público V2 XLSX](https://dadosabertos.rj.gov.br/dataset/438b51fd-5e97-4354-9324-05a024a2bdfc/resource/66ad1d72-d15b-4546-8248-2e0555448e41/download/trangr-detalhado-dicionario-publico-v2.xlsx), [TRANGR Detalhado Dicionário Público V1 XLSX](https://dadosabertos.rj.gov.br/dataset/438b51fd-5e97-4354-9324-05a024a2bdfc/resource/7e1b3427-c663-468c-9b55-38487bc55d9f/download/trangr-detalhado-dicionario-publico.xlsx), [TRANGR Consolidado Dicionário Público V1 XLSX](https://dadosabertos.rj.gov.br/dataset/438b51fd-5e97-4354-9324-05a024a2bdfc/resource/a5859289-95a2-4001-a480-1b607824c2c9/download/trangr-consolidado-dicionario-publico.xlsx), [TRANSACAO_GRATUIDADE_PUBLICO_2025_07_06… ZIP](https://dadosabertos.rj.gov.br/dataset/438b51fd-5e97-4354-9324-05a024a2bdfc/resource/e1cfc4ff-102d-4894-815b-719c362d999d/download/transacao_gratuidade_publico_2025_07_06.csv.zip)
- Dados BUI Público (atualizado 2026-11-05): [TRANBU Detalhado Dicionario Publico V2 XLSX](https://dadosabertos.rj.gov.br/dataset/af44cdef-c988-4a48-93e9-2c874f7b3dd9/resource/f00c1406-619b-4b62-8269-c68dff633b43/download/tranbu-detalhado-dicionario-publico-v2.xlsx), [TRANBU Detalhado Dicionario Publico V1 XLS](https://dadosabertos.rj.gov.br/dataset/af44cdef-c988-4a48-93e9-2c874f7b3dd9/resource/d41b4a61-9a35-405b-8be0-ab97bc207067/download/tranbu-detalhado-dicionario-publico.xlsx), [TRANBU Consolidado Dicionario V1 XLS](https://dadosabertos.rj.gov.br/dataset/af44cdef-c988-4a48-93e9-2c874f7b3dd9/resource/7205cd6f-3f46-4893-9816-952b7b346b59/download/tranbu-consolidado-dicionario.xlsx), [TRANSACAO_BU_PUBLICO_2025_05_31.csv ZIP](https://dadosabertos.rj.gov.br/dataset/af44cdef-c988-4a48-93e9-2c874f7b3dd9/resource/55902462-bf3d-4d3f-9350-51f7eaea7040/download/transacao_bu_publico_2025_05_31.csv.zip)
- Dados do Sistema de Bilhetagem Eletrônica (atualizado 2026-11-05): [TRANBE Detalhado Dicionário Público V2 XLSX](https://dadosabertos.rj.gov.br/dataset/4068a13c-d2bd-4be5-aa3e-e63c3b71429d/resource/a1d470d2-c749-4731-a7bc-9390912dc53d/download/tranbe-detalhado-dicionario-publico-v2.xlsx), [TRANBE Detalhado Dicionário Público V1 XLS](https://dadosabertos.rj.gov.br/dataset/4068a13c-d2bd-4be5-aa3e-e63c3b71429d/resource/df535ea9-a8ae-46cd-ab6e-faf3d6176884/download/tranbe-detalhado-dicionario-publico.xlsx), [TRANBE Consolidado Dicionário V1 XLS](https://dadosabertos.rj.gov.br/dataset/4068a13c-d2bd-4be5-aa3e-e63c3b71429d/resource/aaced2d7-a279-489f-9916-03036ed2016b/download/tranbe-consolidado-dicionario.xlsx), [TransaçõesconsolidadoBE_2025_05.csv ZIP](https://dadosabertos.rj.gov.br/dataset/4068a13c-d2bd-4be5-aa3e-e63c3b71429d/resource/6c55fe51-46e1-4be9-b3bd-8fce4da5fb50/download/transacoesconsolidadobe_2025_05.csv.zip)
- Extratos de Repasse e Regras de Negócio do BUI (atualizado 2026-10-01): [PROCEDIMENTO_DE_REPASSE_DO_CONVENIO_001… PDF](https://dadosabertos.rj.gov.br/dataset/fbe8c49d-303d-402d-a5c0-3587cc34aed7/resource/0d9b65d3-afcd-419b-be4c-0b1e2e3f9721/download/procedimento_de_repasse_do_convenio_001.2013.pdf), [ITAU CC BUI 23588-7 12.2023 PDF](https://dadosabertos.rj.gov.br/dataset/fbe8c49d-303d-402d-a5c0-3587cc34aed7/resource/b225083d-78cd-4bb6-83c9-2de153e6ed7a/download/itau-cc-bui-23588-7-12.2023.pdf), [ITAU CC BUI 23588-7 12.2022 PDF](https://dadosabertos.rj.gov.br/dataset/fbe8c49d-303d-402d-a5c0-3587cc34aed7/resource/922db2f0-63b1-4679-81f4-0616620b9f2c/download/itau-cc-bui-23588-7-12.2022.pdf), [ITAU CC BUI 23588-7 12.2021 PDF](https://dadosabertos.rj.gov.br/dataset/fbe8c49d-303d-402d-a5c0-3587cc34aed7/resource/2c617677-24e9-4dc0-b486-92bd48dc210b/download/itau-cc-bui-23588-7-12.2021.pdf)
- Plano Anual de Auditoria Interna 2025 (atualizado 2025-09-18): [PLANAT-2025.csv CSV](https://dadosabertos.rj.gov.br/dataset/bfbc736d-6399-4913-83e4-f608c8a33c14/resource/1f97ba03-b123-4d67-aeac-2cc2bfe84a88/download/planat-2025.csv)
- Relatório Anual de Atividades de auditoria Interna 2024 (atualizado 2025-09-18): [RANAT-2024.csv CSV](https://dadosabertos.rj.gov.br/dataset/e999e593-227e-4d8c-9d2f-5bb1b75099c2/resource/b7e37637-6446-4836-be70-b22904607ba8/download/ranat-2024.csv)
- Relatório Anual de Atividades de auditoria Interna 2023 (atualizado 2025-09-18): [RANAT-2023.csv CSV](https://dadosabertos.rj.gov.br/dataset/c9fe6a43-4b78-44d4-8afd-d950940e1452/resource/04faeb1e-1445-4b80-a9a2-dc4f80078d6f/download/ranat-2023.csv)
- Plano Anual de Auditoria Interna 2024 (atualizado 2025-09-18): [PLANAT-2024.csv CSV](https://dadosabertos.rj.gov.br/dataset/cb1bf1a3-f860-457b-aae6-b23bbc84357a/resource/990e2f8d-8054-4908-a3ed-b80b5687783b/download/planat-2024.csv)
- Relatório de Auditoria  de Prestação de Contas Anual  de Gestão 2024 (atualizado 2025-09-18): [Relatório-de-Auditoria-PCA-2024.csv CSV](https://dadosabertos.rj.gov.br/dataset/817e84d8-c37f-40a4-9f73-d9f24730aa11/resource/70f9c769-c62a-4f76-990d-b09c504862bf/download/relatorio-de-auditoria-pca-2024.csv)
- Relatório de Auditoria  de Prestação de Contas Anual  de Gestão 2023 (atualizado 2025-09-18): [Relatório-de-Auditoria-PCA-2023.csv CSV](https://dadosabertos.rj.gov.br/dataset/9c6f235d-2507-4bab-bbcf-c45936c32649/resource/a3627e8d-415f-4c43-ac56-4b881bd2eeb4/download/relatorio-de-auditoria-pca-2023.csv)
- Plano de Integridade  SETRAM (atualizado 2025-09-10): [Plano de Integridade SETRAM PDF](https://dadosabertos.rj.gov.br/dataset/f2c6d889-1e90-44e0-9fb7-a97b979a4d4d/resource/b19d13d9-ba2f-45c4-83b3-a92b2629b846/download/plano_de_integridade_2023_final_valido_1.pdf)
- PED TIC 2024 a 2027 (atualizado 2025-09-10): [PED TIC 2024 a 2027 CSV](https://dadosabertos.rj.gov.br/dataset/3becc628-e34d-4db5-b809-23bba3082de7/resource/3ba6d944-028c-4dff-8ba0-21694f323edf/download/pedtic-setram-2024-2027.csv)
- OGE - Pedidos de  Acesso à Informação (atualizado 2025-09-10): [OGE - Pedidos de Acesso à Informação 20… CSV](https://dadosabertos.rj.gov.br/dataset/7dc3cbb6-4157-490a-a026-481277cffd1a/resource/a8043555-182c-4908-8cf8-2731e6c60dd4/download/manifestacao-de-ouvidorias-setram-2024.csv)
- Balanço Patrimonial  2024 Setram (atualizado 2025-09-10): [Balanço Patrimonial 2024 Setram CSV](https://dadosabertos.rj.gov.br/dataset/f6166d94-9b6e-4531-af45-988d3753c9eb/resource/fce28559-0d98-4b39-b5af-db9baf34bcf0/download/balanco-patrimonial-setram-2024.csv)
- Balanço Patrimonial  2023 Setram (atualizado 2025-09-10): [Balanço Patrimonial 2023 Setram CSV](https://dadosabertos.rj.gov.br/dataset/1a1d40c3-d4dd-46b8-887d-b798d8314a15/resource/1992d27f-1ff9-4a1a-adc7-60ace9a94b41/download/balanco-patrimonial-setram-2023.csv)
- Balanço Orçamentário  2024 Setram (atualizado 2025-09-10): [Balanço Orçamentário 2024 Setram CSV](https://dadosabertos.rj.gov.br/dataset/5ae91e06-f022-4e96-8c2f-f09ed6295014/resource/2370fec3-81a8-4f22-971a-f197ef4b76e2/download/balanco-orcamentario-setram-2024.csv)
- Balanço Orçamentário  2023 Setram (atualizado 2025-09-10): [Balanço Orçamentário 2023 Setram CSV](https://dadosabertos.rj.gov.br/dataset/7c1632d1-26da-434e-a941-beb4930a9e7b/resource/7f9a6e58-63d6-4b61-a2a8-2596c16833cb/download/balanco-orcamentario-setram-2023.csv)
- Quadro especial complementar da administração direta SETRAM (atualizado 2025-09-10): [Quadro especial complementar da adminis… CSV](https://dadosabertos.rj.gov.br/dataset/2fb3d143-d572-4490-a8fc-f2077789ec32/resource/2b4bc43c-96e4-4f1b-a011-204afd97d732/download/valores-cargos-efetivos.csv)
- Composição do quadro de pessoal  SETRAM (atualizado 2025-09-10): [Composição do quadro de pessoal SETRAM CSV](https://dadosabertos.rj.gov.br/dataset/c1e1df5d-e318-476f-923f-8b1054b20680/resource/657d1041-4949-4422-930d-6fde4ac7dc98/download/composicao-do-quadro-de-pessoal-setram.csv)
- Valores dos subsídios da estrutura da SETRAM (atualizado 2025-09-03): [Valores dos subsídios e Cargos Comissio… CSV](https://dadosabertos.rj.gov.br/dataset/f523b04b-424b-412f-a819-84aa7822c81f/resource/4643753f-92eb-4fe2-843d-47cc45fbe5a6/download/tabelas-de-valores-subsidios-e-cargos-comissionados.csv)
- Secretários de Estado de Transportes e Mobilidade Urbana (atualizado 2025-09-03): [Secretários de Estado de Transporte e M… CSV](https://dadosabertos.rj.gov.br/dataset/0f791c3f-f119-46ce-8c24-2f43273520b0/resource/b768e516-1969-401d-a80b-12edb4be3118/download/secretarios-de-transporte-desde-sua-criacao-ate-a-presente-data.csv)
- Relatório de Manifestações de Ouvidoria 2024 (atualizado 2025-09-03): [Relatório de Manifestações de Ouvidoria… CSV](https://dadosabertos.rj.gov.br/dataset/c76f63dc-2cac-4ece-a399-90497da77988/resource/da4d7e34-3d52-49ee-8591-b8102c593d68/download/manifestacao-de-ouvidorias-setram-2024.csv)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 6 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

- Um risco financeiro-operacional recente é a cobrança, pela TrensRJ, de R$ 68 milhões até 28 de agosto de 2026; a empresa alertou que a falta do repasse suspenderia a folha salarial e que fornecedores ameaçavam cortar serviços essenciais, embora tenha afirmado que não haveria paralisação. [BandNews — TrensRJ cobra R$ 68 milhões](https://www.band.com.br/bandnews-fm/rio-de-janeiro/noticias/trensrj-cobra-r-68-milhoes-do-estado-e-fala-em-risco-de-paralisacao-202608281752)
- A continuidade dos repasses depende de contrato emergencial da Setram com a RioCard, válido por sete meses até março de 2027; a secretaria informou que ainda precisava de ajustes técnicos para assumir todas as atividades com segurança. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- O TCE-RJ manteve, em março de 2026, a decisão que declarou ilegais convênios do Estado com a RioCard e determinou o desenvolvimento de capacidade estatal autônoma para verificar os dados usados nos pagamentos. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- As fontes também registram riscos à operação ferroviária associados a dívidas com fornecedores, além de uma disputa judicial envolvendo valores devidos à SuperVia. [Veja Rio — operação dos trens ameaçada](https://vejario.abril.com.br/cidade/trens-rio-operacao-ameacada-divida-supervia-trensrj/) [Ônibus & Transporte — atrasos no BUI e na Tarifa Social](https://onibusetransporte.com/2026/01/06/atraso-bilhete-unico-intermunicipal-tarifa-social-repasses-rj/)

##### Alertas vermelhos

- **Repasse à TrensRJ:** a empresa afirmou que aguardava R$ 68 milhões, relativos ao IFO e a parcelas contratuais que dizia já terem sido auditados; o Governo informou que pagaria após análise da Agetransp. A TrensRJ advertiu que a falta do repasse poderia impedir o pagamento da folha e levar à paralisação, mas afirmou que não haveria paralisação. [BandNews — TrensRJ cobra R$ 68 milhões](https://www.band.com.br/bandnews-fm/rio-de-janeiro/noticias/trensrj-cobra-r-68-milhoes-do-estado-e-fala-em-risco-de-paralisacao-202608281752)
- **Fornecedores ferroviários:** reportagem de julho registrou risco de fornecedores com pagamentos em atraso deixarem de prestar serviços essenciais e informou dívida de cerca de R$ 15 milhões com fornecedores somente em maio, sem valor total conhecido. [Veja Rio — operação dos trens ameaçada](https://vejario.abril.com.br/cidade/trens-rio-operacao-ameacada-divida-supervia-trensrj/)
- **Bilhetagem e controle de repasses:** o contrato emergencial com a RioCard, válido por sete meses, manteria a empresa à frente do sistema de repasses do Bilhete Único Intermunicipal pelo menos até março de 2027. A Setram justificou a contratação afirmando que não conseguiria internalizar com segurança todas as atividades até o fim do convênio anterior. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- **Histórico de controle:** o TCE-RJ manteve em março de 2026 a decisão de ilegalidade dos convênios com a RioCard e determinou que o Estado desenvolvesse capacidade própria de verificação, auditoria, validação e controle dos dados que fundamentam pagamentos públicos. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- **Crises operacionais ferroviárias:** foram relatados princípio de incêndio em subestação em 13 de agosto de 2026 e descarrilamentos em junho, incluindo ocorrência em Guapimirim que suspendeu a circulação no trecho. [BandNews — TrensRJ cobra R$ 68 milhões](https://www.band.com.br/bandnews-fm/rio-de-janeiro/noticias/trensrj-cobra-r-68-milhoes-do-estado-e-fala-em-risco-de-paralisacao-202608281752)

##### Contratos e serviços críticos

- **Bilhetagem e repasses:** a Setram celebrou contrato emergencial com a RioCard por sete meses, até março de 2027, para executar os pagamentos às concessionárias e permissionárias com base nos valores previamente verificados e validados pela secretaria; a previsão é de transferências quinzenais que somariam mais de R$ 235 milhões até o fim da vigência. O preço ofertado foi R$ 0,00 por transação. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- O contrato restringe a RioCard à execução de pagamentos com base em valores previamente verificados e validados pela Setram, proíbe antecipação de recursos e retenção de saldos, e a secretaria informou que o Contrato nº 005/2026 lhe permite ler, verificar e validar autonomamente os dados de bilhetagem. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- A Setram informou ter consultado 56 empresas para a contratação emergencial; nenhuma apresentou proposta no prazo nem se manifestou após novo contato, e a RioCard apresentou a proposta de menor preço, de R$ 0,00 por transação. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- **TrensRJ:** a gestão definitiva começou em maio, e o novo modelo remunera a operadora por quilômetro rodado, não por passageiro; a fonte não informa número, valor total ou vigência do contrato. [BandNews — TrensRJ cobra R$ 68 milhões](https://www.band.com.br/bandnews-fm/rio-de-janeiro/noticias/trensrj-cobra-r-68-milhoes-do-estado-e-fala-em-risco-de-paralisacao-202608281752)
- A nova operação ferroviária foi atribuída à TrensRJ para 270 quilômetros de trilhos, em 12 cidades e 104 estações; a fonte não informa número, valor ou vigência do contrato. [Veja Rio — operação dos trens ameaçada](https://vejario.abril.com.br/cidade/trens-rio-operacao-ameacada-divida-supervia-trensrj/)
- **Processo de alienação ligado à SuperVia:** o Edital de Processo Competitivo nº 001/2026 previa alienação judicial da totalidade do capital social da SPE FERROVIÁRIA, associada à UPI do serviço ferroviário metropolitano, e viabilização de nova delegação por contrato de permissão de cinco anos. A realização estava prevista para 10 de fevereiro de 2026. [TCE-RJ — Processo nº 101.211-9/2026](https://www.tribunanf.com.br/wp-content/uploads/2026/02/TCE-RJ-leilao-Supervia.pdf)
- O edital e a minuta indicavam valor global estimado de R$ 660.234.654,12, na data-base de setembro de 2025, composto por R$ 611.103.687,76 de Investimentos Críticos e R$ 49.130.966,36 de preço de aquisição; o valor não incluía a receita operacional da futura permissionária. [TCE-RJ — Processo nº 101.211-9/2026](https://www.tribunanf.com.br/wp-content/uploads/2026/02/TCE-RJ-leilao-Supervia.pdf)
- A representação citava a cláusula 20.1.2 da minuta, que previa R$ 652.234.654,12 para ressarcimento dos Investimentos Críticos ao longo dos cinco anos; a fonte informa que os valores mensais e anuais constariam do Anexo 03 A. [TCE-RJ — Processo nº 101.211-9/2026](https://www.tribunanf.com.br/wp-content/uploads/2026/02/TCE-RJ-leilao-Supervia.pdf)
- A representação também questionava a estrutura de remuneração: segundo ela, 90% da Parcela A seria garantida e 10% poderia variar conforme desempenho, enquanto a Parcela B estaria associada ao ressarcimento dos Investimentos Críticos. Esses pontos são alegações da representação, não conclusões de mérito demonstradas no trecho fornecido. [TCE-RJ — Processo nº 101.211-9/2026](https://www.tribunanf.com.br/wp-content/uploads/2026/02/TCE-RJ-leilao-Supervia.pdf)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- **TCE-RJ e RioCard:** em julho de 2021, o Tribunal declarou ilegais convênios do Estado com a RioCard e seus termos aditivos, apontando, entre outros motivos, conflito relacionado à representação de interesses da Fetranspor, falta de estudos técnicos e falta de justificativa para a escolha da empresa. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- O Estado recorreu, suspendendo os efeitos da declaração enquanto o recurso aguardava julgamento; em março de 2026, o recurso foi julgado e a decisão de ilegalidade foi mantida. O TCE-RJ também determinou o desenvolvimento de capacidade estatal autônoma para verificar, auditar, validar e controlar os dados usados nos pagamentos às empresas de transporte. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- **Judiciário e SuperVia:** em dezembro de 2025, segundo a reportagem, a SuperVia acionou a Justiça para garantir mais de R$ 17 milhões; a 6ª Vara Empresarial intimou o Estado em 19 de dezembro a regularizar o repasse em até cinco dias, sob pena de penhora. A fonte informou que a empresa aguardava a quitação. [Ônibus & Transporte — atrasos no BUI e na Tarifa Social](https://onibusetransporte.com/2026/01/06/atraso-bilhete-unico-intermunicipal-tarifa-social-repasses-rj/)
- **MPRJ:** Nada encontrado nas fontes consultadas sobre procedimentos ou ações do Ministério Público do Estado do Rio de Janeiro. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml) [BandNews — TrensRJ cobra R$ 68 milhões](https://www.band.com.br/bandnews-fm/rio-de-janeiro/noticias/trensrj-cobra-r-68-milhoes-do-estado-e-fala-em-risco-de-paralisacao-202608281752) [Veja Rio — operação dos trens ameaçada](https://vejario.abril.com.br/cidade/trens-rio-operacao-ameacada-divida-supervia-trensrj/)
- **Processo competitivo da SuperVia:** a fonte informa que houve decisão monocrática assinada pelo relator do TCE-RJ em 9 de fevereiro de 2026, às 18:08:28, após os autos chegarem ao gabinete em 5 de fevereiro sem manifestação prévia do Corpo Instrutivo e do Ministério Público de Contas. Na decisão, foi determinada a oitiva da SETRAM por até cinco dias úteis e, depois, o encaminhamento dos autos à Secretaria Geral de Controle Externo para análise, em especial, do pedido de tutela provisória. [TCE-RJ — Processo nº 101.211-9/2026](https://www.tribunanf.com.br/wp-content/uploads/2026/02/TCE-RJ-leilao-Supervia.pdf)

##### Riscos de apagão administrativo

- A contratação emergencial da RioCard foi feita enquanto a Setram ainda precisava de ajustes técnicos para internalizar com segurança todas as atividades de bilhetagem; a data de término informada para o contrato é março de 2027. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- A reportagem registra que a PGE recebeu o processo para análise em 18 de agosto de 2026, dois dias antes do prazo final para a celebração do acordo, e apresentou parecer em 19 de agosto. O procurador-chefe destacou a urgência da análise, e o parecer recomendou, entre outras medidas, iniciar estudos para uma licitação definitiva e priorizar o cumprimento das determinações do TCE-RJ. Com aval da PGE, o contrato foi celebrado e entrou em vigor após o término do convênio, que vigorava até 20 de agosto. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- A dependência de dados de bilhetagem validados pela Setram é especialmente relevante porque o TCE-RJ havia determinado que o Estado desenvolvesse capacidade autônoma de controle e a própria secretaria informou que ainda precisava de ajustes para assumir todas as atividades com segurança. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- As fontes não permitem concluir se a estrutura de pessoal, sistemas, procedimentos de auditoria e contingência da Setram está pronta para o fim do contrato emergencial ou para a continuidade dos repasses sem interrupção. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)

##### Fatos recentes

- Em janeiro de 2026, reportagem estimou em cerca de R$ 150 milhões os atrasos de repasses do BUI e da Tarifa Social, referentes a atrasos iniciados em meados de novembro de 2025; a fonte informou que a Seplag liberou valores para viabilizar os repasses, sem esclarecer o saldo posterior. [Ônibus & Transporte — atrasos no BUI e na Tarifa Social](https://onibusetransporte.com/2026/01/06/atraso-bilhete-unico-intermunicipal-tarifa-social-repasses-rj/)
- Em fevereiro de 2026, o TCE-RJ recebeu representação contra o processo competitivo relativo à SuperVia; a decisão monocrática foi assinada em 9 de fevereiro e o certame estava previsto para 10 de fevereiro. A decisão determinou a oitiva da SETRAM por até cinco dias úteis e o posterior encaminhamento dos autos para análise. [TCE-RJ — Processo nº 101.211-9/2026](https://www.tribunanf.com.br/wp-content/uploads/2026/02/TCE-RJ-leilao-Supervia.pdf)
- Em julho de 2026, a Setram informou que a PGE daria ciência à Justiça sobre dívidas da SuperVia e ressaltou que a mudança de gestão não transferia ao Estado a responsabilidade pelos contratos da empresa com fornecedores. [Veja Rio — operação dos trens ameaçada](https://vejario.abril.com.br/cidade/trens-rio-operacao-ameacada-divida-supervia-trensrj/)
- Em agosto de 2026, a TrensRJ cobrou R$ 68 milhões e apontou risco para folha salarial e serviços essenciais caso o repasse não ocorresse; o Estado condicionou o pagamento à análise da Agetransp. [BandNews — TrensRJ cobra R$ 68 milhões](https://www.band.com.br/bandnews-fm/rio-de-janeiro/noticias/trensrj-cobra-r-68-milhoes-do-estado-e-fala-em-risco-de-paralisacao-202608281752)
- Em setembro de 2026, foi noticiada a contratação emergencial da RioCard, por sete meses, para executar os pagamentos às operadoras do Bilhete Único Intermunicipal com base nos valores verificados e validados pela Setram, até março de 2027. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)

- As fontes consultadas não informam a situação atual dos R$ 68 milhões cobrados pela TrensRJ, se o pagamento foi efetuado, quais parcelas permanecem pendentes ou qual é o cronograma atualizado de análise pela Agetransp; solicitar posição financeira conciliada e comprovantes de pagamento. [BandNews — TrensRJ cobra R$ 68 milhões](https://www.band.com.br/bandnews-fm/rio-de-janeiro/noticias/trensrj-cobra-r-68-milhoes-do-estado-e-fala-em-risco-de-paralisacao-202608281752)
- As fontes não apresentam o saldo atualizado de dívidas da SuperVia com fornecedores, a relação de serviços essenciais em risco nem o andamento posterior da comunicação à Justiça; solicitar posição por credor, serviço e medida de continuidade. [Veja Rio — operação dos trens ameaçada](https://vejario.abril.com.br/cidade/trens-rio-operacao-ameacada-divida-supervia-trensrj/)
- As fontes não informam o plano de transição da bilhetagem após março de 2027, o cronograma de ajustes técnicos, os marcos de prontidão do Contrato nº 005/2026 nem os controles de contingência; solicitar plano, responsáveis, riscos e evidências de testes. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml)
- A fonte reproduz decisão monocrática do TCE-RJ que determinou a oitiva do jurisdicionado e o posterior encaminhamento dos autos para análise, mas não informa o desfecho posterior do Processo Competitivo nº 001/2026 nem a situação jurídica e contratual atual da operação ferroviária; solicitar à secretaria informações atualizadas sobre esses pontos. [TCE-RJ — Processo nº 101.211-9/2026](https://www.tribunanf.com.br/wp-content/uploads/2026/02/TCE-RJ-leilao-Supervia.pdf)
- As fontes não detalham o andamento da ação judicial sobre os mais de R$ 17 milhões reclamados pela SuperVia nem confirmam a quitação; solicitar número e situação atual do processo, decisões posteriores e comprovantes de pagamento. [Ônibus & Transporte — atrasos no BUI e na Tarifa Social](https://onibusetransporte.com/2026/01/06/atraso-bilhete-unico-intermunicipal-tarifa-social-repasses-rj/)
- Nada encontrado nas fontes consultadas sobre procedimentos do MPRJ, inventário completo de contratos críticos da Setram, saldo atualizado dos passivos de transporte ou plano consolidado de continuidade dos serviços para os primeiros 90 dias do novo governo. [Extra — contrato emergencial com a RioCard](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml) [BandNews — TrensRJ cobra R$ 68 milhões](https://www.band.com.br/bandnews-fm/rio-de-janeiro/noticias/trensrj-cobra-r-68-milhoes-do-estado-e-fala-em-risco-de-paralisacao-202608281752) [Veja Rio — operação dos trens ameaçada](https://vejario.abril.com.br/cidade/trens-rio-operacao-ameacada-divida-supervia-trensrj/)

##### Fontes consultadas
1. [PROCESSO: TCE-RJ Nº 101.211-9/2026 ...](https://www.tribunanf.com.br/wp-content/uploads/2026/02/TCE-RJ-leilao-Supervia.pdf) — 2026-02-13
2. [Estado faz contrato emergencial com RioCard para repassar ...](https://extra.globo.com/rio/noticia/2026/09/estado-faz-contrato-emergencial-com-riocard-para-repassar-arrecadacao-do-bilhete-unico.ghtml) — 2026-09-11
3. [Arquivo de destaque - Página 77 de 834 - Tempo Real](https://temporealrj.com/tag/destaque/page/77/) — 2026-11-05
4. [Atraso no Bilhete Único Intermunicipal e Tarifa Social ...](https://onibusetransporte.com/2026/01/06/atraso-bilhete-unico-intermunicipal-tarifa-social-repasses-rj/) — 2026-01-06
5. [TrensRJ cobra R$ 68 milhões do Estado e fala em risco de paralisação](https://www.band.com.br/bandnews-fm/rio-de-janeiro/noticias/trensrj-cobra-r-68-milhoes-do-estado-e-fala-em-risco-de-paralisacao-202608281752) — 2026-08-28
6. [Operação dos trens no Rio está ameaçada por dívida da ...](https://vejario.abril.com.br/cidade/trens-rio-operacao-ameacada-divida-supervia-trensrj/) — 2026-07-23


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2023008379 (CS BRASIL FROTAS S.A.) vence em 12/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2026007420 (FRAMOT BAZAR E UTILIDADES LTDA) vence em 16/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2021007547 (CONSTRUTORA INTERNACIONAL LTDA) vence em 22/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2025008678 (CONTATO DIÁRIO LTDA) vence em 25/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025008873 (UNIMAC UNIVERSO DAS MAQUINAS LTDA) vence em 25/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2023009562 (MPE ENGENHARIA E SERVIÇOS S/A, R$ 69,8 mi) consta 'Ativo' no SIGA com fim em 21/01/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2022005329 (FUNDAÇÃO DE APOIO À BIODIVERSIDADE SÃO …, R$ 25,9 mi) consta 'Ativo' no SIGA com fim em 13/12/2024: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2018003087 (GRUPO HOSPITALAR DO RIO DE JANEIRO LTDA…, R$ 20,0 mi) consta 'Ativo' no SIGA com fim em 08/02/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2024009240 (NOTRE DAME INTERMÉDICA SAÚDE S.A., R$ 7,7 mi) consta 'Ativo' no SIGA com fim em 13/11/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2023010649 (JGP CONSTRUTORA LTDA, R$ 5,4 mi) consta 'Ativo' no SIGA com fim em 17/12/2024: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
