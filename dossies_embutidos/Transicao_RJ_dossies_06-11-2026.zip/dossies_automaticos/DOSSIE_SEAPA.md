# Dossiê de transição — Secretaria de Estado de Agricultura, Pecuária, Pesca e Abastecimento (SEAPA)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/seapa)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 2466 | R$ 2.338.326.366,94 |
| Com vigência futura (válidos no SIGA) | 155 | R$ 444.504.270,45 |
| até 30 dias | 6 | R$ 19.310.291,72 |
| até 60 dias | 21 | R$ 167.977.782,52 |
| até 90 dias | 9 | R$ 8.022.447,12 |
| até 180 dias | 47 | R$ 46.670.198,94 |
| vencido no SIGA | 2311 | R$ 1.893.822.096,49 |
| sem data | 13 | R$ 46.084.887,43 |
| Fornecedores em recuperação judicial | 1 | R$ 8.697.828,99 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 1.081,0 mi / R$ 535,2 mi / R$ 530,8 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2023010241 (MODERA ENGENHARIA LTDA) vence em 30/11/2026 — 24 dias — R$ 5.598.251,20. Objeto: Contratação de empresa especialiada de serviços de apoio as atividades administ…
- Contrato 2023010379 (CERTIFICA PARKING & FACILITIES LTDA) vence em 30/11/2026 — 24 dias — R$ 3.687.366,84. Objeto: Contratação de empresa especialiada em serviços de controle de acesso
- Contrato 2025005321 (RESBRITEC CONSTRUÇÕES COMÉRCIO E SERVIÇOS LTDA) vence em 30/11/2026 — 24 dias — R$ 9.890.000,00. Objeto: Contratação de Empresa Especializada para Execução de Obras Civis com instalaçã…
- Contrato 2024000556 (PLIMA VIGILANCIA E SEGURANCA PRIVADA LTDA ME) vence em 28/12/2026 — 52 dias — R$ 47.971.311,01. Objeto: Contratação de empresa especialiada em serviços de vigilância
- Contrato 2024000555 (EMSIMEM MANUTENÇÃO E CONSERVAÇÃO LTDA ME) vence em 01/01/2027 — 56 dias — R$ 11.553.390,00. Objeto: Contratação de empresa especialiada em serviços de engenharia
- Contrato 2024000734 (JRF MANUTENCAO E SERVICOS EIRELI ME) vence em 01/01/2027 — 56 dias — R$ 69.234.774,90. Objeto: Contratação de empresa especialiada em serviços de coleta de lixo
- Mais 3 contratos menores (R$ 0,1 mi) vencem em até 30 dias — ver seção 3.
- 62 contratos (R$ 237,7 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 343 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 612,9 mi); 12 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 1968 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 1.280,9 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Fornecedor em recuperação judicial: CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO JUDICIAL — 1 contrato(s), R$ 8,7 mi, último fim 13/10/2025.

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024008782 | PESAGRO-RIO | REDE NACIONAL DE APRENDIZAGEM, PROMOÇÃO SOCI… | Contratação de Serviços de empresa para cooperação recíproca entre as… | R$ 129.652,80 | 06/11/2026 | 0 |
| 2026008921 | CEASA-RJ | TOP MIX COMÉRCIO E SERVIÇOS LTDA | FRIGOBAR,COR: BRANCO, CAPACIDADE FREEZER: 8 L, CAPACIDADE REFRIGERADO… | R$ 1.250,00 | 12/11/2026 | 6 |
| 2023010241 | CEASA-RJ | MODERA ENGENHARIA LTDA | Contratação de empresa especialiada de serviços de apoio as atividade… | R$ 5.598.251,20 | 30/11/2026 | 24 |
| 2023010379 | CEASA-RJ | CERTIFICA PARKING & FACILITIES LTDA | Contratação de empresa especialiada em serviços de controle de acesso | R$ 3.687.366,84 | 30/11/2026 | 24 |
| 2025005321 | CEASA-RJ | RESBRITEC CONSTRUÇÕES COMÉRCIO E SERVIÇOS LT… | Contratação de Empresa Especializada para Execução de Obras Civis com… | R$ 9.890.000,00 | 30/11/2026 | 24 |
| 2023010418 | CEASA-RJ | AVISO URGENTE TECNOLOGIA E INFORMAÇÃO LTDA. | Contratação de empresa especialiada na prestação de serviços de Clipp… | R$ 3.770,88 | 03/12/2026 | 27 |
| 2021007396 | CEASA-RJ | CLARO S/A (FILIAL) | Contratação de Link de Dados rede IP Governo - Crítico - Velocidade 1… | R$ 406.145,36 | 07/12/2026 | 31 |
| 2025010209 | SEAPPA | MULTIPLAR ENGENHARIA E LOCACOES LTDA | contratação de empresa para a prestação de serviços de locação de máq… | R$ 8.339.110,63 | 10/12/2026 (PNCP) | 34 |
| 2025010556 | FIPERJ | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | Contratação de empresa especializada na prestação de serviços de emis… | R$ 126.000,00 | 12/12/2026 | 36 |
| 2025007917 | EMATER-RIO | 54.078.213 MARA JORDANA BARBOSA DA SILVA | O objeto da presente contratação é a prestação de serviços de consult… | R$ 49.980,00 | 15/12/2026 | 39 |
| 2021007622 | CEASA-RJ | ASSOCIAÇÃO NITEROIENSE DOS DEFICIENTES FISIC… | Contratação de mão de obra terceirizada. | R$ 7.586.811,96 | 21/12/2026 | 45 |
| 2025007870 | PESAGRO-RIO | SALESTECH SOLUÇÕES EM TI LTDA | Contratação de empresa para fornecimento de renovação de licença para… | R$ 26.206,00 | 24/12/2026 | 48 |
| 2024009708 | FIPERJ | SANRITA COMERCIO E SERVICOS LTDA - ME | Aquisição de material de limpeza | R$ 10.189,35 | 27/12/2026 | 51 |
| 2024009714 | FIPERJ | DANJAC DISTRIBUIDORA LTDA. | Aquisição de material de limpeza | R$ 10.079,25 | 27/12/2026 | 51 |
| 2024009716 | FIPERJ | FRAMOT BAZAR E UTILIDADES LTDA | Aquisição de material de limpeza | R$ 6.039,00 | 27/12/2026 | 51 |
| 2024000036 | CEASA-RJ | JRF MANUTENCAO E SERVICOS EIRELI ME | Contratação de empresa especialiada em serviços de limpea e higieniaç… | R$ 6.230.528,55 | 28/12/2026 | 52 |
| 2024000556 | CEASA-RJ | PLIMA VIGILANCIA E SEGURANCA PRIVADA LTDA ME | Contratação de empresa especialiada em serviços de vigilância | R$ 47.971.311,01 | 28/12/2026 | 52 |
| 2024000555 | CEASA-RJ | EMSIMEM MANUTENÇÃO E CONSERVAÇÃO LTDA ME | Contratação de empresa especialiada em serviços de engenharia | R$ 11.553.390,00 | 01/01/2027 | 56 |
| 2024000733 | CEASA-RJ | PLENA LOCACAO E SERVICOS EIRELI ME | Contratação de empresa especialiada de serviços de circuito interno d… | R$ 1.579.307,82 | 01/01/2027 | 56 |
| 2024000734 | CEASA-RJ | JRF MANUTENCAO E SERVICOS EIRELI ME | Contratação de empresa especialiada em serviços de coleta de lixo | R$ 69.234.774,90 | 01/01/2027 | 56 |
| 2024000735 | CEASA-RJ | EMSIMEM MANUTENÇÃO E CONSERVAÇÃO LTDA ME | Contratação de empresa especialiada em serviços de coleta de lixo | R$ 7.553.948,49 | 01/01/2027 | 56 |
| 2024000736 | CEASA-RJ | SERG BRASIL MANUTENCAO E SERVICOS EIRELI ME | Contratação de empresa especialiada em controle de veículos | R$ 6.801.332,43 | 01/01/2027 | 56 |
| 2026001824 | EMATER-RIO | EMPRESA UNIDA MANSUR & FILHOS LTDA | Fornecimento do vale-transporte | R$ 31.355,76 | 01/01/2027 | 56 |
| 2026001825 | EMATER-RIO | VIAÇÃO VALE DO PIRANGA LTDA | Fornecimento do vale-transporte | R$ 3.985,56 | 01/01/2027 | 56 |
| 2026001830 | EMATER-RIO | CBD BOLHETE DIGITAL S/A | Fornecimento do vale-transporte | R$ 64.225,20 | 01/01/2027 | 56 |
| 2026005330 | CEASA-RJ | AKRON CONTROLE PROFISSIONAL DE PRAGAS LTDA-ME | 1- SERVIÇOS DE DEDETIZAÇÃO, DESCRIÇÃO: CONTRATAÇÃO DE EMPRESA ESPECIA… | R$ 378.841,26 | 03/01/2027 | 58 |
| 2024000557 | CEASA-RJ | OK ITAOCARA PROVEDOR INTERNET LTDA | Contratação de link de comunicação de dados para interligação a inter… | R$ 14.220,00 | 04/01/2027 | 59 |
| 2026006379 | PESAGRO-RIO | OTONI SEGURANÇA E SERVIÇOS LTDA | Contratação de serviços de Vigilância Patrimonial a ser prestado por … | R$ 164.480,04 | 06/01/2027 | 61 |
| 2026000011 | CEASA-RJ | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação de empresa especializada em prestação de serviços de hosp… | R$ 10.212,00 | 08/01/2027 | 63 |
| 2026001574 | CEASA-RJ | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | 1- SRVIÇOS DE PUBLICAÇÃO, DESCRIÇÃO: | R$ 100.000,00 | 11/01/2027 | 66 |
| 2021002298 | CEASA-RJ | CENTRO INTEGRADO DE ESTUDOS E PROGRAMAS DE D… | CONTRATAÇÃO DE EMPRESA PRESTADORA DE SERVIÇO DE APOIO AS ATIVIDADES A… | R$ 2.390.014,08 | 27/01/2027 | 82 |
| 2026000119 | CEASA-RJ | CBD BOLHETE DIGITAL S/A | Contratação de Empresa Especializada para Prestação de Serviços de Fo… | R$ 360.000,00 | 29/01/2027 | 84 |
| 2026000124 | CEASA-RJ | MAIS MOBI SERVICOS LTDA | 1-SERVIÇO DE FORNECIMENTO/RECARGA VALE TRANPORTE, DESCRIÇÃO: CONTRATA… | R$ 36.000,00 | 29/01/2027 | 84 |
| 2026000125 | CEASA-RJ | MAIS MOBI SERVICOS LTDA | Contratação de Empresa Especializada para Prestação de Serviços de Fo… | R$ 420.000,00 | 29/01/2027 | 84 |
| 2026006158 | CEASA-RJ | PLUXEE BENEFICIOS BRASIL S.A. | CONTRATAÇÃO DE EMPRESA ESPECIALIZADANO VALE ALIMENTAÇÃO E REFEIÇÃO. | R$ 3.169.059,00 | 30/01/2027 (PNCP) | 85 |
| 2024000796 | SEAPPA | BRS SUPRIMENTOS CORPORATIVOS S/A | SERVICOS DE APOIO AS ATIVIDADES ADMINISTRATIVAS, TECNICAS EOPERACIONA… | R$ 1.372.682,00 | 01/02/2027 | 87 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000099 | FUNDEAGRO | BIOLOGISTICA SOLUCOES EM LOGISTICA E SERVICO… | Contratação tem por objetivo a contratação de empresa para realizar o… | R$ 111.400,34 | 05/02/2027 | 91 |
| 2026000116 | CEASA-RJ | LIGHT SERVICOS DE ELETRICIDADE SA | CONTRATACAO DE EMPRESA PARA PRESTACAO DE SERVICOS DE FORNECIMENTO DE … | R$ 23.000.000,00 | 06/02/2027 (PNCP) | 92 |
| 2026000117 | CEASA-RJ | AGUAS DO RIO 1 SPE S.A | CONTRATACAO DE EMPRESA PARA PRESTACAO DE SERVICOS DE FORNECIMENTO DE … | R$ 600.000,00 | 06/02/2027 (PNCP) | 92 |
| 2026000122 | CEASA-RJ | IGUA RIO DE JANEIRO S.A. | CONTRATACAO DE EMPRESA CONCESSIONARIA PARAPRESTACAO DE SERVICOS DE AB… | R$ 23.170,97 | 06/02/2027 | 92 |
| 2026000118 | CEASA-RJ | AGUAS DO RIO 4 SPE S.A | CONTRATACAO DE EMPRESA PARA PRESTACAO DE SERVICOS DE FORNECIMENTO DE … | R$ 3.800.000,00 | 09/02/2027 (PNCP) | 95 |
| 2026000120 | CEASA-RJ | ENERGISA NOVA FRIBURGO DISTRIBUIDORA DE ENER… | CONTRATACAO DE EMPRESA PARA PRESTACAO DE SERVICOSDE FORNECIMENTO DE E… | R$ 255.326,10 | 09/02/2027 | 95 |
| 2026000123 | CEASA-RJ | RIO + SANEAMENTO BL3 S.A | CONTRATACAO DE EMPRESA PARA PRESTACAO DE SERVICOS DE FORNECIMENTO DE … | R$ 26.358,78 | 09/02/2027 | 95 |
| 2026000126 | CEASA-RJ | AMPLA ENERGIA E SERVIÇOS S/A | CONTRATACAO DE EMPRESA PARA PRESTACAO DE SERVICOS DE FORNECIMENTO DE … | R$ 104.695,20 | 09/02/2027 | 95 |
| 2026000631 | FIPERJ | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação de serviço de hospedagem em Servidores Virtuais Privados … | R$ 38.772,24 | 10/02/2027 | 96 |
| 2026000670 | CEASA-RJ | LIGHT SERVICOS DE ELETRICIDADE SA | 1-FORNECIMENTO DE ENERGIA ELETRICA, DESCRIÇÃO: CONTRATAÇÃO DE EMPRESA… | R$ 82.753,10 | 10/02/2027 | 96 |
| 2026000729 | FIPERJ | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Projeto Novo Portal FIPERJ | R$ 34.482,96 | 10/02/2027 | 96 |
| 2025000758 | CEASA-RJ | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | Contratação de instituição Especializada em Execução de Serviços de S… | R$ 21.191,52 | 13/02/2027 | 99 |
| 2025001079 | CEASA-RJ | VICMA COMERCIO DE EQUIPAMENTOS PARA ESCRITÓR… | SERVIÇOS DE LOCAÇÃO DE MAQUINAS E EQUIPAMENTOS REPOGRAFICOS, DESCRIÇÃ… | R$ 89.400,00 | 21/02/2027 | 107 |
| 2026000647 | CEASA-RJ | SEGUROS SURA S.A. | Contratação de empresa especializada na prestação de seguro total de … | R$ 3.100,00 | 23/02/2027 | 109 |
| 2026000128 | CEASA-RJ | AGUAS DO RIO 1 SPE S.A | CONTRATACAO DE EMPRESA CONCESSIONARIA PARAPRESTACAO DE SERVICOS DE AB… | R$ 20.679,11 | 23/02/2027 | 109 |
| 2026000988 | CEASA-RJ | AMPLA ENERGIA E SERVIÇOS S/A | 1-FORNECIMENTO DE ENERGIA ELETRICA, DESCRIÇÃO: CONTRATAÇÃO DE EMPRESA… | R$ 127.007,91 | 23/02/2027 | 109 |
| 2026000798 | CEASA-RJ | EMPRESA BRASILEIRA DE CORREIOS E TELEGRAFOS | 1- SERVIÇOS DE CORREIOS E TELEGRAFOS, DESCRIÇÃO: CONTRATAÇAO DE EMPRE… | R$ 34.800,00 | 26/02/2027 | 112 |
| 2023001612 | CEASA-RJ | JFA MANUTENÇAO E SERVIÇOS EIRELI | Contratação de Mão de Obra Terceiriada | R$ 5.445.738,40 | 28/02/2027 | 114 |
| 2026001360 | CEASA-RJ | FACULDADES CATOLICAS | 1-COMPRA DE VAGAS EM CURSOS , DESCRIÇÃO MPRA DE VAGAS EM CURSO OFEREC… | R$ 10.487,10 | 03/03/2027 | 117 |
| 2026001386 | CEASA-RJ | SOCIEDADE DE ENSINO SUPERIOR ESTACIO DE SA L… | 1-COMPRA DE VAGAS EM CURSOS, DESCRIÇÃO: COMPRA DE VAGAS EM CURSO OFER… | R$ 1.931,43 | 03/03/2027 | 117 |
| 2026001662 | SEAPPA | BWL TRANSPORTES E LOCAÇÕES EIRELI | AQUISIÇÃO DE MATERIAL DE CONSUMO (BRITA CORRIDA) | R$ 892.212,75 | 10/03/2027 | 124 |
| 2026003790 | PESAGRO-RIO | IMPRENSA NACIONAL | Despesa com publicações no Diário Oficial da União junto à Imprensa N… | R$ 2.000,00 | 10/03/2027 | 124 |
| 2026000845 | FIPERJ | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação de fornecimento de energia elétrica através da LIGHT. | R$ 40.000,00 | 13/03/2027 | 127 |
| 2026000846 | FIPERJ | AMPLA ENERGIA E SERVIÇOS S/A | Contratação de fornecimento de energia elétrica através daENEL/AMPLA. | R$ 40.000,00 | 13/03/2027 | 127 |
| 2026003852 | CEASA-RJ | PLENA LOCACAO E SERVICOS EIRELI ME | Serviços de recuperação e reforma de bens imoveis, descrição: Contrat… | R$ 7.380.000,00 | 14/03/2027 (PNCP) | 128 |
| 2023003124 | CEASA-RJ | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | SERVICOS DE INFRAESTRUTURA EM TECNOLOGIA DA INFORMACAO: PLANO DE HOSP… | R$ 155.880,00 | 30/03/2027 | 144 |
| 2026002020 | FIPERJ | UNIMAC UNIVERSO DAS MAQUINAS LTDA | Aquisição por Pregão Eletrônico por Sistema de Registro de Preços, de… | R$ 122.056,90 | 09/04/2027 | 154 |
| 2026002024 | FIPERJ | SOBERANA COMERCIO E SERVIÇOS LTDA | Aquisição por Pregão Eletrônico por Sistema de Registro de Preços, de… | R$ 945.778,53 | 09/04/2027 (PNCP) | 154 |
| 2026002025 | FIPERJ | PROSAFE INDUSTRIA E COMERCIO DE ROUPAS PROFI… | aquisição de Equipamentos de Proteção Individual (EPIs) | R$ 144.645,60 | 09/04/2027 | 154 |
| 2026002052 | FIPERJ | ASSOCIAÇÃO BRASILEIRA DAS ENTIDADES ESTADUAI… | O presente processo tem por objeto o pagamento de mensalidade de asso… | R$ 33.000,00 | 09/04/2027 | 154 |
| 2026000258 | PESAGRO-RIO | AGUAS DE NITEROI S/A | Serviço de fornecimento de agua e tratamento de esgoto. | R$ 54.000,00 | 17/04/2027 | 162 |
| 2026000292 | PESAGRO-RIO | COMPANHIA ESTADUAL DE AGUAS E ESGOTOS-CEDAE | Fornecimento de água e tratamento de esgoto para o Laboratório de Sol… | R$ 2.520,00 | 17/04/2027 | 162 |
| 2026000298 | PESAGRO-RIO | LIGHT SERVICOS DE ELETRICIDADE SA | Fornecimento de energia elétrica, através da Light Serviços de Eletri… | R$ 58.800,00 | 17/04/2027 | 162 |
| 2026000329 | PESAGRO-RIO | CBD BOLHETE DIGITAL S/A | Aquisição de vale-transporte em cartão magnético. | R$ 13.550,28 | 17/04/2027 | 162 |
| 2026000330 | PESAGRO-RIO | FEDERACAO DAS EMPRESAS DE TRANSPORTE DE PASS… | Beneficio de vale transporte. | R$ 156.000,00 | 17/04/2027 | 162 |
| 2026000380 | PESAGRO-RIO | COMPANHIA DISTRIBUIDORA DE GAS DO RIO DE JAN… | : Fornecimento de gás canalizado, através da Companhia Distribuidora … | R$ 13.200,00 | 17/04/2027 | 162 |
| 2026000381 | PESAGRO-RIO | AGUAS DO RIO 1 SPE S.A | Serviço de fornecimento de agua e tratamento de esgoto. | R$ 7.200,00 | 17/04/2027 | 162 |
| 2026000382 | PESAGRO-RIO | RIO + SANEAMENTO BL3 S.A | Fornecimento de Água e Tratamento de Esgoto - Rio + Saneamento BL3 S.A | R$ 122.400,00 | 17/04/2027 | 162 |
| 2026000383 | PESAGRO-RIO | BRK AMBIENTAL MACAÉ S.A | Fornecimento de Água e Tratamento de Esgoto - BRK AMBIETAL | R$ 11.760,00 | 17/04/2027 | 162 |
| 2026000384 | PESAGRO-RIO | AGUAS DO PARAIBA SA | Fornecimento de água e tratamento de esgoto para o Centro Estadual de… | R$ 112.800,00 | 17/04/2027 | 162 |
| 2026000424 | PESAGRO-RIO | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Publicações no Diário Oficial do Estado do Rio de Janeiro, através da… | R$ 25.200,00 | 17/04/2027 | 162 |
| 2026000426 | PESAGRO-RIO | AMPLA ENERGIA E SERVIÇOS S/A | Fornecimento de energia elétrica, através da Ampla Energia e Serviços… | R$ 121.200,00 | 17/04/2027 | 162 |
| 2025003931 | PESAGRO-RIO | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Prestação de serviço para Diretório Secundário (Microsoft Active Dire… | R$ 42.180,24 | 19/04/2027 | 164 |
| 2023003106 | PESAGRO-RIO | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | Registro de preços visando a contratação de empresa especialiada na p… | R$ 402.588,00 | 27/04/2027 | 172 |
| 2026006482 | PESAGRO-RIO | TRANSFER SERVIÇOS DE ENERGIA LTDA | Locação de aparelhos de nobreak | R$ 21.000,00 | 28/04/2027 | 173 |
| 2025001987 | EMATER-RIO | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | contratação de Entidade Sem Fins Lucrativos, inscrita e aprovada no C… | R$ 328.930,56 | 29/04/2027 | 174 |
| 2022008714 | PESAGRO-RIO | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Fornecimento de Combustível TRIVALE | R$ 1.590.000,92 | 30/04/2027 | 175 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2022007182 | SEAPPA | CONPLAN EMPREENDIMENTOS E SERVIÇOS LTDA-ME | Contratação para prestação de serviços de locação de máquinas, caminh… | R$ 60.282.000,00 | 22/09/2025 | -410 |
| 2022006734 | SEAPPA | ABBM BRAGA COMERCIO E SERVIÇOS LTDA ME | Contratação de empresa para prestação de serviços de locação de máqui… | R$ 29.391.675,99 | 09/09/2025 | -423 |
| 2022006957 | SEAPPA | G S GOUVEA DISTRIBUIDORA E SERVIÇOS EIRELI | contratação para prestação de serviços de locação de máquinas, caminh… | R$ 26.102.699,25 | 18/09/2025 | -414 |
| 2021003605 | CEASA-RJ | PLUXEE BENEFICIOS BRASIL S.A. | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA CONFECÇÃO, FORNECIMENTO E A… | R$ 24.990.894,72 | 09/07/2026 | -120 |
| 2022008997 | SEAPPA | LOCTECH LOCAÇÃO DE MÁQUINAS E EQUIPAMENTOS L… | Contratação para prestação de serviços de locação de máquinas, caminh… | R$ 15.713.466,25 | 07/11/2025 | -364 |
| 2022002862 | SEAPPA | CIAP TERRAPLANAGEM EIRELI EPP | CONTRATAÇÃO DE EMPRESA INSCRITA NO CADASTRO RESERVA, ATRAVÉS DA ATA 0… | R$ 15.290.816,69 | 28/10/2025 | -374 |
| 2025001028 | CEASA-RJ | LIGHT SERVICOS DE ELETRICIDADE SA | FORNECIMENTO DE ENERGIA ELETRICA,DESCRIÇÃO: CONTRATACAODE EMPRESA PAR… | R$ 15.000.000,00 | 20/02/2026 (PNCP) | -259 |
| 2024009942 | EMATER-RIO | BELLAMAR PARTICIPAÇÕES E NEGÓCIOS LTDA | o registro de preços para a eventual contratação de prestação de serv… | R$ 12.545.800,00 | 27/12/2025 (PNCP) | -314 |
| 2024008264 | SEAPPA | W O MAGALHÃES - ME | Prestação de serviços de locação de máquinas, caminhões e equipamento… | R$ 12.273.997,02 | 19/09/2025 | -413 |
| 2025004120 | EMATER-RIO | W O MAGALHÃES - ME | O presente termo tem por objetivo nortear os licitantes quanto às esp… | R$ 12.273.997,02 | 20/05/2026 | -170 |
| 2022007270 | SEAPPA | INVICTA COMERCIAL E SERVIÇOS LTDA | Contratação de empresa para prestação de serviços de locação de máqui… | R$ 11.249.999,94 | 27/09/2025 | -405 |
| 2023009843 | SEAPPA | RPS EMPRESARIAL SERVICOS E LOCACAO LTDA | Prestação de serviços de locação de máquinas caminhões e equipamentos… | R$ 10.036.125,00 | 19/09/2025 | -413 |
| 2023004969 | SEAPPA | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | Contratação de empresa para prestação de serviços de locação de máqui… | R$ 9.711.701,22 | 15/05/2025 | -540 |
| 2023005731 | SEAPPA | INDUSTRIA E COMERCIO DE PEDRAS VALE ALPINO | Fornecimento de brita corrida COTA RESERVADA e AMPLA CONCORRÊNCIA par… | R$ 9.298.579,95 | 25/07/2025 | -469 |
| 2025006356 | SEAPPA | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | ADESÃO A ATA DE REGISTRO DE PREÇOS Nº 001/2025 -GABINETE DE SEGURANÇA… | R$ 8.906.300,00 | 19/08/2026 (PNCP) | -79 |
| 2022002511 | SEAPPA | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | LOCAÇÃO DE MÁQUINAS E EQUIPAMENTOS PARA RECUPERAÇÃO E MANUTENÇÃO DE E… | R$ 8.697.828,99 | 13/10/2025 | -389 |
| 2025007682 | PESAGRO-RIO | FUNDACAO SOCIAL, CULTURAL E EDUCATIVA REDE C… | Viabilizar a contratação POR INEXIGIBILIDADE, da FUNDAÇÃO SOCIAL, CUL… | R$ 8.500.000,00 | 24/11/2025 (PNCP) | -347 |
| 2023009079 | PESAGRO-RIO | FUNDAÇÃO DE APOIO À BIODIVERSIDADE SÃO FRANC… | Contratação de prestador de serviços para a gestão e execução do Magr… | R$ 8.497.282,57 | 30/10/2026 | -7 |
| 2024007569 | SEAPPA | J R V EMPREENDIMENTOS - EIRELI - ME | Prestação de serviços de locação de máquinas, caminhões e equipamento… | R$ 7.392.052,11 | 15/09/2025 | -417 |
| 2024008261 | SEAPPA | DESTAQUE CONSTRUTORA EIRELI | Prestação de serviços de locação de máquinas, caminhões e equipamento… | R$ 7.266.304,09 | 10/09/2025 | -422 |
| 2024001827 | SEAPPA | BWL TRANSPORTES E LOCAÇÕES EIRELI | Prestação de serviços de locação de máquinas, caminhões e equipamento… | R$ 7.184.854,06 | 10/03/2025 | -606 |
| 2024004548 | SEAPPA | JAS LOGÍSTICA LTDA | Locação de máquinas, caminhões e equipamentos para desobstrução, limp… | R$ 7.069.499,64 | 20/06/2025 | -504 |
| 2024006685 | EMATER-RIO | INDUSTRIA E COMERCIO DE PEDRAS VALE ALPINO | Contratação de empresa para fornecimento de Brita/ Pedra. | R$ 7.011.255,12 | 06/08/2025 | -457 |
| 2025005518 | FIPERJ | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | Adesão à Ata de Registro de Preços elaborada pela Secretaria de Estad… | R$ 6.554.872,70 | 11/08/2026 (PNCP) | -87 |
| 2023010768 | SEAPPA | BELLAMAR PARTICIPAÇÕES E NEGÓCIOS LTDA | Fornecimento de brita corrida COTA RESERVADA e AMPLA CONCORRÊNCIA par… | R$ 6.479.665,20 | 19/12/2024 | -687 |
| 2024007147 | EMATER-RIO | BELLAMAR PARTICIPAÇÕES E NEGÓCIOS LTDA | Contratação de empresa para fornecimento de Brita/ Pedra. | R$ 6.479.665,20 | 21/08/2025 | -442 |
| 2023005765 | SEAPPA | GLX DE ITAOCARA COMERCIO E SERVIÇOS EIRELI | AQUISIÇÃO DE BRITA CORRIDA PARA RECUPERAÇÃO DE ESTRADAS VICINAIS VINC… | R$ 6.398.475,24 | 24/07/2025 | -470 |
| 2024002093 | SEAPPA | FARAO PARTICIPAÇÕES E EMPREENDIMENTOS LTDA | : Prestação de serviços de locação de máquinas,caminhões e equipament… | R$ 6.199.500,00 | 18/03/2025 | -598 |
| 2023010763 | SEAPPA | MINERAÇÃO SANTA LUZIA DE ITAGUAÍ LTDA. | AQUISIÇÃO DE BRITA ATRAVÉS DA ATA DE REGISTRO DE PREÇOS 0622023 | R$ 6.089.930,00 | 19/12/2024 | -687 |
| 2025005299 | PESAGRO-RIO | MMAR MONTAGENS EVENTOS E PROGRAMACAO VISUAL … | Viabilizar a contratação POR INEXIGIBILIDADE, da empresa MMAR MONTAGE… | R$ 5.491.200,00 | 13/11/2025 (PNCP) | -358 |

_Registros mais antigos (provável falta de baixa no SIGA): 1968, R$ 1.280,9 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024000734 | CEASA-RJ | JRF MANUTENCAO E SERVICOS EIRELI ME | Contratação de empresa especialiada em serviços de coleta de lixo | R$ 69.234.774,90 | 01/01/2027 | 56 |
| 2024000556 | CEASA-RJ | PLIMA VIGILANCIA E SEGURANCA PRIVADA LTDA ME | Contratação de empresa especialiada em serviços de vigilância | R$ 47.971.311,01 | 28/12/2026 | 52 |
| 2023009061 | PESAGRO-RIO | FUNDAÇÃO DE APOIO A PESQUISA, ENSINO E ASSIS… | Contratação de prestador de serviços para a gestão e execução do Prog… | R$ 45.181.028,00 | 30/10/2027 | 358 |
| 2025004153 | EMATER-RIO | ENGECON CONSTRUÇÕES E SERVIÇOS DE ENGENHARIA… | CONTRATAÇÃO DE EMPRESA ESPECIALIZ. P/EVENTUAL E FUTURA PREST. SERV. D… | R$ 44.660.000,00 | — |  |
| 2024007423 | CEASA-RJ | EMSIMEM MANUTENÇÃO E CONSERVAÇÃO LTDA ME | 1- SERVIÇOS DE ENGENHARIA , DESCRIÇÃO: CONTRATAÇÃO DE EMPRESA ESPECIA… | R$ 36.640.387,25 | 05/09/2027 | 303 |
| 2026000116 | CEASA-RJ | LIGHT SERVICOS DE ELETRICIDADE SA | CONTRATACAO DE EMPRESA PARA PRESTACAO DE SERVICOS DE FORNECIMENTO DE … | R$ 23.000.000,00 | 06/02/2027 (PNCP) | 92 |
| 2024000555 | CEASA-RJ | EMSIMEM MANUTENÇÃO E CONSERVAÇÃO LTDA ME | Contratação de empresa especialiada em serviços de engenharia | R$ 11.553.390,00 | 01/01/2027 | 56 |
| 2026001040 | FIPERJ | GRUPO SBV EMPREENDIMENTOS E PARTICIPAÇÕES | Contratação, em Sistema de Registro de Preços, de empresa especializa… | R$ 10.900.000,00 | 07/05/2027 | 182 |
| 2024007681 | CEASA-RJ | DB2 ENGENHARIA LTDA | Item Valor Unitário Quantidade1 - SERVICOS DE LIMPEZA SISTEMA DE ESGO… | R$ 10.119.275,24 | 01/09/2027 | 299 |
| 2025005321 | CEASA-RJ | RESBRITEC CONSTRUÇÕES COMÉRCIO E SERVIÇOS LT… | Contratação de Empresa Especializada para Execução de Obras Civis com… | R$ 9.890.000,00 | 30/11/2026 | 24 |
| 2024005014 | PESAGRO-RIO | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de Serviços de Fornecimento de Vale Alimentação na modali… | R$ 9.102.681,43 | 26/06/2027 | 232 |
| 2025010209 | SEAPPA | MULTIPLAR ENGENHARIA E LOCACOES LTDA | contratação de empresa para a prestação de serviços de locação de máq… | R$ 8.339.110,63 | 10/12/2026 (PNCP) | 34 |
| 2021007622 | CEASA-RJ | ASSOCIAÇÃO NITEROIENSE DOS DEFICIENTES FISIC… | Contratação de mão de obra terceirizada. | R$ 7.586.811,96 | 21/12/2026 | 45 |
| 2024000735 | CEASA-RJ | EMSIMEM MANUTENÇÃO E CONSERVAÇÃO LTDA ME | Contratação de empresa especialiada em serviços de coleta de lixo | R$ 7.553.948,49 | 01/01/2027 | 56 |
| 2026003852 | CEASA-RJ | PLENA LOCACAO E SERVICOS EIRELI ME | Serviços de recuperação e reforma de bens imoveis, descrição: Contrat… | R$ 7.380.000,00 | 14/03/2027 (PNCP) | 128 |
| 2026003916 | SEAPPA | FLC LOCAÇOES E TRANSPORTES LTDA | Contratação de empresa para a prestação de serviços de locação de máq… | R$ 7.366.673,52 | 22/05/2027 | 197 |
| 2024000736 | CEASA-RJ | SERG BRASIL MANUTENCAO E SERVICOS EIRELI ME | Contratação de empresa especialiada em controle de veículos | R$ 6.801.332,43 | 01/01/2027 | 56 |
| 2024000036 | CEASA-RJ | JRF MANUTENCAO E SERVICOS EIRELI ME | Contratação de empresa especialiada em serviços de limpea e higieniaç… | R$ 6.230.528,55 | 28/12/2026 | 52 |
| 2025005254 | PESAGRO-RIO | ASSOCIACAO FACULDADE INSTITUTO UNIVERSITARIO… | Contratação de Organização da Sociedade Civil para prestação de servi… | R$ 5.800.000,00 | 04/08/2028 | 637 |
| 2023010241 | CEASA-RJ | MODERA ENGENHARIA LTDA | Contratação de empresa especialiada de serviços de apoio as atividade… | R$ 5.598.251,20 | 30/11/2026 | 24 |

## 7. Fornecedores em recuperação judicial
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2022002511 | SEAPPA | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | LOCAÇÃO DE MÁQUINAS E EQUIPAMENTOS PARA RECUPERAÇÃO E MANUTENÇÃO DE E… | R$ 8.697.828,99 | 13/10/2025 | -389 |

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| JRF MANUTENCAO E SERVICOS EIRELI ME | 2 | R$ 75.465.303,45 |
| EMSIMEM MANUTENÇÃO E CONSERVAÇÃO LTDA ME | 3 | R$ 55.747.725,74 |
| PLIMA VIGILANCIA E SEGURANCA PRIVADA LTDA ME | 1 | R$ 47.971.311,01 |
| FUNDAÇÃO DE APOIO A PESQUISA, ENSINO E ASSISTENCIA A ESCOLA… | 2 | R$ 46.949.961,17 |
| ENGECON CONSTRUÇÕES E SERVIÇOS DE ENGENHARIA EIRELI | 1 | R$ 44.660.000,00 |
| LIGHT SERVICOS DE ELETRICIDADE SA | 4 | R$ 23.181.553,10 |
| GRUPO SBV EMPREENDIMENTOS E PARTICIPAÇÕES | 1 | R$ 10.900.000,00 |
| DB2 ENGENHARIA LTDA | 1 | R$ 10.119.275,24 |
| RESBRITEC CONSTRUÇÕES COMÉRCIO E SERVIÇOS LTDA | 1 | R$ 9.890.000,00 |
| LECARD ADMNISTRADORA DE CARTÕES LTDA | 1 | R$ 9.102.681,43 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2022001925 | CLINICA VETERINARIA RICARDO LTDA | R$ 6.992.614,20 | R$ 0,00 | R$ 6.992.614,20 |
| 2022008314 | BASE MONTAGENS E SERVIÇOS PROMOCIONAIS LTDA | R$ 3.501.680,00 | R$ 0,00 | R$ 3.501.680,00 |
| 2022005914 | MAJU PET SHOP E VETERINARIA LTDA | R$ 2.680.000,00 | R$ 0,00 | R$ 2.680.000,00 |
| 2022005328 | CONSUVET - SOLUÇÕES EM SAÚDE ANIMAL LTDA | R$ 2.347.434,92 | R$ 0,00 | R$ 2.347.434,92 |
| 2021001809 | DIMENSIONAL ENGENHARIA LTDA | R$ 3.668.118,55 | R$ 1.327.708,29 | R$ 2.340.410,26 |
| 2022005159 | FUNDAÇÃO DE APOIO A PESQUISA, ENSINO E ASSIS… | R$ 1.960.000,00 | R$ 0,00 | R$ 1.960.000,00 |
| 2018007059 | ATAC FIRE EXTINTORES COMERCIO E SERVIÇOS LTDA | R$ 11.981.319,48 | R$ 10.257.926,55 | R$ 1.723.392,93 |
| 2022006305 | MAJU PET SHOP E VETERINARIA LTDA | R$ 1.543.524,00 | R$ 0,00 | R$ 1.543.524,00 |
| 2020000513 | CONSTRUMAX DE ITAOCARA CONSTRUÇÃO REFORMA E … | R$ 3.172.063,09 | R$ 2.060.117,87 | R$ 1.111.945,22 |
| 2021007663 | SIGIL SOCIEDADE INDUSTRIAL DE GRANITOS LTDA | R$ 1.195.697,32 | R$ 165.191,30 | R$ 1.030.506,02 |
| 2020000510 | FERNANDES & FERNANDES ATIVIDADES PAISAGISTIC… | R$ 3.221.505,23 | R$ 2.362.397,59 | R$ 859.107,64 |
| 2023005765 | GLX DE ITAOCARA COMERCIO E SERVIÇOS EIRELI | R$ 2.318.279,04 | R$ 1.604.793,54 | R$ 713.485,50 |
| 2023007134 | GRUPO SBV EMPREENDIMENTOS E PARTICIPAÇÕES | R$ 2.374.978,00 | R$ 1.757.139,88 | R$ 617.838,12 |
| 2021003908 | LIMPPAR CONSTRUCAO E SERVICOS LTDA | R$ 1.193.858,89 | R$ 650.588,48 | R$ 543.270,41 |
| 2021003605 | PLUXEE BENEFICIOS BRASIL S.A. | R$ 4.940.165,96 | R$ 4.436.720,63 | R$ 503.445,33 |
| 2022002084 | AGUAS DO RIO 1 SPE S.A | R$ 485.870,61 | R$ 5.870,61 | R$ 480.000,00 |
| 2021007659 | DIMENSIONAL ENGENHARIA LTDA | R$ 640.976,72 | R$ 166.970,03 | R$ 474.006,69 |
| 2021006210 | CONSUVET - SOLUÇÕES EM SAÚDE ANIMAL LTDA | R$ 882.819,00 | R$ 453.522,51 | R$ 429.296,49 |
| 2021003927 | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | R$ 1.680.221,09 | R$ 1.288.305,83 | R$ 391.915,26 |
| 2022003247 | CIRAC-CENTRO INTEGRADO DE RECOLHIMENTO, ASSI… | R$ 317.055,06 | R$ 0,00 | R$ 317.055,06 |

## 11. Unidades incluídas neste dossiê
- CASERJ - COMPANHIA DE ARMAZÉNS E SILOS DO EST DO RJ
- CEASA-RJ - CENTRAIS DE ABASTECIMENTO DO ESTADO DO RJ
- EMATER-RIO - EMPR DE ASSIST TÉCN E EXT RURAL DO EST DO RJ
- FIPERJ - FUNDACAO INSTITUTO DE PESCA DO ESTADO DO RJ
- FUNDEAGRO  - Fundo Estadual de Defesa Agropecuária
- FUNDEAGRO - FUNDO ESTADUAL DE DEFESA AGROPECUÁRIA
- PESAGRO-RIO - EMPR DE PESQUISA AGROPECUÁRIA DO EST DO RJ
- SEAPPA - GES/SP - SEAAPI-PROJETO RIO RURAL/GES-SEP
- SEAPPA - Secretaria de Estado de Agricultura, Pecuária, Pesca e Abastastecimento
- SEDRAP - SEC EST DESEN REG  ABASTEC E PESCA

## 12. Conjuntos de dados abertos da secretaria
- PEDTIC SEAPA (atualizado 2026-07-09): [PEDTIC_SEAPPA_2025.pdf PDF](https://dadosabertos.rj.gov.br/dataset/055d7635-cf96-4dab-bfbf-ebada2dbdad1/resource/e3303a64-b60f-495e-a565-66dbb2d463ab/download/pedtic_seappa_2025.pdf), [PEDTIC_SEAPPA_2024.pdf PDF](https://dadosabertos.rj.gov.br/dataset/055d7635-cf96-4dab-bfbf-ebada2dbdad1/resource/56321b16-c147-4e5a-b8e1-0151803c13f3/download/pedtic_seappa_2024_2027.pdf), [PEDTIC_SEAPPA_2020.pdf PDF](https://dadosabertos.rj.gov.br/dataset/055d7635-cf96-4dab-bfbf-ebada2dbdad1/resource/9b4b2857-743f-4267-b561-21729bac1963/download/sei_sei_020007_002181_2020___pdtic_seappa_2020_2021.pdf), [PEDTIC_SEAPA_2025_revisao.pdf PDF](https://dadosabertos.rj.gov.br/dataset/055d7635-cf96-4dab-bfbf-ebada2dbdad1/resource/fd958234-a2f0-4002-b263-c58dbe066150/download/pedtic-seappa-2025-revisao.pdf)
- Projeto Agropecuário Financiado - PEFATE (atualizado 2025-06-06): [Produto - 2561 - Projeto agropecuário f… XLSX](https://dadosabertos.rj.gov.br/dataset/d1e0c147-4dc0-439d-b6ba-7ee73a1bff3d/resource/46fb0c83-6209-4311-ae11-e0adfe960aa9/download/produto-2561-projeto-agropecuario-financiado.xlsx)
- Lista de Estabelecimentos Registrados no Serviço de Inspeção Estadual (SIE) - SUPDA (atualizado 2025-06-04): [LISTA DE ESTABELECIMENTOS REGISTRADO-RE… PDF](https://dadosabertos.rj.gov.br/dataset/2043680b-3a42-43c4-9616-a52f97602e8c/resource/2fca7253-c963-4b41-bb92-789889b30eec/download/lista-de-estabelecimentos-registrado-relacionados-cooipoa-20.05.25.pdf)
- Fiscalizações e vistorias Realizadas - SUPDA; (atualizado 2025-06-04): [Indicadores - 1 QUAD 2025 - Defesa Agro… XLSX](https://dadosabertos.rj.gov.br/dataset/6b21b9f9-4679-4305-89f6-03cee454f0b5/resource/22c13b76-7c65-4e6a-a692-c90916118f5e/download/indicadores-1-quad-2025-defesa-agropecuaria.xlsx)
- Número de Produtores Atendidos Pela Educação Sanitária - SUPDA; (atualizado 2025-06-04): [8493 - Produtor capacitado em Sanidade … XLSX](https://dadosabertos.rj.gov.br/dataset/c6928178-bbf3-4276-ba8f-ba7154c0b4d0/resource/ca8064a8-6cd3-48c9-b3bb-bd8077654550/download/8493-produtor-capacitado-em-sanidade-agropecuaria.xlsx)
- Projetos de Cadeias Produtivas - PEFATE (atualizado 2025-06-03): [Produto - 6742 - Projeto de Cadeias Pro… XLSX](https://dadosabertos.rj.gov.br/dataset/3997b558-04a1-4a8e-9665-ae4e924fba58/resource/d16e43ef-55a3-40bf-9c18-fd96258ab2d6/download/produto-6742-projeto-de-cadeias-produtivas-apoiado.xlsx)
- Produtor Capacitado Em Técnicas Agropecuárias E Comercialização - PEFATE (atualizado 2025-06-03): [Produto - 8490 - Produtor capacitado em… XLSX](https://dadosabertos.rj.gov.br/dataset/f960a539-8efb-4060-a728-20efc8b0f8f2/resource/444c972b-f852-4d4c-9e54-6937ba9c2693/download/produto-8490-produtor-capacitado-em-tecnicas-agropecuarias-e-comercializacao.xlsx)
- Número de Agroindústrias Registradas de produtos de origem animal - SUPDA (atualizado 2025-06-02): [2560 - Agroindústria inserida no mercad… XLSX](https://dadosabertos.rj.gov.br/dataset/d61de374-8103-4f47-b171-610894fbc032/resource/9e11171a-406f-4f82-bf52-d97f93bf7950/download/2560-agroindustria-inserida-no-mercado-formal.xlsx)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 5 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

- Em 27/10/2026, a Polícia Federal deflagrou a segunda fase da Operação Castratio para apurar suspeitas de irregularidades em contratos ligados à Secretaria, cujo valor total informado pela imprensa é de R$ 200 milhões. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/) [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- A PF investiga suspeitas de direcionamento, superfaturamento e fraude à licitação, sem que as fontes fornecidas relatem condenação ou conclusão definitiva sobre esses fatos. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/) [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- O governo informou que os serviços da Consuvet no programa RJ PET estavam extintos desde 2024, após auditoria da Secretaria de Saúde; as fontes não relatam risco atual de interrupção desses serviços. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- Em junho de 2026, a Secretaria informava planos de revisão contratual e economia, mas as fontes não esclarecem se as metas foram implementadas até 06/11/2026. [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/) [O Globo — corte nos contratos vigentes](https://oglobo.globo.com/blogs/ancelmo-gois/post/2026/06/governo-do-rio-preve-corte-de-12percent-nos-contratos-vigentes-da-secretaria-de-agricultura.ghtml)

##### Alertas vermelhos

- **Investigação criminal em andamento:** a segunda fase da Operação Castratio apura possível atuação de organização criminosa na Secretaria e suspeitas de direcionamento, superfaturamento e fraude à licitação; os fatos são investigados, não apresentados pelas fontes como ilícitos comprovados. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/)
- **Contratos de alto valor sob investigação:** a reportagem do G1 atribui à primeira fase da operação a apuração de irregularidades em contratos que totalizavam R$ 200 milhões, firmados com a Consuvet para castração e esterilização de animais. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- **Indícios relatados pela imprensa:** segundo o G1, a Consuvet foi criada três meses antes dos acordos, o comprovante usado para demonstrar capacidade de prestar o serviço teria sido emitido 17 meses antes da criação da empresa e o registro necessário no Conselho Regional de Medicina Veterinária teria sido obtido após a assinatura do contrato. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- **Agente público e movimentações financeiras sob suspeita:** o G1 relata que Antônio Emílio Santos, então diretor administrativo e financeiro da Secretaria, autorizou a abertura da licitação e depois se tornou sócio da Consuvet; relatórios de inteligência citados pela reportagem apontaram recebimentos de R$ 888 mil em oito meses e saque superior a R$ 700 mil em dezembro de 2023. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- **Busca e apreensão determinada pelo STF:** na segunda fase, foram cumpridos cinco mandados de busca e apreensão no Rio de Janeiro e em Niterói, expedidos pelo Supremo Tribunal Federal. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/)

##### Contratos e serviços críticos

- A reportagem do G1 identifica a Consuvet como a empresa privada contratada para serviços de castração e esterilização de animais e informa que os contratos investigados totalizavam R$ 200 milhões; as fontes não informam quantidade, números, valores individuais ou vigência contratual. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- A PF informou que os contratos foram firmados entre o Governo do Estado e uma empresa privada, mas não identificou a empresa nem detalhou número, valor individual ou vigência. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/)
- O governo declarou, segundo o G1, que os serviços da Consuvet no programa RJ PET, originalmente contratados pela Secretaria, estavam extintos desde 2024 após auditoria da Secretaria de Saúde. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- Em 08/06/2026, o governo do estado anunciou uma meta inicial de redução de 12% no valor dos contratos vigentes e a expectativa de reduzir em até 20% os custos administrativos; a economia estimada era de R$ 33,7 milhões ao longo dos 12 meses seguintes. [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/) [O Globo — corte nos contratos vigentes](https://oglobo.globo.com/blogs/ancelmo-gois/post/2026/06/governo-do-rio-preve-corte-de-12percent-nos-contratos-vigentes-da-secretaria-de-agricultura.ghtml)
- A Secretaria afirmou que a revisão seria conduzida sem reduzir o escopo dos serviços à população e preservando ações de apoio ao produtor rural; as fontes não confirmam o resultado final da revisão. [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/) [O Globo — corte nos contratos vigentes](https://oglobo.globo.com/blogs/ancelmo-gois/post/2026/06/governo-do-rio-preve-corte-de-12percent-nos-contratos-vigentes-da-secretaria-de-agricultura.ghtml)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- **Polícia Federal:** a primeira fase da Operação Castratio foi deflagrada em 12/05/2026 e a segunda em 27/10/2026; a PF informou que materiais obtidos na primeira fase motivaram a nova etapa. [PF — primeira fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/05/pf-combate-organizacao-criminosa-suspeita-de-fraudes-em-licitacoes-no-rio-de-janeiro) [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/)
- **MPRJ e Polícia Civil:** o G1 informa que ambos haviam identificado indícios de superfaturamento e direcionamento; as fontes não apresentam decisão final ou desfecho dessas apurações. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- **STF:** o Supremo expediu os mandados de busca e apreensão cumpridos nas duas fases da operação, conforme as notícias da PF; as fontes não detalham outras decisões judiciais nem eventual denúncia ou julgamento. [PF — primeira fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/05/pf-combate-organizacao-criminosa-suspeita-de-fraudes-em-licitacoes-no-rio-de-janeiro) [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/)
- **TCE-RJ e Controladoria:** a defesa de Marcelo Queiroz afirmou que os contratos passaram pelo controle do Tribunal de Contas e da Controladoria sem apontamento de irregularidade, mas o G1 não cita decisão específica do TCE-RJ, data ou resultado de julgamento. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- **TCE-RJ:** Nada encontrado nas fontes consultadas sobre decisão específica do Tribunal relativa aos contratos investigados. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)

##### Riscos de apagão administrativo

- Nada encontrado nas fontes consultadas que indique risco atual de interrupção de serviços; o governo declarou que os serviços da Consuvet no RJ PET estavam extintos desde 2024, e, segundo a equipe técnica responsável, a revisão contratual não previa redução do escopo dos serviços prestados à população. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml) [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/)
- Nada encontrado nas fontes consultadas sobre atrasos, crise operacional, dívidas ou passivos da Secretaria. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/) [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/)
- A revisão de contratos e a economia de R$ 33,7 milhões eram planos divulgados em junho de 2026, mas as fontes não informam se houve implementação, quais contratos foram revistos ou se houve impacto administrativo até 06/11/2026. [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/) [O Globo — corte nos contratos vigentes](https://oglobo.globo.com/blogs/ancelmo-gois/post/2026/06/governo-do-rio-preve-corte-de-12percent-nos-contratos-vigentes-da-secretaria-de-agricultura.ghtml)

##### Fatos recentes

- Em 27/10/2026, a PF deflagrou a segunda fase da Operação Castratio e cumpriu cinco mandados de busca e apreensão no Rio de Janeiro e em Niterói, por ordem do STF. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/)
- Na primeira fase, deflagrada em 12/05/2026, a PF cumpria 12 mandados de busca e apreensão; no estado do Rio, informou ações em Itaocara, Macaé, Niterói e na capital. [PF — primeira fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/05/pf-combate-organizacao-criminosa-suspeita-de-fraudes-em-licitacoes-no-rio-de-janeiro)
- Em 08/06/2026, notícias relataram que a Secretaria negociava reduções contratuais e buscava economizar R$ 33,7 milhões em 12 meses. [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/) [O Globo — corte nos contratos vigentes](https://oglobo.globo.com/blogs/ancelmo-gois/post/2026/06/governo-do-rio-preve-corte-de-12percent-nos-contratos-vigentes-da-secretaria-de-agricultura.ghtml)
- Em junho de 2026, o Tempo Real RJ informou que Felipe Brasil permanecia à frente da Secretaria após a saída do ex-secretário Dr. Flávio; as fontes não atualizam a titularidade da pasta até 06/11/2026. [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)

- Solicitar a relação integral dos contratos vigentes e encerrados relacionados à Consuvet e ao programa RJ PET, incluindo números, valores individuais, vigências, aditivos, pagamentos, entregas e responsáveis, pois as fontes não apresentam esses dados. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/) [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- Solicitar os resultados e documentos da auditoria da Secretaria de Saúde mencionada na notícia, além de informação sobre a situação atual dos serviços e eventual contratação substituta, pois a fonte apenas registra que os serviços da Consuvet estavam extintos desde 2024. [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- Solicitar o status atualizado das apurações da PF, do MPRJ e da Polícia Civil, bem como cópias ou referências a decisões do STF, do TCE-RJ e da Controladoria, pois as fontes consultadas não informam seus desfechos nem decisões específicas do TCE-RJ. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/) [G1 — Marcelo Queiroz é alvo da PF](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml)
- Solicitar a execução efetiva das metas de redução contratual anunciadas em junho de 2026, com contratos renegociados, economia realizada e impactos sobre serviços e políticas públicas, pois as notícias não atualizam esses resultados. [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/) [O Globo — corte nos contratos vigentes](https://oglobo.globo.com/blogs/ancelmo-gois/post/2026/06/governo-do-rio-preve-corte-de-12percent-nos-contratos-vigentes-da-secretaria-de-agricultura.ghtml)
- Solicitar posição atualizada sobre dívidas, passivos, atrasos de pagamento e riscos de interrupção de serviços, além da titularidade atual da Secretaria. As fontes não informam esses dados atualizados; a matéria do Tempo Real RJ registrava Felipe Brasil no comando da pasta na data da publicação. [PF — segunda fase da Operação Castratio](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/) [Tempo Real RJ — redução no valor dos contratos](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/)

##### Fontes consultadas
1. [PF apura irregularidades em contratos no Rio de Janeiro](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/10/pf-investiga-irregularidades-em-contratos-no-rio-de-janeiro/) — 2026-10-27
2. [PF apura suspeita de fraudes em licitações no Rio de Janeiro](https://www.gov.br/pf/pt-br/assuntos/noticias/2026/05/pf-combate-organizacao-criminosa-suspeita-de-fraudes-em-licitacoes-no-rio-de-janeiro) — 2026-05-12
3. [Marcelo Queiroz é alvo da PF em operação sobre castração de animais   G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/27/pf-deflagra-a-2a-fase-da-operacao-castratio.ghtml) — 2026-10-27
4. [Secretaria de Agricultura do estado anuncia redução no valor dos contratos; governo espera diminuir em até 20%](https://temporealrj.com/secretaria-de-agricultura-reduzir-20-custos/) — 2026-06-08
5. [Governo do Rio prevê corte de 12% nos contratos vigentes ...](https://oglobo.globo.com/blogs/ancelmo-gois/post/2026/06/governo-do-rio-preve-corte-de-12percent-nos-contratos-vigentes-da-secretaria-de-agricultura.ghtml) — 2026-06-08


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2024008782 (REDE NACIONAL DE APRENDIZAGEM, PROMOÇÃO…) vence em 06/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2026008921 (TOP MIX COMÉRCIO E SERVIÇOS LTDA) vence em 12/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2023010241 (MODERA ENGENHARIA LTDA) vence em 30/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2023010379 (CERTIFICA PARKING & FACILITIES LTDA) vence em 30/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025005321 (RESBRITEC CONSTRUÇÕES COMÉRCIO E SERVIÇ…) vence em 30/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2022007182 (CONPLAN EMPREENDIMENTOS E SERVIÇOS LTDA…, R$ 60,3 mi) consta 'Ativo' no SIGA com fim em 22/09/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2022006734 (ABBM BRAGA COMERCIO E SERVIÇOS LTDA ME, R$ 29,4 mi) consta 'Ativo' no SIGA com fim em 09/09/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2022006957 (G S GOUVEA DISTRIBUIDORA E SERVIÇOS EIR…, R$ 26,1 mi) consta 'Ativo' no SIGA com fim em 18/09/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2021003605 (PLUXEE BENEFICIOS BRASIL S.A., R$ 25,0 mi) consta 'Ativo' no SIGA com fim em 09/07/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2022008997 (LOCTECH LOCAÇÃO DE MÁQUINAS E EQUIPAMEN…, R$ 15,7 mi) consta 'Ativo' no SIGA com fim em 07/11/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Qual é o plano de contingência para o contrato 2022002511 com CONSTRUTORA LYTORANEA LTDA - EM RECUPER… (em recuperação judicial)? Garantia contratual está válida?
13. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
14. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
15. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
16. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
17. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
