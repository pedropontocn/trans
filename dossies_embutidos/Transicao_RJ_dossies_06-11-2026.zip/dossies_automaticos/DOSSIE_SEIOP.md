# Dossiê de transição — Secretaria de Estado de Infraestrutura e Obras Públicas (SEIOP)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/seiop)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 563 | R$ 5.806.301.170,75 |
| Com vigência futura (válidos no SIGA) | 54 | R$ 850.770.850,54 |
| até 30 dias | 1 | R$ 741.600,00 |
| até 60 dias | 2 | R$ 177.387,50 |
| até 90 dias | 3 | R$ 9.190.794,96 |
| até 180 dias | 19 | R$ 376.347.894,12 |
| vencido no SIGA | 509 | R$ 4.955.530.320,21 |
| sem data | 0 | R$ 0,00 |
| Fornecedores em recuperação judicial | 11 | R$ 328.652.231,06 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 1.609,6 mi / R$ 467,6 mi / R$ 420,6 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Mais 1 contratos menores (R$ 0,7 mi) vencem em até 30 dias — ver seção 3.
- 17 contratos (R$ 175,4 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 124 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 2.316,0 mi); 49 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 385 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 2.639,5 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Fornecedor em recuperação judicial: CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO JUDICIAL — 3 contrato(s), R$ 104,5 mi, último fim 29/08/2026.
- Fornecedor em recuperação judicial: CONSORCIO RECUPERACAO SERRA DE PARACAMBI — 1 contrato(s), R$ 72,7 mi, último fim 14/12/2025.

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2023005053 | SEIOP | REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | Locação de veículos automotores categoria Representação RP02 Modelo S… | R$ 741.600,00 | 14/11/2026 | 8 |
| 2025010020 | DER-RJ | PORTAL TRANSPORTE E COMÉRCIO DE RESÍDUOS E L… | SERVIÇO DE COLETA DE RESÍDUOS SÓLIDOS, URBANOS, INDUSTRIAL E ESPECIAL… | R$ 4.000,00 | 10/12/2026 | 34 |
| 2025010645 | SEIOP | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada paraconfecção, fornecimento e ad… | R$ 173.387,50 | 19/12/2026 | 43 |
| 2026000064 | DER-RJ | ELEVADORES ATLAS SCHINDLER LTDA. | Prestação de serviços de manutenção preventiva e corretiva de 04 (qua… | R$ 118.474,68 | 06/01/2027 | 61 |
| 2026000073 | DER-RJ | JSB COMERCIO E SERVIÇOS LTDA | SERVIÇOS DE LOCAÇÃO DE PURIFICADORES DE ÁGUA, com troca de filtro, ma… | R$ 43.080,00 | 06/01/2027 | 61 |
| 2024000033 | DER-RJ | CS BRASIL FROTAS S.A. | O presente Termo de Referência tem por objetivo estabelecer as condiç… | R$ 9.029.240,28 | 22/01/2027 | 77 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2021000591 | DER-RJ | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | SERVIÇOS CONTÍNUOS DE CONSERVAÇÃO ROTINEIRA PARA A MALHA RODOVIÁRIA E… | R$ 16.213.934,40 | 05/02/2027 | 91 |
| 2025000361 | DER-RJ | VISION RIO PROJETOS E EXECUÇÕES LTDA | SERVIÇOS DE ESTABILIZAÇÃO DE TALUDES DE RODOVIA COM APLICAÇÃO DE GEL … | R$ 37.025.891,60 | 07/02/2027 (PNCP) | 93 |
| 2025008995 | SEIOP | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | contratação de serviço de hospedagem em Servidores Virtuais Privados … | R$ 161.114,64 | 19/02/2027 | 105 |
| 2024007934 | SEIOP | ABRE CONSTRUÇÕES LTDA | ONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM SERVIÇOS COMUNS DE ENGENHARIA … | R$ 32.480.623,00 | 20/02/2027 (PNCP) | 106 |
| 2026000170 | SEIOP | LUKES ENGENHARIA LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NO RAMO DE ENGENHARIA E/OU ARQUI… | R$ 1.302.281,25 | 22/02/2027 (PNCP) | 108 |
| 2024008575 | SEIOP | CONSTRUPOWER ENGENHARIA LTDA | OBRAS DE RESTAURAÇÃO, ACESSIBILIDADE, ESTRUTURA, INSTALAÇÕES, LUMINOT… | R$ 21.398.000,00 | 02/03/2027 (PNCP) | 116 |
| 2026000096 | DER-RJ | CONSTRUTORA MEDEIROS CARVALHO DE ALMEIDA LTDA | Contratação via certame licitatório, de empresa especializada nos SER… | R$ 13.214.500,14 | 02/03/2027 (PNCP) | 116 |
| 2026000402 | DER-RJ | BRASVIP SEGURANCA PRIVADA LTDA | Contratação via certame licitatório, de âmbito nacional, de empresa e… | R$ 14.100.000,01 | 02/03/2027 (PNCP) | 116 |
| 2026000466 | DER-RJ | BVIX SEGURADORA S/A | SERVIÇO DE COBERTURA DE SEGURO AO PRÉDIO E AO SEU CONTEÚDO, contempla… | R$ 107.333,00 | 10/03/2027 | 124 |
| 2026001408 | DER-RJ | SINAPE SINALIZAÇÃO VIÁRIA LTDA | Contratação para a prestação de serviçoscontínuos de conservação nas … | R$ 28.628.718,36 | 23/03/2027 (PNCP) | 137 |
| 2025001930 | DER-RJ | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Contratação da Imprensa Oficial do Estado do Rio de Janeiro, nos term… | R$ 700.000,00 | 24/03/2027 (PNCP) | 138 |
| 2026001728 | SEIOP | CNS NACIONAL DE SERVIÇOS LTDA | CONTRATAÇÃO DE EMPRESA PARA PRESTAÇÃO DE SERVIÇOS DE APOIO OPERACIONA… | R$ 382.938,99 | 06/04/2027 | 151 |
| 2024007651 | SEIOP | CONSTRUTORA R2X LTDA ME | CONTRATAÇÃO, PELA SECRETARIA DE ESTADO DE INFRAESTRUTURA E OBRAS PÚBL… | R$ 68.827.616,00 | 07/04/2027 (PNCP) | 152 |
| 2025001073 | IEEA | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação de serviços de hospedagem de mensagem eletrônica (e-mail)… | R$ 26.200,80 | 09/04/2027 | 154 |
| 2026002799 | SEIOP | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | PRESTAÇÃO DO SERVIÇO DE LOCAÇÃO DE MÁQUINAS,VEÍCULOS E EQUIPAMENTOS P… | R$ 3.400.000,00 | 10/04/2027 (PNCP) | 155 |
| 2023002114 | DER-RJ | HORIZONTE 16 LOCADORA DE VEÍCULOS LTDA EPP | Contratação via certame licitatório de empresa especialiada na presta… | R$ 166.104,00 | 14/04/2027 | 159 |
| 2026002715 | SEIOP | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | PRESTAÇÃO DO SERVIÇO DE LOCAÇÃO DE MÁQUINAS,VEÍCULOS E EQUIPAMENTOS P… | R$ 3.270.000,00 | 15/04/2027 (PNCP) | 160 |
| 2024009146 | DER-RJ | ESSENCIO AMBIENTAL TECNOLOGIA E PARTICIPACOE… | CONTRATAÇÃO DE EMPRESA PARA A PRESTAÇÃO DE SERVIÇOS DE MANUTENÇÃO, RE… | R$ 131.982.637,94 | 16/04/2027 (PNCP) | 161 |
| 2026002053 | SEIOP | ENEX CONSTRUÇÕES LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA RECONSTRUÇÃO DA ESCOLA CREC… | R$ 2.960.000,00 | 26/04/2027 (PNCP) | 171 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024008523 | DER-RJ | OMEGA CONSTRUTORA E SERVIÇOS LTDA | CONTRATAÇÃO DE EMPRESA PARA A PRESTAÇÃO DE SERVIÇOS DE CONSERVAÇÃO DA… | R$ 165.184.182,50 | 21/10/2026 (PNCP) | -16 |
| 2021000714 | DER-RJ | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | OBRAS DE RESTAURAÇÃO E MELHORIAS FÍSICO - OPERACIONAIS DA RJ - 99, DO… | R$ 146.039.466,63 | 03/04/2026 | -217 |
| 2024005766 | SEIOP | OMEGA CONSTRUTORA E SERVIÇOS LTDA | REVESTIMENTO ASFÁLTICO E DRENAGEM DE LOUGRADOUROS PÚBLICOS DO 2 DISTR… | R$ 121.209.193,39 | 17/01/2026 | -293 |
| 2025006496 | SEIOP | MPE ENGENHARIA E SERVIÇOS S/A | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA A REALIZAÇÃO DOS SERVIÇOS D… | R$ 116.500.000,00 | 26/03/2026 (PNCP) | -225 |
| 2024009630 | SEIOP | POMA S.A.S | AQUISIÇÃO DE EQUIPAMENTOS ESPECIALIZADOS PARA REABILITAÇÃO ELETROMECA… | R$ 105.077.465,13 | 03/03/2026 (PNCP) | -248 |
| 2022009368 | DER-RJ | COFRANZA CONSTRUTORA LTDA | RJ-162 - Obras de drenagem, pavimentação, sinalização, obras de artes… | R$ 97.913.755,42 | 03/04/2026 | -217 |
| 2022005110 | DER-RJ | RC VIEIRA ENGENHARIA LTDA | Trecho 1 (RJ-106) - Obra de Reconstrução de Pavimento e Projeto Execu… | R$ 94.781.771,35 | 20/12/2024 | -686 |
| 2024005362 | SEIOP | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | REVESTIMENTO ASFÁLTICO E DRENAGEM DE LOUGRADOUROS PÚBLICOS DO 2 DISTR… | R$ 93.233.268,36 | 31/12/2025 | -310 |
| 2024006383 | DER-RJ | CONSORCIO RECUPERACAO SERRA DE PARACAMBI | CONTRATAÇÃO DE EMPRESA PARA ELABORAÇÃO DE PROJETO BÁSICO E ESTIMATIVA… | R$ 72.679.397,97 | 14/12/2025 (PNCP) | -327 |
| 2023005856 | DER-RJ | CONSTRUTORA METROPOLITANA S.A. | RJ071 Obra de Revitaliação de Pavimento da Linha Vermelha A partir do… | R$ 71.972.109,66 | 22/12/2024 | -684 |
| 2022001145 | DER-RJ | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | RJ-106/140 - Obra de Reconstrução de Pavimento e Projeto Executivo no… | R$ 70.305.340,98 | 25/06/2026 | -134 |
| 2024010219 | DER-RJ | CONSTRUVERDE CONSTRUCOES E SERVICOS EIRELI | CONTRATAÇÃO DE EMPRESA PARA EXECUÇÃO DE OBRAS DE CONTENÇÃO DE ENCOSTA… | R$ 56.098.693,37 | 16/12/2025 (PNCP) | -325 |
| 2025001093 | DER-RJ | DP BARROS - PAVIMENTACAO E CONSTRUCAO LTDA | RJ081 Obra de Revitaliação de Pavimento e Detalhamento de Projeto Exe… | R$ 52.029.057,50 | 07/06/2026 | -152 |
| 2024007935 | SEIOP | PLENAPLAN CONSTRUTORA EIRELI | EXECUÇÃO DOS SERVIÇOS DE PAVIMENTAÇÃO, SINALIZAÇÃO HORIZONTAL E VERTI… | R$ 51.416.747,71 | 27/05/2026 (PNCP) | -163 |
| 2022003741 | SEIOP | MPE ENGENHARIA E SERVIÇOS S/A | CONTRATAÇÃO, PELA SECRETARIA DE ESTADO DEINFRAESTRUTURA E OBRAS - SEI… | R$ 50.662.699,12 | 01/12/2024 | -705 |
| 2022007256 | SEIOP | DRATEC ENGENHARIA LTDA | Contratação de empresa especializada em serviços de engenharia para ¿… | R$ 47.869.330,34 | 01/12/2024 | -705 |
| 2021001537 | DER-RJ | CONSTRUTORA AVENIDA LTDA | OBRAS DE DRENAGEM, TERRAPLENAGEM, PAVIMENTAÇÃO COM IMPLANTAÇÃO DE ACO… | R$ 47.452.622,73 | 03/09/2026 | -64 |
| 2024000197 | SEIOP | CONSTRUTORA COLARES LINHARES S.A. | Empresa especializada em obras de engenharia para construção de viadu… | R$ 41.522.873,42 | 07/07/2026 | -122 |
| 2023007333 | SEIOP | ENGE PRAT ENGENHARIA E SERVIÇOS LTDA | CONTRATAÇÃO PELA SECRETARIA DE ESTADO DE INFRAESTRUTURA E CIDADES SEI… | R$ 41.290.047,36 | 14/03/2025 | -602 |
| 2024010053 | DER-RJ | ECONORTE, MEIO AMBIENTE, INFRAESTRUTURA E SE… | CONTRATAÇÃO DE EMPRESA PARA EXECUÇÃO DE OBRAS EMERGENCIAISDE CONTENÇÃ… | R$ 41.062.138,68 | 12/06/2026 (PNCP) | -147 |
| 2024000423 | SEIOP | ORIENTE CONSTRUÇÃO CIVIL LTDA | OBRA DE DRENAGEM PLUVIAL E PAVIMENTAÇÃO ASFÁLTICA EM DIVERSOS LOGRADO… | R$ 38.898.356,53 | 30/01/2025 | -645 |
| 2022000131 | DER-RJ | PROCEC ENGENHARIA S/A | ``Implantação, pavimentação e restauração de rodovias e construção da… | R$ 37.844.872,07 | 27/07/2026 | -102 |
| 2024009872 | DER-RJ | ENGE PRAT ENGENHARIA E SERVIÇOS LTDA | CONTRATAÇÃO DE EMPRESA PARA EXECUÇÃO DE OBRAS EMERGENCIAIS DE CONTENÇ… | R$ 36.918.166,36 | 05/12/2025 (PNCP) | -336 |
| 2024006030 | DER-RJ | RIVALL ENGENHARIA LTDA | CONTRATAÇÃO DE EMPRESA PARA EXECUÇÃO DE OBRAS EMERGENCIAISDE CONTENÇ… | R$ 36.744.949,61 | 17/05/2026 (PNCP) | -173 |
| 2024002422 | SEIOP | OMEGA CONSTRUTORA E SERVIÇOS LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA IMPLANTAÇÃO DA PONTE DO PIL… | R$ 35.780.446,88 | 30/11/2024 | -706 |
| 2024010054 | DER-RJ | LBL CONSULTORIA EM ENGENHARIA LTDA | CONTRATAÇÃO DE EMPRESA PARA EXECUÇÃO DE OBRAS EMERGENCIAIS DE CONTENÇ… | R$ 33.299.539,53 | 10/12/2025 (PNCP) | -331 |
| 2024010578 | DER-RJ | COFRANZA CONSTRUTORA LTDA | CONTRATAÇÃO DE EMPRESA PARA EXECUÇÃO DE OBRAS EMERGENCIAIS DE CONTENÇ… | R$ 29.355.234,46 | 26/07/2026 (PNCP) | -103 |
| 2024002399 | SEIOP | PETROPUMP SERVIÇOS LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇOS DE ENGE… | R$ 27.739.392,32 | 30/09/2025 | -402 |
| 2025010475 | SEIOP | 34.551.839/0001-30 | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA EXECUÇÃO DE OBRA EMERGENCIA… | R$ 27.434.724,00 | 12/08/2026 (PNCP) | -86 |
| 2022001765 | DER-RJ | VISÃO EMPREENDIMENTOS LTDA. | RJ-158- OBRA DE RECUPERAÇÃO DE RODOVIA. NO TRECHO ENTRE ANGELIM (SÃO … | R$ 24.208.232,29 | 21/04/2025 | -564 |

_Registros mais antigos (provável falta de baixa no SIGA): 385, R$ 2.639,5 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024009146 | DER-RJ | ESSENCIO AMBIENTAL TECNOLOGIA E PARTICIPACOE… | CONTRATAÇÃO DE EMPRESA PARA A PRESTAÇÃO DE SERVIÇOS DE MANUTENÇÃO, RE… | R$ 131.982.637,94 | 16/04/2027 (PNCP) | 161 |
| 2024009787 | DER-RJ | FMV CONSTRUÇÕES E LOCAÇÕES DE EQUIPAMENTOS L… | RJ-194  RESTAURAÇÃO DO PAVIMENTO  OBRAS DE DRENAGEM, PAVIMENTAÇÃO E… | R$ 101.648.912,58 | 24/06/2027 | 230 |
| 2026005103 | DER-RJ | ORIENTE CONSTRUÇÃO CIVIL LTDA | EXECUÇÃO DE OBRAS PARA MELHORIAS FÍSICAS E OPERACIONAIS DESTINADAS A … | R$ 86.488.878,18 | 11/10/2027 | 339 |
| 2026001760 | DER-RJ | SPLICE INDÚSTRIA, COMÉRCIO E SERVIÇOS LTDA. | Prestação de Serviços de Locação de Equipamentos/sistemas e Serviços … | R$ 78.849.996,69 | 16/12/2028 | 771 |
| 2026001758 | DER-RJ | SPLICE INDÚSTRIA, COMÉRCIO E SERVIÇOS LTDA. | Prestação de Serviços de Locação de Equipamentos/sistemas e Serviços … | R$ 78.549.999,97 | 16/12/2028 | 771 |
| 2026001394 | DER-RJ | PERKONS S.A. | Prestação de Serviços de Locação de Equipamentos/sistemas e Serviços … | R$ 73.989.750,96 | 16/12/2028 | 771 |
| 2024007651 | SEIOP | CONSTRUTORA R2X LTDA ME | CONTRATAÇÃO, PELA SECRETARIA DE ESTADO DE INFRAESTRUTURA E OBRAS PÚBL… | R$ 68.827.616,00 | 07/04/2027 (PNCP) | 152 |
| 2025000361 | DER-RJ | VISION RIO PROJETOS E EXECUÇÕES LTDA | SERVIÇOS DE ESTABILIZAÇÃO DE TALUDES DE RODOVIA COM APLICAÇÃO DE GEL … | R$ 37.025.891,60 | 07/02/2027 (PNCP) | 93 |
| 2024007934 | SEIOP | ABRE CONSTRUÇÕES LTDA | ONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM SERVIÇOS COMUNS DE ENGENHARIA … | R$ 32.480.623,00 | 20/02/2027 (PNCP) | 106 |
| 2026001408 | DER-RJ | SINAPE SINALIZAÇÃO VIÁRIA LTDA | Contratação para a prestação de serviçoscontínuos de conservação nas … | R$ 28.628.718,36 | 23/03/2027 (PNCP) | 137 |
| 2024008575 | SEIOP | CONSTRUPOWER ENGENHARIA LTDA | OBRAS DE RESTAURAÇÃO, ACESSIBILIDADE, ESTRUTURA, INSTALAÇÕES, LUMINOT… | R$ 21.398.000,00 | 02/03/2027 (PNCP) | 116 |
| 2021000591 | DER-RJ | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | SERVIÇOS CONTÍNUOS DE CONSERVAÇÃO ROTINEIRA PARA A MALHA RODOVIÁRIA E… | R$ 16.213.934,40 | 05/02/2027 | 91 |
| 2026000402 | DER-RJ | BRASVIP SEGURANCA PRIVADA LTDA | Contratação via certame licitatório, de âmbito nacional, de empresa e… | R$ 14.100.000,01 | 02/03/2027 (PNCP) | 116 |
| 2026000096 | DER-RJ | CONSTRUTORA MEDEIROS CARVALHO DE ALMEIDA LTDA | Contratação via certame licitatório, de empresa especializada nos SER… | R$ 13.214.500,14 | 02/03/2027 (PNCP) | 116 |
| 2024000033 | DER-RJ | CS BRASIL FROTAS S.A. | O presente Termo de Referência tem por objetivo estabelecer as condiç… | R$ 9.029.240,28 | 22/01/2027 | 77 |
| 2025004702 | SEIOP | CLIMA AIR REFORMAS, MANUTENÇÃO E LOCAÇÃO DE … | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM CLIMATIZAÇÃO DE AMBIENTE, PAR… | R$ 8.753.953,11 | 16/07/2030 | 1348 |
| 2022000139 | DER-RJ | SPLICE INDÚSTRIA, COMÉRCIO E SERVIÇOS LTDA. | Prestação de serviços de locação de equipamentos/sistemas e serviços … | R$ 8.687.000,00 | 15/07/2027 | 251 |
| 2025001979 | SEIOP | ECONORTE, MEIO AMBIENTE, INFRAESTRUTURA E SE… | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇOS TÉCNICO… | R$ 7.066.834,90 | 03/09/2027 (PNCP) | 301 |
| 2025003132 | DER-RJ | JKN ASSESSORIA E SERVICOS DE ENGENHARIAS LTD… | EXECUÇÃO DE SERVIÇOS CONTÍNUOS DE CONSERVAÇÃO E RESTAURAÇÃO ROTINEIRA… | R$ 5.505.343,47 | 25/07/2027 | 261 |
| 2026002799 | SEIOP | CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | PRESTAÇÃO DO SERVIÇO DE LOCAÇÃO DE MÁQUINAS,VEÍCULOS E EQUIPAMENTOS P… | R$ 3.400.000,00 | 10/04/2027 (PNCP) | 155 |

## 7. Fornecedores em recuperação judicial
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024005362 | SEIOP | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | REVESTIMENTO ASFÁLTICO E DRENAGEM DE LOUGRADOUROS PÚBLICOS DO 2 DISTR… | R$ 93.233.268,36 | 31/12/2025 | -310 |
| 2024006383 | DER-RJ | CONSORCIO RECUPERACAO SERRA DE PARACAMBI | CONTRATAÇÃO DE EMPRESA PARA ELABORAÇÃO DE PROJETO BÁSICO E ESTIMATIVA… | R$ 72.679.397,97 | 14/12/2025 (PNCP) | -327 |
| 2022006099 | SEIOP | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | Obras de Infraestrutura no Município de São João de Meriti | R$ 66.749.521,15 | 17/08/2023 | -1177 |
| 2023006024 | SEIOP | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA REALIZAÇÃO DE OBRAS DE MICR… | R$ 31.389.790,64 | 04/08/2024 | -824 |
| 2023000821 | SEIOP | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | ELABORAÇÃO DE PROJETO EXECUTIVO E OBRA DE DRENAGEM URBANA, PAVIMENTAÇ… | R$ 17.497.895,59 | 22/02/2024 | -988 |
| 2022003457 | SEIOP | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | OBRAS DE RECUPERAÇÃO E PAVIMENTAÇÃO EM CBUQ COM MELHORIAS OPERACIONAI… | R$ 11.315.830,18 | 23/12/2022 | -1414 |
| 2022004670 | SEIOP | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇOS DE ENGE… | R$ 10.384.023,61 | 26/02/2023 | -1349 |
| 2022003307 | SEIOP | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | Mão de obra e equipamentos para prestação de serviço de usinagem, tra… | R$ 8.973.983,87 | 21/01/2023 | -1385 |
| 2025004847 | SEIOP | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | CONCLUSÃO DO SALDO REMANESCENTE DO CONTRATO 014/2023, TENDO POR OBJET… | R$ 7.430.869,32 | 06/05/2026 | -184 |
| 2022005778 | SEIOP | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA PARA ELABORAÇÃO DE PROJETOS EXEC… | R$ 5.182.638,30 | 02/03/2023 | -1345 |
| 2025003295 | DER-RJ | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | EXECUÇÃO DE OBRA DE IMPLANTAÇÃO DE PONTE SOBRE O RIO PIABANHA, E ROTA… | R$ 3.815.012,07 | 29/08/2026 (PNCP) | -69 |

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| SPLICE INDÚSTRIA, COMÉRCIO E SERVIÇOS LTDA. | 3 | R$ 166.086.996,66 |
| ESSENCIO AMBIENTAL TECNOLOGIA E PARTICIPACOES LTDA | 1 | R$ 131.982.637,94 |
| FMV CONSTRUÇÕES E LOCAÇÕES DE EQUIPAMENTOS LTDA | 1 | R$ 101.648.912,58 |
| ORIENTE CONSTRUÇÃO CIVIL LTDA | 1 | R$ 86.488.878,18 |
| PERKONS S.A. | 1 | R$ 73.989.750,96 |
| CONSTRUTORA R2X LTDA ME | 1 | R$ 68.827.616,00 |
| VISION RIO PROJETOS E EXECUÇÕES LTDA | 1 | R$ 37.025.891,60 |
| ABRE CONSTRUÇÕES LTDA | 1 | R$ 32.480.623,00 |
| SINAPE SINALIZAÇÃO VIÁRIA LTDA | 1 | R$ 28.628.718,36 |
| CONSTRUSAN SERVIÇOS INDUSTRIAIS LTDA. | 3 | R$ 22.883.934,40 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2022005110 | RC VIEIRA ENGENHARIA LTDA | R$ 11.892.075,09 | R$ 4.809.255,21 | R$ 7.082.819,88 |
| 2021007493 | SEEL - SERVIÇOS ESPECIAIS DE ENGENHARIA LTDA | R$ 10.086.511,25 | R$ 3.599.014,91 | R$ 6.487.496,34 |
| 2021004468 | ALBERTO COUTO ALVES BRASIL LTDA | R$ 27.373.426,01 | R$ 23.246.987,25 | R$ 4.126.438,76 |
| 2021004555 | ALBERTO COUTO ALVES BRASIL LTDA | R$ 23.274.306,72 | R$ 19.304.267,82 | R$ 3.970.038,90 |
| 2022008700 | CONCREJATO SERVIÇOS TECNICOS DE ENGENHARIA S… | R$ 8.674.579,23 | R$ 5.559.461,90 | R$ 3.115.117,33 |
| 2021001537 | CONSTRUTORA AVENIDA LTDA | R$ 10.167.343,56 | R$ 7.252.936,08 | R$ 2.914.407,48 |
| 2021000714 | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | R$ 54.767.699,05 | R$ 52.925.937,37 | R$ 1.841.761,68 |
| 2022005158 | CONSTRUTORA METROPOLITANA S.A. | R$ 17.270.751,04 | R$ 15.457.322,18 | R$ 1.813.428,86 |
| 2022000967 | GEO AMBIENTAL EMPREENDIMENTOS LTDA | R$ 1.417.078,81 | R$ 0,00 | R$ 1.417.078,81 |
| 2022007256 | DRATEC ENGENHARIA LTDA | R$ 13.205.639,19 | R$ 11.957.494,54 | R$ 1.248.144,65 |
| 2022009307 | STATLED BRASIL CONSTRUTORA E PARTICIPAÇÕES S… | R$ 2.700.166,67 | R$ 1.525.383,86 | R$ 1.174.782,81 |
| 2022004656 | CONE ENGENHARIA E CONSTRUÇÃO LTDA | R$ 1.283.478,18 | R$ 200.017,06 | R$ 1.083.461,12 |
| 2023000470 | MJRE CONSTRUTORA LTDA | R$ 18.156.212,86 | R$ 17.249.704,90 | R$ 906.507,96 |
| 2022001555 | SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LTDA | R$ 2.593.521,61 | R$ 1.798.580,09 | R$ 794.941,52 |
| 2023004243 | GRAVISA CONSTRUCOES E EMPREENDIMENTOS LIMITA… | R$ 10.754.243,81 | R$ 9.969.184,01 | R$ 785.059,80 |
| 2022004053 | MIDAS ENGENHARIA LTDA | R$ 2.279.699,85 | R$ 1.547.068,56 | R$ 732.631,29 |
| 2021005991 | OMEGA CONSTRUTORA E SERVIÇOS LTDA | R$ 9.769.077,44 | R$ 9.134.319,29 | R$ 634.758,15 |
| 2022004954 | FARO CONSTRUÇÕES, LOCAÇÕES E CONSULTORIA LTDA | R$ 3.083.513,45 | R$ 2.538.469,42 | R$ 545.044,03 |
| 2020002901 | MULTIPLY SERVIÇOS E MANUTENÇÃO EIRELI | R$ 5.399.270,23 | R$ 4.885.010,78 | R$ 514.259,45 |
| 2022002177 | COMAL CONSTRUTORA LTDA | R$ 1.094.354,25 | R$ 629.011,19 | R$ 465.343,06 |

## 11. Unidades incluídas neste dossiê
- DER-RJ - FUND DEP ESTRADAS DE RODAGEM DO ESTADO DO RJ
- EMOP - EMPRESA DE OBRAS PÚBLICAS DO ESTADO DO RJ
- IEEA - INST ESTADUAL DE ENGENHARIA E ARQUITETURA
- SEINFRA - Secretaria de Estado de Infra e Obras
- SEIOP - SECRETARIA DE ESTADO DE INFRAESTRUTURA E OBRAS PUBLICAS - SEIOP

## 12. Conjuntos de dados abertos da secretaria
- PLANO ANUAL DE AUDITORIA - PLANAT (atualizado 2026-09-16): [PLANAT 2024.pdf PDF](https://dadosabertos.rj.gov.br/dataset/14e3c5de-ca8e-4ef4-898d-a43484aa0b93/resource/287b46a0-1e63-44a1-a30e-e15a97310e3f/download/planat-2024.pdf), [PLANAT 2025.pdf PDF](https://dadosabertos.rj.gov.br/dataset/14e3c5de-ca8e-4ef4-898d-a43484aa0b93/resource/1ce9855f-bfb8-485f-8f6d-bb1bc8e03c0c/download/planat-2025.pdf), [PLANAT 2026.pdf PDF](https://dadosabertos.rj.gov.br/dataset/14e3c5de-ca8e-4ef4-898d-a43484aa0b93/resource/3cbbff4c-2ad4-4acb-bd35-05f84f80a3b7/download/planat-2026.pdf)
- Relação de Estagiários (atualizado 2026-04-20): [Relação_de_Estagiários.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/ca271136-d25c-4a7d-9526-b81996c933b9/resource/a9caf213-5fda-44eb-9809-250d05747ede/download/relacao_de_estagiarios.xlsx)
- Relação de Terceirizado (atualizado 2026-04-20): [Relação_de_Tercerizados.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/5c27d61a-28f6-4224-abc6-03c3e40427b6/resource/ead15795-3530-42e0-9ad8-41cd15eda2bd/download/relacao_de_tercerizados.xlsx)
- PEDTIC 2025 (atualizado 2026-03-19): [PEDTIC_SEIOP_2025 (2).docx DOCX](https://dadosabertos.rj.gov.br/dataset/7a2b89ea-bb06-4b8f-9b08-038c5c07d82b/resource/f0951b9a-2d12-4b8c-a958-6111e4ce59d5/download/pedtic_seiop_2025-2.docx)
- RELATÓRIOS DA OUVIDORIA (atualizado 2026-03-19): [ ](https://www.rj.gov.br/seiop/node/85)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 4 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

- O TCE-RJ acompanha a implantação da nova sede do Museu da Imagem e do Som (MIS). Em decisão de 17 de março de 2025, determinou, entre outras medidas, a apuração de possíveis infrações relacionadas ao Contrato nº 012/2022 e estudos de planejamento para mitigar riscos de prazo nas novas contratações. Já em 16 de março de 2026, acolheu as defesas, determinou comunicações para ciência e arquivou os autos. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- Há um valor de **R$ 217.923,11** solicitado para Termo de Ajuste de Contas por serviços da Peri Formas e Escoamentos Ltda. cujo pagamento, segundo a informação reportada, não havia sido efetivado por falta de disponibilidade orçamentária. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- Em levantamento do TCE-RJ publicado em agosto de 2026, a Secretaria de Estado de Infraestrutura e Obras aparece com **11 contratos classificados como paralisados**, mas a matéria não identifica os contratos nem atribui especificamente ao órgão os efeitos gerais de atrasos e paralisações apontados pela auditoria. [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)
- Registros orçamentários com posição em **31/03/2026** mostram pagamentos em 2026 para a recuperação dos equipamentos do Teleférico do Alemão; as fontes não informam se o serviço está operando normalmente ou se há risco iminente de interrupção. [Investimento em Obras 2026 — CSV](https://www.rj.gov.br/transparencia/sites/default/files/arquivos_paginas/Investimento%20em%20Obras%202026%2003.csv)

##### Alertas vermelhos

- **Pendência financeira reportada:** a EMOP informou ter solicitado disponibilidade orçamentária para celebrar Termo de Ajuste de Contas no valor de **R$ 217.923,11** com a Peri Formas e Escoamentos Ltda.; o pagamento não havia sido efetivado por falta de disponibilidade orçamentária. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- **Contratos paralisados:** levantamento do TCE-RJ contabilizou **11 contratos** da Secretaria de Estado de Infraestrutura e Obras como paralisados, sem divulgar números, contratadas, valores, causas, situação individual ou prazo de retomada. [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)
- **Risco orçamentário sistêmico, sem atribuição específica à SEIOP:** auditoria do TCE-RJ apontou uso de bloqueios de recursos para equilibrar o orçamento e afirmou que o mecanismo pode provocar atrasos e paralisações de obras essenciais; a matéria não associa especificamente esses efeitos à Secretaria. [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)
- **Apuração relativa ao MIS:** o TCE-RJ determinou apurar possíveis infrações na fase interna da licitação e na execução do Contrato nº 012/2022, especialmente quanto à perda da garantia de manutenção do equilíbrio econômico-financeiro; o contrato foi objeto de distrato amigável formalizado em **24/06/2025**. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- **Passivo de controle de obra rodoviária antiga:** matéria de novembro de 2026 relata decisão do TCE-RJ sobre contratos do programa Asfalto na Porta 2, atribuídos à antiga Secretaria de Estado de Obras, com prejuízo apontado de aproximadamente **R$ 22,8 milhões** e multas individuais que somam **R$ 4.326.800,01**; a fonte não estabelece que a SEIOP seja responsável ou sucessora das obrigações nesse caso. [TCE-RJ aponta prejuízo no Asfalto na Porta 2](https://temporealrj.com/tce-rj-asfalto-na-porta-2-governo-estado/)

##### Contratos e serviços críticos

- **MIS — Contrato nº 012/2022:** a contratada indicada é Compass Build Control Ltda.; o distrato amigável foi formalizado em **24/06/2025** e publicado no Diário Oficial, sem data de publicação, valor ou vigência informados. O TCE-RJ determinou apuração de possíveis infrações licitatórias e de execução, com atenção à garantia de manutenção do equilíbrio econômico-financeiro. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- **MIS — novas contratações:** o acórdão menciona o Contrato nº 012/2024 e a Concorrência Pública nº 015/2023 no contexto da implantação do museu e registra atenção a estudos de planejamento e mitigação de riscos relativos a prazos; a fonte não informa empresa, valor ou vigência do Contrato nº 012/2024. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- **MIS — Contrato nº 031/2021:** segundo as alegações dos defendentes registradas no acórdão, foi adotada advertência formal à pessoa jurídica contratada em razão da baixa execução do contrato; o trecho não informa contratada, valor ou vigência. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- **MIS — Contrato nº 039/2013:** a Fundação Roberto Marinho é citada por insumos técnico-conceituais especializados ligados ao projeto museológico e à concepção do equipamento cultural; valor e vigência não são informados. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- **MIS — Termo de Ajuste de Contas:** a EMOP informou solicitação de disponibilidade orçamentária para valor total de **R$ 217.923,11** à Peri Formas e Escoamentos Ltda., por serviços executados no empreendimento, e informou que o pagamento ainda não havia sido efetivado por falta de disponibilidade orçamentária. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- **Teleférico do Alemão:** o arquivo de investimentos, com posição em **31/03/2026**, registra para a MPE Engenharia e Serviços S/A a nota de empenho **2026NE00218**, com **R$ 4.823.492,73** empenhados, liquidados e pagos, e a nota **2026NE00304**, com **R$ 2.069.211,53** nas mesmas três situações; ambas se referem à recuperação de equipamentos eletromecânicos das seis estações e à instalação de componentes do sistema de transporte por cabos. [Investimento em Obras 2026 — CSV](https://www.rj.gov.br/transparencia/sites/default/files/arquivos_paginas/Investimento%20em%20Obras%202026%2003.csv)
- **Teleférico do Alemão — pagamentos registrados em 2025:** o arquivo também lista pagamentos de **R$ 84.237,12** na nota **2025NE00940** e de **R$ 123.731,58** na nota **2025NE01192**, ambos para a Petropump Serviços Ltda., vinculados à reforma para recuperação das seis estações; o arquivo apresenta empenhado e liquidado como **R$ 0,00** nesses registros. [Investimento em Obras 2026 — CSV](https://www.rj.gov.br/transparencia/sites/default/files/arquivos_paginas/Investimento%20em%20Obras%202026%2003.csv)
- **Contratos paralisados:** a fonte informa 11 contratos atribuídos à Secretaria de Estado de Infraestrutura e Obras no levantamento, mas não fornece dados que permitam identificar contratos ou serviços críticos específicos para priorização operacional. [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- **TCE-RJ — MIS:** o Processo nº **104.341-5/2023** trata do acompanhamento das obras da nova sede do MIS. Em **16 de março de 2026**, o Plenário decidiu por unanimidade pelo acolhimento da defesa, com comunicação e arquivamento. O acórdão registra determinações anteriores relativas à fiscalização da execução e ao planejamento dos contratos, além de informar que o acompanhamento prosseguiu em outra fiscalização. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- **TCE-RJ — orçamento e paralisações:** o Tribunal determinou ao governo alteração da programação e liberação de recursos, com cronograma mais detalhado por órgão, fontes e prioridades, e determinou maior integração entre Planejamento e Fazenda; a matéria informa que a Secretaria-Geral de Controle Externo acompanhará o cumprimento. [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)
- **TCE-RJ — Asfalto na Porta 2:** o Acórdão nº **026503/2026**, no Processo nº **114182-6/2018**, julgou irregulares contas relacionadas a obras de 2012 atribuídas à antiga Seobras; a matéria informa prejuízo aproximado de **R$ 22,8 milhões**, multas que somam **R$ 4.326.800,01**, cobrança executiva dos valores devidos e possibilidade de inscrição em dívida ativa se não houver pagamento no prazo regulamentar. A fonte não atribui a responsabilidade à SEIOP. [TCE-RJ aponta prejuízo no Asfalto na Porta 2](https://temporealrj.com/tce-rj-asfalto-na-porta-2-governo-estado/)
- **MPRJ e Judiciário:** Nada encontrado nas fontes consultadas sobre procedimentos do MPRJ, ações judiciais ou decisões judiciais envolvendo a SEIOP ou os contratos aqui mencionados. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026) [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/) [TCE-RJ aponta prejuízo no Asfalto na Porta 2](https://temporealrj.com/tce-rj-asfalto-na-porta-2-governo-estado/)

##### Riscos de apagão administrativo

- **Disponibilidade orçamentária:** a falta de disponibilidade orçamentária foi indicada como motivo para o não pagamento do Termo de Ajuste de Contas de **R$ 217.923,11** relacionado ao empreendimento do MIS. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- **Programação e liberação de recursos:** segundo a matéria sobre a auditoria do TCE-RJ, a concentração da execução após a liberação das cotas pode provocar atrasos e paralisações de obras essenciais. A matéria informa separadamente que os investimentos do DER-RJ ficaram praticamente parados no início de 2025, sem atribuir esse quadro especificamente à SEIOP. [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)
- **Continuidade de serviços:** as fontes não confirmam apagão administrativo, interrupção iminente de serviço público ou risco de paralisação do Teleférico do Alemão; os registros de pagamentos para sua recuperação não comprovam, por si sós, a situação operacional do sistema. [Investimento em Obras 2026 — CSV](https://www.rj.gov.br/transparencia/sites/default/files/arquivos_paginas/Investimento%20em%20Obras%202026%2003.csv)
- **Transição de governo:** Nada encontrado nas fontes consultadas sobre plano de transição, continuidade administrativa, equipes, sistemas ou riscos específicos associados à posse de **01/01/2027**. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026) [Investimento em Obras 2026 — CSV](https://www.rj.gov.br/transparencia/sites/default/files/arquivos_paginas/Investimento%20em%20Obras%202026%2003.csv) [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)

##### Fatos recentes

- Em **01/11/2026**, reportagem informou que o TCE-RJ publicou editais em **23/10/2026** relacionados ao Acórdão nº **026503/2026** sobre o Asfalto na Porta 2; a matéria relata prazos de 15 dias para determinadas citações e notificações e de 30 dias para recursos contra a decisão que julgou irregulares as contas. [TCE-RJ aponta prejuízo no Asfalto na Porta 2](https://temporealrj.com/tce-rj-asfalto-na-porta-2-governo-estado/)
- Em **16/08/2026**, reportagem sobre levantamento do TCE-RJ informou a existência de 87 contratos classificados como paralisados no conjunto analisado, dos quais 11 aparecem associados à Secretaria de Estado de Infraestrutura e Obras; os números individuais desses contratos não foram divulgados. [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)
- Em **16/03/2026**, o Plenário Virtual do TCE-RJ decidiu por unanimidade acolher a defesa, com comunicação e arquivamento, no Acórdão nº **009981/2026-PLENV**. O acórdão registra que o acompanhamento da implantação da nova sede do MIS permanece em curso no âmbito da Fiscalização nº 066/2025. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- O arquivo de investimentos da SEIOP tem posição em **31/03/2026** e registra pagamentos em 2026 para recuperação dos equipamentos eletromecânicos e instalação de componentes do Teleférico do Alemão. [Investimento em Obras 2026 — CSV](https://www.rj.gov.br/transparencia/sites/default/files/arquivos_paginas/Investimento%20em%20Obras%202026%2003.csv)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)

- Solicitar a relação completa dos **11 contratos classificados como paralisados**, com número, objeto, contratada, valor, situação de vigência, causa da paralisação, pagamentos, saldo, medidas de retomada e previsão atualizada, pois esses dados não constam na matéria consultada. [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)
- Solicitar a situação operacional atual do Teleférico do Alemão, cronograma e marcos de conclusão das intervenções, riscos de interrupção e contratos associados, pois o arquivo informa empenhos e pagamentos, mas não a condição de funcionamento ou a previsão de entrega. [Investimento em Obras 2026 — CSV](https://www.rj.gov.br/transparencia/sites/default/files/arquivos_paginas/Investimento%20em%20Obras%202026%2003.csv)
- Solicitar o processo completo de apuração do Contrato nº **012/2022**, as providências adotadas após o distrato de **24/06/2025**, a situação da garantia e o resultado da apuração determinada pelo TCE-RJ, pois os dados disponíveis não informam o desfecho nem valores do contrato. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- Solicitar à Secretaria informações atualizadas sobre a situação, os valores, os responsáveis e o cronograma dos Contratos nº **012/2024** e **031/2021**, e da Concorrência Pública nº **015/2023**, além da documentação e do estágio de implementação das medidas de planejamento e mitigação de prazos do MIS. O acórdão menciona propostas conceituais, mas não detalha sua adoção integral. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- Solicitar comprovação da disponibilidade orçamentária e do pagamento, ou atualização da pendência, do Termo de Ajuste de Contas de **R$ 217.923,11**, pois a informação disponível registra que o pagamento não havia sido efetivado. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026)
- Solicitar posição atual sobre o cumprimento das determinações do TCE-RJ relativas à programação e liberação de recursos e sobre a integração entre Planejamento e Fazenda, pois a fonte informa as determinações, mas não seu cumprimento posterior. [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)
- Solicitar à assessoria jurídica levantamento de processos do MPRJ e do Judiciário, passivos, dívidas, garantias e prazos processuais da Secretaria, pois Nada encontrado nas fontes consultadas sobre esses temas. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026) [TCE-RJ aponta prejuízo no Asfalto na Porta 2](https://temporealrj.com/tce-rj-asfalto-na-porta-2-governo-estado/)
- Solicitar plano de transição e continuidade administrativa para os primeiros 90 dias, incluindo contratos essenciais, responsáveis, sistemas e riscos de interrupção, pois Nada encontrado nas fontes consultadas sobre planejamento da transição para **01/01/2027**. [Acórdão TCE-RJ nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026) [Bloqueios propositais de recursos atrasam obras em estradas](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/)

##### Fontes consultadas
1. [ACÓRDÃO Nº 009981/2026-PLENV](https://www.tcerj.tc.br/documento-webapi-externo/api/documento/acordao/9981/2026) — 2026-07-06
2. [TCE-RJ aponta prejuízo de R$ 22,8 milhões em obras do programa Asfalto na Porta 2, do governo do estado; multa](https://temporealrj.com/tce-rj-asfalto-na-porta-2-governo-estado/) — 2026-11-01
3. [https://www.rj.gov.br/transparencia/sites/default/...](https://www.rj.gov.br/transparencia/sites/default/files/arquivos_paginas/Investimento%20em%20Obras%202026%2003.csv) — 2026-04-09
4. [Bloqueios propositais de recursos atrasam obras em estradas ...](https://temporealrj.com/tce-rj-aponta-bloqueios-orcamento-obras-paradas/) — 2026-08-16


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2023005053 (REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS L…) vence em 14/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2025010020 (PORTAL TRANSPORTE E COMÉRCIO DE RESÍDUO…) vence em 10/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025010645 (LECARD ADMNISTRADORA DE CARTÕES LTDA) vence em 19/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2026000064 (ELEVADORES ATLAS SCHINDLER LTDA.) vence em 06/01/2027: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2026000073 (JSB COMERCIO E SERVIÇOS LTDA) vence em 06/01/2027: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2024008523 (OMEGA CONSTRUTORA E SERVIÇOS LTDA, R$ 165,2 mi) consta 'Ativo' no SIGA com fim em 21/10/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2021000714 (SANTA LUZIA ENGENHARIA E CONSTRUÇÕES LT…, R$ 146,0 mi) consta 'Ativo' no SIGA com fim em 03/04/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2024005766 (OMEGA CONSTRUTORA E SERVIÇOS LTDA, R$ 121,2 mi) consta 'Ativo' no SIGA com fim em 17/01/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2025006496 (MPE ENGENHARIA E SERVIÇOS S/A, R$ 116,5 mi) consta 'Ativo' no SIGA com fim em 26/03/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2024009630 (POMA S.A.S, R$ 105,1 mi) consta 'Ativo' no SIGA com fim em 03/03/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Qual é o plano de contingência para o contrato 2024005362 com CONSTRUTORA LYTORANEA LTDA - EM RECUPER… (em recuperação judicial)? Garantia contratual está válida?
13. Qual é o plano de contingência para o contrato 2024006383 com CONSORCIO RECUPERACAO SERRA DE PARACAMBI (em recuperação judicial)? Garantia contratual está válida?
14. Qual é o plano de contingência para o contrato 2022006099 com CONSTRUTORA LYTORANEA LTDA - EM RECUPER… (em recuperação judicial)? Garantia contratual está válida?
15. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
16. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
17. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
18. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
19. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
