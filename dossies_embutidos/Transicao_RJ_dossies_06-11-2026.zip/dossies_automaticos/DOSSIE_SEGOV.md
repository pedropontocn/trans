# Dossiê de transição — Secretaria de Estado de Governo (SEGOV)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/segov)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 193 | R$ 437.394.021,33 |
| Com vigência futura (válidos no SIGA) | 67 | R$ 213.048.725,58 |
| até 30 dias | 2 | R$ 459.120,64 |
| até 60 dias | 7 | R$ 78.397.425,58 |
| até 90 dias | 1 | R$ 348.359,76 |
| até 180 dias | 23 | R$ 63.731.416,64 |
| vencido no SIGA | 126 | R$ 224.345.295,75 |
| sem data | 3 | R$ 131.589,60 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 62,6 mi / R$ 20,5 mi / R$ 19,7 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2025009850 (STEM SOLUÇÕES E INTEGRAÇÕES EDUCACIONAIS LTDA) vence em 10/12/2026 — 34 dias — R$ 25.662.000,00. Objeto: Aquisição de 100.000 (cem mil) kits de material educativo sobre segurança no tr…
- Contrato 2025010890 (FUNDAÇÃO CESGRANRIO) vence em 23/12/2026 — 47 dias — R$ 49.667.956,58. Objeto: O presente Termo de Referência tem por objetivo estabelecer as condições, espec…
- Mais 2 contratos menores (R$ 0,5 mi) vencem em até 30 dias — ver seção 3.
- 30 contratos (R$ 126,6 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 58 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 190,7 mi); 6 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 68 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 33,7 mi): provável falta de baixa no SIGA (risco de controle, não de execução).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026002503 | SEGOV | ZENITE INFORMAÇÃO E CONSULTORIA S.A. | Participação na capacitação presencial: Curso: Alterações e Aditivos … | R$ 23.980,00 | 12/11/2026 | 6 |
| 2021006205 | SEGOV | EMPRESA BRASILEIRA DE ENGENHARIA E COMÉRCIO … | Adesão à ATA DE REGISTRO DE PREÇOS para a locação de veículos automot… | R$ 435.140,64 | 02/12/2026 | 26 |
| 2022003570 | SEGOV | AMPLA ENERGIA E SERVIÇOS S/A | Despesas com fornecimento de energia elétrica na base da Operação Seg… | R$ 7.000,00 | 09/12/2026 | 33 |
| 2025010265 | SEGOV | BICICLETARIA E LANCHONETE CARIOCA LTDA | Registro de preços para a aquisição eventual de até 400(quatrocentas)… | R$ 42.500,00 | 09/12/2026 | 33 |
| 2025009850 | SEGOV | STEM SOLUÇÕES E INTEGRAÇÕES EDUCACIONAIS LTDA | Aquisição de 100.000 (cem mil) kits de material educativo sobre segur… | R$ 25.662.000,00 | 10/12/2026 (PNCP) | 34 |
| 2025010264 | SEGOV | BICICLETARIA E LANCHONETE CARIOCA LTDA | Registro de preços para a aquisição eventual de até 400(quatrocentas)… | R$ 2.840.000,00 | 10/12/2026 (PNCP) | 34 |
| 2025010346 | SEGOV | NP TECNOLOGIA E GESTAO DE DADOS LTDA | Fornecimento de senha de acesso a banco de dados para consulta de pre… | R$ 15.375,00 | 19/12/2026 | 43 |
| 2025010810 | SEGOV | SHEMÁ SUPRIMENTOS E SERVIÇOS LTDA | Aquisição de uniformes operacionais para suprir o efetivo da Operação… | R$ 162.594,00 | 19/12/2026 | 43 |
| 2025010890 | SEGOV | FUNDAÇÃO CESGRANRIO | O presente Termo de Referência tem por objetivo estabelecer as condiç… | R$ 49.667.956,58 | 23/12/2026 (PNCP) | 47 |
| 2021005229 | SEGOV | EMPRESA BRASILEIRA DE ENGENHARIA E COMÉRCIO … | : Trata-se de locação de veículos automotores novos, do tipo VAN, com… | R$ 348.359,76 | 13/01/2027 | 68 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000742 | SEGOV | XPTO INC TECNOLOGIA LTDA | A contratação ocorrerá por decorrência da Ata de Registro de Preços S… | R$ 31.956.000,00 | 10/02/2027 (PNCP) | 96 |
| 2025000476 | SEGOV | FJB SÃO BENTO EMPREENDIMENTOS LTDA | A Secretaria de Estado do Governo tem suas instalações sediadas no 4º… | R$ 1.158.912,09 | 17/02/2027 (PNCP) | 103 |
| 2022004324 | SEGOV | IGUA RIO DE JANEIRO S.A. | Serviços de fornecimento de água potável, recepção e tratamento de es… | R$ 7.705,48 | 28/02/2027 | 114 |
| 2022005043 | SEGOV | AGUAS DO PARAIBA SA | Serviços de fornecimento de água potável, recepção e tratamento de es… | R$ 9.957,50 | 28/02/2027 | 114 |
| 2025005328 | SEGOV | AGUAS DO RIO 1 SPE S.A | SERVICO DE FORNECIMENTO DE AGUA - DESCRIÇÃO: CONTRATACAO DE EMPRESA C… | R$ 3.030,22 | 10/03/2027 | 124 |
| 2025005335 | SEGOV | IGUA RIO DE JANEIRO S.A. | SERVICO DE FORNECIMENTO DE AGUA - DESCRIÇÃO: CONTRATACAO DE EMPRESA C… | R$ 250.431,86 | 10/03/2027 | 124 |
| 2025006953 | SEGOV | AGUAS DO RIO 4 SPE S.A | Contratação de serviço de abastecimento de água para a base Del Casti… | R$ 18.717,14 | 10/03/2027 | 124 |
| 2025006958 | SEGOV | LIGHT SERVICOS DE ELETRICIDADE SA | FORNECIMENTO DE ENERGIA ELETRICA,DESCRIÇÃO: CONTRATACAO DE EMPRESA PA… | R$ 12.608,67 | 10/03/2027 | 124 |
| 2025006959 | SEGOV | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação da Concessionária Light, para prestar, de forma contínua,… | R$ 15.506,16 | 10/03/2027 | 124 |
| 2025007418 | SEGOV | IGUA RIO DE JANEIRO S.A. | Contratação da Concessionária Iguá, para prestar, de forma contínua, … | R$ 5.932,36 | 10/03/2027 | 124 |
| 2025007420 | SEGOV | IGUA RIO DE JANEIRO S.A. | Contratação da Concessionária Iguá, para prestar, de forma contínua, … | R$ 5.932,36 | 10/03/2027 | 124 |
| 2025008131 | SEGOV | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação da Concessionária Light, para prestar, de forma contínua,… | R$ 15.506,16 | 10/03/2027 | 124 |
| 2025009032 | SEGOV | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação da Concessionária Light, para prestar, de forma contínua,… | R$ 13.502,28 | 10/03/2027 | 124 |
| 2025010314 | SEGOV | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | É objeto da presente contratação a aquisição de nove certificados dig… | R$ 2.791,00 | 10/03/2027 | 124 |
| 2025010785 | SEGOV | LIGHT SERVICOS DE ELETRICIDADE SA | FORNECIMENTO DE ENERGIA ELETRICA - DESCRIÇÃO: CONTRATACAO DE EMPRESA … | R$ 7.540,20 | 10/03/2027 | 124 |
| 2026001679 | SEGOV | BICICLETARIA E LANCHONETE CARIOCA LTDA | Consumo da Ata de Registro de Preços NI 0004/2025/570100-01, fornecim… | R$ 1.974.512,50 | 13/03/2027 (PNCP) | 127 |
| 2025001858 | SEGOV | LETS RENT A CAR S/A | SERVICOS DE LOCACAO VEICULO TRANSPORTE DE PASSAGEIROS - CAPACIDADE: 1… | R$ 630.714,72 | 23/03/2027 | 137 |
| 2026002276 | SEGOV | SOLIDEZ GESTÃO PREDIAL LTDA | Consumo da Ata de Registro de Preços SEGOV nº 0008/2026/570100-01 ref… | R$ 10.561.165,68 | 25/03/2027 (PNCP) | 139 |
| 2025001671 | SEGOV | FUNDAÇÃO ESCOLA DE SOCIOLOGIA E POLITICA DE … | O presente procedimento administrativo tem como objeto a compra de 01… | R$ 39.960,00 | 26/03/2027 | 140 |
| 2025002072 | SEGOV | CONDOMÍNIO DO EDIFÍCIO SÃO BENTO OITO | Trata o presente administrativo das diversas fases da despesa de cond… | R$ 685.956,48 | 01/04/2027 (PNCP) | 146 |
| 2026000875 | SEGOV | CONDOR S/A INDUSTRIA QUIMICA | Aquisição dispositivos de dispersão, não explosivos (espargidores) pa… | R$ 322.551,45 | 07/04/2027 | 152 |
| 2026003304 | SEGOV | XPTO INC TECNOLOGIA LTDA | Contratação de empresa especializada para prestação de serviços de lo… | R$ 15.978.000,00 | 28/04/2027 (PNCP) | 173 |
| 2026001413 | SEGOV | MUNICIPIO DE RIO DE JANEIRO | Trata o presente administrativo da despesa de IPTU referente à locaçã… | R$ 54.482,33 | 29/04/2027 | 174 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025003186 | SEGOV | GLOBALTEC TECNOLOGIAS EDUCACIONAIS LTDA | O objeto é a aquisição, fornecimento, transporte, montagem, instalaçã… | R$ 57.116.600,00 | 08/05/2026 | -182 |
| 2025001299 | SEGOV | BARRA BR COMÉRCIO E SERVIÇOS LTDA | SERVICOS DE ORGANIZACAO DE EVENTOS - DESCRIÇÃO: CONTRATACAO DE EMPRES… | R$ 25.656.000,00 | 26/02/2026 (PNCP) | -253 |
| 2024000651 | SEGOV | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | Serviços de gestão do abastecimento, com utilização de solução tecnol… | R$ 24.994.813,96 | 10/09/2025 | -422 |
| 2022002785 | SEGOV | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Prestação de serviços de gestão do abastecimento, com utilização de s… | R$ 14.946.765,00 | 09/11/2024 | -727 |
| 2025010381 | SEGOV | HSOL INCENTIVE PERFORMANCE S.A. | Aquisição de vagas em cursos | R$ 12.690.000,00 | 13/02/2026 (PNCP) | -266 |
| 2024010747 | SEGOV | BARRA BR COMÉRCIO E SERVIÇOS LTDA | A contratação abrange produção, locação, instalação, operação e manut… | R$ 11.367.900,00 | 03/01/2025 (PNCP) | -672 |
| 2022003612 | SEGOV | CS BRASIL FROTAS S.A. | Prestação de serviços, comuns e contínuos deLOCAÇÃO DE 80 (oitenta) V… | R$ 7.472.000,00 | 14/03/2025 | -602 |
| 2025010506 | SEGOV | INSTITUTO NTC DO BRASIL LTDA | COMPRA DE VAGAS EM CURSOS,DESCRIÇÃO: COMPRA DE VAGA EM CURSO OFERECID… | R$ 6.082.560,00 | 10/02/2026 (PNCP) | -269 |
| 2025005910 | SEGOV | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | CONTRATAÇÃO DE PRESTAÇÃO DE SERVIÇOS DE IMPLEMENTAÇÃO, GERENCIAMENTO … | R$ 5.599.139,00 | 08/10/2026 (PNCP) | -29 |
| 2024003278 | SEGOV | TELTRONIC BRASIL LTDA | Aquisição de rádios | R$ 4.594.122,00 | 01/05/2025 | -554 |
| 2025010374 | SEGOV | INSTITUTO NOVAS ATITUDES TRANSFORMAM O AMANHÃ | Trata-se de contratação de empresaespecializada em prestação de servi… | R$ 2.990.400,00 | 13/02/2026 (PNCP) | -266 |
| 2024010212 | SEGOV | INSTITUTO NACIONAL DE DESENVOLVIMENTO EDUCAC… | SERVICO DE SELECAO,DESCRICAO: CONTRATACAO DE EMPRESA ESPECIALIZADA EM… | R$ 1.950.000,00 | 11/12/2025 (PNCP) | -330 |
| 2024007836 | SEGOV | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Trata-se do processo de Contratação de empresa para o fornecimento de… | R$ 1.640.770,00 | 25/09/2025 | -407 |
| 2024009253 | SEGOV | BICICLETARIA E LANCHONETE CARIOCA LTDA | BICICLETA ELETRICA,ARO: 26 ~ 29, MATERIAL ARO:ALUMINIO, MATERIAL QUAD… | R$ 1.597.000,00 | 13/11/2025 (PNCP) | -358 |
| 2022000640 | SEGOV | L8 GROUP S/A | Prestação de serviços, de solução integrada de software e hardware, c… | R$ 1.482.960,00 | 04/01/2026 | -306 |
| 2023000855 | SEGOV | CS BRASIL FROTAS S.A. | Registro de preços para a prestação de serviços de locação de veículo… | R$ 1.457.985,24 | 14/03/2026 | -237 |
| 2026005587 | SEGOV | AGS COMÉRCIO E SERVIÇOS LTDA - EPP | Aquisição de 400.000 (cem mil) unidades de bocais para o Etilômetro m… | R$ 1.200.000,00 | 11/09/2026 (PNCP) | -56 |
| 2022009207 | SEGOV | LIBEX SERVIÇOS E LOCAÇÕES DE VEÍCULOS LTDA E… | Prestação de SERVIÇOS DE Locação de Veículos Especiais de Representaç… | R$ 930.600,00 | 05/12/2025 | -336 |
| 2022001596 | SEGOV | AMAZON SERVIÇOS E CONSTRUÇÕES LTDA | Contratação de serviço de locação de Van adaptada para o transporte d… | R$ 819.936,00 | 23/03/2025 | -593 |
| 2023009005 | SEGOV | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Contratação de empresa para o fornecimento de solução tecnológica de … | R$ 699.868,00 | 18/12/2024 | -688 |
| 2025002986 | SEGOV | A.SILVA DOMINGUES COMÉRCIO E SERVIÇOS DE ASS… | O presente processo tem como objetivo a aquisição de capacetes, visan… | R$ 685.125,00 | 13/05/2026 (PNCP) | -177 |
| 2024003173 | SEGOV | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Contratação de empresa especializada na PRESTAÇÃO DE SERVIÇOS DE AGEN… | R$ 649.980,00 | 08/06/2026 | -151 |
| 2023004489 | SEGOV | BRS SUPRIMENTOS CORPORATIVOS S/A | Prestação de serviços continuados de outsourcing para operação de alm… | R$ 495.051,78 | 29/06/2026 | -130 |
| 2025006347 | SEGOV | AGS COMÉRCIO E SERVIÇOS LTDA - EPP | Aquisição de 150.000 (cento e cinquenta mil) unidades de bocais para … | R$ 450.000,00 | 28/08/2026 | -70 |
| 2025002509 | SEGOV | AGS COMÉRCIO E SERVIÇOS LTDA - EPP | BOCAL BAFOMETRO/ETILOMETRO, MODELO COMPATIVEL: ALCOLIZER MODELO LE5, … | R$ 420.000,00 | 28/10/2025 | -374 |
| 2024009695 | SEGOV | AGS COMÉRCIO E SERVIÇOS LTDA - EPP | Descrição:BOCAL BAFOMETRO/ETILOMETRO - MODELO COMPATIVEL: ALCOLIZER M… | R$ 405.000,00 | 02/02/2025 | -642 |
| 2022008890 | SEGOV | HADDAD RENT A CAR LOCADORA LTDA | Prestação de SERVIÇOS DE Locação de Veículos Especiais de Representaç… | R$ 388.800,00 | 24/11/2025 | -347 |
| 2022008709 | SEGOV | CS BRASIL FROTAS S.A. | Prestação de Serviços de Locação de Veículos Especiais de Representaç… | R$ 335.232,00 | 18/12/2025 | -323 |
| 2025009715 | SEGOV | AGS COMÉRCIO E SERVIÇOS LTDA - EPP | Fornecimento de bocais para o Etilômetro Alcolizer LS5, visando atend… | R$ 300.000,00 | 26/01/2026 | -284 |
| 2024010150 | SEGOV | RC CARD SOLUCOES EM PAGAMENTOS LTDA | CONTRATACAO DE EMPRESA ESPECIALIZADA PARA CONFECCAO, FORNECIMENTO E A… | R$ 288.000,00 | 11/12/2025 | -330 |

_Registros mais antigos (provável falta de baixa no SIGA): 68, R$ 33,7 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025010890 | SEGOV | FUNDAÇÃO CESGRANRIO | O presente Termo de Referência tem por objetivo estabelecer as condiç… | R$ 49.667.956,58 | 23/12/2026 (PNCP) | 47 |
| 2026000742 | SEGOV | XPTO INC TECNOLOGIA LTDA | A contratação ocorrerá por decorrência da Ata de Registro de Preços S… | R$ 31.956.000,00 | 10/02/2027 (PNCP) | 96 |
| 2025009850 | SEGOV | STEM SOLUÇÕES E INTEGRAÇÕES EDUCACIONAIS LTDA | Aquisição de 100.000 (cem mil) kits de material educativo sobre segur… | R$ 25.662.000,00 | 10/12/2026 (PNCP) | 34 |
| 2025010857 | SEGOV | INTERIMAGEM TECNOLOGIA, CONSTRUÇAO E ENERGIA… | PRESTAÇÃO DE SOLUÇÃO INTEGRADA ENGLOBANDO SERVIÇOS, COMUNS E CONTÍNUO… | R$ 17.227.440,00 | 16/08/2027 | 283 |
| 2025009980 | SEGOV | HORIZONTE 16 LOCADORA DE VEÍCULOS LTDA EPP | Locação de veículos de serviço e operacional, sem fornecimento de com… | R$ 16.367.400,00 | 05/06/2028 | 577 |
| 2026003304 | SEGOV | XPTO INC TECNOLOGIA LTDA | Contratação de empresa especializada para prestação de serviços de lo… | R$ 15.978.000,00 | 28/04/2027 (PNCP) | 173 |
| 2026002731 | SEGOV | HORIZONTE 16 LOCADORA DE VEÍCULOS LTDA EPP | trata-se de consumo decorrente da ARP NI 0007/2025/570100-01, cujo ob… | R$ 15.930.936,00 | 27/02/2029 | 844 |
| 2025009981 | SEGOV | XPTO INC TECNOLOGIA LTDA | Locação de veículos automotor tipo motocicleta operacional | R$ 11.029.761,60 | 04/06/2028 | 576 |
| 2026002276 | SEGOV | SOLIDEZ GESTÃO PREDIAL LTDA | Consumo da Ata de Registro de Preços SEGOV nº 0008/2026/570100-01 ref… | R$ 10.561.165,68 | 25/03/2027 (PNCP) | 139 |
| 2025010264 | SEGOV | BICICLETARIA E LANCHONETE CARIOCA LTDA | Registro de preços para a aquisição eventual de até 400(quatrocentas)… | R$ 2.840.000,00 | 10/12/2026 (PNCP) | 34 |
| 2026005152 | SEGOV | AVANTE MARKETING E LOGÍSTICA LTDA | Contratação de serviços de locação de veículos tipo minicargo, median… | R$ 2.035.929,60 | 30/06/2029 | 967 |
| 2026001679 | SEGOV | BICICLETARIA E LANCHONETE CARIOCA LTDA | Consumo da Ata de Registro de Preços NI 0004/2025/570100-01, fornecim… | R$ 1.974.512,50 | 13/03/2027 (PNCP) | 127 |
| 2025006227 | SEGOV | CS BRASIL FROTAS S.A. | Locação de 20 (vinte) veiculos automotor de serviço, do tipo hatch. | R$ 1.849.910,83 | 26/08/2028 | 659 |
| 2025000973 | SEGOV | NTSEC SOLUÇÕES EM TELEINFORMÁTICA LTDA | objetivo descrever a Contratação de empresa de Tecnologia da Informaç… | R$ 1.163.170,58 | 18/02/2028 | 469 |
| 2025000476 | SEGOV | FJB SÃO BENTO EMPREENDIMENTOS LTDA | A Secretaria de Estado do Governo tem suas instalações sediadas no 4º… | R$ 1.158.912,09 | 17/02/2027 (PNCP) | 103 |
| 2025002072 | SEGOV | CONDOMÍNIO DO EDIFÍCIO SÃO BENTO OITO | Trata o presente administrativo das diversas fases da despesa de cond… | R$ 685.956,48 | 01/04/2027 (PNCP) | 146 |
| 2025008389 | SEGOV | AVANTE MARKETING E LOGÍSTICA LTDA | LOCACAO DE VEICULOS PADRAO,DESCRICAO: SERVICO DE LOCACAO DE VEICULOS,… | R$ 636.540,12 | 12/11/2028 | 737 |
| 2025001858 | SEGOV | LETS RENT A CAR S/A | SERVICOS DE LOCACAO VEICULO TRANSPORTE DE PASSAGEIROS - CAPACIDADE: 1… | R$ 630.714,72 | 23/03/2027 | 137 |
| 2024010320 | SEGOV | AVANTE MARKETING E LOGÍSTICA LTDA | LOCAÇÃO DE VEÍCULOS PADRÃO, DESCRIÇÃO: SERVIÇO DE LOCAÇÃO DE VEÍCULOS… | R$ 568.029,24 | 20/12/2027 | 409 |
| 2024005536 | SEGOV | AGS COMÉRCIO E SERVIÇOS LTDA - EPP | Contratação de empresa especializada para a realização de manutenção … | R$ 517.104,00 | 24/07/2027 | 260 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| XPTO INC TECNOLOGIA LTDA | 3 | R$ 58.963.761,60 |
| FUNDAÇÃO CESGRANRIO | 1 | R$ 49.667.956,58 |
| HORIZONTE 16 LOCADORA DE VEÍCULOS LTDA EPP | 2 | R$ 32.298.336,00 |
| STEM SOLUÇÕES E INTEGRAÇÕES EDUCACIONAIS LTDA | 1 | R$ 25.662.000,00 |
| INTERIMAGEM TECNOLOGIA, CONSTRUÇAO E ENERGIA LTDA | 1 | R$ 17.227.440,00 |
| SOLIDEZ GESTÃO PREDIAL LTDA | 1 | R$ 10.561.165,68 |
| BICICLETARIA E LANCHONETE CARIOCA LTDA | 4 | R$ 4.903.325,40 |
| AVANTE MARKETING E LOGÍSTICA LTDA | 3 | R$ 3.240.498,96 |
| CS BRASIL FROTAS S.A. | 2 | R$ 2.045.128,97 |
| NTSEC SOLUÇÕES EM TELEINFORMÁTICA LTDA | 1 | R$ 1.163.170,58 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2022003612 | CS BRASIL FROTAS S.A. | R$ 855.026,29 | R$ 580.559,47 | R$ 274.466,82 |
| 2018003778 | VELOZ TRANSRIO TRANSPORTE LTDA | R$ 1.367.480,65 | R$ 1.222.730,68 | R$ 144.749,97 |
| 2021004064 | LOCADORA DE VEÍCULOS CAXANGÁ LTDA | R$ 1.165.784,90 | R$ 1.040.415,62 | R$ 125.369,28 |
| 2022002785 | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | R$ 384.040,80 | R$ 316.588,36 | R$ 67.452,44 |
| 2021007478 | CS BRASIL FROTAS S.A. | R$ 132.524,09 | R$ 75.446,37 | R$ 57.077,72 |
| 2020000231 | EMPRESA BRASILEIRA DE ENGENHARIA E COMÉRCIO … | R$ 4.456.591,00 | R$ 4.418.923,00 | R$ 37.668,00 |
| 2021001799 | CS BRASIL FROTAS S.A. | R$ 350.447,18 | R$ 318.075,29 | R$ 32.371,89 |
| 2022002869 | RADIONET LTDA | R$ 49.400,40 | R$ 28.217,52 | R$ 21.182,88 |
| 2017003104 | EBEC LOCACAO DE VEICULOS S/A | R$ 1.297.574,67 | R$ 1.277.474,67 | R$ 20.100,00 |
| 2017004171 | MAPTRADE INDUSTRIA E COMERCIO DE PRODUTOS LT… | R$ 1.924.078,28 | R$ 1.912.790,28 | R$ 11.288,00 |
| 2022008709 | CS BRASIL FROTAS S.A. | R$ 18.624,00 | R$ 9.312,00 | R$ 9.312,00 |
| 2023005599 | LIEX RIO INDÚSTRIA E COMÉRCIO LTDA | R$ 7.035,00 | R$ 0,00 | R$ 7.035,00 |
| 2022001596 | AMAZON SERVIÇOS E CONSTRUÇÕES LTDA | R$ 38.339,60 | R$ 36.153,10 | R$ 2.186,50 |
| 2022002500 | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | R$ 6.242,96 | R$ 4.682,22 | R$ 1.560,74 |

## 11. Unidades incluídas neste dossiê
- SEGOV - Secretaria de Estado de Governo

## 12. Conjuntos de dados abertos da secretaria
- Operação Segurança Presente (atualizado 2025-06-04): [Endereço das Bases da Operação Seguranç… CSV](https://dadosabertos.rj.gov.br/dataset/08d1f95b-e2ca-4965-a4ac-5b9e31294681/resource/2a98aa6a-2e54-497f-a679-b12455d3731d/download/endereco_bases.csv)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 6 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo
- A apuração mais relevante envolve contrato de R$ 49,6 milhões com a Fundação Cesgranrio para avaliar o Programa Operação Segurança Presente: auditoria estadual apontou indícios de sobrepreço e problemas na comprovação dos serviços, e informou que os pagamentos foram suspensos após a gestão interina assumir o governo; as fontes não confirmam se a suspensão continua em 06/11/2026. [Auditoria sobre o Segurança Presente](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/)
- O TCE-RJ solicitou informações sobre licitação de aluguel de veículos de quase R$ 62 milhões, inclusive se houve anulação, contratos, empenhos ou pagamentos; a fonte não registra a resposta final nem decisão de mérito. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/)
- A Corregedoria da Segov instaurou cinco sindicâncias, mas a fonte não identifica os contratos ou fatos investigados nem informa os resultados. [Cinco sindicâncias na Segov](https://boletimrj.com.br/pente-fino-corregedoria-da-secretaria-de-governo-abre-cinco-sindicancias-e-substitui-comissoes-de-investigacoes-em-andamento/)
- Segurança Presente e Barricada Zero foram transferidos para a Polícia Militar em abril de 2026; as fontes não informam o estado atual da operação, dos contratos ou da continuidade dos serviços após a transferência. [Mudanças na Segov e no GSI](https://oglobo.globo.com/rio/noticia/2026/04/30/ricardo-couto-enxuga-segov-e-gsi-transferindo-seguranca-presente-e-barricada-zero-para-a-pm.ghtml)

##### Alertas vermelhos
- **Contrato Cesgranrio — risco financeiro e de controle:** a auditoria apontou indícios, não uma decisão definitiva, de estimativa de preço sem pesquisa independente, possível cobrança em duplicidade, despesas sem detalhamento suficiente e critérios insuficientes para medir a qualidade dos serviços. [Auditoria sobre o Segurança Presente](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/)
- No mesmo contrato, a auditoria registrou que documentos associados a R$ 11,9 milhões somavam 16 páginas e tratavam de questões preliminares; recomendou avaliar a continuidade do contrato e sugeriu Tomada de Contas para apurar eventual prejuízo e responsabilidades. [Auditoria sobre o Segurança Presente](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/)
- **Licitação de veículos — situação contratual incerta:** a denúncia questionou especificações técnicas restritivas e exigência de registro e licenciamento de toda a frota no estado; a área técnica do TCE-RJ apontou indícios de procedência das duas questões, sem que a fonte registre decisão definitiva sobre o mérito. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/)
- **Sindicâncias sem objeto divulgado:** cinco apurações foram instauradas, três comissões anteriores foram substituídas e duas sindicâncias foram abertas pela primeira vez; os objetos e eventuais irregularidades concretas não são informados. [Cinco sindicâncias na Segov](https://boletimrj.com.br/pente-fino-corregedoria-da-secretaria-de-governo-abre-cinco-sindicancias-e-substitui-comissoes-de-investigacoes-em-andamento/)
- **Capacidade administrativa:** após a chegada da nova gestão interina, foram exonerados 385 dos 487 cargos comissionados da Segov e a folha mensal caiu de R$ 4,2 milhões para R$ 1,1 milhão; as fontes não demonstram impacto efetivo sobre a execução dos serviços, mas a mudança justifica verificar cobertura de funções essenciais e processos pendentes. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/)

##### Contratos e serviços críticos
- **Fundação Cesgranrio / Operação Segurança Presente:** contrato sem licitação de R$ 49,6 milhões, firmado em dezembro de 2025 para avaliar o programa; segundo a auditoria, até menos de três meses de vigência haviam sido pagos R$ 29,7 milhões, e o último pagamento registrado ocorreu em 23 de março de 2026. [Auditoria sobre o Segurança Presente](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/)
- A auditoria apontou indícios de que a estimativa do Estudo Técnico Preliminar reproduziu o valor da proposta da Cesgranrio, uso de contratos antigos da Secretaria de Educação sem equivalência técnica demonstrada, despesas globalizadas e possíveis duplicidades; são apontamentos de auditoria, não uma decisão judicial ou do TCE-RJ. [Auditoria sobre o Segurança Presente](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/)
- **Aluguel de veículos:** licitação de 2025 avaliada em quase R$ 62 milhões; a fonte não confirma anulação, atas vigentes, contratos decorrentes, empenhos ou pagamentos. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/)
- **Segurança Presente:** programa de policiamento comunitário com dezenas de bases foi transferido da Segov para a Polícia Militar por decreto publicado em 30/04/2026; não há informação nas fontes sobre contratos, custos da transferência ou continuidade operacional. [Mudanças na Segov e no GSI](https://oglobo.globo.com/rio/noticia/2026/04/30/ricardo-couto-enxuga-segov-e-gsi-transferindo-seguranca-presente-e-barricada-zero-para-a-pm.ghtml)
- **Barricada Zero e Lei Seca:** a fonte informa que Barricada Zero passou do GSI para a Polícia Militar e que Segov e GSI também eram responsáveis pelo programa Lei Seca, mas não detalha contratos, custos ou a situação atual desses serviços. [Mudanças na Segov e no GSI](https://oglobo.globo.com/rio/noticia/2026/04/30/ricardo-couto-enxuga-segov-e-gsi-transferindo-seguranca-presente-e-barricada-zero-para-a-pm.ghtml)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)
- **TCE-RJ — veículos:** a decisão noticiada determinou nova diligência para a Segov informar se anulou a licitação, a situação das atas de registro de preços e se houve contratos, empenhos ou pagamentos; a fonte também relata que o secretário intimado em etapa anterior não respondeu no prazo. Não há resposta final ou decisão de mérito informada. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/)
- **TCE-RJ e MPRJ — Cesgranrio:** a auditoria recomendou avaliar a continuidade do contrato, sugeriu Tomada de Contas e informou que o relatório seria encaminhado ao TCE-RJ e ao MPRJ; a fonte não informa decisão desses órgãos, instauração de procedimento ou ação judicial. [Auditoria sobre o Segurança Presente](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/)
- **Sindicâncias internas:** as cinco comissões tinham 30 dias corridos para concluir os trabalhos e apresentar relatório, segundo a página, atualizada em 19/07/2026; a fonte não informa se os relatórios foram concluídos ou quais providências foram adotadas. [Cinco sindicâncias na Segov](https://boletimrj.com.br/pente-fino-corregedoria-da-secretaria-de-governo-abre-cinco-sindicancias-e-substitui-comissoes-de-investigacoes-em-andamento/)
- **Judiciário:** nada encontrado nas fontes consultadas sobre ações judiciais relativas aos contratos ou à gestão da Segov. [Auditoria sobre o Segurança Presente](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/) [Cinco sindicâncias na Segov](https://boletimrj.com.br/pente-fino-corregedoria-da-secretaria-de-governo-abre-cinco-sindicancias-e-substitui-comissoes-de-investigacoes-em-andamento/)

##### Riscos de apagão administrativo
- **Continuidade dos serviços transferidos:** a transferência do Segurança Presente e do Barricada Zero para a Polícia Militar pode exigir conferência de responsabilidades, equipes, recursos e instrumentos administrativos; as fontes confirmam a transferência, mas não apontam interrupção de serviço. [Mudanças na Segov e no GSI](https://oglobo.globo.com/rio/noticia/2026/04/30/ricardo-couto-enxuga-segov-e-gsi-transferindo-seguranca-presente-e-barricada-zero-para-a-pm.ghtml)
- **Equipe e memória administrativa:** a Segov teve 385 dos 487 cargos comissionados exonerados, e a folha mensal caiu de R$ 4,2 milhões para R$ 1,1 milhão. Segundo a decisão, o secretário Roberto Lisandro Leão foi intimado, mas não respondeu dentro do prazo. A fonte não relaciona a redução da folha a uma paralisação. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/)
- **Pagamentos e continuidade contratual:** como os pagamentos do contrato Cesgranrio foram suspensos após a assunção interina, é necessário confirmar a situação atual, os serviços efetivamente entregues e os efeitos de eventual continuidade ou encerramento; a fonte não informa o status em 06/11/2026. [Auditoria sobre o Segurança Presente](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/)
- **Troca de comando:** em 14/10/2026, notícia sobre a transição apontou Bruno Bonetti e Jair Bittencourt como nomes em disputa para comandar a Segov, sem informar decisão final; a definição de autoridade responsável é relevante para acompanhar as pendências abertas. [Disputa pela chefia da Segov](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)

##### Fatos recentes
- Em 14/10/2026, a imprensa noticiou que Bruno Bonetti e Jair Bittencourt disputavam a indicação para comandar a Segov; a fonte não informa quem foi escolhido. [Disputa pela chefia da Segov](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)
- Em 26/09/2026, foi noticiada auditoria com indícios de sobrepreço e outras fragilidades no contrato de avaliação do Segurança Presente; os pagamentos haviam sido suspensos após a gestão interina assumir, sem confirmação do estado atual da suspensão. [Auditoria sobre o Segurança Presente](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/)
- A página, cuja última atualização consta como 19/07/2026, informa que foram instauradas cinco sindicâncias na Corregedoria da Segov: três com substituição de comissões em apurações em andamento e duas novas. [Cinco sindicâncias na Segov](https://boletimrj.com.br/pente-fino-corregedoria-da-secretaria-de-governo-abre-cinco-sindicancias-e-substitui-comissoes-de-investigacoes-em-andamento/)
- A página foi atualizada em 19/07/2026 e noticia nova diligência do TCE-RJ sobre a licitação de veículos, após etapa anterior em que o secretário não teria respondido no prazo; a fonte não informa o desfecho posterior. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/)
- Em 30/04/2026, decretos transferiram Segurança Presente e Barricada Zero para a Polícia Militar, no contexto de enxugamento da Segov e do GSI. [Mudanças na Segov e no GSI](https://oglobo.globo.com/rio/noticia/2026/04/30/ricardo-couto-enxuga-segov-e-gsi-transferindo-seguranca-presente-e-barricada-zero-para-a-pm.ghtml)

##### Lacunas da pesquisa
- Solicitar à Segov e à unidade responsável os processos integrais, aditivos, notas de empenho, liquidações, pagamentos, entregáveis e situação atual do contrato de R$ 49,6 milhões com a Cesgranrio, incluindo eventual decisão sobre continuidade ou encerramento e providências após a auditoria. [Auditoria sobre o Segurança Presente](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/)
- Solicitar a íntegra do processo da licitação de veículos, a resposta à diligência do TCE-RJ, a situação das atas e a confirmação documentada sobre anulação, contratos, empenhos e pagamentos. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/)
- Solicitar relação dos cinco processos de sindicância, objetos apurados, atos de instauração, responsáveis atuais, prorrogações e relatórios finais ou previsão de conclusão. [Cinco sindicâncias na Segov](https://boletimrj.com.br/pente-fino-corregedoria-da-secretaria-de-governo-abre-cinco-sindicancias-e-substitui-comissoes-de-investigacoes-em-andamento/)
- Solicitar inventário de programas e contratos transferidos, especialmente Segurança Presente, Barricada Zero e Lei Seca, com indicação do órgão gestor atual, equipes, dotações, obrigações pendentes e medidas de continuidade. [Mudanças na Segov e no GSI](https://oglobo.globo.com/rio/noticia/2026/04/30/ricardo-couto-enxuga-segov-e-gsi-transferindo-seguranca-presente-e-barricada-zero-para-a-pm.ghtml)
- Solicitar organograma e quadro atual de pessoal, identificação de funções essenciais, responsáveis por contratos e controle interno, e situação da chefia da Secretaria após as mudanças noticiadas. [TCE cobra explicações sobre licitação](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/) [Disputa pela chefia da Segov](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml)
- A página institucional consultada apresenta seções de transparência, incluindo “Licitações e Contratos”, mas os trechos disponíveis não detalham contratos, valores, vigências, decisões de controle ou irregularidades, nem permitem avaliar se há um quadro consolidado do orçamento, passivos, contratos vigentes e riscos de interrupção da Segov. [Secretaria de Estado de Governo](https://www.rj.gov.br/segov/)

##### Fontes consultadas
1. [Secretaria de Estado de Governo](https://www.rj.gov.br/segov/) — 2026-06-18
2. [TCE cobra explicações sobre licitação de R$ 62 milhões para aluguel de veículos feita durante gestão de André ](https://boletimrj.com.br/tce-cobra-explicacoes-sobre-licitacao-de-r-62-milhoes-para-aluguel-de-veiculos-feita-durante-gestao-de-andre-moura-na-segov/) — 2026-07-19
3. [Ricardo Couto enxuga Segov e GSI transferindo Segurança Presente e Barricada Zero para a PM](https://oglobo.globo.com/rio/noticia/2026/04/30/ricardo-couto-enxuga-segov-e-gsi-transferindo-seguranca-presente-e-barricada-zero-para-a-pm.ghtml) — 2026-04-30
4. [Auditoria aponta indícios de sobrepreço em contrato de R$ ...](https://temporealrj.com/auditoria-indicios-sobrepreco-seguranca-presente/) — 2026-09-26
5. [Pente-fino: Corregedoria da Secretaria de Governo abre cinco sindicâncias e substitui comissões de investigaçõ](https://boletimrj.com.br/pente-fino-corregedoria-da-secretaria-de-governo-abre-cinco-sindicancias-e-substitui-comissoes-de-investigacoes-em-andamento/) — 2026-07-19
6. [Ruas começa transição de governo estudando mudanças na ...](https://oglobo.globo.com/rio/noticia/2026/10/14/ruas-comeca-transicao-de-governo-estudando-mudancas-na-seguranca-publica-e-unificacao-de-secretarias-veja-os-detalhes.ghtml) — 2026-10-14


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2026002503 (ZENITE INFORMAÇÃO E CONSULTORIA S.A.) vence em 12/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2021006205 (EMPRESA BRASILEIRA DE ENGENHARIA E COMÉ…) vence em 02/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2022003570 (AMPLA ENERGIA E SERVIÇOS S/A) vence em 09/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2025010265 (BICICLETARIA E LANCHONETE CARIOCA LTDA) vence em 09/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025009850 (STEM SOLUÇÕES E INTEGRAÇÕES EDUCACIONAI…) vence em 10/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2025003186 (GLOBALTEC TECNOLOGIAS EDUCACIONAIS LTDA, R$ 57,1 mi) consta 'Ativo' no SIGA com fim em 08/05/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2025001299 (BARRA BR COMÉRCIO E SERVIÇOS LTDA, R$ 25,7 mi) consta 'Ativo' no SIGA com fim em 26/02/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2024000651 (PRIME CONSULTORIA E ASSESSORIA EMPRESAR…, R$ 25,0 mi) consta 'Ativo' no SIGA com fim em 10/09/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2022002785 (TRIVALE INSTITUICAO DE PAGAMENTO LTDA, R$ 14,9 mi) consta 'Ativo' no SIGA com fim em 09/11/2024: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2025010381 (HSOL INCENTIVE PERFORMANCE S.A., R$ 12,7 mi) consta 'Ativo' no SIGA com fim em 13/02/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
