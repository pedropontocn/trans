# Dossiê de transição — Secretaria de Estado de Transformação Digital (SETD)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/setd)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 53 | R$ 247.404.606,05 |
| Com vigência futura (válidos no SIGA) | 26 | R$ 170.399.670,44 |
| até 30 dias | 2 | R$ 516.406,25 |
| até 60 dias | 3 | R$ 27.832.664,83 |
| até 90 dias | 1 | R$ 25.183.304,56 |
| até 180 dias | 3 | R$ 1.905.517,32 |
| vencido no SIGA | 27 | R$ 77.004.935,61 |
| sem data | 3 | R$ 4.712.011,73 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 17,8 mi / R$ 16,0 mi / R$ 15,5 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2025010822 (VERT ANALYTICS LTDA.) vence em 26/12/2026 — 50 dias — R$ 16.222.050,00. Objeto: Aquisição de licença perpétua de Solução de Inteligência analítica integrada de…
- Contrato 2025001499 (CIX CITIZEN EXPERIENCE S/A) vence em 15/01/2027 — 70 dias — R$ 25.183.304,56. Objeto: Contratação de empresa especializada para implantação e disponibilização de sol…
- Mais 2 contratos menores (R$ 0,5 mi) vencem em até 30 dias — ver seção 3.
- 9 contratos (R$ 55,4 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 4 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 9,4 mi); 0 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 23 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 67,6 mi): provável falta de baixa no SIGA (risco de controle, não de execução).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025009154 | PRODERJ | CLAVIS BBR CONSULTORIA EM INFORMATICA S/A | Contratação de empresa de Tecnologia da Informação para o forneciment… | R$ 321.406,25 | 19/11/2026 | 13 |
| 2025009610 | PRODERJ | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada para a confecção de cartão eletr… | R$ 195.000,00 | 28/11/2026 | 22 |
| 2025010858 | PRODERJ | LGPDNOW TRATAMENTO E HOSPEDAGEM DE DADOS LTDA | Contratação de plataforma para Automação de Machine Learning e Confor… | R$ 6.750.763,59 | 23/12/2026 (PNCP) | 47 |
| 2025010830 | PRODERJ | BLUE EYE SOLUÇÕES EM TECNOLOGIA LTDA | Prestação de serviços de subscrições de Plataforma para Gerenciamento… | R$ 4.859.851,24 | 24/12/2026 (PNCP) | 48 |
| 2025010822 | PRODERJ | VERT ANALYTICS LTDA. | Aquisição de licença perpétua de Solução de Inteligência analítica in… | R$ 16.222.050,00 | 26/12/2026 (PNCP) | 50 |
| 2025001499 | SETD | CIX CITIZEN EXPERIENCE S/A | Contratação de empresa especializada para implantação e disponibiliza… | R$ 25.183.304,56 | 15/01/2027 (PNCP) | 70 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000741 | PRODERJ | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Contratação da Imprensa Oficial do Estado do Rio de Janeiro  IOERJ, … | R$ 158.327,80 | 10/02/2027 | 96 |
| 2025010682 | SETD | CEMAFER PRODUÇÕES LTDA | Trata-se de contrato de patrocínio que tem como objeto o apoio financ… | R$ 1.100.000,00 | 25/02/2027 (PNCP) | 111 |
| 2026000660 | SETD | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | O objeto do presente Contrato é a prestação de serviços de agente de … | R$ 647.189,52 | 25/02/2027 (PNCP) | 111 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025009521 | PRODERJ | 3STRUCTURE IT LTDA | Registro de Preços visando a aquisição de solução de appliances de ba… | R$ 7.817.177,04 | 06/06/2026 (PNCP) | -153 |
| 2025008809 | PRODERJ | XERTICA BRASIL LTDA | Prestação de serviços de computação em nuvem da plataforma Google Clo… | R$ 1.422.000,00 | 03/11/2026 (PNCP) | -3 |
| 2025007414 | PRODERJ | INSTITUTO IBDO DE GESTÃO E PROJETOS | Contratação de pessoa jurídica especializada na prestação de serviços… | R$ 144.000,00 | 24/09/2026 | -43 |
| 2025009223 | PRODERJ | CLG TREINAMENTO PROFISSIONAL LTDA | O objeto da contratação proposta é a participação de 05 (cinco) servi… | R$ 6.390,40 | 06/12/2025 | -335 |

_Registros mais antigos (provável falta de baixa no SIGA): 23, R$ 67,6 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025007002 | PRODERJ | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Lote I: Registro de preços para a prestação de serviços de subscriçõe… | R$ 43.268.361,00 | 11/09/2027 | 309 |
| 2025001499 | SETD | CIX CITIZEN EXPERIENCE S/A | Contratação de empresa especializada para implantação e disponibiliza… | R$ 25.183.304,56 | 15/01/2027 (PNCP) | 70 |
| 2026002990 | PRODERJ | KTREE PENSO TECNOLOGIA DA INFORMAÇÃO LTDA. | Contratação de empresa para prestação de serviços de subscrições de p… | R$ 25.002.000,00 | 16/04/2029 | 892 |
| 2025010822 | PRODERJ | VERT ANALYTICS LTDA. | Aquisição de licença perpétua de Solução de Inteligência analítica in… | R$ 16.222.050,00 | 26/12/2026 (PNCP) | 50 |
| 2025006919 | PRODERJ | ORACLE DO BRASIL SISTEMAS LTDA | Prestação dos serviços de suporte Especializado ao Produto (Nível Pri… | R$ 15.173.168,30 | 17/09/2027 | 315 |
| 2024010456 | PRODERJ | 3STRUCTURE IT LTDA | Contratação de empresa especializada no fornecimento de subscrições d… | R$ 10.110.660,89 | 26/12/2029 | 1146 |
| 2024008661 | PRODERJ | CABERJ INTEGRAL SAÚDE S/A | O Termo de Referência em questão visa à contratação, por meio de Preg… | R$ 6.984.000,00 | 28/10/2027 | 356 |
| 2025010858 | PRODERJ | LGPDNOW TRATAMENTO E HOSPEDAGEM DE DADOS LTDA | Contratação de plataforma para Automação de Machine Learning e Confor… | R$ 6.750.763,59 | 23/12/2026 (PNCP) | 47 |
| 2025010830 | PRODERJ | BLUE EYE SOLUÇÕES EM TECNOLOGIA LTDA | Prestação de serviços de subscrições de Plataforma para Gerenciamento… | R$ 4.859.851,24 | 24/12/2026 (PNCP) | 48 |
| 2012009460 | PRODERJ | TAREA GERENCIAMENTO LTDA | Prestação de serviço de suporte técnico assistido Oracle. | R$ 4.049.771,73 | — |  |
| 2025010828 | PRODERJ | 3STRUCTURE IT LTDA | Contratação de empresa especializada no fornecimento de subscrições d… | R$ 3.114.485,00 | 24/12/2030 | 1509 |
| 2025007871 | PRODERJ | 3STRUCTURE IT LTDA | A presente Ata tem por objeto o registro de preços para a eventual co… | R$ 1.671.040,00 | 17/10/2030 | 1441 |
| 2024005205 | PRODERJ | RIOPAR PARTICIPAÇÕES S/A | CONTRATAÇÃO DA EMPRESA RIOPAR PARTICIPAÇÕES S/A, CNPJ: 16.727.386/000… | R$ 1.427.976,00 | 26/06/2028 | 598 |
| 2025005723 | PRODERJ | CBD BOLHETE DIGITAL S/A | Contratação, POR INEXIGIBILIDADE, da empresa CBD BILHETE DIGITAL S/A,… | R$ 1.427.976,00 | 01/08/2027 | 268 |
| 2025005235 | PRODERJ | CS BRASIL FROTAS S.A. | A presente Ata tem por objeto o registro de preços para a contratação… | R$ 1.195.136,26 | 05/08/2028 | 638 |
| 2025010682 | SETD | CEMAFER PRODUÇÕES LTDA | Trata-se de contrato de patrocínio que tem como objeto o apoio financ… | R$ 1.100.000,00 | 25/02/2027 (PNCP) | 111 |
| 2026000660 | SETD | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | O objeto do presente Contrato é a prestação de serviços de agente de … | R$ 647.189,52 | 25/02/2027 (PNCP) | 111 |
| 2012002069 | PRODERJ | FIRST TECH TECNOLOGIA LTDA | Prestação de serviços para implementação de uma solução avançada de f… | R$ 548.000,00 | — |  |
| 2026000712 | PRODERJ | 3CORP TECHNOLOGY S/A INFRA ESTRUTURA TELECOM | Contratação de empresa especializada na prestação de serviços de Solu… | R$ 340.804,80 | 13/03/2028 | 493 |
| 2026006142 | SETD | REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | LOCAÇÃO DE VEÍCULO DE REPRESENTAÇÃO BLINDADO | R$ 324.000,00 | 27/08/2029 | 1025 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES LTDA | 1 | R$ 43.268.361,00 |
| CIX CITIZEN EXPERIENCE S/A | 1 | R$ 25.183.304,56 |
| KTREE PENSO TECNOLOGIA DA INFORMAÇÃO LTDA. | 1 | R$ 25.002.000,00 |
| VERT ANALYTICS LTDA. | 1 | R$ 16.222.050,00 |
| ORACLE DO BRASIL SISTEMAS LTDA | 1 | R$ 15.173.168,30 |
| 3STRUCTURE IT LTDA | 3 | R$ 14.896.185,89 |
| CABERJ INTEGRAL SAÚDE S/A | 1 | R$ 6.984.000,00 |
| LGPDNOW TRATAMENTO E HOSPEDAGEM DE DADOS LTDA | 1 | R$ 6.750.763,59 |
| BLUE EYE SOLUÇÕES EM TECNOLOGIA LTDA | 1 | R$ 4.859.851,24 |
| TAREA GERENCIAMENTO LTDA | 1 | R$ 4.049.771,73 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2019003649 | TECHNE ENGENHARIA E SISTEMAS LTDA | R$ 8.053.295,00 | R$ 7.563.369,61 | R$ 489.925,39 |

## 11. Unidades incluídas neste dossiê
- PRODERJ - CENTRO DE TECN DE INFORMAÇÃO E COMUN DO ERJ
- SETD - SECRETARIA DE ESTADO DE TRANSFORMACAO DIGITAL

## 12. Conjuntos de dados abertos da secretaria
- Órgãos do Poder Executivo Estadual e respectivos responsáveis (atualizado 2026-10-21): [2026_10_21_Orgaos_e_Responsaveis_Diario… CSV](https://dadosabertos.rj.gov.br/dataset/ef82dd92-7384-4b60-a0cf-0f6d774c0946/resource/c87b0701-dbdd-4284-b995-5df3e7016cd0/download/2026_10_21_orgaos_e_responsaveis_diario_oficial.csv), [2026_10_14_Orgaos_e_Responsaveis_Diario… CSV](https://dadosabertos.rj.gov.br/dataset/ef82dd92-7384-4b60-a0cf-0f6d774c0946/resource/52c70d5f-4224-48e5-b2ac-aac49dce5875/download/2026_10_14_orgaos_e_responsaveis_diario_oficial.csv), [2026_10_07_Orgaos_e_Responsaveis_Diario… CSV](https://dadosabertos.rj.gov.br/dataset/ef82dd92-7384-4b60-a0cf-0f6d774c0946/resource/c231af50-2a53-4c5b-b411-45b1e0242766/download/2026_10_07_orgaos_e_responsaveis_diario_oficial.csv), [2026_09_30_Orgaos_e_Responsaveis_Diario… CSV](https://dadosabertos.rj.gov.br/dataset/ef82dd92-7384-4b60-a0cf-0f6d774c0946/resource/5e289aed-5b58-4594-ba6a-05fd9b3338f2/download/2026_09_30_orgaos_e_responsaveis_diario_oficial.csv)
- Serviços no Portal RJ Digital (rj.gov.br) (atualizado 2026-10-14): [Servicos_2026_09_16.csv CSV](https://dadosabertos.rj.gov.br/dataset/3ece64a3-bfdb-4d2e-b0fa-ace0fb0d0a03/resource/54d6dad3-7c31-40f9-9560-2ff173b024e7/download/servicos_2026_09_16.csv), [Servicos_2026_09_16.json JSON](https://dadosabertos.rj.gov.br/dataset/3ece64a3-bfdb-4d2e-b0fa-ace0fb0d0a03/resource/46df039f-235c-41a7-83e7-4d0c07d03892/download/servicos_2026_09_16.json), [Acessos a serviços no Portal CSV](https://dadosabertos.rj.gov.br/dataset/3ece64a3-bfdb-4d2e-b0fa-ace0fb0d0a03/resource/5d848d92-bf75-4d1a-b02b-1ef27dd585a3/download/acessos_2024_03_13_extensa.csv), [Serviços ofertados no portal 19/mar/26 CSV](https://dadosabertos.rj.gov.br/dataset/3ece64a3-bfdb-4d2e-b0fa-ace0fb0d0a03/resource/78be25b6-cbbd-438e-9ee3-cf24f5057dfb/download/acessos_2026_03_19_compacta.csv)
- Municípios participantes do Programa RJ Digital (atualizado 2026-05-14): [Municípios participantes do programa RJ… CSV](https://dadosabertos.rj.gov.br/dataset/a92b531f-7fd3-4b15-b45e-fa9e56d7989a/resource/c8b44d8d-fbc1-4a8f-ba81-52dd914126e4/download/2026_01_10_adesao_ao_programa_rjdigital_principal.csv), [Municípios participantes do programa RJ… CSV](https://dadosabertos.rj.gov.br/dataset/a92b531f-7fd3-4b15-b45e-fa9e56d7989a/resource/df9afff3-1a00-4efa-bd3a-5b0ac6d62d6f/download/2025_10_10_adesao_ao_programa_rjdigital__principal.csv), [Municípios participantes do programa RJ… CSV](https://dadosabertos.rj.gov.br/dataset/a92b531f-7fd3-4b15-b45e-fa9e56d7989a/resource/9d8c3f03-5f60-4a57-ba46-e0da87894e88/download/2025_10_10_adesao_ao_programa_rjdigital_principal.csv), [Municípios participantes do programa RJ… CSV](https://dadosabertos.rj.gov.br/dataset/a92b531f-7fd3-4b15-b45e-fa9e56d7989a/resource/e8367339-7a47-4e50-8d38-d650ccc70a77/download/2025_07_10_adesao_ao_programa_rjdigital_principal.csv)
- Guias para o Portal de Dados Abertos (atualizado 2026-05-08): [Manual do gestor para o Portal de Dados… PDF](https://dadosabertos.rj.gov.br/dataset/fa33c1f0-8e12-439f-a3fc-e9dbb2c606be/resource/a2ba56fa-1631-4aec-ad03-305640772078/download/manual_portal_dados_abertos__gestores.pdf), [Manual do Cidadão para o Portal de Dado… PDF](https://dadosabertos.rj.gov.br/dataset/fa33c1f0-8e12-439f-a3fc-e9dbb2c606be/resource/2452eeb2-b55e-45b7-98c8-e139b03f0c25/download/guia_cidadao_para_portal_dados_abertos_rj-final-.pdf), [Guia_Portal_Dados_Abertos_RJ_SECC_DOERJ… PDF](https://dadosabertos.rj.gov.br/dataset/fa33c1f0-8e12-439f-a3fc-e9dbb2c606be/resource/b29e1ab7-9085-4359-97fe-25c90a181888/download/guia_portal_dados_abertos_rj_secc_doerj_lei.pdf)
- Acordos de Cooperação Técnica (atualizado 2026-05-07): [ACTs_SETD_2025_.csv CSV](https://dadosabertos.rj.gov.br/dataset/5d05583a-a303-408c-9d3b-3347a50c1a67/resource/517a98e3-3209-4303-a75e-ba7ae87eab44/download/acts_setd_2025.csv)
- Órgãos com Encarregado pela Lei Geral de Proteção de Dados Pessoais (LGPD) indicado (atualizado 2026-05-07): [2026_03_10_orgaos_lgpd_indicados.csv CSV](https://dadosabertos.rj.gov.br/dataset/7fadcc34-7f97-4623-93f9-61590bd5ad9d/resource/ba7d3e77-e48d-4843-b544-27dda3e953ef/download/2026_03_10_orgaos_lgpd_indicados.csv)
- Órgãos com DPO (Data Protection Officer/Encarregado de Proteção de Dados) indicados (atualizado 2026-05-07): [2026_03_10_orgaos_dpo_indicados.csv CSV](https://dadosabertos.rj.gov.br/dataset/807b26f9-51b9-4130-84a4-c32e382e8d65/resource/329926ca-70fe-41d1-8aa3-5610a1185fe5/download/2026_03_10_orgaos_dpo_indicados.csv), [2026_02_10_orgaos_dpo_indicados.csv CSV](https://dadosabertos.rj.gov.br/dataset/807b26f9-51b9-4130-84a4-c32e382e8d65/resource/59cfbb5f-797a-4717-ad79-1117644bfba4/download/2026_02_10_orgaos_dpo_indicados.csv), [2026_01_10_orgaos_dpo_indicados.csv CSV](https://dadosabertos.rj.gov.br/dataset/807b26f9-51b9-4130-84a4-c32e382e8d65/resource/6421db76-2a18-45be-84f9-87d21a76fe7c/download/2026_01_10_orgaos_dpo_indicados.csv), [2025_12_10_orgaos_dpo_indicados.csv CSV](https://dadosabertos.rj.gov.br/dataset/807b26f9-51b9-4130-84a4-c32e382e8d65/resource/aafb2bd9-a127-4b3c-8e9f-1701dc1b2d4b/download/2025_12_10_orgaos_dpo_indicados.csv)
- Dados quantitativos SEI-RJ (atualizado 2026-05-07): [sigla_orgao-total_documentos_0425 CSV](https://dadosabertos.rj.gov.br/dataset/54a7c611-d1ca-4ec0-8779-8dea64163055/resource/3931515f-c122-4017-8ec4-48a65322801a/download/sigla_orgao-total_documentos.csv), [sigla_orgao-total_processos_0425 CSV](https://dadosabertos.rj.gov.br/dataset/54a7c611-d1ca-4ec0-8779-8dea64163055/resource/ed91419c-52dc-4747-b26e-ef0d0df3f82a/download/sigla_orgao-total_processos.csv), [tipo_documental-total_0425 CSV](https://dadosabertos.rj.gov.br/dataset/54a7c611-d1ca-4ec0-8779-8dea64163055/resource/e8648417-ff41-4021-9462-0315e4f8e854/download/tipo_documental-total.csv), [tipo_processual-total_0425 CSV](https://dadosabertos.rj.gov.br/dataset/54a7c611-d1ca-4ec0-8779-8dea64163055/resource/68aa8a49-0e6b-4e8c-ac7f-23353406bd9c/download/tipo_processual-total.csv)
- Órgãos com pontos focais (representantes) para o Programa Dados Abertos (atualizado 2026-05-07): [versão 10/abr/2026: Órgãos com pontos f… CSV](https://dadosabertos.rj.gov.br/dataset/822ab217-ed2e-460a-8ed2-ffacca163b67/resource/760b07cc-9c37-4ae9-8400-4e6195ad3eb4/download/2026_04_10_orgaos_pontos_focais_dad_abert_indicados_pub_dad_abert.csv), [versão 01/jan/2026: Órgãos com pontos f… CSV](https://dadosabertos.rj.gov.br/dataset/822ab217-ed2e-460a-8ed2-ffacca163b67/resource/52877bee-861f-42de-bd92-45c065b19668/download/2026_01_06_orgaos_pontos_focais_dad_abert_indicados_pub_dad_abert-2025_10_10_orgaos_pontos_focai.csv), [versão 10/nov/2025: Órgãos com pontos f… CSV](https://dadosabertos.rj.gov.br/dataset/822ab217-ed2e-460a-8ed2-ffacca163b67/resource/e87147bd-d854-4e09-bc5a-36e02d2be048/download/2025_11_10_orgaos_pontos_focais_dad_abert_indicados_pub_dad_abert.csv), [versão 10/out/2025: Órgãos com pontos f… CSV](https://dadosabertos.rj.gov.br/dataset/822ab217-ed2e-460a-8ed2-ffacca163b67/resource/55ac0710-38ea-4a8a-bbb2-463a0be8d371/download/2025_10_10_orgaos_pontos_focais_dad_abert_indicados_pub_dad_abert.csv)
- Plano de Dados Abertos SETD (atualizado 2025-12-18): [SEI_121083710_Plano_de_Dados_Abertos_PD… PDF](https://dadosabertos.rj.gov.br/dataset/eab8e9c5-8f00-4c13-8120-368bd89dc2ac/resource/69281d69-9d09-4f88-a0f3-562fa30fcf05/download/sei_121083710_plano_de_dados_abertos_pda_setd_2025_assinado.pdf)
- Órgãos com pontos focais (representantes) para o Programa Qualidade do RJ Digital (atualizado 2025-10-27): [versão 10/mar/2025: Órgãos com pontos f… CSV](https://dadosabertos.rj.gov.br/dataset/35b92fab-32a0-4e73-8443-04f7197b7f5e/resource/eefb0930-15d3-4bb5-bbb6-d828867017cd/download/2025_03_10_orgaos_pontos_focais_rede_qualidade_indicados.csv), [versão 10/fev/2025: Órgãos com pontos f… CSV](https://dadosabertos.rj.gov.br/dataset/35b92fab-32a0-4e73-8443-04f7197b7f5e/resource/c3241025-f9a7-422e-85f4-7841db37e91e/download/2025_02_10_orgaos_pontos_focais_rede_qualidade_indicados.csv), [versão 10/jan/2025: Órgãos com pontos f… CSV](https://dadosabertos.rj.gov.br/dataset/35b92fab-32a0-4e73-8443-04f7197b7f5e/resource/7c2844ba-408e-4d4e-b220-dc67ee50ead5/download/2025_01_10_orgaos_pontos_focais_rede_qualidade_indicados.csv), [versão 10/dez/2024: Órgãos com pontos f… CSV](https://dadosabertos.rj.gov.br/dataset/35b92fab-32a0-4e73-8443-04f7197b7f5e/resource/20cd2602-4f3d-4e49-92d2-6142a06cc205/download/2024_12_10_orgaos_pontos_focais_rede_qualidade_indicados.csv)
- Catálogo de Dados disponibilizados no Portal de Dados Abertos do Estado do Rio de Janeiro (atualizado 2025-10-27): [Dados agrupados do portal CSV](https://dadosabertos.rj.gov.br/dataset/8e58c8aa-5e7d-4ae6-bf59-ac336cc2a00d/resource/af0fd8fe-dfd4-4bc4-9ed6-38c199f46580/download/ckan-dados-agrupados.csv)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 8 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo
- O TCE-RJ concluiu auditoria sobre o Programa RJ Digital e determinou que SETD e PRODERJ elaborem planos de ação para atender às medidas corretivas. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
- Há registros de procedimentos de contratação de tecnologia vinculados ao PRODERJ: uma licitação de firewall, divulgada por R$ 90,2 milhões, e a adjudicação do Lote 1 do pregão para registro de preços de soluções Qlik por R$ 32,4 milhões. As fontes não confirmam a execução atual desses objetos nem a vigência de eventuais contratos. [Licitação de firewall do PRODERJ](https://temporealrj.com/ta-em-crise-chama-o-proderj-empresa-finaliza-mais-uma-licitacao-desta-vez-de-r-902-milhoes/) [Homologação de pregão do PRODERJ](https://www.rj.gov.br/proderj/sites/default/files/arquivos-andamento/Publicacao%20ADJ%20e%20Homolog_APM_DOERJ.pdf)
- O achado de ausência de integração de serviços ao Portal RJ Digital e a ineficiência no pagamento de taxas são problemas apontados pela auditoria, mas as fontes não registram interrupção de serviços ou apagão administrativo. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
- A página do [Arquivo de Transparência — Tempo Real](https://temporealrj.com/category/transparencia/page/8/) exibe reportagem cujo título informa que dois pregões do PRODERJ custariam R$ 390 milhões. No conteúdo fornecido, não constam os pregões, fornecedores, valores individuais ou vigências.

##### Alertas vermelhos
- **Controle externo:** o TCE-RJ determinou planos de ação à SETD e ao PRODERJ e informou que acompanhará o cumprimento em auditorias futuras; as fontes fornecidas não mostram os planos nem o estágio de cumprimento. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
- **Entrega do RJ Digital:** a auditoria apontou excesso de 297% de serviços cadastrados no portal em relação aos serviços efetivos, falta de planos de digitalização em 28 órgãos estaduais, ausência de integração de serviços ao portal e ineficiência no pagamento de taxas; o texto não atribui individualmente esses achados à SETD. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
- **Exposição financeira a esclarecer:** a página do Tempo Real traz no título dois pregões do PRODERJ por R$ 390 milhões e informa que a reportagem foi atualizada com nota da Secretaria, mas não reproduz a nota nem os detalhes dos pregões no conteúdo fornecido. Isso é um tema para diligência, não evidência de irregularidade. [Arquivo de Transparência — Tempo Real](https://temporealrj.com/category/transparencia/page/8/)
- **Apuração administrativa sem desfecho disponível:** em fevereiro de 2026, a SETD instituiu duas comissões de sindicância para apurar fatos de processos administrativos distintos, com prazo de 30 dias para conclusão; as fontes não descrevem os fatos apurados nem informam resultados. [Publicação de resoluções e atos da SETD/PRODERJ](https://www.rj.gov.br/proderj/sites/default/files/arquivos-andamento/Publicacao%20ADJ%20e%20Homolog_APM_DOERJ.pdf)
- **Risco administrativo histórico:** o PLANAT 2025 registrou que a SETD não recebeu da extinta SEJUS patrimônio, recursos, pessoal, processos, registros ou informações, e que usava espaço limitado e compartilhado com o PRODERJ; o documento previa transferência para nova sede ao longo de 2025, mas as fontes não informam a situação atual. [PLANAT 2025 da SETD](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/PLANAT%202025.pdf)

##### Contratos e serviços críticos
- A licitação de firewall noticiada em dezembro de 2024 tinha como objeto hardware, software, instalação, configuração e treinamento; foram informados R$ 60,8 milhões para 2R Datatel Teleinformática e R$ 29,4 milhões para PPN Tecnologia e Informática, totalizando R$ 90,2 milhões. A reportagem informa garantia de 60 meses, mas não informa número da licitação nem vigência contratual. [Licitação de firewall do PRODERJ](https://temporealrj.com/ta-em-crise-chama-o-proderj-empresa-finaliza-mais-uma-licitacao-desta-vez-de-r-902-milhoes/)
- Em publicação referente ao Pregão Eletrônico para Registro de Preços PE-RP 011/2024, o PRODERJ adjudicou e homologou o resultado do Lote 1 à JAMC Consultoria e Representação de Software Ltda., por R$ 32.400.000,00, para subscrições, licenças, serviços técnicos, suporte, treinamento, garantia, atualização e manutenção de ambiente Qlik. A fonte não informa, no trecho fornecido, a vigência da ata ou a execução dos serviços. [Homologação de pregão do PRODERJ](https://www.rj.gov.br/proderj/sites/default/files/arquivos-andamento/Publicacao%20ADJ%20e%20Homolog_APM_DOERJ.pdf)
- O Tempo Real reportou dois pregões do PRODERJ que, segundo o título, custariam R$ 390 milhões; o conteúdo fornecido não identifica objetos, números, fornecedores, valores individuais ou vigências. [Arquivo de Transparência — Tempo Real](https://temporealrj.com/category/transparencia/page/8/)
- O PLANAT identifica o PRODERJ como ente vinculado à SETD e gestor estadual de TIC, mas as fontes não apresentam inventário de sistemas críticos, contratos de operação, níveis de serviço, dependências técnicas ou plano de continuidade. [PLANAT 2025 da SETD](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/PLANAT%202025.pdf)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)
- O TCE-RJ recomendou padronizar documentos de arrecadação e criar solução única de pagamento integrada ao Portal RJ Digital, com PIX para taxas estaduais; publicar painel público de monitoramento; e reavaliar o MPISD para reforçar o alinhamento entre as redes Unifica e de Qualidade. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
- A SETD e o PRODERJ devem elaborar planos de ação estruturados para cumprir as medidas corretivas, e o TCE-RJ informou que fará monitoramento em auditorias futuras; não há, nas fontes fornecidas, prazo, plano apresentado ou decisão posterior sobre cumprimento. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
- **MPRJ:** nada encontrado nas fontes consultadas sobre ações ou procedimentos do Ministério Público relacionados à SETD ou aos fatos descritos. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital) [Licitação de firewall do PRODERJ](https://temporealrj.com/ta-em-crise-chama-o-proderj-empresa-finaliza-mais-uma-licitacao-desta-vez-de-r-902-milhoes/) [Arquivo de Transparência — Tempo Real](https://temporealrj.com/category/transparencia/page/8/)
- **Judiciário:** nada encontrado nas fontes consultadas sobre ações judiciais relacionadas à SETD, ao PRODERJ ou aos contratos citados. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital) [Licitação de firewall do PRODERJ](https://temporealrj.com/ta-em-crise-chama-o-proderj-empresa-finaliza-mais-uma-licitacao-desta-vez-de-r-902-milhoes/) [Arquivo de Transparência — Tempo Real](https://temporealrj.com/category/transparencia/page/8/)
- As resoluções de sindicância de fevereiro de 2026 identificam os processos SEI-430001/006268/2025 e SEI-430001/006854/2025, mas o conteúdo fornecido não revela os fatos investigados nem resultados; é necessário obter os autos e os relatórios conclusivos. [Publicação de resoluções e atos da SETD/PRODERJ](https://www.rj.gov.br/proderj/sites/default/files/arquivos-andamento/Publicacao%20ADJ%20e%20Homolog_APM_DOERJ.pdf)

##### Riscos de apagão administrativo
- A auditoria do TCE-RJ registrou ausência de integração de serviços ao Portal RJ Digital e ineficiência no processo de pagamento de taxas, além das lacunas de planejamento de digitalização; esses achados indicam riscos à entrega e à jornada digital, mas não comprovam interrupção de serviço. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
- O PLANAT 2025 documentou espaço físico limitado, compartilhamento de sala com o PRODERJ e previsão de mudança de sede ao longo de 2025; a fonte não confirma se a mudança ocorreu ou qual é a condição atual de instalações e continuidade operacional. [PLANAT 2025 da SETD](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/PLANAT%202025.pdf)
- Nada encontrado nas fontes consultadas que confirme risco de interrupção de serviços, apagão de sistemas, plano de contingência acionado ou crise financeira da SETD; a reportagem de 2024, ao contrário, afirma que o PRODERJ seguia finalizando licitações apesar da crise nos caixas estaduais. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital) [Licitação de firewall do PRODERJ](https://temporealrj.com/ta-em-crise-chama-o-proderj-empresa-finaliza-mais-uma-licitacao-desta-vez-de-r-902-milhoes/)

##### Fatos recentes
- Em conteúdo datado de 2026, o Tempo Real registrou que uma reportagem sobre dois pregões do PRODERJ, intitulada como licitações de R$ 390 milhões, foi atualizada com nota da Secretaria; a íntegra da nota não aparece no material fornecido. [Arquivo de Transparência — Tempo Real](https://temporealrj.com/category/transparencia/page/8/)
- Em fevereiro de 2026, a SETD publicou resoluções instituindo duas comissões de sindicância, ambas com prazo de 30 dias para conclusão; não há resultado das apurações no conteúdo fornecido. [Publicação de resoluções e atos da SETD/PRODERJ](https://www.rj.gov.br/proderj/sites/default/files/arquivos-andamento/Publicacao%20ADJ%20e%20Homolog_APM_DOERJ.pdf)
- A Resolução SETD nº 130, de 3 de fevereiro de 2026, aprovou procedimentos de gestão, fiscalização e pagamento de contratos da Secretaria, entrou em vigor na publicação e revogou as Resoluções SETD nº 17/2023 e nº 129/2026. [Resolução SETD nº 130/2026](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/RES_SETD_130-2026_Gest%C3%A3o_e_Fiscaliza%C3%A7%C3%A3o.pdf)
- O documento PEDTIC 2026, versão 1.7, registra revisão extraordinária em janeiro de 2026 e assinaturas eletrônicas em 6 de fevereiro de 2026; o material fornecido não informa sua data de publicação. [PEDTIC 2026 da SETD](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/PEDTIC_SETD_2026_Vers%C3%A3o_1.7.pdf)

##### Lacunas da pesquisa
- Solicitar à SETD e ao PRODERJ os planos de ação apresentados ao TCE-RJ, evidências de execução e situação de cada recomendação, pois as fontes apenas registram a determinação e o futuro monitoramento. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital)
- Solicitar a íntegra da reportagem e da nota da Secretaria sobre os dois pregões de R$ 390 milhões, além dos editais, atas, adjudicações, contratos, fornecedores, valores individuais, vigências e situação de execução. [Arquivo de Transparência — Tempo Real](https://temporealrj.com/category/transparencia/page/8/)
- Solicitar os instrumentos contratuais e a situação de execução da licitação de firewall de R$ 90,2 milhões e do Lote 1 Qlik de R$ 32.400.000,00, inclusive vigências, garantias, pagamentos, fiscais, níveis de serviço e eventuais aditivos, pois esses dados não constam integralmente nas fontes fornecidas. [Licitação de firewall do PRODERJ](https://temporealrj.com/ta-em-crise-chama-o-proderj-empresa-finaliza-mais-uma-licitacao-desta-vez-de-r-902-milhoes/) [Homologação de pregão do PRODERJ](https://www.rj.gov.br/proderj/sites/default/files/arquivos-andamento/Publicacao%20ADJ%20e%20Homolog_APM_DOERJ.pdf)
- Solicitar inventário de serviços e sistemas críticos, integrações, indisponibilidades, contingência, dependências de fornecedores e situação atual da mudança de sede; as fontes não informam esses dados atuais. [TCE-RJ sobre o RJ Digital](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital) [PLANAT 2025 da SETD](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/PLANAT%202025.pdf)
- Solicitar os autos e os relatórios finais das sindicâncias dos processos SEI-430001/006268/2025 e SEI-430001/006854/2025, uma vez que as fontes fornecidas não descrevem os fatos apurados nem o resultado. [Publicação de resoluções e atos da SETD/PRODERJ](https://www.rj.gov.br/proderj/sites/default/files/arquivos-andamento/Publicacao%20ADJ%20e%20Homolog_APM_DOERJ.pdf)
- Solicitar posição atualizada sobre orçamento, dívidas, restos a pagar, passivos, quadro de pessoal, ocupação da sede e titularidade da Secretaria; esses dados não estão estabelecidos pelas fontes fornecidas, e o documento que identifica o secretário Fernando Braga Martins é de fevereiro de 2026, não bastando para confirmar a titularidade em 06/11/2026. [Resolução SETD nº 130/2026](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/RES_SETD_130-2026_Gest%C3%A3o_e_Fiscaliza%C3%A7%C3%A3o.pdf) [PLANAT 2025 da SETD](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/PLANAT%202025.pdf)

##### Fontes consultadas
1. [TCE-RJ recomenda aprimoramentos na execução do Programa RJ ...](https://www.tcerj.tc.br/portalnovo/noticia/tce_rj_recomenda_aprimoramentos_na_execucao_do_programa_rj_digital) — 2025-10-30
2. [Tá em crise? Chama o Proderj: empresa finaliza mais uma ...](https://temporealrj.com/ta-em-crise-chama-o-proderj-empresa-finaliza-mais-uma-licitacao-desta-vez-de-r-902-milhoes/) — 2024-12-28
3. [Arquivo de Transparência - Página 8 de 73 - Tempo Real](https://temporealrj.com/category/transparencia/page/8/) — 2026-10-26
4. [ PDF  Anexo 1 PEDTIC 2026 - Governo do Estado do Rio de Janeiro](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/PEDTIC_SETD_2026_Vers%C3%A3o_1.7.pdf) — 2026-02-20
5. [ PDF  Á - RJ Gov](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/RES_SETD_130-2026_Gest%C3%A3o_e_Fiscaliza%C3%A7%C3%A3o.pdf) — 2026-04-15
6. [23/02/2026 PI230226-S-01___24](https://www.rj.gov.br/proderj/sites/default/files/arquivos-andamento/Publicacao%20ADJ%20e%20Homolog_APM_DOERJ.pdf) — 2026-03-25
7. [PLANO ANUAL DE ATIVIDADES DA AUDITORIA INTERNA](https://www.rj.gov.br/digital/sites/default/files/arquivos_paginas/PLANAT%202025.pdf) — 2026-01-09
8. [��Á���](https://www.rj.gov.br/seiop/sites/default/files/arquivos_pagina_basica/Anexo%20Publica%C3%A7%C3%A3o%20no%20D.O..pdf) — 2025-11-29


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2025009154 (CLAVIS BBR CONSULTORIA EM INFORMATICA S…) vence em 19/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2025009610 (LECARD ADMNISTRADORA DE CARTÕES LTDA) vence em 28/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025010858 (LGPDNOW TRATAMENTO E HOSPEDAGEM DE DADO…) vence em 23/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2025010830 (BLUE EYE SOLUÇÕES EM TECNOLOGIA LTDA) vence em 24/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025010822 (VERT ANALYTICS LTDA.) vence em 26/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2025009521 (3STRUCTURE IT LTDA, R$ 7,8 mi) consta 'Ativo' no SIGA com fim em 06/06/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2025008809 (XERTICA BRASIL LTDA, R$ 1,4 mi) consta 'Ativo' no SIGA com fim em 03/11/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2025007414 (INSTITUTO IBDO DE GESTÃO E PROJETOS, R$ 0,1 mi) consta 'Ativo' no SIGA com fim em 24/09/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2025009223 (CLG TREINAMENTO PROFISSIONAL LTDA, R$ 0,0 mi) consta 'Ativo' no SIGA com fim em 06/12/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
12. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
13. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
14. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
15. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
