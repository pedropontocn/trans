# Unidades do SIGA sem secretaria definida

Inclua-as em `config/mapa_unidades.csv`.


