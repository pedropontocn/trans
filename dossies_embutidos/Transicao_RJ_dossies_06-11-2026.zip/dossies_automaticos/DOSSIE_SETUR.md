# Dossiê de transição — Secretaria de Estado de Turismo (SETUR)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/setur)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 174 | R$ 40.531.427,36 |
| Com vigência futura (válidos no SIGA) | 3 | R$ 547.914,13 |
| até 30 dias | 0 | R$ 0,00 |
| até 60 dias | 0 | R$ 0,00 |
| até 90 dias | 0 | R$ 0,00 |
| até 180 dias | 0 | R$ 0,00 |
| vencido no SIGA | 171 | R$ 39.983.513,24 |
| sem data | 2 | R$ 352.695,99 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 6,2 mi / R$ 5,3 mi / R$ 3,7 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- 3 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 0,6 mi); 0 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 168 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 39,4 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Concentração: BARRA LIVRE EVENTOS E PROMOCOES EIRELI-EPP detém 64% do valor vigente (1 contratos).

## 3. Vencimentos nos próximos 90 dias
_Nenhum registro._

## 4. Vencimentos entre 91 e 180 dias
_Nenhum registro._

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024002474 | TURISRIO | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | PRESTAÇÃO DE SERVIÇO DE AGENCIAMENTO DE PASSAGENS AÉREAS NACIONAIS E … | R$ 481.600,00 | 04/04/2025 | -581 |
| 2024004344 | TURISRIO | RIOPAR PARTICIPAÇÕES S/A | VALE TRANSPORTE DOS EMPREGADOS E ESTAGIÁRIOS ATRAVÉS DE BILHETE ELETR… | R$ 81.000,00 | 12/06/2025 | -512 |
| 2025005664 | TURISRIO | CBD BOLHETE DIGITAL S/A | Aquisição de Serviço de Bilhetagem de Transporte - para mobilidade na… | R$ 34.020,15 | 30/07/2026 | -99 |

_Registros mais antigos (provável falta de baixa no SIGA): 168, R$ 39,4 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 3)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2013010761 | SETUR | BARRA LIVRE EVENTOS E PROMOCOES EIRELI-EPP | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA REALIZAÇÃO DE EVENTOS | R$ 350.229,99 | — |  |
| 2024010374 | TURISRIO | CS BRASIL FROTAS S.A. | Veículo de Representação pelo período de 36 meses conforme previsto n… | R$ 195.218,14 | 15/01/2028 | 435 |
| 2013005786 | SETUR | M.G. COMERCIO DISTRIBUIDORA E SERVIÇOS LTDA | AQUISIÇÃO DE PAPEL A-4 | R$ 2.466,00 | — |  |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| BARRA LIVRE EVENTOS E PROMOCOES EIRELI-EPP | 1 | R$ 350.229,99 |
| CS BRASIL FROTAS S.A. | 1 | R$ 195.218,14 |
| M.G. COMERCIO DISTRIBUIDORA E SERVIÇOS LTDA | 1 | R$ 2.466,00 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2016004472 | CENARIOS E CENAS CONSULTORIA ASSESSORIA E PL… | R$ 972.197,83 | R$ 0,00 | R$ 972.197,83 |
| 2016003093 | COBRAPE CIA BRASILEIRA DE PROJETOS E EMPREEN… | R$ 233.273,13 | R$ 0,00 | R$ 233.273,13 |
| 2016002798 | UNIVERSIDADE FEDERAL FLUMINENSE | R$ 769.780,00 | R$ 559.840,00 | R$ 209.940,00 |
| 2016002052 | FUNDAÇÃO GETULIO VARGAS | R$ 468.081,60 | R$ 312.054,40 | R$ 156.027,20 |
| 2022008222 | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | R$ 30.951,28 | R$ 15.010,40 | R$ 15.940,88 |
| 2016005639 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 35.211,39 | R$ 20.218,56 | R$ 14.992,83 |
| 2020004949 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 22.068,55 | R$ 12.206,99 | R$ 9.861,56 |
| 2016000976 | DIBOA COMERCIAL LTDA | R$ 7.450,00 | R$ 0,00 | R$ 7.450,00 |
| 2017002415 | CLARO S/A | R$ 7.270,84 | R$ 4.528,64 | R$ 2.742,20 |
| 2017003817 | CLARO S/A | R$ 8.476,75 | R$ 5.829,19 | R$ 2.647,56 |
| 2022002925 | RIOPAR PARTICIPAÇÕES S/A | R$ 2.495,40 | R$ 0,00 | R$ 2.495,40 |
| 2022006388 | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | R$ 51.419,21 | R$ 49.245,19 | R$ 2.174,02 |
| 2019004906 | ELEVADORES ATLAS SCHINDLER LTDA. | R$ 12.124,00 | R$ 10.724,00 | R$ 1.400,00 |
| 2016002901 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 1.194,00 | R$ 0,00 | R$ 1.194,00 |
| 2021006723 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 1.814,47 | R$ 1.417,41 | R$ 397,06 |
| 2016002916 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 350,00 | R$ 0,00 | R$ 350,00 |
| 2018005843 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 350,00 | R$ 0,00 | R$ 350,00 |
| 2020000705 | ATMOSFERA DISENAMOS ESPACIOS SAS | R$ 47.545,55 | R$ 47.545,54 | R$ 0,01 |

## 11. Unidades incluídas neste dossiê
- SETUR - SECRETARIA DE TURISMO
- TURISRIO - COMPANHIA DE TURISMO DO EST RJ

## 12. Conjuntos de dados abertos da secretaria
- Nenhum conjunto encontrado no portal.

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 7 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo
- A Setur-RJ destinou R$ 10.998.000 a patrocínios e apoio financeiro para 18 eventos realizados entre 28 de julho e 27 de agosto de 2026; a reportagem também registra reconhecimento de dívida de R$ 349.326,56 referente a evento de 2025. [Patrocínios de agosto](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/)
- Há uma informação de controle a verificar com prioridade: o TCE-RJ deu 15 dias ao ex-secretário Gustavo Tutuca para apresentar defesa sobre patrocínio de R$ 5 milhões ligado à Universal, mas a fonte não informa o resultado nem o andamento posterior. [Prazo do TCE-RJ](https://temporealrj.com/category/transparencia/page/9/)
- Em maio, a imprensa apontou R$ 12.449.000 em extratos de investimentos e repasses publicados após anúncio de contenção de gastos; a Secretaria afirmou que os eventos citados decorriam de contratos anteriores e que 25 eventos deixaram de receber apoio, com economia superior a R$ 26.000.000. [Patrocínios e contenção de gastos](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)
- A troca de comando de Gustavo Tutuca para Lucas Alves foi descrita como planejada e sem ruptura, mas as fontes não detalham medidas administrativas para a transição de governo em 01/01/2027. [Transição na Setur-RJ](https://brasilturis.com.br/2026/03/20/tutuca-deixa-setur-rj-apos-cinco-anos-e-lucas-alves-assume-comando/)

##### Alertas vermelhos
- **Controle externo:** o prazo de 15 dias concedido pelo TCE-RJ para a defesa de Gustavo Tutuca sobre patrocínio de R$ 5 milhões ligado à Universal exige verificação imediata de protocolo, decisão subsequente e eventuais providências da Secretaria; a fonte não informa esses desdobramentos nem detalha a questão examinada. [Prazo do TCE-RJ](https://temporealrj.com/category/transparencia/page/9/)
- **Conciliação dos patrocínios e da contenção de gastos:** a reportagem de maio informou R$ 12.449.000 em extratos publicados, enquanto a Secretaria declarou que os eventos reportados estavam vinculados a contratos firmados e executados antes das medidas de contenção e que 25 eventos foram cancelados, com economia superior a R$ 26.000.000; a lista dos eventos cancelados não foi apresentada. [Patrocínios e contenção de gastos](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)
- **Dívidas reconhecidas:** a Setur-RJ registrou reconhecimento de dívida de R$ 349.326,56 por evento realizado em outubro de 2025, e outra reportagem registra reconhecimento de dívida de R$ 1.000.000 relacionado a evento realizado no ano anterior em Orlando; as fontes não esclarecem pagamento, saldo ou situação contábil atual desses valores. [Dívida do Fenacam](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/) [Reconhecimento de dívida do Flamengo](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)
- **Volume recente de repasses:** em outubro, foram destinados R$ 6.522.034,26 a 15 patrocínios; em agosto, R$ 10.998.000 a 18 eventos, além do reconhecimento de dívida mencionado acima. Os dados justificam conferir compromissos vigentes, execução e pagamentos, mas, por si só, não demonstram irregularidade. [Patrocínios de outubro](https://temporealrj.com/turismo-6-milhoes-15-patrocinios-outubro/) [Patrocínios de agosto](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/)

##### Contratos e serviços críticos
- Em outubro, o maior patrocínio individual informado foi de R$ 1.194.000 ao Roadshow BBG Brasil — Europa 2026, executado pela BBG Brasil Assessoria, Consultoria Comunicação e Eventos Ltda.; a fonte não fornece número do contrato, vigência ou situação dos pagamentos. [Patrocínios de outubro](https://temporealrj.com/turismo-6-milhoes-15-patrocinios-outubro/)
- Nos extratos publicados entre 18 e 29 de maio, a reportagem identificou patrocínio de R$ 500.000 à IC Week 2026, organizada pela ACE Digital Ltda.; contrato de R$ 600.000 para Canção Nova Abraça Rio 2026; e repasses de R$ 2.250.000 ao Rally Carioca 2026, R$ 1.000.000 à Expo Agulhas Negras e R$ 1.000.000 ao Rio Futsummit 26. [Patrocínios e contenção de gastos](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)
- Em agosto, a reportagem identificou repasse de R$ 1.500.000 à iniciativa “Turismo RJ: segurança e tecnologia em grandes eventos”, realizada pela Editora Globo S/A. Também descreveu contratações por contratos de patrocínio e processos de inexigibilidade de licitação, sem reproduzir os instrumentos completos. [Patrocínios de agosto](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/)
- As fontes fornecidas não identificam contratos de serviços essenciais continuados, seus fornecedores, vigências ou riscos de interrupção; os dados disponíveis se concentram em patrocínios, eventos e reconhecimentos de dívida. [Patrocínios de outubro](https://temporealrj.com/turismo-6-milhoes-15-patrocinios-outubro/) [Patrocínios de agosto](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/) [Patrocínios e contenção de gastos](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)
- **TCE-RJ:** há registro de prazo de 15 dias para que o ex-secretário Gustavo Tutuca apresentasse defesa sobre patrocínio de R$ 5 milhões ligado à Universal; as fontes não informam o número do processo, os fundamentos detalhados, o envio da defesa ou decisão posterior. [Prazo do TCE-RJ](https://temporealrj.com/category/transparencia/page/9/)
- A existência do prazo de defesa não permite concluir, com as informações disponíveis, que houve irregularidade ou responsabilização; a fonte não descreve os detalhes da questão submetida ao Tribunal. [Prazo do TCE-RJ](https://temporealrj.com/category/transparencia/page/9/)
- **MPRJ e Judiciário:** Nada encontrado nas fontes consultadas sobre ações ou procedimentos do Ministério Público do Estado do Rio de Janeiro ou do Judiciário relacionados à Setur-RJ. [Prazo do TCE-RJ](https://temporealrj.com/category/transparencia/page/9/) [Patrocínios de agosto](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/) [Transição na Setur-RJ](https://brasilturis.com.br/2026/03/20/tutuca-deixa-setur-rj-apos-cinco-anos-e-lucas-alves-assume-comando/)

##### Riscos de apagão administrativo
- Nada encontrado nas fontes consultadas que indique risco concreto de interrupção de serviços da Setur-RJ. As matérias sobre patrocínios não relatam risco de paralisação, e a notícia da troca de secretário descreve a transição interna como planejada e sem ruptura. [Patrocínios de agosto](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/) [Transição na Setur-RJ](https://brasilturis.com.br/2026/03/20/tutuca-deixa-setur-rj-apos-cinco-anos-e-lucas-alves-assume-comando/)
- Gustavo Tutuca deixou a Secretaria em 20/03/2026 e Lucas Alves, antes chefe de gabinete, assumiu o comando; a fonte registra a intenção de continuidade das políticas, mas não apresenta plano de transição para a posse do novo governo em 01/01/2027. [Transição na Setur-RJ](https://brasilturis.com.br/2026/03/20/tutuca-deixa-setur-rj-apos-cinco-anos-e-lucas-alves-assume-comando/)
- A Setur-RJ afirmou que sua política de patrocínios foi reformulada e passaria a adotar critérios de impacto turístico, retorno econômico para os municípios, alcance de público, relevância regional e disponibilidade orçamentária; a fonte não apresenta normas, procedimentos ou resultados que comprovem a implementação desses critérios. [Patrocínios e contenção de gastos](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)

##### Fatos recentes
- Em 31/10/2026, a Setur-RJ publicou o total de R$ 6.522.034,26 destinado a 15 patrocínios referentes a atos de 1º a 26 de outubro; o maior patrocínio individual informado foi de R$ 1.194.000 ao Roadshow BBG Brasil — Europa 2026. [Patrocínios de outubro](https://temporealrj.com/turismo-6-milhoes-15-patrocinios-outubro/)
- Em 29/08/2026, foram informados R$ 10,998 milhões em apoio e patrocínio a 18 eventos realizados entre 28 de julho e 27 de agosto; incluindo o reconhecimento de dívida de R$ 349.326,56, o total movimentado no período foi de R$ 11,347 milhões. [Patrocínios de agosto](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/)
- Em 31/05/2026, reportagem sobre extratos publicados entre 18 e 29 de maio informou R$ 12.449.000 em investimentos e repasses, em meio ao anúncio de redução de gastos e à promessa de cortes de até 60% nos patrocínios. [Patrocínios e contenção de gastos](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)
- A Secretaria declarou que a revisão do calendário levou 25 eventos a deixar de receber apoio e gerou economia superior a R$ 26.000.000; a reportagem não fornece a relação desses eventos. [Patrocínios e contenção de gastos](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)
- O programa Experiência Rio de Janeiro 2026 foi apresentado como iniciativa de promoção turística, geração de negócios e interiorização, com previsão de passar por 15 cidades emissoras de turistas; a fonte não informa orçamento ou contratos do programa. [Experiência Rio de Janeiro 2026](https://www.rj.gov.br/secturismo/node/391)

##### Lacunas da pesquisa
- Solicitar à Setur-RJ o processo completo e a situação atual da matéria do TCE-RJ sobre o patrocínio de R$ 5 milhões ligado à Universal, incluindo número do processo, defesa apresentada, decisões e providências pendentes. [Prazo do TCE-RJ](https://temporealrj.com/category/transparencia/page/9/)
- Solicitar a relação dos 25 eventos que, segundo a Secretaria, deixaram de receber apoio, os documentos de cancelamento e a memória de cálculo da economia superior a R$ 26.000.000, além da conciliação com os R$ 12.449.000 em extratos citados na reportagem. [Patrocínios e contenção de gastos](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)
- Solicitar, para os patrocínios e reconhecimentos de dívida mencionados, contratos integrais, números dos processos, vigências, valores empenhados, liquidados e pagos, entregas comprovadas e saldos em aberto; as fontes não fornecem esse conjunto de dados. [Patrocínios de outubro](https://temporealrj.com/turismo-6-milhoes-15-patrocinios-outubro/) [Patrocínios de agosto](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/) [Patrocínios e contenção de gastos](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)
- Solicitar a situação de pagamento e contabilização dos reconhecimentos de dívida de R$ 349.326,56 e R$ 1.000.000, pois as fontes não informam se foram pagos ou se há saldo pendente. [Dívida do Fenacam](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/) [Reconhecimento de dívida do Flamengo](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/)
- Solicitar inventário de contratos de serviços continuados e respectivos prazos, fornecedores, responsáveis pela fiscalização e planos de continuidade, pois esses dados não aparecem nas fontes consultadas. [Patrocínios de outubro](https://temporealrj.com/turismo-6-milhoes-15-patrocinios-outubro/) [Patrocínios de agosto](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/)
- Solicitar plano de transição administrativa para 01/01/2027, com responsáveis, pendências, compromissos financeiros e continuidade dos programas; a fonte sobre a troca Tutuca–Lucas Alves trata da sucessão interna de março de 2026, não da transição para o governo eleito. [Transição na Setur-RJ](https://brasilturis.com.br/2026/03/20/tutuca-deixa-setur-rj-apos-cinco-anos-e-lucas-alves-assume-comando/)
- As fontes não apresentam informações suficientes para confirmar ou afastar procedimentos do MPRJ ou ações judiciais; solicitar certidões e relação de processos à Secretaria e às unidades competentes. [Prazo do TCE-RJ](https://temporealrj.com/category/transparencia/page/9/) [Patrocínios de agosto](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/)

##### Fontes consultadas
1. [Arquivo de Transparência - Página 11 de 74 - Tempo Real](https://temporealrj.com/category/transparencia/page/11/) — 2026-11-05
2. [Arquivo de Transparência - Página 9 de 74 - Tempo Real](https://temporealrj.com/category/transparencia/page/9/) — 2026-11-03
3. [roadshow começa com foco em negócios e na força do turismo ...](https://www.rj.gov.br/secturismo/node/391) — 2026-06-17
4. [Turismo do Estado destina R$ 6,52 milhões a 15 patrocínios em outubro; capital e Região do Médio Paraíba levam](https://temporealrj.com/turismo-6-milhoes-15-patrocinios-outubro/) — 2026-10-31
5. [Tutuca deixa Setur-RJ após cinco anos e Lucas Alves assume ...](https://brasilturis.com.br/2026/03/20/tutuca-deixa-setur-rj-apos-cinco-anos-e-lucas-alves-assume-comando/) — 2026-03-20
6. [Turismo do estado publica R$ 12,4 milhões em patrocínios ...](https://temporealrj.com/corte-cego-turismo-rj-r-124-milhoes-patrocinios-ricardo-couto/) — 2026-05-31
7. [A fa(r)tura de agosto: Secretaria de Turismo do estado distribui R$ 11 ...](https://temporealrj.com/secretaria-turismo-milhoes-patrocinios-fim-inverno/) — 2026-08-29


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2024002474 (WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EI…, R$ 0,5 mi) consta 'Ativo' no SIGA com fim em 04/04/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
3. Contrato 2024004344 (RIOPAR PARTICIPAÇÕES S/A, R$ 0,1 mi) consta 'Ativo' no SIGA com fim em 12/06/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
4. Contrato 2025005664 (CBD BOLHETE DIGITAL S/A, R$ 0,0 mi) consta 'Ativo' no SIGA com fim em 30/07/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
5. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
6. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
7. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
8. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
9. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
