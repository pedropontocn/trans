# Dossiê de transição — Secretaria de Estado de Trabalho e Renda (SETRAB)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/setrab)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 59 | R$ 30.564.791,39 |
| Com vigência futura (válidos no SIGA) | 20 | R$ 17.005.716,91 |
| até 30 dias | 2 | R$ 271.359,79 |
| até 60 dias | 1 | R$ 4.223.081,65 |
| até 90 dias | 3 | R$ 1.238.024,24 |
| até 180 dias | 3 | R$ 7.103.818,00 |
| vencido no SIGA | 39 | R$ 13.559.074,49 |
| sem data | 0 | R$ 0,00 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 3,1 mi / R$ 1,1 mi / R$ 1,0 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Mais 2 contratos menores (R$ 0,3 mi) vencem em até 30 dias — ver seção 3.
- 8 contratos (R$ 12,8 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 24 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 10,0 mi); 0 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 15 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 3,5 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Concentração: HSOL INCENTIVE PERFORMANCE S.A. detém 36% do valor vigente (1 contratos).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2023008971 | SETRAB | BRS SUPRIMENTOS CORPORATIVOS S/A | A contratação de prestação dos serviços continuados de outsourcing pa… | R$ 258.359,79 | 06/11/2026 | 0 |
| 2026008483 | SETRAB | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | Contratação direta de 02 vagas de servidores da SETRAB-RJ na 20a. Pre… | R$ 13.000,00 | 12/11/2026 | 6 |
| 2025009400 | SETRAB | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | CONTRATACAO DE EMPRESA ESPECIALIZADA PARA CONFECCAO,FORNECIMENTO E AD… | R$ 4.223.081,65 | 12/12/2026 (PNCP) | 36 |
| 2024010474 | SETRAB | INSTITUTO BRASILEIRO DE ADMINISTRAÇÃO PUBLIC… | Contratação de instituição especializada para ministrar Curso de Form… | R$ 1.077.500,00 | 06/01/2027 (PNCP) | 61 |
| 2025009960 | SETRAB | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação dos Serviços de Hospedagem IaaS (VPS´s), Serviço de diret… | R$ 88.524,24 | 06/01/2027 | 61 |
| 2024010199 | SETRAB | TERMINAL GARAGEM MENEZES CÔRTES S/A | A contratação de empresa especializada para locação de 10 (dez) vagas… | R$ 72.000,00 | 09/01/2027 | 64 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026001054 | SETRAB | HSOL INCENTIVE PERFORMANCE S.A. | Compra de 2.000 vagas em cursos, oferecido por pessoa jurídica (PJ) e… | R$ 6.115.000,00 | 24/02/2027 (PNCP) | 110 |
| 2026008186 | FTRJ | SERVIÇO NACIONAL DE APRENDIZAGEM INDUSTRIAL | Contratação direta, por dispensa de licitação (art. 75, XV, da Lei Fe… | R$ 985.600,00 | 28/02/2027 (PNCP) | 114 |
| 2024002162 | SETRAB | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Aquisição de CERTIFICADO DIGITAL MODELO A1 por um período de 12 (doze… | R$ 3.218,00 | 25/04/2027 | 170 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025006369 | SETRAB | FORTES SERVIÇOS LTDA | Contratação de serviços de Manutenção Predial para atender à Coordena… | R$ 4.230.597,94 | 04/03/2026 (PNCP) | -247 |
| 2024006442 | SETRAB | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | Contratação de empresa especializada na prestação de serviços de tecn… | R$ 2.880.000,00 | 11/08/2025 | -452 |
| 2025000032 | SETRAB | SERVIÇO NACIONAL DE APRENDIZAGEM COMERCIAL -… | Contratação direta de Instituição Brasileira que oferte junto a Secre… | R$ 1.568.351,36 | 23/01/2026 (PNCP) | -287 |
| 2024002820 | SETRAB | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | O objetivo deste Termo de Referência é estabelecer as condições para … | R$ 360.126,00 | 22/10/2025 | -380 |
| 2024006443 | SETRAB | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Prestação dos serviços e das regras de participação ocorridas no Regi… | R$ 248.000,00 | 18/08/2025 | -445 |
| 2018004414 | SETRAB | CONTINENTE SUPERMERCADOS LTDA | CONTRATO DE COMODATO (LEI 8666/93 ARTIGO 24 INCISO X) | R$ 149.376,00 | 18/04/2026 | -202 |
| 2021006969 | SETRAB | CS BRASIL FROTAS S.A. | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM PRESTAÇÃO DE LOCAÇÃO DE VEÍCU… | R$ 127.168,92 | 16/12/2024 | -690 |
| 2025005455 | FTRJ | INSTITUTO SUPERA BRASIL | Trata-se de contratação de serviço especializado de uma instituição p… | R$ 83.265,65 | 01/08/2026 | -97 |
| 2023009004 | SETRAB | CS BRASIL FROTAS S.A. | Contratação de empresa especialiada na prestação de serviços de locaç… | R$ 73.260,00 | 13/11/2024 | -723 |
| 2024009528 | SETRAB | R. R. F. GUIMARAES AGENCIA DE VIAGENS LTDA | A contratação de empresa especializada na prestação de serviço de hos… | R$ 58.743,50 | 24/12/2024 | -682 |
| 2024002913 | SETRAB | QUALITY ELETROMOVEIS LTDA | Contratação de empresa para fornecimento sob demanda (parceladamente)… | R$ 53.700,00 | 16/04/2025 | -569 |
| 2017001497 | SETRAB | JARDIM GUADALUPE ADMINISTRADORA E INCORPORAD… | Serviço de condominio | R$ 36.223,92 | 08/05/2026 | -182 |
| 2024005847 | SETRAB | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação dos Serviços de Hospedagem IaaS (VPS´s), Serviço de diret… | R$ 35.260,56 | 13/10/2025 | -389 |
| 2024008394 | SETRAB | ATIVA LICITACOES EMPREENDIMENTOS COMERCIAIS … | Contratação de empresa para fornecimento, sob parcela única, de 1 (um… | R$ 28.693,65 | 16/10/2025 | -386 |
| 2024008207 | SETRAB | FORUM NACIONAL E SECRETARIAS DO TRABALHO | Pagamento da anuidade do Fórum Nacional de Secretarias de Trabalho - … | R$ 20.000,00 | 03/11/2025 | -368 |
| 2025005776 | FTRJ | SANLIMP DISTRIBUIDORA E TRANSPORTADORA EIREL… | Aquisição de 304 (trezentos e quatro) coletes e 1.500 (mil e quinhent… | R$ 18.270,40 | 29/08/2026 | -69 |
| 2025000283 | SETRAB | FRAMOT BAZAR E UTILIDADES LTDA | Contratação de empresa para fornecimento, sob demanda, de material de… | R$ 11.866,14 | 31/03/2026 | -220 |
| 2024009911 | SETRAB | MORAIS CARVALHO COMÉRCIO E SOLUÇÕES INTEGRAD… | Aquisição de café, em pó homogêneo, torrado e moído, ponto de torra m… | R$ 10.194,00 | 31/03/2026 | -220 |
| 2026006803 | SETRAB | CONTAGOV LTDA | Contratação direta de empresa especializada para a realização de curs… | R$ 9.380,00 | 19/09/2026 | -48 |
| 2026008198 | SETRAB | PORTAL L&C CURSOS E CAPITAÇÕES LTDA | Contratação direta de empresa especializada para a realização do 2º S… | R$ 7.180,00 | 31/10/2026 | -6 |
| 2025005773 | FTRJ | IDPROMO COMERCIAL EIRELI - EPP | Aquisição de 304 (trezentos e quatro) coletes e 1.500 (mil e quinhent… | R$ 4.500,00 | 29/08/2026 | -69 |
| 2025000284 | SETRAB | MSL PRESTACAO DE SERVICOS LTDA | Contratação de empresa para fornecimento, sob demanda, de material de… | R$ 3.597,68 | 31/03/2026 | -220 |
| 2024002912 | SETRAB | ATIVA LICITACOES EMPREENDIMENTOS COMERCIAIS … | Contratação de empresa para fornecimento sob demanda (parceladamente)… | R$ 3.500,00 | 16/04/2025 | -569 |
| 2024009909 | SETRAB | AVANTE JF COMERCIAL LTDA | Aquisição de café, em pó homogêneo, torrado e moído, ponto de torra m… | R$ 3.193,50 | 31/03/2026 | -220 |

_Registros mais antigos (provável falta de baixa no SIGA): 15, R$ 3,5 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026001054 | SETRAB | HSOL INCENTIVE PERFORMANCE S.A. | Compra de 2.000 vagas em cursos, oferecido por pessoa jurídica (PJ) e… | R$ 6.115.000,00 | 24/02/2027 (PNCP) | 110 |
| 2025009400 | SETRAB | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | CONTRATACAO DE EMPRESA ESPECIALIZADA PARA CONFECCAO,FORNECIMENTO E AD… | R$ 4.223.081,65 | 12/12/2026 (PNCP) | 36 |
| 2024008229 | SETRAB | CS BRASIL FROTAS S.A. | Contratação de serviços de locação de veículos de serviços e veículos… | R$ 1.873.462,76 | 24/10/2027 | 352 |
| 2024010474 | SETRAB | INSTITUTO BRASILEIRO DE ADMINISTRAÇÃO PUBLIC… | Contratação de instituição especializada para ministrar Curso de Form… | R$ 1.077.500,00 | 06/01/2027 (PNCP) | 61 |
| 2026006217 | SETRAB | FUNDAÇÃO SANTA CABRINI | Contratação de 25 (vinte e cinco) apenados oriundos do Sistema Penite… | R$ 1.069.634,16 | 05/08/2027 | 272 |
| 2026008186 | FTRJ | SERVIÇO NACIONAL DE APRENDIZAGEM INDUSTRIAL | Contratação direta, por dispensa de licitação (art. 75, XV, da Lei Fe… | R$ 985.600,00 | 28/02/2027 (PNCP) | 114 |
| 2026001146 | SETRAB | AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA L… | Contratação de empresa especializada para prestação de serviços contí… | R$ 595.595,48 | 27/02/2028 | 478 |
| 2023008971 | SETRAB | BRS SUPRIMENTOS CORPORATIVOS S/A | A contratação de prestação dos serviços continuados de outsourcing pa… | R$ 258.359,79 | 06/11/2026 | 0 |
| 2025003578 | SETRAB | FUNDAÇÃO SANTA CABRINI | Contratação de empresa especializada para prestação de serviços de bu… | R$ 250.560,00 | 18/06/2027 | 224 |
| 2024008231 | SETRAB | AVANTE MARKETING E LOGÍSTICA LTDA | Contratação de serviços de locação de veículos de serviços e veículos… | R$ 201.481,92 | 24/10/2027 | 352 |
| 2026004445 | SETRAB | 3CORP TECHNOLOGY S/A INFRA ESTRUTURA TELECOM | Contratação de serviços de Solução Integrada de VoIP com PABX Virtual… | R$ 125.724,00 | 17/06/2028 | 589 |
| 2025009960 | SETRAB | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação dos Serviços de Hospedagem IaaS (VPS´s), Serviço de diret… | R$ 88.524,24 | 06/01/2027 | 61 |
| 2024010199 | SETRAB | TERMINAL GARAGEM MENEZES CÔRTES S/A | A contratação de empresa especializada para locação de 10 (dez) vagas… | R$ 72.000,00 | 09/01/2027 | 64 |
| 2026006280 | SETRAB | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação de Empresa para Prestação de Serviços de fornecimento de … | R$ 25.453,93 | 10/08/2027 | 277 |
| 2026008483 | SETRAB | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | Contratação direta de 02 vagas de servidores da SETRAB-RJ na 20a. Pre… | R$ 13.000,00 | 12/11/2026 | 6 |
| 2026006710 | SETRAB | AGUAS DO RIO 4 SPE S.A | Contratação de empresa especializada na prestaçãode serviços de forne… | R$ 11.646,97 | 20/08/2036 | 3575 |
| 2025003734 | SETRAB | MALINOIS LICITACOES LTDA | Serviço de Subscrição de Licença do Software AUTOCAD LT 2025, pelo pe… | R$ 10.998,00 | 08/07/2028 | 610 |
| 2024002162 | SETRAB | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Aquisição de CERTIFICADO DIGITAL MODELO A1 por um período de 12 (doze… | R$ 3.218,00 | 25/04/2027 | 170 |
| 2025006105 | SETRAB | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Serviço de Certificação Digital através da contratação de 10 (dez) To… | R$ 3.000,00 | 19/08/2028 | 652 |
| 2026001401 | SETRAB | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | O objetivo da contratação é propiciar a Emissão de Certificados Digit… | R$ 1.876,00 | 23/03/2029 | 868 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| HSOL INCENTIVE PERFORMANCE S.A. | 1 | R$ 6.115.000,00 |
| TRIVALE INSTITUICAO DE PAGAMENTO LTDA | 1 | R$ 4.223.081,65 |
| CS BRASIL FROTAS S.A. | 1 | R$ 1.873.462,76 |
| FUNDAÇÃO SANTA CABRINI | 2 | R$ 1.320.194,16 |
| INSTITUTO BRASILEIRO DE ADMINISTRAÇÃO PUBLICA E APOIO UNIVE… | 1 | R$ 1.077.500,00 |
| SERVIÇO NACIONAL DE APRENDIZAGEM INDUSTRIAL | 1 | R$ 985.600,00 |
| AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA LTDA | 1 | R$ 595.595,48 |
| BRS SUPRIMENTOS CORPORATIVOS S/A | 1 | R$ 258.359,79 |
| AVANTE MARKETING E LOGÍSTICA LTDA | 1 | R$ 201.481,92 |
| 3CORP TECHNOLOGY S/A INFRA ESTRUTURA TELECOM | 1 | R$ 125.724,00 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2022003134 | A.SILVA DOMINGUES COMÉRCIO E SERVIÇOS DE ASS… | R$ 39.120,00 | R$ 11.790,00 | R$ 27.330,00 |
| 2022003004 | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | R$ 49.771,03 | R$ 29.580,14 | R$ 20.190,89 |
| 2021004203 | LIGHT SERVICOS DE ELETRICIDADE SA | R$ 26.687,60 | R$ 17.939,16 | R$ 8.748,44 |
| 2022004991 | WP SISTEMAS REPROGRAFICOS E IMPRESSAO LTDA E… | R$ 13.200,00 | R$ 6.600,00 | R$ 6.600,00 |
| 2021006410 | GP MALLS LTDA | R$ 40.747,80 | R$ 36.472,60 | R$ 4.275,20 |
| 2018004414 | CONTINENTE SUPERMERCADOS LTDA | R$ 12.064,75 | R$ 11.859,87 | R$ 204,88 |

## 11. Unidades incluídas neste dossiê
- FTRJ - FUNDO DO TRABALHO DO ESTADO DO RIO DE JANEIRO - FT/RJ
- SETRAB - SECRETARIA DE ESTADO DO TRABALHO E RENDA

## 12. Conjuntos de dados abertos da secretaria
- Plano Plurianual PPA 2024/2027 (atualizado 2025-09-03): [Plano Plurianual 2024-2027.pdf PDF](https://dadosabertos.rj.gov.br/dataset/a2c77660-9d83-453b-b705-4cd19ccb1e11/resource/c2eb3865-9de0-4d1b-af47-f2c2bef03fc8/download/plano-plurianual-2024-2027.pdf)
- Metas físicas e indicadores de resultados - PPA 2025 (atualizado 2025-09-03): [METAS FÍSICAS E INDICADORES DE RESULTAD… PDF](https://dadosabertos.rj.gov.br/dataset/d7bf787e-1c25-4a13-bb5b-c2a59c34b7a5/resource/5bfce745-b5f7-4333-9371-db180a440782/download/metas-fisicas-e-indicadores-de-resultados-ppa-2025.pdf)
- SETRAB_PCA (atualizado 2025-09-03): [SETRAB_PCA PDF](https://dadosabertos.rj.gov.br/dataset/7a037f90-b4b4-4e5e-9fe3-e8045e441943/resource/b76842d9-fc24-4fab-a548-82d7eb3804fe/download/pca.pdf)
- SETRAB_PLANAT (atualizado 2025-09-03): [SETRAB_PLANAT PDF](https://dadosabertos.rj.gov.br/dataset/5b57a7fa-b504-469b-907d-4e6c9fdc7c41/resource/aca74873-c6f7-4e09-b85e-cde16aade07d/download/planat.pdf)
- SETRAB_RANAT (atualizado 2025-09-03): [SETRAB_RANAT PDF](https://dadosabertos.rj.gov.br/dataset/401b5aff-4044-4029-b957-f384b6056508/resource/649b1418-36b2-45c2-8174-f2821081cdc3/download/ranat.pdf)
- Programação Orçamentária 2025 (atualizado 2025-09-03): [Programação Orçamentária 2025 - SETRAB PDF](https://dadosabertos.rj.gov.br/dataset/6641f61c-7f5d-4b48-96bc-d26418e62901/resource/e19c8771-22fd-4e91-9693-505174fd4c65/download/programacao-orcamentaria-2025.pdf)
- Controle de Contratações (atualizado 2025-09-03): [Controle de Contratações PDF](https://dadosabertos.rj.gov.br/dataset/0bf12300-5658-4d8d-b7d1-8100fe5d27b0/resource/da792435-afa0-4b30-b45b-db52d1f7aa83/download/controle-de-contratacoes.pdf)
- Metas Físicas PPA 2025 (atualizado 2025-09-03): [Metas Físicas PPA 2025 PDF](https://dadosabertos.rj.gov.br/dataset/9d4fb61d-37b7-4202-9355-54ced24b7ea2/resource/83790b55-05f4-4390-856e-23549e41e8fe/download/metas-fisicas-e-indicadores-de-resultados-2025-sine.xlsx.pdf)
- Metas de Resultados (atualizado 2025-09-03): [Metas físicas PDF](https://dadosabertos.rj.gov.br/dataset/09ef4058-f452-43f1-bdc4-28e4e8479fb7/resource/b36f997b-2702-4b3c-a75b-c5e6cbcbbab1/download/metas-e-resultados-imo.pdf)
- Unidades de Atendimentos - SINE (atualizado 2025-09-03): [Unidades de Atendimento SINE XLSX](https://dadosabertos.rj.gov.br/dataset/6103ad98-f2dc-42f1-95f5-4d52df3da5ec/resource/a2566e3e-583c-4dba-9012-668ebbc111a1/download/relacao-das-unidades-de-atendimento-sine.xlsx)
- Controle de Contratos (atualizado 2025-09-03): [Controle de Contratos PDF](https://dadosabertos.rj.gov.br/dataset/fb74e70d-8b9e-4169-9fd3-a29ac5d920c8/resource/cae8dc20-9b24-475c-8544-c8f0989ba264/download/controle-de-contratos.pdf)
- Relatório de Gestão (atualizado 2025-09-03): [Relatório de Gestão - 2024 PDF](https://dadosabertos.rj.gov.br/dataset/abeb0d27-5d40-46fb-a2ee-8a7cf1c5ea49/resource/ddad8672-83e0-47c5-a82a-0b802537e2bb/download/relatorio-de-gestao-gestao-e-manutencao-da-rede-sine.pdf)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 8 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo (3-5 linhas)

O contrato nº 13/2024 com o IBAP-RJ teve vigência prorrogada de 07/01/2026 a 06/01/2027, por aditivo que manteve o valor em R$ 1.077.500,00, o que exige confirmar objeto, execução e providências para sua proximidade do término durante a transição.[Diário Oficial — 2º Termo Aditivo](https://www.rj.gov.br/planejamento/sites/default/files/arquivos_paginas/12.2%29%20II%20Termo%20Aditivo_0.pdf)

A auditoria da CGE apontou falhas no contrato de R$ 6.115.000 com a HSOL para cursos online, e a Setrab abriu sindicância preliminar após solicitação de informações do MPRJ; esses fatos indicam apuração em curso, não conclusão de responsabilidade individual.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)

Há uma sindicância preliminar da Setrab para apurar possíveis irregularidades envolvendo a ex-chefe de gabinete; a fonte não informa seu desfecho. A proposta do piso regional de 2026 também enfrentava atraso burocrático no encaminhamento à Alerj, e as fontes não esclarecem sua situação posterior.[Tempo Real — ex-chefe de gabinete](https://temporealrj.com/tag/destaque/page/36/) [Tempo Real — atraso do piso regional](https://temporealrj.com/piso-salarial-regional-rio-atraso-burocratico/)

As fontes não apresentam decisão do TCE-RJ sobre os temas da Setrab nem confirmam interrupção de serviços, dívidas ou ações judiciais contra a secretaria.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/) [Tempo Real — atraso do piso regional](https://temporealrj.com/piso-salarial-regional-rio-atraso-burocratico/)

##### Alertas vermelhos

- **Apuração do contrato HSOL:** segundo relatório de auditoria da CGE, a contratação por inexigibilidade teve fragilidades na justificativa da escolha da empresa, inconsistências na estimativa da demanda, falhas na pesquisa de preços e no controle da execução, além de parâmetros inadequados para demonstrar a vantagem econômica. A Setrab instaurou sindicância preliminar para apurar possíveis irregularidades. [Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- O contrato HSOL, de R$ 6.115.000, previa 2 mil vagas em cursos online; a auditoria reportou custo de R$ 421,88 por hora-aula, ante serviços semelhantes encontrados por valores próximos de R$ 250 por hora-aula.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- A auditoria relatou liquidação integral do pagamento poucos dias depois de a empresa encaminhar nota fiscal e pedido em 12 de março de 2026, embora um dos cursos estivesse previsto para terminar em 20 de março de 2026.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- O cruzamento de dados da auditoria identificou 36 servidores públicos ativos entre os beneficiários dos cursos e 53 registros com CPFs considerados inválidos; segundo a fonte, essas inconsistências comprometem a confiabilidade dos dados usados para comprovar a execução.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- Em auditoria mais ampla, publicada em 26/06/2026, foi informado que 80% dos cargos de confiança da Setrab eram ocupados por funcionários fantasmas; a fonte atribuiu R$ 16,7 milhões por mês ao conjunto de funcionários fantasmas, sem especificar quanto cabia à secretaria.[G1 — relatório sobre funcionários fantasmas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/26/relatorio-funcionarios-fantasmas-governo-rj.ghtml)
- A Setrab instaurou sindicância preliminar para apurar possíveis repasses de um projeto social a um parente da ex-chefe de gabinete Anelise Alves Tupinambá; a fonte não informa projeto, valores, período ou conclusão da apuração.[Tempo Real — sindicância sobre ex-chefe de gabinete](https://temporealrj.com/tag/destaque/page/36/)

##### Contratos e serviços críticos

- **IBAP-RJ:** o 2º Termo Aditivo ao Contrato nº 13/2024 prorrogou a vigência por 365 dias, de 07/01/2026 a 06/01/2027, e manteve o valor total indicado em R$ 1.077.500,00; o documento fornecido não informa o objeto do contrato.[Diário Oficial — 2º Termo Aditivo](https://www.rj.gov.br/planejamento/sites/default/files/arquivos_paginas/12.2%29%20II%20Termo%20Aditivo_0.pdf)
- **HSOL Incentive Performance S.A.:** o contrato de R$ 6.115.000 foi firmado por inexigibilidade para oferecer 2 mil vagas em cursos de capacitação profissional online com aulas síncronas; a fonte não informa vigência nem situação atual de execução do contrato.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- O MPRJ requisitou cópia integral dos processos administrativos de contratação, fiscalização e pagamento do contrato HSOL, além de informações sobre providências tomadas pela Setrab, com prazo de 30 dias para resposta; a fonte não informa a data de recebimento do ofício nem se a resposta foi enviada.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- A fonte sobre o contrato HSOL informa a abertura de sindicância preliminar pela Corregedoria da Setrab, fundamentada em relatório da CGE, para apurar eventual responsabilidade de servidores e possível prejuízo ao estado; não apresenta conclusão da sindicância.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- As fontes não informam risco confirmado de interrupção dos cursos ou de outro serviço associado a esses contratos; a proximidade do fim da vigência do contrato IBAP, em 06/01/2027, justifica confirmar objeto, saldo, entregas e eventual necessidade de continuidade, sem presumir que o serviço será interrompido.[Diário Oficial — 2º Termo Aditivo](https://www.rj.gov.br/planejamento/sites/default/files/arquivos_paginas/12.2%29%20II%20Termo%20Aditivo_0.pdf) [Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- **MPRJ:** a 6ª Promotoria de Justiça de Tutela Coletiva do Patrimônio Público e da Cidadania da Capital requisitou documentos e informações sobre o contrato HSOL; a secretaria recebeu prazo de 30 dias, mas as fontes não confirmam resposta ou medidas posteriores.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- **CGE e sindicância:** as falhas descritas são apontamentos de auditoria; a sindicância preliminar foi aberta para apurar responsabilidades e possível prejuízo, sem resultado final informado.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- **TCE-RJ:** Nada encontrado nas fontes consultadas sobre decisões do Tribunal relativas aos contratos ou às apurações da Setrab.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/) [Tempo Real — arquivo de transparência](https://temporealrj.com/category/transparencia/page/9/)
- **Judiciário:** Nada encontrado nas fontes consultadas sobre ações judiciais relacionadas à Setrab ou aos contratos descritos.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/) [Tempo Real — arquivo de transparência](https://temporealrj.com/category/transparencia/page/9/)
- A fonte sobre a transição estadual informa que Ricardo Couto assumiu o governo em março de 2026 e que o STF analisava a possibilidade de eleição indireta para governador-tampão, mas não relaciona esse julgamento a processos da Setrab.[G1 — relatório sobre funcionários fantasmas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/26/relatorio-funcionarios-fantasmas-governo-rj.ghtml)

##### Riscos de apagão administrativo

- **Continuidade contratual:** o contrato do IBAP termina em 06/01/2027, seis dias após a posse; como o objeto não aparece no documento fornecido, é necessário confirmar se há serviço essencial, entregas pendentes ou providência de continuidade.[Diário Oficial — 2º Termo Aditivo](https://www.rj.gov.br/planejamento/sites/default/files/arquivos_paginas/12.2%29%20II%20Termo%20Aditivo_0.pdf)
- **Cursos HSOL:** a auditoria apontou problemas de fiscalização e de comprovação dos beneficiários, mas as fontes não dizem se as aulas continuam, se as vagas foram integralmente entregues ou se há risco de interrupção.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- **Piso salarial regional:** atas do Ceter-RJ registraram demora na tramitação da proposta de 2026 na secretaria, mesmo após parecer favorável da PGE no fim de maio; centrais sindicais manifestaram preocupação com o calendário eleitoral e com a possibilidade de dificultar a votação em 2026.[Tempo Real — atraso do piso regional](https://temporealrj.com/piso-salarial-regional-rio-atraso-burocratico/)
- A fonte sobre o piso informa que a classe mencionada não tinha reajuste desde 2018 e que, diante de atrasos anteriores, o Ceter-RJ alterou a estratégia para preparar o piso de 2027; não informa se a tramitação do piso de 2026 foi concluída até 06/11/2026.[Tempo Real — atraso do piso regional](https://temporealrj.com/piso-salarial-regional-rio-atraso-burocratico/)
- O Ceter-RJ registrou verbas federais do FAT destinadas à qualificação profissional, acumuladas de anos anteriores e ainda não executadas, e a busca urgente de convênios com o Sistema S para evitar perda de novos repasses; valores, prazos e situação atual não são informados.[Tempo Real — atraso do piso regional](https://temporealrj.com/piso-salarial-regional-rio-atraso-burocratico/)
- A fonte informa que um projeto de assessoramento estatístico sobre população em situação de rua foi definitivamente descontinuado por falhas metodológicas, falta de indicadores e sobreposição com diagnósticos nacionais, e que o saldo orçamentário retido seria redirecionado a cursos; não informa valor ou execução do redirecionamento.[Tempo Real — atraso do piso regional](https://temporealrj.com/piso-salarial-regional-rio-atraso-burocratico/)
- **Não há apagão confirmado:** as fontes consultadas não relatam paralisação ou interrupção de serviços da Setrab.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/) [Tempo Real — atraso do piso regional](https://temporealrj.com/piso-salarial-regional-rio-atraso-burocratico/)

##### Fatos recentes

- Em 05/09/2026, a Setrab instaurou sindicância preliminar sobre possíveis repasses de projeto social a parente da ex-chefe de gabinete Anelise Alves Tupinambá; a fonte não apresenta conclusão.[Tempo Real — sindicância sobre ex-chefe de gabinete](https://temporealrj.com/tag/destaque/page/36/)
- Em 06/09/2026, foi publicada a notícia de que, após ofício do MPRJ, a Setrab abriu sindicância preliminar sobre o contrato de cursos online da HSOL, com base em auditoria da CGE.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- Em 11/08/2026, foi noticiada a demora interna na tramitação do piso regional de 2026 e a preocupação de representantes dos trabalhadores com o calendário eleitoral.[Tempo Real — atraso do piso regional](https://temporealrj.com/piso-salarial-regional-rio-atraso-burocratico/)
- Em 26/06/2026, foi publicada auditoria que apontou funcionários fantasmas em cargos de confiança da Setrab; o governo informou exonerações de comissionados desde março de 2026, mas a fonte não identifica quantas exonerações eram da secretaria.[G1 — relatório sobre funcionários fantasmas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/26/relatorio-funcionarios-fantasmas-governo-rj.ghtml)
- A página institucional fornecida identifica Paulo Renato Marques como secretário no cabeçalho, mas descreve Daniel Martins como secretário em 2026; essa divergência requer confirmação junto à secretaria e não permite determinar, apenas com essa fonte, quem ocupava o cargo na data de publicação.[Governo do RJ — Trabalho e Renda](https://www.rj.gov.br/trabalho/)

##### Lacunas da pesquisa

- Solicitar à secretaria o processo integral, objeto, medições, pagamentos, saldo, entregas e plano de encerramento ou continuidade do Contrato nº 13/2024 com o IBAP-RJ, cujo termo aditivo informa vigência até 06/01/2027, mas não descreve o objeto.[Diário Oficial — 2º Termo Aditivo](https://www.rj.gov.br/planejamento/sites/default/files/arquivos_paginas/12.2%29%20II%20Termo%20Aditivo_0.pdf)
- Solicitar o processo integral do contrato HSOL, comprovante de resposta ao MPRJ, estado atual da sindicância, confirmação da execução efetiva das 2 mil vagas, detalhamento documental dos pagamentos e eventual apuração de dano. A fonte informa o pagamento integral antes do término previsto de um dos cursos, mas não esclarece a resposta ao MPRJ, o estado ou desfecho da sindicância, a execução de todas as vagas ou eventual conclusão sobre dano; também não apresenta outros detalhes dos pagamentos. [Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/)
- Solicitar decisões, auditorias ou procedimentos do TCE-RJ e confirmar se houve novas providências do MPRJ ou do Judiciário, pois nada disso foi encontrado nas fontes consultadas sobre os contratos e as apurações descritos.[Tempo Real — sindicância e cursos online](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/) [Tempo Real — arquivo de transparência](https://temporealrj.com/category/transparencia/page/9/)
- Solicitar o desfecho da sindicância sobre a ex-chefe de gabinete, identificando projeto, beneficiários, valores, período e eventual dano, informações ausentes na notícia consultada.[Tempo Real — sindicância sobre ex-chefe de gabinete](https://temporealrj.com/tag/destaque/page/36/)
- Solicitar atualização sobre a tramitação do piso de 2026, a preparação do piso de 2027 e os valores, prazos e execução das verbas do FAT e dos convênios de qualificação; a fonte disponível é de agosto de 2026 e não esclarece a situação em 06/11/2026.[Tempo Real — atraso do piso regional](https://temporealrj.com/piso-salarial-regional-rio-atraso-burocratico/)
- Solicitar organograma e lista atualizada de dirigentes, com confirmação de quem era o titular da Setrab em 06/11/2026, dada a divergência entre Paulo Renato Marques e Daniel Martins na página institucional fornecida.[Governo do RJ — Trabalho e Renda](https://www.rj.gov.br/trabalho/)
- As fontes consultadas não apresentam orçamento total da secretaria, passivos ou dívidas, contratos completos além dos citados, situação atual dos serviços, ou quantificação das exonerações especificamente na Setrab.[Governo do RJ — Trabalho e Renda](https://www.rj.gov.br/trabalho/) [G1 — relatório sobre funcionários fantasmas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/26/relatorio-funcionarios-fantasmas-governo-rj.ghtml)

##### Fontes consultadas
1. [g1.globo.com › rj › rio-de-janeiroSecretaria de Trabalho do RJ tinha 80% de funcionários ... - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/06/26/relatorio-funcionarios-fantasmas-governo-rj.ghtml) — 2026-06-26
2. [Arquivo de Transparência - Página 9 de 74 - Tempo Real](https://temporealrj.com/category/transparencia/page/9/) — 2026-11-03
3. [Atraso burocrático em secretaria e calendário eleitoral ameaçam ...](https://temporealrj.com/piso-salarial-regional-rio-atraso-burocratico/) — 2026-08-11
4. [Trabalho e Renda - Governo do Estado do Rio de Janeiro](https://www.rj.gov.br/trabalho/) — 2026-06-20
5. [Estado gera mais de 86 mil postos de trabalho no ano](https://www.correiodamanha.com.br/estado-do-rio/2026/11/332564-estado-gera-mais-de-86-mil-postos-de-trabalho-no-ano.html) — 2026-11-05
6. [Arquivo de destaque - Página 36 de 834 - Tempo Real](https://temporealrj.com/tag/destaque/page/36/) — 2026-11-03
7. [Notificada pelo MPRJ, Secretaria Estadual de Trabalho abre ...](https://temporealrj.com/setrab-sindicancia-irregularidades-cursos-online/) — 2026-09-06
8. [ PDF  DIÁRIO OFICIAl - Governo do Estado do Rio de Janeiro](https://www.rj.gov.br/planejamento/sites/default/files/arquivos_paginas/12.2%29%20II%20Termo%20Aditivo_0.pdf) — 2026-04-23


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2023008971 (BRS SUPRIMENTOS CORPORATIVOS S/A) vence em 06/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2026008483 (INSTITUTO NEGOCIOS PUBLICOS DO BRASIL -…) vence em 12/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025009400 (TRIVALE INSTITUICAO DE PAGAMENTO LTDA) vence em 12/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2024010474 (INSTITUTO BRASILEIRO DE ADMINISTRAÇÃO P…) vence em 06/01/2027: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025009960 (PRODERJ - CENTRO DE TECNOLOGIA DE INFOR…) vence em 06/01/2027: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2025006369 (FORTES SERVIÇOS LTDA, R$ 4,2 mi) consta 'Ativo' no SIGA com fim em 04/03/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2024006442 (INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E RE…, R$ 2,9 mi) consta 'Ativo' no SIGA com fim em 11/08/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2025000032 (SERVIÇO NACIONAL DE APRENDIZAGEM COMERC…, R$ 1,6 mi) consta 'Ativo' no SIGA com fim em 23/01/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2024002820 (PRIME CONSULTORIA E ASSESSORIA EMPRESAR…, R$ 0,4 mi) consta 'Ativo' no SIGA com fim em 22/10/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2024006443 (WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EI…, R$ 0,2 mi) consta 'Ativo' no SIGA com fim em 18/08/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
