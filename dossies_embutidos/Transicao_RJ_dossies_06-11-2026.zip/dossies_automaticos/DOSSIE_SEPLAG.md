# Dossiê de transição — Secretaria de Estado de Planejamento e Gestão (SEPLAG)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/seplag)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 2012 | R$ 1.543.555.879,06 |
| Com vigência futura (válidos no SIGA) | 124 | R$ 200.132.072,01 |
| até 30 dias | 3 | R$ 44.360,83 |
| até 60 dias | 9 | R$ 4.635.408,80 |
| até 90 dias | 4 | R$ 1.443.876,00 |
| até 180 dias | 12 | R$ 25.148.076,00 |
| vencido no SIGA | 1888 | R$ 1.343.423.807,05 |
| sem data | 13 | R$ 1.101.677,45 |
| Fornecedores em recuperação judicial | 1 | R$ 326.995,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 216,6 mi / R$ 93,9 mi / R$ 93,6 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Mais 3 contratos menores (R$ 0,0 mi) vencem em até 30 dias — ver seção 3.
- 25 contratos (R$ 27,8 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 164 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 87,6 mi); 2 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 1724 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 1.255,9 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- 1 contrato(s) 'Ativo' com data de fim inválida no SIGA (R$ 0,0 mi), ex.: 2012006999 (21/09/9201). Corrigir o cadastro e informar a vigência real.
- Fornecedor em recuperação judicial: HOTEIS OTHON S.A. - EM RECUPERACAO JUDICIAL — 1 contrato(s), R$ 0,3 mi, último fim 01/01/2026.

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024008301 | SEPLAG | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Contratação de serviços especializados de Certificado Digital modelo … | R$ 19.000,00 | 24/11/2026 | 18 |
| 2026007409 | RIOPREVIDÊNCIA | SOBERANA COMERCIO E SERVIÇOS LTDA | 1.1. O presente Termo de Referência visa a contratação de empresa esp… | R$ 6.099,00 | 06/12/2026 | 30 |
| 2026007690 | RIOPREVIDÊNCIA | SOBERANA COMERCIO E SERVIÇOS LTDA | O presente Termo de Referência visa a contratação de empresa especial… | R$ 19.261,83 | 06/12/2026 | 30 |
| 2022009117 | SEPLAG | LIZ SERVIÇOS ONLINE LTDA | Contratação de empresa especializada na prestação continuada de servi… | R$ 379.980,00 | 12/12/2026 | 36 |
| 2025010444 | RIOPREVIDÊNCIA | TAMANDARÉ INFORMATICA LTDA | Aquisição de equipamentos de informática, compreendendo microcomputad… | R$ 2.230.950,00 | 15/12/2026 (PNCP) | 39 |
| 2023010803 | RIOPREVIDÊNCIA | BRS SUPRIMENTOS CORPORATIVOS S/A | Este Termo de Referência TR versa sobre as condições de prestação de … | R$ 932.932,80 | 20/12/2026 | 44 |
| 2025008380 | CEPERJ | CARLOS HENRIQUE SFORCA LTDA | Trata-se de aquisição de computadores de alto desempenho com configur… | R$ 60.000,00 | 26/12/2026 | 50 |
| 2025008393 | CEPERJ | LECARD ADMNISTRADORA DE CARTÕES LTDA | Trata-se de contratação de empresa especializada na prestação de serv… | R$ 92.950,00 | 26/12/2026 | 50 |
| 2026005202 | CEPERJ | LAOA SERVICOS E EMPREENDIMENTOS LTDA | Contratação de empresa especializada na aquisição de placas de painéi… | R$ 9.000,00 | 26/12/2026 | 50 |
| 2021007413 | SEPLAG | CLARO S/A (FILIAL) | Fornecimento de link de dados e conexão com a internet para toda estr… | R$ 178.596,00 | 28/12/2026 | 52 |
| 2021007677 | RIOPREVIDÊNCIA | EMPRESA DE TECNOLOGIA E INFORMACOES DA PREVI… | Custeio do novo sistema COMPREV | R$ 720.000,00 | 31/12/2026 | 55 |
| 2025007697 | CEPERJ | ELOAR SERVIÇOS DE COMUNICAÇÃO E MARKETING LT… | Cuida o presente processo administrativo sobre contratação de empresa… | R$ 31.000,00 | 05/01/2027 | 60 |
| 2023007352 | SEPLAG | CS BRASIL FROTAS S.A. | Contratação de Empresa Especialiada em Locação de veiculo com KIT STR… | R$ 167.616,00 | 24/01/2027 | 79 |
| 2024010237 | RIOPREVIDÊNCIA | MAR E FIRE EQUIP. E PROT. CONTRA INCÊNDIO LT… | Contratação de empresa especializada na prestação de serviços de manu… | R$ 31.760,00 | 27/01/2027 | 82 |
| 2026000343 | RJPREV | PFM CONSULTORIA E SISTEMAS LTDA. | O objeto do presente Termo de Referência é a contratação de empresa p… | R$ 44.500,00 | 29/01/2027 | 84 |
| 2026000333 | RIOPREVIDÊNCIA | RIOPAR PARTICIPAÇÕES S/A | Fornecimento de vale-transporte para os servidores do Fundo Único de … | R$ 1.200.000,00 | 03/02/2027 (PNCP) | 89 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000115 | RIOPREVIDÊNCIA | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação de serviços de desenvolvimento, hospedagem e manutenção d… | R$ 34.482,96 | 06/02/2027 | 92 |
| 2026000755 | SEPLAG | TAREA GERENCIAMENTO LTDA | A aquisição do licenciamento de softwares Oracle e Options se faz ess… | R$ 21.200.000,00 | 19/02/2027 (PNCP) | 105 |
| 2025001896 | SEPLAG | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação de serviços de hospedagemde mensagem eletrônica (e-mail),… | R$ 146.004,00 | 01/03/2027 | 115 |
| 2026007419 | RJPREV | R&F SOLUCOES EM TECNOLOGIA DA INFORMACAO LTDA | Contratação de empresa especializada, devidamente regularizada, para … | R$ 9.600,00 | 08/03/2027 | 122 |
| 2022001451 | SEPLAG | CLARO S/A (FILIAL) | SERVICOS DE ACESSO A INTERNET,DESCRIÇÃO: CONTRATACAO DE LINK DE DADOS… | R$ 142.200,00 | 15/03/2027 | 129 |
| 2026001950 | RJPREV | EDITORA GLOBO S/A | O presente Termo de Referência tem por objeto renovação do serviço de… | R$ 586,80 | 17/03/2027 | 131 |
| 2025001593 | SEPLAG | GAPPO ELEVADORES, PROJETOS E CONSULTORIA TÉC… | Contratação de empresa com notória especialização, em assessoria técn… | R$ 28.000,00 | 31/03/2027 | 145 |
| 2026000809 | CEPERJ | NP TECNOLOGIA E GESTAO DE DADOS LTDA | Trata o presente administrativo sobre a contratação de prestação de s… | R$ 17.375,00 | 31/03/2027 | 145 |
| 2026001664 | CEPERJ | 62642580 JORGE ARAUJO DA SILVA | Trata o presente administrativo sobre a contratação de empresa especi… | R$ 49.990,00 | 31/03/2027 | 145 |
| 2026002826 | RJPREV | BRASILSEG COMPANHIA DE SEGUROS | Contratação de pessoa jurídica especializada na Prestação de Serviços… | R$ 600,00 | 10/04/2027 | 155 |
| 2024007881 | SEPLAG | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | contratação de Agente Integrador para realizar recrutamento, seleção,… | R$ 3.292.800,00 | 13/04/2027 (PNCP) | 158 |
| 2021001653 | SEPLAG | DES SERVICOS EM ELEVADORES LTDA | Trata- se da contratação de empresa especializada para prestação de s… | R$ 226.437,24 | 25/04/2027 | 170 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024008758 | RIOPREVIDÊNCIA | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | Contratação de serviços de apoio a soluções de Tecnologia da Informaç… | R$ 16.681.010,88 | 23/10/2025 | -379 |
| 2024009206 | RIOPREVIDÊNCIA | FUNDAÇÃO DE APOIO A PESQUISA, ENSINO E ASSIS… | O objeto deste termo de referência visa a contratação de instituição … | R$ 14.960.000,00 | 31/12/2025 (PNCP) | -310 |
| 2025010826 | RIOPREVIDÊNCIA | 3STRUCTURE IT LTDA | Aquisição de solução de appliances de backup em cluster do fabricante… | R$ 7.890.234,04 | 21/06/2026 (PNCP) | -138 |
| 2023011040 | RIOPREVIDÊNCIA | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Solução LGPD | R$ 6.064.467,00 | 27/12/2024 | -679 |
| 2022003260 | RIOPREVIDÊNCIA | FOCO ASN 2010 SERVIÇOS GERAIS LTDA | Contratação de empresa especializada na prestação de serviços de limp… | R$ 4.363.889,90 | 09/11/2024 | -727 |
| 2025005791 | SEPLAG | INOVATTA - GESTAO E PROCESSOS EM TECNOLOGIA … | Contratação de empresa especializada no fornecimento de ``Solução int… | R$ 3.589.093,11 | 11/08/2026 (PNCP) | -87 |
| 2025005348 | RIOPREVIDÊNCIA | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Contratação através da Ata de Registro de Preços nº 001/2025 do Gabin… | R$ 3.506.750,00 | 21/07/2026 (PNCP) | -108 |
| 2022005759 | SEPLAG | CS BRASIL FROTAS S.A. | Contratação de prestação de serviços de locação de veículos, com intu… | R$ 3.379.999,68 | 08/08/2025 | -455 |
| 2023010540 | RIOPREVIDÊNCIA | ARS TECNOLOGIA SERVICOS E CONSULTORIA LTDA | Contratação de plataforma de anonimiação e gerenciamento de chaves cr… | R$ 3.284.584,00 | 13/12/2024 | -693 |
| 2024008892 | RIOPREVIDÊNCIA | MGS CLEAN SOLUÇÕES E SERVIÇOS LTDA | . Contratação, em caráter emergencial, de empresa especializada na pr… | R$ 3.171.961,74 | 01/11/2025 (PNCP) | -370 |
| 2025005981 | RIOPREVIDÊNCIA | PPN TECNOLOGIA E INFORMÁTICA LTDA | Contratação de solução de firewall para o Fundo Único de Previdência … | R$ 3.094.473,75 | 11/02/2026 (PNCP) | -268 |
| 2024006099 | RIOPREVIDÊNCIA | FORTLINE INDUSTRIA E COMERCIO DE MOVEIS LTDA | Constitui objeto deste termo, a aquisição de Bens Patrimoniais para s… | R$ 1.508.694,00 | 31/12/2024 | -675 |
| 2024001976 | SEPLAG | LESTE & SUDESTE SERVIÇOS GERAIS LTDA | Contratação de empresa prestadora de serviço continuado de limpea des… | R$ 1.452.693,52 | 16/10/2026 | -21 |
| 2023007771 | SEPLAG | SERMACOL COMÉRCIO E SERVIÇOS LTDA | Contratação de empresa especialiada para prestação de serviços de pre… | R$ 1.402.567,20 | 30/09/2026 | -37 |
| 2023010608 | SEPLAG | TECNO TEMP COMÉRCIO INSTALAÇÃO E MANUTENÇÃO … | Aquisição e instalação de Condensadoras 172000 Btu Mod RUM 180BTE5 de… | R$ 1.176.000,00 | 15/12/2024 | -691 |
| 2025003561 | CEPERJ | PLUXEE BENEFICIOS BRASIL S.A. | Trata o presente administrativo de contratação de empresa especializa… | R$ 913.680,00 | 06/07/2026 | -123 |
| 2023004743 | SEPLAG | BRS SUPRIMENTOS CORPORATIVOS S/A | Registro de Preços de serviços continuados de outsourcing para operaç… | R$ 658.590,64 | 05/07/2026 | -124 |
| 2023003935 | RIOPREVIDÊNCIA | CS BRASIL FROTAS S.A. | Contratação de prestação de serviços de locação de 05 veículos de ser… | R$ 637.611,48 | 29/05/2026 | -161 |
| 2025009490 | SEPLAG | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Contratação de serviços de projetos gráficos, diagramação, revisão, p… | R$ 592.697,00 | 18/01/2026 (PNCP) | -292 |
| 2025002953 | CEPERJ | RIOPAR PARTICIPAÇÕES S/A | Cuida o presente processo administrativo de contratação de empresa es… | R$ 589.920,00 | 25/08/2026 (PNCP) | -73 |
| 2024005578 | RIOPREVIDÊNCIA | EMPRESA DE TECNOLOGIA E INFORMACOES DA PREVI… | Contratação da Empresa de Tecnologia e Informações da Previdência SA … | R$ 505.890,00 | 07/08/2025 (PNCP) | -456 |
| 2022006345 | SEPLAG | J G M MOREIRA JUNIOR 3 COMÉRCIO E SERVIÇOS | Prestação de serviços de operação, manutenção preventiva, corretiva, … | R$ 487.990,00 | 15/09/2026 | -52 |
| 2022006577 | SEPLAG | ASSOCIAÇÃO NITEROIENSE DOS DEFICIENTES FISIC… | Prestação de serviços contínuos de apoio administrativo nas áreas de … | R$ 453.702,00 | 07/09/2026 | -60 |
| 2020004510 | RIOPREVIDÊNCIA | CONSTRUTORA DUARTE ISIDORO LTDA | Locação de imóvel comercial para atender as necessidades do público | R$ 365.421,60 | 29/09/2025 | -403 |
| 2024009341 | RIOPREVIDÊNCIA | FLEXFORM INDUSTRIA METALÚRGICA LTDA. | Constitui objeto deste termo, a aquisição de Bens Patrimoniais  cade… | R$ 355.066,00 | 18/01/2025 | -657 |
| 2025009912 | SEPLAG | HOTEIS OTHON S.A. - EM RECUPERACAO JUDICIAL | Contratação de empresa especializada na prestação de serviços de orga… | R$ 326.995,00 | 01/01/2026 | -309 |
| 2024003956 | CEPERJ | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | O presente administrativo tem por objetivo a contratação de agente de… | R$ 324.000,00 | 03/07/2025 | -491 |
| 2023004061 | RIOPREVIDÊNCIA | A CHAVE NEIDE - ME. | Contratação de empresa especialiada na prestação de serviços de confe… | R$ 314.849,00 | 31/05/2025 | -524 |
| 2024003242 | RIOPREVIDÊNCIA | VALOR EMPRESA DE SERVIÇOS LTDA | Contratação emergencial de empresa especializada em prestação de serv… | R$ 282.874,68 | 13/11/2024 | -723 |
| 2023002847 | RIOPREVIDÊNCIA | REI DE OURO MUDANÇAS E TRANSPORTES LTDA | Contratação de empresa especializada em prestação de serviços contínu… | R$ 258.000,00 | 29/06/2025 | -495 |

_Registros mais antigos (provável falta de baixa no SIGA): 1724, R$ 1.255,9 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026008153 | RIOPREVIDÊNCIA | VEROCHEQUE REFEIÇÕES LTDA | A presente contratação visa a contratação de empresaespecializada no … | R$ 27.300.000,00 | 01/10/2028 | 695 |
| 2025000910 | RJPREV | ICATU SEGUROS S/A | Contratação de seguro específico para cobertura de riscos atuariais d… | R$ 23.538.630,54 | 17/02/2035 | 3025 |
| 2026000755 | SEPLAG | TAREA GERENCIAMENTO LTDA | A aquisição do licenciamento de softwares Oracle e Options se faz ess… | R$ 21.200.000,00 | 19/02/2027 (PNCP) | 105 |
| 2026009213 | RIOPREVIDÊNCIA | SOFTWAREONE COMÉRCIO E SERVIÇOS DE INFORMÁTI… | Contratação de empresa especializada para fornecimento de licenças de… | R$ 9.026.446,80 | 29/10/2029 | 1088 |
| 2026007727 | RIOPREVIDÊNCIA | TECNETWORKING SERVICOS E SOLUCOES EM TI LTDA | Contratação de empresa especializada para fornecimento de licenças de… | R$ 7.977.600,00 | 21/09/2029 | 1050 |
| 2025008040 | RIOPREVIDÊNCIA | FENIX CONSTRUTORA LTDA | Contratação de empresa especializada na prestação de serviços continu… | R$ 7.398.999,90 | 07/04/2028 | 518 |
| 2024009046 | RIOPREVIDÊNCIA | TELTEX TECNOLOGIA SA | Este Termo de Referência estabelece os alicerces para a fornecimento … | R$ 6.938.286,41 | 04/11/2027 | 363 |
| 2025008907 | RIOPREVIDÊNCIA | LESTE & SUDESTE SERVIÇOS GERAIS LTDA | A presente contratação visa a contratação de empresa especializada na… | R$ 6.900.000,00 | 03/05/2028 | 544 |
| 2026008935 | RJPREV | TRUST SERVICE BRASIL LTDA | Serviço de fornecimento de licença de uso de software integrado de ge… | R$ 6.444.000,00 | 20/10/2041 | 5462 |
| 2024005804 | SEPLAG | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | Prestação de serviços de tecnologia da comunicação e informação (tic)… | R$ 5.120.000,00 | 06/08/2027 | 273 |
| 2025003018 | RIOPREVIDÊNCIA | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | A presente contratação visa a contratação da Imprensa Oficial do Esta… | R$ 4.328.715,30 | 18/09/2027 | 316 |
| 2026003596 | RIOPREVIDÊNCIA | LPM TELEINFORMATICA LTDA - EPP | Contratação de empresa especializada para a execução de serviços, por… | R$ 4.195.860,95 | 08/05/2029 | 914 |
| 2025010654 | RIOPREVIDÊNCIA | TEMPO SOLUCOES EM PROCESSOS DA INFORMACAO LT… | Contratação de empresa especializada na prestação deserviços de Guard… | R$ 4.136.689,80 | 23/12/2028 | 778 |
| 2025008124 | RIOPREVIDÊNCIA | EMPRESA BRASILEIRA DE CORREIOS E TELÉGRAFOS | Tem como objetivo a contratação de empresa para prestação de serviços… | R$ 4.113.943,90 | 03/10/2030 | 1427 |
| 2025007222 | RIOPREVIDÊNCIA | INSTITUTO SOCIAL SE LIGA | Contratação de empresa especializada para a prestação dos serviços de… | R$ 3.460.346,16 | 19/09/2027 | 317 |
| 2024007881 | SEPLAG | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | contratação de Agente Integrador para realizar recrutamento, seleção,… | R$ 3.292.800,00 | 13/04/2027 (PNCP) | 158 |
| 2025007221 | RIOPREVIDÊNCIA | INSTITUTO SOCIAL SE LIGA | Contratação de empresa especializada para a prestação dos serviços de… | R$ 3.269.993,04 | 20/10/2027 | 348 |
| 2023005643 | SEPLAG | FXX SEGURANCA E TRANSPORTE DE VALORES LTDA | Contratação de serviços de Vigilância Patrimonial | R$ 3.209.157,60 | 27/07/2027 | 263 |
| 2024009229 | RIOPREVIDÊNCIA | PRO-SERV RIO COMERCIAL E SOLUCOES LTDA | Contratação de empresa especializada para prestação de serviço de apo… | R$ 2.679.927,60 | 06/07/2027 | 242 |
| 2023004106 | SEPLAG | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | Contratação de empresa especialiada na prestação de serviços de imple… | R$ 2.678.000,00 | 12/06/2027 | 218 |

## 7. Fornecedores em recuperação judicial
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025009912 | SEPLAG | HOTEIS OTHON S.A. - EM RECUPERACAO JUDICIAL | Contratação de empresa especializada na prestação de serviços de orga… | R$ 326.995,00 | 01/01/2026 | -309 |

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| VEROCHEQUE REFEIÇÕES LTDA | 1 | R$ 27.300.000,00 |
| ICATU SEGUROS S/A | 1 | R$ 23.538.630,54 |
| TAREA GERENCIAMENTO LTDA | 1 | R$ 21.200.000,00 |
| SOFTWAREONE COMÉRCIO E SERVIÇOS DE INFORMÁTICA LTDA. | 1 | R$ 9.026.446,80 |
| TECNETWORKING SERVICOS E SOLUCOES EM TI LTDA | 1 | R$ 7.977.600,00 |
| FENIX CONSTRUTORA LTDA | 1 | R$ 7.398.999,90 |
| TELTEX TECNOLOGIA SA | 1 | R$ 6.938.286,41 |
| LESTE & SUDESTE SERVIÇOS GERAIS LTDA | 1 | R$ 6.900.000,00 |
| INSTITUTO SOCIAL SE LIGA | 2 | R$ 6.730.339,20 |
| TRUST SERVICE BRASIL LTDA | 1 | R$ 6.444.000,00 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2016002198 | FOCO ASN 2010 SERVIÇOS GERAIS LTDA | R$ 6.332.912,70 | R$ 5.455.954,99 | R$ 876.957,71 |
| 2020001526 | FORÇA TATICA VIGILANCIA E SEGURANÇA EIRELI | R$ 3.988.055,85 | R$ 3.303.444,78 | R$ 684.611,07 |
| 2016005734 | ORACLE DO BRASIL SISTEMAS LTDA | R$ 15.677.434,92 | R$ 15.295.617,94 | R$ 381.816,98 |
| 2016000445 | HÓLOS CONSULTORES ASSOCIADOS LTDA | R$ 666.026,06 | R$ 334.931,92 | R$ 331.094,14 |
| 2016006283 | BMC VIGILANCIA E SEGURANCA LTDA EPP | R$ 3.361.610,59 | R$ 3.122.270,29 | R$ 239.340,30 |
| 2018002851 | RIO DE JANEIRO SERVICOS E COMERCIO LTDA ME | R$ 1.650.287,48 | R$ 1.449.794,96 | R$ 200.492,52 |
| 2016000744 | EXTREME DIGITAL CONSULTORIA E REPRESENTAÇÕES… | R$ 2.152.888,18 | R$ 1.960.666,02 | R$ 192.222,16 |
| 2020005012 | LESTE & SUDESTE SERVIÇOS GERAIS LTDA | R$ 2.246.835,93 | R$ 2.076.345,36 | R$ 170.490,57 |
| 2018006583 | VETORSEG VIGILÂNCIA PATRIMONIAL LTDA ME | R$ 1.805.183,06 | R$ 1.640.411,69 | R$ 164.771,37 |
| 2020005015 | PLURAL SERVIÇOS TÉCNICOS LTDA. | R$ 1.416.956,27 | R$ 1.294.473,65 | R$ 122.482,62 |
| 2017004459 | FOCO ASN 2010 SERVIÇOS GERAIS LTDA | R$ 1.039.391,44 | R$ 925.865,92 | R$ 113.525,52 |
| 2022003699 | SPEEDMAIS SOLUCOES LTDA | R$ 377.108,17 | R$ 269.110,85 | R$ 107.997,32 |
| 2016002183 | FOCO ASN 2010 SERVIÇOS GERAIS LTDA | R$ 1.106.608,65 | R$ 1.006.894,57 | R$ 99.714,08 |
| 2021006098 | FOCO ASN 2010 SERVIÇOS GERAIS LTDA | R$ 241.502,60 | R$ 146.585,40 | R$ 94.917,20 |
| 2017003116 | TECHNE ENGENHARIA E SISTEMAS LTDA | R$ 4.820.533,07 | R$ 4.748.225,10 | R$ 72.307,97 |
| 2019004062 | P C EMPREEDIMENTOS E SERVIÇOS GERAIS EIRELI | R$ 1.740.515,21 | R$ 1.670.545,14 | R$ 69.970,07 |
| 2021004296 | OI S/A | R$ 125.168,10 | R$ 55.698,18 | R$ 69.469,92 |
| 2021006528 | IRMÃOS HADDAD CONSTRUTORA EIRELI | R$ 937.487,26 | R$ 871.863,15 | R$ 65.624,11 |
| 2022004094 | EXTREME DIGITAL SERVICES SOCIEDADE LIMITADA | R$ 915.396,75 | R$ 869.626,90 | R$ 45.769,85 |
| 2022005759 | CS BRASIL FROTAS S.A. | R$ 84.193,42 | R$ 42.174,36 | R$ 42.019,06 |

## 11. Unidades incluídas neste dossiê
- CEPERJ - FUND CENTRO EST. ESTAT.  PESQ. SERV RJ
- IASERJ - INSTITUTO DE ASSIST DOS SERVID DO EST RJ
- RIOPREVIDÊNCIA - FUNDO UNICO DE PREVIDENCIA DO ERJ
- RIOPREVIDÊNCIA - FUNDO UNICO DE PREVIDENCIA SOCIAL DO ESTADO DO RIO DE JANEIRO
- RJPREV - Fundação de Previdência Complem do ERJ
- SEPLAG  - SUBSECRETARIA DE LOGÍSTICA
- SEPLAG - SEC DE EST DE PLANEJAMENTO E GESTÃO (Antiga SEPLAG)
- SEPLAG - Secretaria de Estado de Planejamento e Gestão

## 12. Conjuntos de dados abertos da secretaria
- Informações Relativas a Terceirizados (atualizado 2026-10-21): [Relação de Terceirizados-2023 - csv CSV](https://dadosabertos.rj.gov.br/dataset/3d053780-b34a-4acb-b81a-770575807906/resource/4463d8f7-2612-4dec-aab3-cd046dbe5f6f/download/treceirizados_2023.csv), [Relação de Terceirizados-2023 - xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/3d053780-b34a-4acb-b81a-770575807906/resource/22595746-07db-4262-8e22-631d31b55f7e/download/terceirizados_2023.xlsx), [Relação de Terceirizados-2024 - csv CSV](https://dadosabertos.rj.gov.br/dataset/3d053780-b34a-4acb-b81a-770575807906/resource/241ac3a3-0afc-4efa-89fb-171b9707ff8a/download/treceirizados_2024.csv), [Relação de Terceirizados-2024 - xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/3d053780-b34a-4acb-b81a-770575807906/resource/5038e6ae-76da-45f5-9361-ac7f0c09ba36/download/terceirizados_2024.xlsx)
- Informações Relativas a Estagiários (atualizado 2026-10-21): [Relação de Estagiários -- Arquivo.xlsx .xlsx](https://dadosabertos.rj.gov.br/dataset/c6797157-bb0a-4236-9724-b0a03809dc36/resource/e60e8111-47f0-4973-b4b2-8e0e13bae145/download/portal_de_dados_abertos_controle_de_estagiarios___09_referencia-setembro-2026.xlsx), [Relação de Estagiários -- Arquivo csv CSV](https://dadosabertos.rj.gov.br/dataset/c6797157-bb0a-4236-9724-b0a03809dc36/resource/b51282c9-9487-430c-88d7-c658bcb3f180/download/portal_de_dados_abertos_controle_de_estagiarios___09_referencia-setembro-2026.csv)
- Acordos Não Financeiros (atualizado 2026-05-14): [Acordos Não Fonanceiros - Ref.04/2026 -… .xlsx](https://dadosabertos.rj.gov.br/dataset/337bce33-6ee3-4121-9d3f-49b979d9ab07/resource/c6581632-c9b3-4b2e-97df-409350b1ff5f/download/acordos_nao_financeiros_seplag_ref_abril_2026.xlsx), [Acordos Não Fonanceiros - Ref.04/2026 -… CSV](https://dadosabertos.rj.gov.br/dataset/337bce33-6ee3-4121-9d3f-49b979d9ab07/resource/a718fb37-2666-4866-ba93-4957af40417a/download/acordos_nao_financeiros_seplag_ref_abril_2026.csv), [Acordos Não Fonanceiros - Ref.04/2026 -… PDF](https://dadosabertos.rj.gov.br/dataset/337bce33-6ee3-4121-9d3f-49b979d9ab07/resource/7bb5bd79-c4ec-4f74-b80f-cf2b5358fde8/download/acordos-nao-financeiros_seplag_rj_ref_abril_2026.pdf)
- Relatório ECM Saldos Almoxarifado (atualizado 2026-02-04): [Relatório ECM Saldos Almoxarifado 04202… PDF](https://dadosabertos.rj.gov.br/dataset/cb8b1459-6e3e-4ffd-9b12-a3898fcc1e53/resource/431371f2-81b3-40a3-9f76-62a8325a2fe0/download/relatorio-ecm-saldos-almoxarifado-042025.pdf)
- LEIS ORDINÁRIAS E LEIS COMPLEMENTARES (atualizado 2026-02-04): [LEIS ORDINÁRIAS E LEIS COMPLEMENTARES -… XLSX](https://dadosabertos.rj.gov.br/dataset/07ab48cd-583d-49e6-8eaf-5682066fb605/resource/e40d5907-e533-4c13-aee4-ee4022bfc4b1/download/-6-leis-ordinarias-e-leis-complementares-todos-os-anos.xlsx)
- IRT Estadual dos Complexos Econômicos (2010 a 2022) (atualizado 2026-02-03): [IRT_estadual_complexos_economicos_2010a… XLSX](https://dadosabertos.rj.gov.br/dataset/0cb04963-b13a-4c9c-89e8-ddc87788a44a/resource/1fc6bbc3-a08d-4538-9429-93f364cc958a/download/irt_estadual_complexos_economicos_2010a2022.xlsx)
- PARTICIPANTES (atualizado 2026-02-03): [PARTICIPANTES CSV](https://www.compras.rj.gov.br/siga/imagens/PARTICIPANTES.CSV)
- FORNECEDORES (atualizado 2026-02-03): [FORNECEDORES CSV](https://www.compras.rj.gov.br/siga/imagens/FORNECEDORES.CSV)
- SANÇÕES FORNECEDOR (atualizado 2026-02-03): [SANÇÕES FORNECEDOR CSV](https://www.compras.rj.gov.br/siga/imagens/FORNECEDOR_SANCOES.CSV)
- MAPEAMENTO FORNECEDOR (atualizado 2026-02-03): [MAPEAMENTO FORNECEDOR CSV](https://www.compras.rj.gov.br/siga/imagens/FORNECEDOR_MAPEAMENTOS.CSV)
- FORNECEDOR HISTÓRICO CONTRATAÇÕES (atualizado 2026-02-02): [FORNECEDOR HISTÓRICO CONTRATAÇÕES CSV](https://www.compras.rj.gov.br/siga/imagens/FORNECEDOR_HISTORICO_CONTRATACOES.CSV)
- CONTRATOS (atualizado 2026-02-02): [CONTRATOS_COMPRAS_PÚBLICAS CSV](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV)
- PROCESSO ELETRÔNICO DE DISPENSA (atualizado 2026-02-02): [PROCESSO ELETRÔNICO DE DISPENSA CSV](https://www.compras.rj.gov.br/siga/imagens/PROCESSOS_ELETRONICOS_DISPENSA.CSV)
- OUTRAS COMPRAS (atualizado 2026-02-02): [OUTRAS COMPRAS CSV](https://www.compras.rj.gov.br/siga/imagens/OUTRAS_COMPRAS.CSV)
- HISTÓRICO DE PREÇOS ATA (atualizado 2026-02-02): [HISTÓRICO DE PREÇOS ATA CSV](https://www.compras.rj.gov.br/siga/imagens/HISTORICO_PRECOS_ATAS.CSV)
- COMPRAS DIRETAS (atualizado 2026-02-02): [COMPRAS DIRETAS CSV](https://www.compras.rj.gov.br/siga/imagens/COMPRAS_DIRETAS.CSV)
- ITENS LICITAÇÕES (atualizado 2026-02-02): [ITENS LICITAÇÕES CSV](https://www.compras.rj.gov.br/siga/imagens/ITENS_LICITACOES.CSV)
- CATÁLOGO (atualizado 2026-02-02): [CATÁLOGO CSV](https://www.compras.rj.gov.br/siga/imagens/CATALOGO.CSV)
- Relação anual de ações do Orçamento Criança e Adolescente (atualizado 2026-01-16): [Relação anual de ações do Orçamento Cri… HTML](https://www.redeplan.planejamento.rj.gov.br/demaisprocessos/oca.html)
- Indicadores de Complexidade Econômica Estaduais (2006 a 2023) (atualizado 2025-08-13): [Indicadores_Complexidade_Econômica_UF_2… XLSX](https://dadosabertos.rj.gov.br/dataset/8914219c-280e-4fa2-95fa-9b065b93d07f/resource/a31a6d74-b934-4ec8-bc29-ced3e8de6628/download/indicadores_complexidade_economica_uf_2006a2023.xlsx), [Dicionário_ICE_estadual.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/8914219c-280e-4fa2-95fa-9b065b93d07f/resource/42d7eaf9-038f-47cf-9cfa-75d758005b41/download/dicionario_ice_estadual.xlsx)
- IRT Regional dos Complexos Econômicos (2010 a 2022) (atualizado 2025-07-18): [IRT_regional_complexos_economicos_2010a… XLSX](https://dadosabertos.rj.gov.br/dataset/1297b858-b081-4832-bb7f-46fc7e9c1e12/resource/1950afc9-3c24-48b2-9d35-ccdd45c6c00c/download/irt_regional_complexos_economicos_2010a2022.xlsx), [Dicionário_IRT_regional.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/1297b858-b081-4832-bb7f-46fc7e9c1e12/resource/4a204920-985b-4084-b767-f6d3369b2d14/download/dicionario_irt_regional.xlsx)
- IRT Município dos Complexos Econômicos (atualizado 2025-07-18): [IRT_municipal_complexos_economicos_2010… XLSX](https://dadosabertos.rj.gov.br/dataset/37a2bee0-2622-4b94-9898-81d0942bf2bc/resource/8306a55a-44c1-44fb-80fc-8c83a89a80e6/download/irt_municipal_complexos_economicos_2010a2022.xlsx), [Dicionário_IRT_municipal.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/37a2bee0-2622-4b94-9898-81d0942bf2bc/resource/4d7a5afa-e99f-43d0-b3a3-ca5b0c91388a/download/dicionario_irt_municipal.xlsx)
- Indicadores de Complexidade Econômica Regional (2006 a 2022) (atualizado 2025-07-18): [Dicionário_ICE_regional.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/c8ebf5ff-7fdb-4f22-aff6-563b152dafdc/resource/bad47671-2ef6-4c73-a7e2-90e529569899/download/dicionario_ice_regional.xlsx), [Indicadores_Complexidade_Econômica_meso… XLSX](https://dadosabertos.rj.gov.br/dataset/c8ebf5ff-7fdb-4f22-aff6-563b152dafdc/resource/ffe895b3-9d27-42fd-8bf0-2687f01a823b/download/indicadores_complexidade_economica_mesorregioesbr_regioesadmrj_2006a2022.xlsx)
- Ficha de Indicadores de Missão Consolidados - PEDES (atualizado 2025-07-18): [Ficha_de_Indicadores_de_Missão_Consolid… XLSX](https://dadosabertos.rj.gov.br/dataset/9a690039-31f2-4096-9f3d-f29c46459946/resource/b3ab048b-c8f0-409d-a33a-c0ce24f834c8/download/ficha_de_indicadores_de_missao_consolidados_pedes.xlsx)
- DADOS GERAIS DE CAPACITAÇÃO (atualizado 2025-06-06): [Dados Gerais de Capacitação HTML](https://egep.planejamento.rj.gov.br/egep/servicos/relatorio/)
- Monitoramento indicadores de resultado do PPA (atualizado 2025-06-06): [Monitoramento indicadores de resultado … HTML](https://www.redeplan.planejamento.rj.gov.br/PPA/relatorios.html)
- Indicadores de iniciativa do PPA (atualizado 2025-06-06): [Indicadores de iniciativa do PPA HTML](https://www.redeplan.planejamento.rj.gov.br/PPA/relatorios.html)
- Monitoramento dos produtos do PPA (atualizado 2025-06-06): [Monitoramento dos produtos do PPA HTML](https://www.redeplan.planejamento.rj.gov.br/PPA/relatorios.html)
- Detalhamento das Emendas Impositivas (atualizado 2025-06-06): [Detalhamento das Emendas Impositivas HTML](https://www.redeplan.planejamento.rj.gov.br/demaisprocessos/emendas.html)
- Indicadores de Programa no PPA (atualizado 2025-06-06): [Indicadores de Programa no PPA HTML](https://www.redeplan.planejamento.rj.gov.br/PPA/programacao.html)
- Metas Físicas do PPA (atualizado 2025-06-06): [Metas Físicas do PPA HTML](https://www.redeplan.planejamento.rj.gov.br/PPA/programacao.html)
- Metas Financeiras do PPA (atualizado 2025-06-06): [Metas Financeiras do PPA HTML](https://www.redeplan.planejamento.rj.gov.br/PPA/programacao.html)
- Relatório de Execução do Orçamento Criança e Adolescente - metas físicas (atualizado 2025-06-06): [Relatório de Execução do Orçamento Cria… HTML](https://www.redeplan.planejamento.rj.gov.br/demaisprocessos/oca.html)
- Relatório de Execução Orçamentária das Emendas Impositivas (atualizado 2025-06-06): [Relatório de Execução Orçamentária das … HTML](https://www.redeplan.planejamento.rj.gov.br/demaisprocessos/emendas.html)
- Relatório de Execução do Orçamento do Idoso (OI) - metas físicas (atualizado 2025-06-06): [Relatório de Execução do Orçamento do I… HTML](https://www.redeplan.planejamento.rj.gov.br/demaisprocessos/orc_idoso.html)
- Relatório de Execução do Orçamento Mulher (OM) - metas físicas (atualizado 2025-06-06): [Relatório de Execução do Orçamento Mulh… HTML](https://www.redeplan.planejamento.rj.gov.br/demaisprocessos/orc_mulher.html)
- Relatório de Execução do Orçamento Criança e Adolescente - execução orçamentária (atualizado 2025-06-06): [Relatório de Execução do Orçamento Cria… HTML](https://www.redeplan.planejamento.rj.gov.br/demaisprocessos/oca.html)
- Relação anual de ações do Orçamento Mulher (OM) (atualizado 2025-06-06): [Relação anual de ações do Orçamento Mul… HTML](https://www.redeplan.planejamento.rj.gov.br/demaisprocessos/orc_mulher.html)
- Relatório de Execução do Orçamento Mulher (OM) - execução orçamentária (atualizado 2025-06-06): [Relatório de Execução do Orçamento Mulh… HTML](https://www.redeplan.planejamento.rj.gov.br/demaisprocessos/orc_mulher.html)
- Relatório de Execução do Orçamento do Idoso - execução orçamentária (atualizado 2025-06-06): [Relatório de Execução do Orçamento do I… HTML](https://www.redeplan.planejamento.rj.gov.br/demaisprocessos/orc_idoso.html)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 5 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo
- O futuro secretário anunciado para a Secretaria de Planejamento, Gestão e Inovação é Anderson Monteze, que integra a equipe de transição de Douglas Ruas; a equipe recebeu relatórios do governo atual, mas as fontes não confirmam se a SEPLAG entregou seu relatório específico nem detalham seu conteúdo. [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)
- A proposta orçamentária de 2027 deverá ser reavaliada, diante de déficit previsto de R$ 14 bilhões, e a futura pasta deverá participar da formulação de um teto de gastos; são planos anunciados, não medidas cuja implementação esteja confirmada. [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml)
- As fontes consultadas não relatam contratos problemáticos, decisões do TCE-RJ, ações do MPRJ ou do Judiciário, nem interrupções de serviços relacionadas à SEPLAG. [G1 — transição de governo no RJ](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/15/transicao-de-governo-no-rj-veja-quem-participa-prazos-e-proximos-passos.ghtml) [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)

##### Alertas vermelhos
- **Alerta fiscal confirmado como previsão divulgada:** há déficit previsto de R$ 14 bilhões para 2027; Anderson Monteze afirmou que as projeções de receita e despesa estão sendo analisadas e que não se deve reduzir artificialmente o déficit para depois rever os números. [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml) [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)
- **Proposta em discussão, não regra implementada:** o projeto de teto de gastos ainda poderia sofrer ajustes e, se aprovado, exigiria adequações na proposta orçamentária de 2027 em análise na Alerj. [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml) [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)
- **Prazo de transição vencido, situação específica não esclarecida:** os secretários deveriam encaminhar relatórios até 30 de outubro; as fontes informam que a equipe de transição recebeu relatórios, mas não confirmam a entrega nem o teor do relatório da SEPLAG. [G1 — Ricardo Couto oficializa transição](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/14/governo-do-rj-inicia-transicao-para-gestao-2027.ghtml) [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)

##### Contratos e serviços críticos
Nada encontrado nas fontes consultadas sobre números, empresas, valores, vigências ou problemas em contratos da SEPLAG, nem sobre serviços críticos sob responsabilidade da secretaria. [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos) [G1 — transição de governo no RJ](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/15/transicao-de-governo-no-rj-veja-quem-participa-prazos-e-proximos-passos.ghtml)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)
- Nada encontrado nas fontes consultadas sobre decisões do TCE-RJ, ações do MPRJ, ações judiciais, irregularidades ou procedimentos de controle relacionados à SEPLAG. [G1 — transição de governo no RJ](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/15/transicao-de-governo-no-rj-veja-quem-participa-prazos-e-proximos-passos.ghtml) [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)
- **Tema de gestão, não pendência judicial noticiada:** a proposta de teto de gastos deverá envolver planejamento e orçamento da Alerj, do TCE, do Ministério Público e do Tribunal de Justiça, conforme a matéria; isso não é descrito como ação, decisão ou investigação contra a secretaria. [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml)

##### Riscos de apagão administrativo
Nada encontrado nas fontes consultadas sobre interrupção de serviços, crise operacional ou risco concreto de apagão administrativo na SEPLAG. [G1 — transição de governo no RJ](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/15/transicao-de-governo-no-rj-veja-quem-participa-prazos-e-proximos-passos.ghtml) [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)

##### Fatos recentes
- Em 14 de outubro, Rafael Ventura Abreu, então secretário estadual de Planejamento e Gestão, foi incluído na Comissão de Transição Governamental, presidida pelo secretário da Casa Civil; os secretários deveriam encaminhar informações até 30 de outubro sobre programas, decisões dos primeiros 100 dias, projetos pendentes ou interrompidos e contas públicas. [G1 — Ricardo Couto oficializa transição](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/14/governo-do-rj-inicia-transicao-para-gestao-2027.ghtml) [CBN — comissão de transição](https://cbn.globo.com/politica/noticia/2026/10/14/ricardo-couto-oficializa-criacao-da-comissao-de-transicao-para-futura-gestao-de-douglas-ruas-no-rj.ghtml)
- Em 3 de novembro, foi anunciado Anderson Monteze para a futura Secretaria de Planejamento, Gestão e Inovação. Entre as atribuições mencionadas estão revisar a proposta orçamentária de 2027 antes da votação e reavaliar as projeções de arrecadação; a equipe também analisa a evolução das receitas e despesas dos últimos anos. [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml) [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)
- A futura pasta deverá assumir a gestão do patrimônio imobiliário estadual, hoje vinculada à Casa Civil, e buscar receitas com exploração ou venda desses imóveis; as fontes descrevem essa atribuição como plano da nova gestão. [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml) [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)
- A equipe de transição estuda reduzir de 31 para 23 o número de pastas estaduais. [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)
- A proposta de teto considera limites para despesas e, segundo a matéria, deverá observar a Lei Complementar 212/2025 e as condições relacionadas ao Propag; a fonte não confirma a aprovação ou a implementação estadual da proposta. [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml) [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)
- Solicitar à secretaria o relatório de transição entregue, ou confirmação de sua entrega, com programas em andamento, decisões necessárias nos primeiros 100 dias, projetos pendentes ou interrompidos e situação das contas, temas previstos no decreto de transição. [G1 — Ricardo Couto oficializa transição](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/14/governo-do-rj-inicia-transicao-para-gestao-2027.ghtml) [CBN — comissão de transição](https://cbn.globo.com/politica/noticia/2026/10/14/ricardo-couto-oficializa-criacao-da-comissao-de-transicao-para-futura-gestao-de-douglas-ruas-no-rj.ghtml)
- Solicitar inventário dos contratos da secretaria, com objeto, contratado, valor, vigência, situação de execução e riscos à continuidade dos serviços, pois esses dados não constam nas fontes consultadas. [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)
- Solicitar quadro atualizado de apontamentos, decisões e recomendações do TCE-RJ, procedimentos ou ações do MPRJ e processos judiciais relacionados à secretaria, pois nada sobre esses casos foi encontrado nas fontes consultadas. [G1 — transição de governo no RJ](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/15/transicao-de-governo-no-rj-veja-quem-participa-prazos-e-proximos-passos.ghtml) [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)
- Solicitar memória de cálculo do déficit previsto de R$ 14 bilhões para 2027, cenários de receitas e despesas e situação da revisão orçamentária, pois as matérias reportam a previsão e a análise em curso, mas não trazem a memória de cálculo nem o resultado da revisão. [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml) [O Globo — intenção de criar teto de gastos](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos)
- Solicitar plano, cronograma e inventário de imóveis estaduais que passariam à gestão da nova pasta, além de estimativas de receitas, pois as fontes informam a atribuição pretendida, mas não detalham imóveis ou valores. [O Globo — primeiros secretários e revisão do orçamento](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml)

##### Fontes consultadas
1. [Transição de governo no RJ: o que acontece agora   G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/15/transicao-de-governo-no-rj-veja-quem-participa-prazos-e-proximos-passos.ghtml) — 2026-10-15
2. [Ricardo Couto oficializa transição para gestão de Douglas ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/10/14/governo-do-rj-inicia-transicao-para-gestao-2027.ghtml) — 2026-10-14
3. [Douglas Ruas anuncia primeiros secretários e prepara revisão do ...](https://oglobo.globo.com/rio/noticia/2026/11/03/douglas-ruas-anuncia-primeiros-secretarios-e-prepara-revisao-do-orcamento-e-teto-de-gastos-no-rio.ghtml) — 2026-11-03
4. [Ricardo Couto oficializa criação da Comissão de Transição para futura gestão de Douglas Ruas no RJ](https://cbn.globo.com/politica/noticia/2026/10/14/ricardo-couto-oficializa-criacao-da-comissao-de-transicao-para-futura-gestao-de-douglas-ruas-no-rj.ghtml) — 2026-10-14
5. [Douglas Ruas anuncia intenção de criar teto de gastos para o governo estadual](https://oglobo.globo.com/rio/noticia/2026/11/04/douglas-ruas-anuncia-intencao-de-criar-teto-de-gastos-para-o-governo-estadual.ghtml?interno_origem=materiasoglobo&interno_midia=menutematico&interno_campanha=teto-de-gastos) — 2026-11-04


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2024008301 (IMPRENSA OFICIAL DO ESTADO DO RIO DE JA…) vence em 24/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2026007409 (SOBERANA COMERCIO E SERVIÇOS LTDA) vence em 06/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2026007690 (SOBERANA COMERCIO E SERVIÇOS LTDA) vence em 06/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2022009117 (LIZ SERVIÇOS ONLINE LTDA) vence em 12/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025010444 (TAMANDARÉ INFORMATICA LTDA) vence em 15/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2024008758 (EXTREME DIGITAL CONSULTORIA E REPRESENT…, R$ 16,7 mi) consta 'Ativo' no SIGA com fim em 23/10/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2024009206 (FUNDAÇÃO DE APOIO A PESQUISA, ENSINO E …, R$ 15,0 mi) consta 'Ativo' no SIGA com fim em 31/12/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2025010826 (3STRUCTURE IT LTDA, R$ 7,9 mi) consta 'Ativo' no SIGA com fim em 21/06/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2023011040 (EVERY TI TECNOLOGIA & INOVAÇÃO LTDA, R$ 6,1 mi) consta 'Ativo' no SIGA com fim em 27/12/2024: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2022003260 (FOCO ASN 2010 SERVIÇOS GERAIS LTDA, R$ 4,4 mi) consta 'Ativo' no SIGA com fim em 09/11/2024: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Qual é o plano de contingência para o contrato 2025009912 com HOTEIS OTHON S.A. - EM RECUPERACAO JUDI… (em recuperação judicial)? Garantia contratual está válida?
13. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
14. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
15. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
16. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
17. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
