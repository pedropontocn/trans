# Dossiê de transição — Secretaria de Estado de Defesa Civil / Corpo de Bombeiros (SEDEC)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/sedec)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 5154 | R$ 2.793.500.166,50 |
| Com vigência futura (válidos no SIGA) | 794 | R$ 563.775.538,22 |
| até 30 dias | 61 | R$ 36.995.971,43 |
| até 60 dias | 32 | R$ 5.565.371,44 |
| até 90 dias | 72 | R$ 32.088.529,15 |
| até 180 dias | 158 | R$ 135.871.027,67 |
| vencido no SIGA | 4360 | R$ 2.229.724.628,27 |
| sem data | 11 | R$ 4.193.424,01 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 1.617,2 mi / R$ 806,9 mi / R$ 762,8 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2024009106 (HELICÓPTEROS DO BRASIL S/A) vence em 12/11/2026 — 6 dias — R$ 5.108.973,95. Objeto: Contratação de empresa especializada na prestação de serviços em aeronaves AS35…
- Contrato 2023009798 (FUNDAÇÃO DE ENSINO E PESQUISA DO SUL DE MINAS) vence em 23/11/2026 — 17 dias — R$ 5.767.488,00. Objeto: contratação de uma Instituição de Ensino Superior reconhecida pelo Ministério d…
- Contrato 2025009401 (BEM ESTAR HOSPITALAR COMÉRCIO DE EQUIPAMENTOS MÉD…) vence em 24/11/2026 — 18 dias — R$ 11.494.440,00. Objeto: Aquisição de viaturas tipo ASE
- Contrato 2022009661 (MESSER GASES LTDA) vence em 27/11/2026 — 21 dias — R$ 1.539.566,07. Objeto: CONTRATAÇÃO DE EMPRESA ESPECIALIZADA, DEVIDAMENTE CREDENCIADA E LICENCIADA PELO…
- Contrato 2025008662 (COMPANHIA DISTRIBUIDORA DE GAS DO RIO DE JANEIRO-…) vence em 27/11/2026 — 21 dias — R$ 2.460.756,46. Objeto: PROCESSO DE PAGAMENTO REFERENTE AOS SERVIÇOS A SEREM PRESTADOS PELA EMPRESA NAT…
- Contrato 2025009915 (HPE AUTOMOTORES DO BRASIL LTDA) vence em 04/12/2026 — 28 dias — R$ 6.235.443,00. Objeto: Aquisição de viaturas tipo AR
- Contrato 2024001494 (ENGE PRAT ENGENHARIA E SERVIÇOS LTDA) vence em 24/01/2027 — 79 dias — R$ 14.960.938,65. Objeto: CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇO DE REFORMA E EXECU…
- Mais 55 contratos menores (R$ 4,4 mi) vencem em até 30 dias — ver seção 3.
- 257 contratos (R$ 180,1 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 1343 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 596,2 mi); 12 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 3017 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 1.633,5 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- 4 contrato(s) 'Ativo' com data de fim inválida no SIGA (R$ 0,2 mi), ex.: 2018001018 (31/12/2108); 2018002195 (31/01/2201); 2018002245 (31/12/2108). Corrigir o cadastro e informar a vigência real.

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2022010214 | FUNESBOM | HOSPITAL DAS CLINICAS DA REGIAO DOS LAGOS S/A | Credenciamento Público Urgência e emergência | R$ 693.026,42 | 06/11/2026 | 0 |
| 2025010754 | FUNESBOM | SILITEC PRODUTOS HOSPITALARES LTDA | : MASCARA CIRURGICADESCARTAVEL,MATERIAL MASCARA: TECIDO NAO TECIDO,QU… | R$ 1.320,00 | 06/11/2026 | 0 |
| 2025008854 | SEDEC | COMITE NACIONAL DO CERIMONIAL E PROTOCOLO -C… | 3 (TRÊS) vagas para a capacitação e atualização de servidores no XXIX… | R$ 5.040,00 | 07/11/2026 | 1 |
| 2025009148 | FUNESBOM | VISUAL INDUSTRIA E COMERCIO DE LONAS EIRELI | Aquisição de BARRACAS TIPO TENDA PANTOGRÁFICA | R$ 88.000,00 | 07/11/2026 | 1 |
| 2025009177 | FUNESBOM | KM2 COMERCIO E REPRESENTAÇÃO | PROTETORES SOLARES FACIAIS - FPS 50 | R$ 271.432,00 | 07/11/2026 | 1 |
| 2022010299 | FUNESBOM | CONFERENCIA SAO JOSE DO AVAI | Credenciamento de empresas pessoa jurídica para prestação de serviços… | R$ 118.328,28 | 08/11/2026 | 2 |
| 2022010307 | FUNESBOM | CLINICA SERRA MED TERESOPOLIS LTDA | Credenciamento de empresas pessoa jurídica para prestação de serviços… | R$ 72.805,00 | 08/11/2026 | 2 |
| 2023000004 | FUNESBOM | CENTRO DE SAÚDE RENASCER LTDA ME | Credenciamento de empresas pessoa jurídica para prestação de serviços… | R$ 124.681,42 | 08/11/2026 | 2 |
| 2025007286 | FUNESBOM | MIGUEL HERNANDEZ INDUSTRIA, COMERCIO DE EQUI… | Aquisição de Cantis | R$ 10.000,00 | 11/11/2026 | 5 |
| 2025009071 | FUNESBOM | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de medicamentos por meio de ATA SRP nº 0113/2025-A, da Fund… | R$ 778,00 | 11/11/2026 | 5 |
| 2025009073 | FUNESBOM | CONQUISTA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de medicamentos por meio de ATA SRP nº 0083/2025-C, da Fund… | R$ 190,00 | 11/11/2026 | 5 |
| 2025009075 | FUNESBOM | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos por meio de ATA SRP nº0083/2025-D, da Funda… | R$ 225,00 | 11/11/2026 | 5 |
| 2025009076 | FUNESBOM | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de medicamentos por meio de ATA SRP nº 0106/2025-C, da Fund… | R$ 79,38 | 11/11/2026 | 5 |
| 2025009123 | FUNESBOM | CIENLABOR INDUSTRIA E COMERCIO LTDA | Aquisição de medicamentos por meio de ATA SRP nº 091/2025, da Fundaçã… | R$ 2.116,50 | 11/11/2026 | 5 |
| 2025009150 | FUNESBOM | DX COMERCIO E IMPORTACAO LTDA | Aquisição de Protetores Solares Corporais | R$ 226.363,44 | 11/11/2026 | 5 |
| 2025009235 | FUNESBOM | EMIGE MATERIAIS ODONTOLÓGICOS LTDA | A aquisição de aparelhos para fotopolimerização para aprimorar o aten… | R$ 84.999,55 | 11/11/2026 | 5 |
| 2024009106 | FUNESBOM | HELICÓPTEROS DO BRASIL S/A | Contratação de empresa especializada na prestação de serviços em aero… | R$ 5.108.973,95 | 12/11/2026 (PNCP) | 6 |
| 2025009067 | FUNESBOM | ESPECIFARMA COMERCIO DE MEDICAMENTOS E PRODU… | Aquisição de medicamentos por meio de ATA SRP nº0113/2025-D, da Funda… | R$ 2.723,00 | 12/11/2026 | 6 |
| 2025009074 | FUNESBOM | DROGAFONTE LTDA. | Aquisição de medicamentos por meio de ATA SRP nº 0106/2025-D, da Fund… | R$ 18,90 | 12/11/2026 | 6 |
| 2025009528 | FUNESBOM | BRASIL MED IMPORTACAO E EXPORTACAO LTDA | Aquisição de insumos por meio de ATA SRP nº 146/2024, da FUNESBOM. | R$ 21.094,00 | 12/11/2026 | 6 |
| 2025009656 | FUNESBOM | MINDMED HOSPITALAR LTDA | Aquisição de medicamentos por meio de ATA SRP nº0130/2025, da Secreta… | R$ 9.500,00 | 16/11/2026 | 10 |
| 2025009337 | FUNESBOM | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de medicamentos por meio de ATA SRP nº110/2025-A, da Fundaç… | R$ 658,80 | 17/11/2026 | 11 |
| 2025009338 | FUNESBOM | LEMAN MEDICAMENTOS E CIA LTDA | Aquisição de medicamentos por meio de ATA SRP nº 110/2025-B, da Funda… | R$ 756,00 | 17/11/2026 | 11 |
| 2025009341 | FUNESBOM | COMERCIAL CIRURGICA RIOCLARENSE LTDA | Aquisição de medicamentos por meio de ATA SRP nº 0121/2025-C, da Fund… | R$ 4.836,50 | 17/11/2026 | 11 |
| 2025009345 | FUNESBOM | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de medicamentos por meio de ATA SRP nº121/2025-B, da Fundaç… | R$ 1.263,60 | 17/11/2026 | 11 |
| 2025008975 | FUNESBOM | ZENIZ PLANEJAMENTOS COMERCIAIS LTDA | Aquisição de Equipamentos de Cozinha e Padaria para produção de refei… | R$ 24.372,00 | 18/11/2026 | 12 |
| 2025008976 | FUNESBOM | GLC ATACADO DE SUPRIMENTOS LTDA EPP | Aquisição de Equipamentos de Cozinha e Padaria para produção de refei… | R$ 38.900,00 | 18/11/2026 | 12 |
| 2025009017 | FUNESBOM | TAVELO COMÉRCIO E DISTRIBUIDORA LTDA | Aquisição de Equipamentos de Cozinha e Padaria para produção de refei… | R$ 37.846,12 | 18/11/2026 | 12 |
| 2025009023 | FUNESBOM | B. D. R. COMERCIO DE EQUIPAMENTOS LTDA | Aquisição de Equipamentos de Cozinha e Padaria para produção de refei… | R$ 2.500,00 | 18/11/2026 | 12 |
| 2025009025 | FUNESBOM | M.T.L. COMERCIO E REPRESENTAÇÃO LTDA | Aquisição de Equipamentos de Cozinha e Padaria para produção de refei… | R$ 41.248,00 | 18/11/2026 | 12 |
| 2025009347 | FUNESBOM | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de medicamentos por meio de ATA SRP nº 121/2025-A, da Funda… | R$ 127,60 | 19/11/2026 | 13 |
| 2022009398 | FUNESBOM | STTR INDUSTRIA E COMERCIO LTDA | A contratação de empresa especializada em serviço de validação (quali… | R$ 5.000,00 | 20/11/2026 | 14 |
| 2025009339 | FUNESBOM | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de medicamentos por meio de ATA SRP nº 0110/2025-E, da Fund… | R$ 78.739,20 | 20/11/2026 | 14 |
| 2025009352 | FUNESBOM | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de medicamentos por meio de ATA SRP nº 086/2025, da Secreta… | R$ 2.229,14 | 20/11/2026 | 14 |
| 2025009355 | FUNESBOM | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de medicamentos por meio de ATA SRP nº 0096/2025-B, da Fund… | R$ 74.150,39 | 20/11/2026 | 14 |
| 2025009357 | FUNESBOM | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de medicamentos por meio de ATA SRP nº0099/2025-B, da Funda… | R$ 60,00 | 20/11/2026 | 14 |
| 2025009358 | FUNESBOM | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de medicamentos por meio de ATA SRP nº 0065/2025, da Secret… | R$ 11.340,00 | 20/11/2026 | 14 |
| 2023009798 | FUNESBOM | FUNDAÇÃO DE ENSINO E PESQUISA DO SUL DE MINAS | contratação de uma Instituição de Ensino Superior reconhecida pelo Mi… | R$ 5.767.488,00 | 23/11/2026 | 17 |
| 2025009445 | FUNESBOM | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de insumos por meio de ATA SRP nº0121/2025, da SECRETARIA D… | R$ 16.506,00 | 23/11/2026 | 17 |
| 2025009446 | FUNESBOM | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de medicamentos por meio de ATA SRP nº110/2025, da Secretar… | R$ 5.088,00 | 23/11/2026 | 17 |
| 2025009529 | FUNESBOM | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de insumos por meio de ATA SRP nº0215/2025, da SECRETARIA D… | R$ 82,50 | 23/11/2026 | 17 |
| 2025009536 | FUNESBOM | HUNTER CIENTIFICA COMERCIAL E SERVIÇOS LTDA | Aquisição de medicamentos por meio de ATA SRP nº 115/2025, da Secreta… | R$ 3.303,00 | 23/11/2026 | 17 |
| 2025009539 | FUNESBOM | STERI-GRAU PRODUTOS HOSPITALARES LTDA - ME | Aquisição de medicamentos por meio de ATA SRP nº0113/2025, da Secreta… | R$ 24.262,25 | 23/11/2026 | 17 |
| 2025009578 | FUNESBOM | LEMARC PRODUTOS MÉDICOS HOSPITALARES LTDA-ME | Aquisição de medicamentos por meio de ATA SRP nº0108/2025, da Secreta… | R$ 1.259,00 | 23/11/2026 | 17 |
| 2025009586 | FUNESBOM | DONEGATE DISTRIBUIDORA LTDA-ME | Aquisição de medicamentos por meio de ATA SRP nº0112/2025, da Secreta… | R$ 2.000,00 | 23/11/2026 | 17 |
| 2025009587 | FUNESBOM | CDK DISTRIBUIDORA DE MEDICAMENTOS LTDA | Aquisição de medicamentos por meio de ATA SRP nº 0059/2025-B, da Fund… | R$ 1.503,21 | 23/11/2026 | 17 |
| 2025009401 | FUNESBOM | BEM ESTAR HOSPITALAR COMÉRCIO DE EQUIPAMENTO… | Aquisição de viaturas tipo ASE | R$ 11.494.440,00 | 24/11/2026 (PNCP) | 18 |
| 2025009583 | FUNESBOM | MEDGLOBAL DISTRIBUIDORA DE MATERIAL MÉDICO H… | Aquisição de medicamentos por meio de ATA SRP nº109/2025, da Secretar… | R$ 1.974,05 | 24/11/2026 | 18 |
| 2025009588 | FUNESBOM | SOARES & MARINS.PAES LTDA | Aquisição de insumos por meio de ATA SRP nº0116/2025, da SECRETARIA D… | R$ 17,58 | 25/11/2026 | 19 |
| 2025009702 | FUNESBOM | BAXTER HOSPITALAR LTDA | Aquisição de medicamentos por meio de ATA SRP nº009/2025-B, da Fundaç… | R$ 18.720,00 | 26/11/2026 | 20 |
| 2022009661 | FUNESBOM | MESSER GASES LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA, DEVIDAMENTE CREDENCIADA E LICEN… | R$ 1.539.566,07 | 27/11/2026 | 21 |
| 2023000075 | FUNESBOM | ENINCENDIO SISTEMA DE PROTEÇÃO E COMBATE LTDA | RECARGA E MANUTENÇÃO DE EXTINTORES | R$ 494.090,64 | 27/11/2026 | 21 |
| 2025000744 | FUNESBOM | RIO + SANEAMENTO BL3 S.A | FORNECIMENTO DE ÁGUA E COLETA DE ESGOTO. | R$ 132.566,14 | 27/11/2026 | 21 |
| 2025008660 | FUNESBOM | CONCESSIONÁRIA ÁGUAS DE JUTURNAÍBA S/A | FORNECIMENTO DE ÁGUA E COLETA DE ESGOTO. | R$ 204.896,60 | 27/11/2026 | 21 |
| 2025008662 | FUNESBOM | COMPANHIA DISTRIBUIDORA DE GAS DO RIO DE JAN… | PROCESSO DE PAGAMENTO REFERENTE AOS SERVIÇOS A SEREM PRESTADOS PELA E… | R$ 2.460.756,46 | 27/11/2026 (PNCP) | 21 |
| 2025009701 | FUNESBOM | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de medicamentos por meio de ATA SRP nº 0119/2025-B, da Fund… | R$ 4.640,00 | 27/11/2026 | 21 |
| 2025009830 | FUNESBOM | BRISTOL MYERS SQUIBB FARMACÊUTICA LTDA | Aquisição de medicamentos por meio de ATA SRP nº 129/2024, da Secreta… | R$ 615.520,60 | 01/12/2026 (PNCP) | 25 |
| 2025009333 | FUNESBOM | DENTAL BONSUCESSO PRODUTOS ODONTOLÓGICOS LTDA | PROTETOR SOLAR LABIAL | R$ 64.481,10 | 03/12/2026 | 27 |
| 2025009533 | SEDEC | CATIA DA CONCEICAO PREDES TEIXEIRA | Vinte vagas no Congresso AUTISMO 360°, promovido pela INCLUIR Treinam… | R$ 17.550,00 | 04/12/2026 | 28 |
| 2025009915 | FUNESBOM | HPE AUTOMOTORES DO BRASIL LTDA | Aquisição de viaturas tipo AR | R$ 6.235.443,00 | 04/12/2026 (PNCP) | 28 |
| 2024000139 | FUNESBOM | CLINICA SANTA HELENA LTDA | Credenciamento de empresa para prestaçãode serviço de saúde provendo … | R$ 724.095,04 | 05/12/2026 | 29 |
| 2021007596 | FUNESBOM | HOSPITAL VIVER MAIS LTDA | Contrato nº 81/2021 - CRED 01/2021 - credenciamento da empresa HOSPIT… | R$ 166.368,80 | 08/12/2026 | 32 |
| 2025010147 | FUNESBOM | CONNECTON MARKETING DE EVENTOS LTDA-ME | Contratação de 5 (cinco) vagas para o evento Curso ``10º CONGRESSO BR… | R$ 22.277,50 | 09/12/2026 | 33 |
| 2025010158 | FUNESBOM | SHELL LIFE MATERIAL HOSPITALAR LTDA | Aquisição de medicamentos por meio de ATA SRP nº 0017/2025, da Secret… | R$ 181.794,48 | 16/12/2026 | 40 |
| 2025010164 | FUNESBOM | ESPECIFARMA COMERCIO DE MEDICAMENTOS E PRODU… | Aquisição de medicamentos por meio de ATA SRP nº 0069/2025-E, da Fund… | R$ 7.040,00 | 16/12/2026 | 40 |
| 2025010449 | FUNESBOM | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de medicamentos por meio de ATA SRP nº 0077/2025-A, da Fund… | R$ 175,00 | 16/12/2026 | 40 |
| 2025010068 | FUNESBOM | PETERSON JOSE BERNARDO | AQUISIÇÃO DE APARELHOS DE LASER TERAPÊUTICOS | R$ 116.100,00 | 17/12/2026 | 41 |
| 2025010269 | FUNESBOM | INDUMED COMERCIO IMPORTACAO E EXPORTACAO DE … | AQUISIÇÃO DE BATERIA PARA DESFIBRILADOR SEMI-AUTOMATICO, MODELO: 12 V… | R$ 65.360,00 | 17/12/2026 | 41 |
| 2025009727 | FUNESBOM | ONCOVIT DISTRIBUIDORA DE MEDICAMENTOS LTDA M… | Aquisição de medicamentos por meio de ATA SRP nº0131/2025, da Secreta… | R$ 4.862,20 | 18/12/2026 | 42 |
| 2025010840 | FUNESBOM | DROGAFONTE LTDA. | Aquisição de insumos por meio de ATA SRP nº0175/2025, da FUNESBOM. | R$ 8.307,20 | 18/12/2026 | 42 |
| 2023000553 | FUNESBOM | CENTRO MÉDICO LOUIS PASTEUR S/S LTDA-EPP | Contratação de Clínica para atendimento ambulatorial Centro Médico Lo… | R$ 76.997,35 | 19/12/2026 | 43 |
| 2025010447 | SEDEC | ESAFI - ESCOLA DE ADMINISTRAÇÃO E TREINAMENT… | Contratação de vagas em curso para aprimoramento e capacitação de mil… | R$ 15.560,00 | 19/12/2026 | 43 |
| 2025010496 | FUNESBOM | DENTAL BONSUCESSO PRODUTOS ODONTOLÓGICOS LTDA | AQUISIÇÃO DE MATERIAL DE CONSUMO ODONTOLÓGICO - ETAPA 7 - ATA 036/2025 | R$ 9.692,64 | 19/12/2026 | 43 |
| 2025000828 | FUNESBOM | PRO LAGOS S/A | Contratação da empresa Prolagos por inexigibilidade para fornecimento… | R$ 398.508,09 | 22/12/2026 | 46 |
| 2025010834 | FUNESBOM | JOHNSON INDUSTRIAL DO BRASIL LTDA | Aquisição de aparelhos de musculação diversos | R$ 152.250,94 | 22/12/2026 | 46 |
| 2025010451 | FUNESBOM | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Solicitação de compra conforme Ata 0062-2025 da FUNESPOM | R$ 234,00 | 24/12/2026 | 48 |
| 2025010915 | FUNESBOM | EXCELENCIA DISTRIBUIDORA DE PRODUTOS E SERVI… | AQUISIÇÃO DE INSUMOS MÉDICO HOSPITALARES - CANULAS E TUBOS POR MEIO D… | R$ 942,82 | 26/12/2026 | 50 |
| 2022010277 | SEDEC | HAWK SEGURANÇA E VIGILÂNCIA LTDA | Contratação de empresa de vigilância patrimonial com vigilantes armad… | R$ 537.284,70 | 27/12/2026 | 51 |
| 2022010289 | FUNESBOM | CLARO S/A (FILIAL) | VALOR REFERENTE AOS SERVIÇOS A SEREM PRESTADOS PELA EMPRESA CLARO SER… | R$ 3.052.988,40 | 27/12/2026 | 51 |
| 2025005072 | FUNESBOM | FORTALEZA AMBIENTAL GERENCIAMENTO DE RESIDUO… | Contratação da empresa Fortaleza Ambiental por inexigibilidade para f… | R$ 12.530,91 | 29/12/2026 | 53 |
| 2025010838 | FUNESBOM | LEMAN MEDICAMENTOS E CIA LTDA | Aquisição de medicamentos por meio de ATA SRP nº0099/2025-C, da Funda… | R$ 88,20 | 29/12/2026 | 53 |
| 2025010961 | FUNESBOM | CONDOR S/A INDUSTRIA QUIMICA | Aquisição de instrumentos de menor potencial ofensivo (IMPO) para ati… | R$ 478.745,80 | 30/12/2026 | 54 |
| 2026003195 | FUNESBOM | INJEX INDUSTRIAS CIRURGICAS LTDA | Aquisição de insumos de saúde - agulhas hipodérmicas tamanhos 25X0,7m… | R$ 3.724,00 | 31/12/2026 | 55 |
| 2026003673 | FUNESBOM | R2 S ABRAHÃO COMÉRCIO E SERVIÇOS LTDA | Aquisição de CÂNULA NASOFARÍNGEA TAMANHO 6,0 ESTÉRIL por meio da Ata … | R$ 719,40 | 31/12/2026 | 55 |
| 2024000020 | FUNESBOM | GENTE SEGURADORA S.A. | Contratação de empresa especialiada para cobertura de seguro de 50 ci… | R$ 102.624,99 | 04/01/2027 | 59 |
| 2024000950 | FUNESBOM | NOVACLIN CLINICA GERAL LTDA | Prestação de serviços de saúde, provendo assistência médica em CONSUL… | R$ 91.061,73 | 04/01/2027 | 59 |
| 2025003829 | FUNESBOM | CONCESSIONÁRIA ÁGUAS DE PARATY S/A | PAGAMENTO DE DESPESAS DA CONCESSIONÁRIA ÁGUAS DE PARATY. | R$ 13.826,01 | 05/01/2027 | 60 |
| 2025004209 | FUNESBOM | PREFEITURA MUNICIPAL DE BARRA DO PIRAÍ | processo instrutivo para pagamento de faturas de água de TAE Barra do… | R$ 11.068,36 | 05/01/2027 | 60 |
| 2025009721 | FUNESBOM | COMERCIAL CIRURGICA RIOCLARENSE LTDA | Aquisição de medicamentos por meio de ATA SRP nº 0012/2025-C, da Fund… | R$ 753,90 | 05/01/2027 | 60 |
| 2025009723 | FUNESBOM | TRES PHARMA DISTRIBUIDORA E SERVIÇOS LTDA | Aquisição de medicamentos por meio de ATA SRP nº 0134/2025, da Secret… | R$ 4.334,73 | 05/01/2027 | 60 |
| 2025009725 | FUNESBOM | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de medicamentos por meio de ATA SRP nº0092/2025, da Secreta… | R$ 5.800,00 | 05/01/2027 | 60 |
| 2025009729 | FUNESBOM | ÂNCORA DISTRIBUIDORA DE MEDICAMENTOS LTDA | Aquisição de medicamentos por meio de ATA SRP nº 0136/2025, da Secret… | R$ 8.820,49 | 05/01/2027 | 60 |
| 2025009732 | FUNESBOM | COMERCIAL CIRURGICA RIOCLARENSE LTDA | Aquisição de medicamentos por meio de ATA SRP nº 0132/2025, da Secret… | R$ 14.528,80 | 05/01/2027 | 60 |
| 2025004201 | FUNESBOM | AGUAS DO RIO 1 SPE S.A | PROCESSO DE PAGAMENTO REFERENTE AOS SERVIÇOS A SEREM PRESTADOS PELA E… | R$ 1.043.292,85 | 06/01/2027 (PNCP) | 61 |
| 2025010898 | FUNESBOM | CM HOSPITALAR SA | Aquisição de medicamentos por meio de ATA SRP nº0146/2025, da Secreta… | R$ 13.380,00 | 06/01/2027 | 61 |
| 2025010899 | FUNESBOM | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de medicamentos por meio de ATA SRP nº 0099/2025-A, da Fund… | R$ 144,45 | 06/01/2027 | 61 |
| 2025010900 | FUNESBOM | ESPECIFARMA COMERCIO DE MEDICAMENTOS E PRODU… | Aquisição de medicamentos por meio de ATA SRP nº 114/2025, da Secreta… | R$ 3.575,00 | 06/01/2027 | 61 |
| 2025010902 | FUNESBOM | SURGICAL MED COMÉRCIO DE IMPORTAÇÃO DE MATER… | Aquisição de medicamentos por meio de ATA SRP nº0142/2025, da Secreta… | R$ 3.598,40 | 06/01/2027 | 61 |
| 2025010948 | FUNESBOM | ALRANTECH IMPORTACOES E COMERCIO LTDA | Aquisição de medicamentos por meio de ATA SRP nº107/2025, da Secretar… | R$ 8.810,85 | 06/01/2027 | 61 |
| 2025010903 | FUNESBOM | COLOPLAST DO BRASIL LTDA | Aquisição de medicamentos por meio de ATA SRP nº0143/2025, da Secreta… | R$ 11.880,00 | 07/01/2027 | 62 |
| 2025010904 | FUNESBOM | COLOPLAST DO BRASIL LTDA | Aquisição de medicamentos por meio de ATA SRP nº 0143/2025, da Secret… | R$ 2.448,00 | 07/01/2027 | 62 |
| 2025010907 | FUNESBOM | ONCOVIT DISTRIBUIDORA DE MEDICAMENTOS LTDA M… | Aquisição de medicamentos por meio de ATA SRP nº0089/2025, da Secreta… | R$ 9.658,80 | 07/01/2027 | 62 |
| 2025010908 | FUNESBOM | BRISTOL MYERS SQUIBB FARMACÊUTICA LTDA | Aquisição de insumos por meio de ATA SRP nº 0027/2025, da FUNESBOM. | R$ 157.149,68 | 07/01/2027 | 62 |
| 2025002690 | FUNESBOM | IGUA RIO DE JANEIRO S.A. | PROCESSO DE PAGAMENTO REFERENTE AOS SERVIÇOS A SEREM PRESTADOS PELA E… | R$ 800.836,33 | 08/01/2027 (PNCP) | 63 |
| 2026000029 | FUNESBOM | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de insumos por meio de ATA SRP nº004/2025, da FUNESBOM. | R$ 4.236,60 | 08/01/2027 | 63 |
| 2026000036 | FUNESBOM | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | Aquisição de insumos por meio de ATA SRP nº0043/2025, da FUNESBOM. | R$ 2.738,30 | 08/01/2027 | 63 |
| 2026000037 | FUNESBOM | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | Aquisição de medicamentos por meio de ATA SRP nº146/2025-A, da Fundaç… | R$ 561,60 | 08/01/2027 | 63 |
| 2026000042 | FUNESBOM | BAXTER HOSPITALAR LTDA | Aquisição de medicamentos por meio de ATA SRP nº0009/2025-B, da Funda… | R$ 14.560,00 | 08/01/2027 | 63 |
| 2026000044 | FUNESBOM | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de insumos por meio de ATA SRP nº040/2025, da FUNESBOM. | R$ 185,00 | 08/01/2027 | 63 |
| 2026000028 | FUNESBOM | BLAU FARMACEUTICA S.A. | Aquisição de medicamentos por meio de ATA SRP nº0166/2025-D, da Funda… | R$ 350.256,90 | 09/01/2027 | 64 |
| 2026000038 | FUNESBOM | SMARTHECNOLOGY COMÉRCIO E ASSISTÊNCIA DE EQU… | Aquisição de mochilas de resgate. | R$ 31.661,00 | 09/01/2027 | 64 |
| 2026000041 | FUNESBOM | LABORATÓRIOS B. BRAUN S.A | Aquisição de medicamentos por meio de ATA SRP nº009/2025-A/2025, da F… | R$ 5.187,00 | 09/01/2027 | 64 |
| 2024000642 | FUNESBOM | STTR INDUSTRIA E COMERCIO LTDA | Contratação de empresa especialiada na prestação de serviços de manut… | R$ 82.800,00 | 10/01/2027 | 65 |
| 2025009752 | FUNESBOM | SGHN - HIGIENIZACAO TEXTIL E NUTRICAO HOSPIT… | Disponibilização de enxoval hospitalar e serviço de lavanderia hospit… | R$ 1.188.641,28 | 10/01/2027 (PNCP) | 65 |
| 2026000139 | FUNESBOM | NOVA LINEA COMERCIO DE PRODUTOS FARMACEUTICO… | Aquisição de medicamentos por meio de ATA SRP nº0148/2025, da Secreta… | R$ 4.265,00 | 12/01/2027 | 67 |
| 2024000895 | FUNESBOM | MEDCOT DIAGNOSTICOS POR IMAGEM LTDA | Credenciamento de empresa para prestaçãocontinuada de serviços de APO… | R$ 188.556,63 | 14/01/2027 | 69 |
| 2026000085 | FUNESBOM | M. CARREGA COMERCIO DE PRODUTOS HOSPITALARES… | AQUISIÇÃO DE ELTROCARDIÓGRAFO | R$ 47.600,00 | 14/01/2027 | 69 |
| 2022000508 | FUNESBOM | BRAVO ASSESSORIA E SERVICOS EMPRESARIAIS LTDA | lIMPEZA DAS UNIDADES DE SAÚDE CO CBMERJ. | R$ 7.891.968,75 | 15/01/2027 | 70 |
| 2024000865 | FUNESBOM | ILAGOS DIAGNOSTICOS POR IMAGEM LTDA | Credenciamento de empresa para prestaçãocontinuada de serviços de APO… | R$ 224.483,01 | 16/01/2027 | 71 |
| 2025009595 | FUNESBOM | RIO MEIER COMERCIO DE MATERIAIS ODONTO-HOSPI… | AQUISIÇÃO DE MATERIAL DE CONSUMO ODONTOLÓGICO - ETAPA 7 - ATA 035 | R$ 4.731,82 | 16/01/2027 | 71 |
| 2025009599 | FUNESBOM | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | AQUISIÇÃO DE INSUMOS DE GRADE GERAL - LUVAS P | R$ 29.924,16 | 16/01/2027 | 71 |
| 2024001470 | SEDEC | SMARTTRACK - MONITORAMENTO E LOGÍSTICA LTDA. | referente à contratação de GPS por meio da Ata de Registro de Prec807… | R$ 412.188,00 | 21/01/2027 | 76 |
| 2026000059 | FUNESBOM | FARMACE - INDÚSTRIA QUÍMICO FARMACÊUTICA CEA… | Aquisição de medicamentos por meio de ATA SRP nº0159/2025-F, da Funda… | R$ 550,00 | 22/01/2027 | 77 |
| 2026000130 | FUNESBOM | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de insumos por meio de ATA SRP nº008/2025, da SECRETARIA DE… | R$ 3.100,00 | 22/01/2027 | 77 |
| 2026000137 | FUNESBOM | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos por meio de ATA SRP nº 0027/2025-A, da Fund… | R$ 1.417,50 | 22/01/2027 | 77 |
| 2026000138 | FUNESBOM | ASLI COMERCIAL LTDA | Aquisição de medicamentos por meio de ATA SRP nº0090/2025-A, da Funda… | R$ 11.160,00 | 22/01/2027 | 77 |
| 2026000175 | FUNESBOM | DROGAFONTE LTDA. | Aquisição de medicamentos por meio de ATA SRP nº0027/2025-B, da Funda… | R$ 1.712,00 | 22/01/2027 | 77 |
| 2026000176 | FUNESBOM | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de insumos por meio de ATA SRP nº0203/2025, da SECRETARIA D… | R$ 45,00 | 22/01/2027 | 77 |
| 2024000955 | FUNESBOM | CLINICA DE IMAGEM COMPUTADORIZADA LTDA | Credenciamento de empresa para prestaçãocontinuada de serviços de APO… | R$ 191.781,07 | 23/01/2027 | 78 |
| 2026000057 | FUNESBOM | BLAU FARMACEUTICA S.A. | Aquisição de medicamentos por meio de ATA SRP nº0159/2025-F, da Funda… | R$ 4.612,00 | 23/01/2027 | 78 |
| 2026000060 | FUNESBOM | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de medicamentos por meio de ATA SRP nº0149/2025-B, da Funda… | R$ 686,07 | 23/01/2027 | 78 |
| 2026000063 | FUNESBOM | PROMEFARMA MEDICAMENTOS E PRODUTOS HOSPITALA… | Aquisição de medicamentos por meio de ATA SRP nº0158/2025-E, da Funda… | R$ 959,20 | 23/01/2027 | 78 |
| 2026000171 | FUNESBOM | MED LAGOS CIRÚRGICA IMPORTAÇÃO E EXPORTAÇÃO … | Aquisição de insumos por meio de ATA SRP nº0189/2025, da SECRETARIA D… | R$ 2.736,00 | 23/01/2027 | 78 |
| 2026000174 | FUNESBOM | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de medicamentos por meio de ATA SRP nº0036/2025-C, da Funda… | R$ 5.957,76 | 23/01/2027 | 78 |
| 2024001494 | FUNESBOM | ENGE PRAT ENGENHARIA E SERVIÇOS LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇO DE REFOR… | R$ 14.960.938,65 | 24/01/2027 | 79 |
| 2024002261 | SEDEC | CLINICA DE MEDICINA NUCLEAR VILLELA PEDRAS L… | Contratação de empresa especializada na realização de exame de Densit… | R$ 25.499,10 | 24/01/2027 | 79 |
| 2026000061 | FUNESBOM | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | Aquisição de medicamentos por meio de ATA SRP nº0159/2025-H, da Funda… | R$ 14.000,00 | 26/01/2027 | 81 |
| 2026000131 | FUNESBOM | INJEX INDUSTRIAS CIRURGICAS LTDA | Aquisição de medicamentos por meio de ATA SRP nº005/2025-B, da Fundaç… | R$ 1.480,00 | 26/01/2027 | 81 |
| 2026000177 | FUNESBOM | ONCOVIT DISTRIBUIDORA DE MEDICAMENTOS LTDA M… | Aquisição de medicamentos por meio de ATA SRP nº0013/2025-B, da Funda… | R$ 5.220,00 | 26/01/2027 | 81 |
| 2026000178 | FUNESBOM | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de medicamentos por meio de ATA SRP nº0027/2025-F, da Funda… | R$ 2.100,00 | 26/01/2027 | 81 |
| 2026000181 | FUNESBOM | MEDITON FARMACEUTICA LTDA | Aquisição de medicamentos por meio de ATA SRP nº0173/2025-G, da Funda… | R$ 451,00 | 26/01/2027 | 81 |
| 2026000184 | FUNESBOM | CONQUISTA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de medicamentos por meio de ATA SRP nº0026/2025-A, da Funda… | R$ 2.729,70 | 26/01/2027 | 81 |
| 2026000183 | FUNESBOM | DROGAFONTE LTDA. | Aquisição de medicamentos por meio de ATA SRP nº0026/2025-B, da Funda… | R$ 18.000,00 | 27/01/2027 | 82 |
| 2026000166 | FUNESBOM | BEL MICRO TECNOLOGIA S/A | CONDICIONADOR AR. | R$ 132.522,70 | 28/01/2027 | 83 |
| 2026000142 | FUNESBOM | W3 INDUSTRIAS REUNIDAS S/A | Aquisicao de Armarios Roupeiros | R$ 416.004,42 | 29/01/2027 | 84 |
| 2026000167 | FUNESBOM | LEAR COMÉRCIO E SERVIÇOS DE AR CONDICIONADO … | CONDICIONADOR AR. | R$ 220.237,60 | 29/01/2027 | 84 |
| 2026000168 | FUNESBOM | TAVELO COMÉRCIO E DISTRIBUIDORA LTDA | CONDICIONADOR AR. | R$ 569.216,84 | 29/01/2027 (PNCP) | 84 |
| 2026000169 | FUNESBOM | VALLE COMERCIAL LTDA ME | CONDICIONADOR AR. | R$ 35.904,30 | 29/01/2027 | 84 |
| 2024000402 | FUNESBOM | ONCOMED CLINICA ONCOLOGICA LTDA | Refere à contratação de EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇO… | R$ 622.653,35 | 31/01/2027 | 86 |
| 2024002612 | FUNESBOM | BRS SUPRIMENTOS CORPORATIVOS S/A | Material de escritório. | R$ 1.336.059,81 | 31/01/2027 | 86 |
| 2025009657 | FUNESBOM | W.A. COMÉRCIO DE MEDICAMENTOS LTDA | Aquisição de insumos por meio de ATA SRP nº0026/2025, da FUNESBOM. | R$ 227.255,00 | 02/02/2027 | 88 |
| 2025010155 | FUNESBOM | NSA DISTRIBUIDORA DE MEDICAMENTOS EIRELLI | Aquisição de medicamentos por meio de ATA SRP nº 0135/2025, da Secret… | R$ 62.683,94 | 02/02/2027 | 88 |
| 2025010839 | FUNESBOM | LEMAN MEDICAMENTOS E CIA LTDA | Aquisição de insumos por meio de ATA SRP nº0134/2025, da SECRETARIA D… | R$ 11.178,00 | 02/02/2027 | 88 |
| 2025010901 | FUNESBOM | COLOPLAST DO BRASIL LTDA | Aquisição de medicamentos por meio de ATA SRP nº0143/2025, da Secreta… | R$ 17.000,00 | 02/02/2027 | 88 |
| 2025010905 | FUNESBOM | HOSPINOVA DISTRIBUIDORA DE PRODUTOS HOSPITAL… | Aquisição de insumos por meio de ATA SRP nº0251/2025, da SECRETARIA D… | R$ 424.198,80 | 02/02/2027 | 88 |
| 2025010906 | FUNESBOM | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos por meio de ATA SRP nº 0149/2025-A, da Fund… | R$ 10.455,00 | 02/02/2027 | 88 |
| 2025010947 | FUNESBOM | KGP FARMA DISTRIBUIDORA DE MEDICAMENTOS LTDA | Aquisição de medicamentos por meio de ATA SRP nº145/2025, da Secretar… | R$ 3.817,12 | 02/02/2027 | 88 |
| 2026000132 | FUNESBOM | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de medicamentos por meio de ATA SRP nº0048/2025-D, da Funda… | R$ 31,98 | 02/02/2027 | 88 |
| 2026000133 | FUNESBOM | BAXTER HOSPITALAR LTDA | Aquisição de medicamentos por meio de ATA SRP nº0113/2025-B, da Funda… | R$ 24.000,00 | 02/02/2027 | 88 |
| 2026000193 | FUNESBOM | DELVA FABRICAÇÃO DE PEÇAS EM METAIS LTDA | Aquisição de Barra Paralelas para Academias | R$ 2.015,00 | 02/02/2027 | 88 |
| 2022001266 | FUNESBOM | UNIMED DE VOLTA REDONDA COOPERATIVA DE TRABA… | Contratação por Credenciamento Público, através de Inexigibilidade de… | R$ 163.735,58 | 03/02/2027 | 89 |
| 2025009440 | FUNESBOM | SELENIUM MEDICAL LTDA | Aquisição de medicamentos por meio de ATA SRP nº 0005/2025-A, da Fund… | R$ 5.126,40 | 03/02/2027 | 89 |
| 2025009654 | FUNESBOM | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de medicamentos por meio de ATA SRP nº 0013/2025-D, da Fund… | R$ 6.231,68 | 03/02/2027 | 89 |
| 2026000186 | FUNESBOM | DROGAFONTE LTDA. | Aquisição de medicamentos por meio de ATA SRP nº0017/2025-C, da Funda… | R$ 555,16 | 03/02/2027 | 89 |
| 2026000281 | FUNESBOM | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de medicamentos por meio de ATA SRP nº0018/2025-C, da Funda… | R$ 3.192,00 | 03/02/2027 | 89 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000252 | FUNESBOM | 7LAN COMERCIO E SERVICOS LTDA | Aquisição de aeronaves tipo drones e acessorios | R$ 12.430.945,70 | 06/02/2027 (PNCP) | 92 |
| 2024000716 | FUNESBOM | 2LIVE STREAMING TELECOMUNICAÇÕES DIGITAIS LT… | LOCAÇÃO DE EQUIPAMENTO DE TRANSMISSÃO DE IMAGENS EM TEMPO REAL UTILIZ… | R$ 277.360,00 | 07/02/2027 | 93 |
| 2024001428 | FUNESBOM | CENTRO DE SAÚDE RENASCER LTDA ME | Credenciamento de empresa para prestação continuada de serviços de AP… | R$ 101.776,37 | 07/02/2027 | 93 |
| 2026000173 | FUNESBOM | HOSPDROGAS COMERCIAL LTDA | Aquisição de medicamentos por meio de ATA SRP nº0036/2025-F, da Funda… | R$ 46.655,00 | 08/02/2027 | 94 |
| 2026000185 | FUNESBOM | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de medicamentos por meio de ATA SRP nº0017/2025-A, da Funda… | R$ 48.139,20 | 08/02/2027 | 94 |
| 2026000385 | FUNESBOM | ONCOVIT DISTRIBUIDORA DE MEDICAMENTOS LTDA M… | Solicitação de compra ATA 0070/2025 da SEPM | R$ 24.969,60 | 08/02/2027 | 94 |
| 2026000161 | FUNESBOM | ORIGINAL IMPLANTES E EQUIPAMENTOS HOSPITALAR… | AQUISIÇÃO DE MATERIAIS DE OSTEOSSÍNTESE (PLACAS E PARAFUSOS DE TITÂNI… | R$ 71.644,00 | 10/02/2027 | 96 |
| 2026000365 | FUNESBOM | CONQUISTA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de medicamentos - diazepam 5mg/ml - ampola 2ml. | R$ 228,00 | 10/02/2027 | 96 |
| 2026000621 | FUNESBOM | MEDMACH SOLUCOES HOSPITALARES LTDA | Aquisição de materiais ata 114/2025-B, da FSERJ | R$ 184,56 | 11/02/2027 | 97 |
| 2026000725 | FUNESBOM | ELOAR SERVIÇOS DE COMUNICAÇÃO E MARKETING LT… | contratação de serviço abrangente de design gráfico, diagramação, edi… | R$ 49.600,00 | 11/02/2027 | 97 |
| 2026000737 | FUNESBOM | GRÁFICA MAGNÍFICO EIRELI | Contratação de serviço de impressão de RAPH | R$ 30.000,00 | 12/02/2027 | 98 |
| 2025005205 | FUNESBOM | BRASIL SAUDE CLINICA MEDICA E ODONTOLOGICA L… | CREDENCIAMENTO DE LABORATÓRIOS DE ANÁLISESCLÍNICA PARA ATENDIMENTO AO… | R$ 106.571,80 | 19/02/2027 | 105 |
| 2026000709 | FUNESBOM | GE HEALTHCARE DO BRASIL COMÉRCIO E SERVIÇOS … | O presente Termo de Referência (TR), motivado pelo Documento de Ofici… | R$ 77.268,00 | 19/02/2027 | 105 |
| 2025001954 | FUNESBOM | ATA NOBREAK SISTEMAS DE ENERGIA LTDA | AQUISIÇÃO DE DISPOSITIVO DE ALIMENTAÇÃO DE ENERGIA ELÉTRICA (NOBREAK) | R$ 46.000,00 | 20/02/2027 | 106 |
| 2025010692 | FUNESBOM | APOTEK DISTRIBUIDORA DE MEDICAMENTOS E MATER… | Aquisição de medicamentos por meio de ATA SRP nº0204/2025, da Fundaçã… | R$ 176,00 | 20/02/2027 | 106 |
| 2026000154 | FUNESBOM | DENTAL BONSUCESSO PRODUTOS ODONTOLÓGICOS LTDA | AQUISIÇÃO DE BANDAS E BRACKETS ORTODÔNTICOS | R$ 1.269,00 | 20/02/2027 | 106 |
| 2026000155 | FUNESBOM | RIO MEIER COMERCIO DE MATERIAIS ODONTO-HOSPI… | AQUISIÇÃO DE SUPRIMENTOS DE DENTÍSTICA - KIT MATRIZ - RESINA BULK FLOW | R$ 19.377,63 | 20/02/2027 | 106 |
| 2026000156 | FUNESBOM | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | AQUISIÇÃO DE MATERIAL DE CONSUMO ODONTOLÓGICO - ETAPA 4 - ÁGUA DESTIL… | R$ 992,82 | 20/02/2027 | 106 |
| 2026000180 | FUNESBOM | ONCO PROD DISTR. DE PROD. HOSPITALARES E ONC… | Aquisição de insumos por meio de ATA SRP nº0052/2025, da SECRETARIA D… | R$ 215.553,60 | 20/02/2027 | 106 |
| 2026000182 | FUNESBOM | BRISTOL MYERS SQUIBB FARMACÊUTICA LTDA | Aquisição de medicamentos por meio de ATA SRP nº0130/2025, da Secreta… | R$ 520.536,24 | 20/02/2027 (PNCP) | 106 |
| 2026000393 | FUNESBOM | JANSSEN CILAG FARMACEUTICA LTDA | Solicitação de compra conforme Ata 0099/2025 da FES | R$ 422.040,96 | 20/02/2027 | 106 |
| 2026000465 | FUNESBOM | ONCO PROD DISTR. DE PROD. HOSPITALARES E ONC… | Aquisição de insumos por meio de ATA SRP nº007/2025, da FUNESBOM. | R$ 168.840,00 | 20/02/2027 | 106 |
| 2026000480 | FUNESBOM | DENTAL BONSUCESSO PRODUTOS ODONTOLÓGICOS LTDA | AQUISIÇÃO DE SUPRIMENTOS PARA CLÍNICA GERAL - PLACA DE VIDRO | R$ 1.300,74 | 20/02/2027 | 106 |
| 2026000620 | FUNESBOM | POLYSUTURE INDUSTRIA E COMERCIO LTDA | Aquisição da ata 0107/2025-F da FSERJ | R$ 593,76 | 20/02/2027 | 106 |
| 2026000624 | FUNESBOM | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de medicamentos por meio de ATA SRP nº 0114/2025-C, da Fund… | R$ 1.040,64 | 20/02/2027 | 106 |
| 2026000857 | FUNESBOM | COUTOFLEX INDÚSTRIA DE MANGUEIRAS DE INCÊNDI… | Aquisição de LGE | R$ 1.039.792,00 | 23/02/2027 (PNCP) | 109 |
| 2025002993 | FUNESBOM | CLINMED SERVIÇOS MÉDICOS LTDA | Prestação continuada de serviços de CONSULTAS AMBULATORIAIS aos benef… | R$ 88.213,40 | 24/02/2027 | 110 |
| 2024001431 | FUNESBOM | RAD MED DIAGNOSTICO POR IMAGEM LTDA | Credenciamento - empresa RAD MED DIAGNOSTICO POR IMAGEM LTDA, CNPJ: 3… | R$ 278.585,72 | 25/02/2027 | 111 |
| 2024002428 | FUNESBOM | ULTRASCAN SERVIÇO DE IMAGEM LTDA | SERVICOS DE RADIODIAGNOSTICOS,DESCRICAO: CONTRATACAO DEPRESTACAO DE S… | R$ 144.384,47 | 27/02/2027 | 113 |
| 2026000484 | FUNESBOM | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | AQUISIÇÃO DE INSUMOS MÉDICO-ODONTOLÓGICOS - GAZE E ALGODÃO | R$ 1.389,84 | 27/02/2027 | 113 |
| 2026000984 | FUNESBOM | RIO MEIER COMERCIO DE MATERIAIS ODONTO-HOSPI… | AQUISIÇÃO DE SUPRIMENTOS PARA CLÍNICA GERAL - ABRIDOR DE BOCA - CABO … | R$ 1.601,46 | 27/02/2027 | 113 |
| 2026001115 | SEDEC | SILCAR COMERCIAL LTDA | Aquisição de sacos mortuários: tamanho adulto sem alça, tamanho adult… | R$ 338.531,65 | 27/02/2027 | 113 |
| 2023001303 | FUNESBOM | OI S/A | Contratação de serviço telefônicofixo comutado STFC fixofixo e fixomó… | R$ 3.134.385,08 | 02/03/2027 | 116 |
| 2023001511 | FUNESBOM | CASA DE SAÚDE JOÃO XXIII LTDA | CREDENCIAMENTO 02 | R$ 33.029,45 | 02/03/2027 | 116 |
| 2026001128 | FUNESBOM | INSTITUTO AOCP | contratação de entidade ou fundação especializada na realização de co… | R$ 2.826.782,00 | 02/03/2027 (PNCP) | 116 |
| 2026000797 | FUNESBOM | SQUADRA DO BRASIL DISTRIBUIDORA DE EQUIPAMEN… | Aquisição de mochilas de resgate. | R$ 29.575,40 | 03/03/2027 | 117 |
| 2026000179 | FUNESBOM | BEM ESTAR HOSPITALAR COMÉRCIO DE EQUIPAMENTO… | Aquisição de Ambulância de Resgate | R$ 21.991.600,00 | 04/03/2027 (PNCP) | 118 |
| 2026001170 | FUNESBOM | MARDISA VEÍCULOS LTDA | Aquisição de viaturas tipo Multimissoes | R$ 18.920.000,00 | 04/03/2027 (PNCP) | 118 |
| 2024002128 | FUNESBOM | CENTRO RADIOLÓGICO DE NOVA FRIBURGO LTDA | SERVICOS DE RADIODIAGNOSTICOS,DESCRICAO: CONTRATACAO DEPRESTACAO DE S… | R$ 251.789,34 | 05/03/2027 | 119 |
| 2026001048 | FUNESBOM | FSG COMERCIO E CONSULTORIA LICITATORIA LTDA | Aquisição de Mochilas de Hidratação (Ataque) | R$ 85.608,00 | 05/03/2027 | 119 |
| 2026001286 | FUNESBOM | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de insumos por meio de ATA SRP nº 0025/2025, da FUNESBOM. | R$ 5.700,00 | 05/03/2027 | 119 |
| 2024002102 | FUNESBOM | LEONARDO DO BRASIL LTDA | Contratação de empresa especialiada na prestação de serviços de forne… | R$ 1.158.419,26 | 06/03/2027 | 120 |
| 2026001306 | FUNESBOM | PARTS LUB DISTRIBUIDORA E SERVICOS LTDA | aquisição de Fluidos, aditivos e lubrificantes | R$ 816.849,60 | 06/03/2027 (PNCP) | 120 |
| 2026001308 | FUNESBOM | PROATIVA COMERCIO DE PECAS E ACESSORIOS AUTO… | aquisição de Fluidos, aditivos e lubrificantes | R$ 365.732,05 | 06/03/2027 | 120 |
| 2026001320 | FUNESBOM | ZUNDFOLGE MOTOR INDUSTRIA E COMERCIO LTDA | aquisição de Fluidos, aditivos e lubrificantes | R$ 663.308,00 | 06/03/2027 (PNCP) | 120 |
| 2026001323 | FUNESBOM | GABIGOLD DISTRIBUIDORA LTDA | aquisição de Fluidos, aditivos e lubrificantes | R$ 8.813,32 | 06/03/2027 | 120 |
| 2026001327 | FUNESBOM | TOVÁ COMÉRCIO DE PNEUS LTDA | aquisição de Fluidos, aditivos e lubrificantes | R$ 905.390,00 | 06/03/2027 (PNCP) | 120 |
| 2026001328 | FUNESBOM | ACTIPLUS EFICIÊNCIA EM ENERGIA LTDA. | aquisição de Fluidos, aditivos e lubrificantes | R$ 110.710,00 | 06/03/2027 | 120 |
| 2026001891 | FUNESBOM | TOTAL PRODUTOS E SERVICOS HOSPITALARES LTDA | Aquisição de insumos por meio de ATA SRP nº1430/2025, da FUNESBOM. | R$ 14.400,00 | 09/03/2027 | 123 |
| 2026001285 | FUNESBOM | ESPECIFARMA COMERCIO DE MEDICAMENTOS E PRODU… | Aquisição de medicamentos por meio de ATA SRP nº 0114/2025, da Fundaç… | R$ 420,00 | 10/03/2027 | 124 |
| 2025002325 | FUNESBOM | ILAGOS DIAGNÓSTICOS POR IMAGEM LTDA | Prestação continuada de serviços de APOIO DIAGNÓSTICO aos beneficiári… | R$ 84.790,19 | 11/03/2027 | 125 |
| 2026001380 | FUNESBOM | COMERCIAL CIRURGICA RIOCLARENSE LTDA | Aquisição de insumos por meio de ATA SRP nº0173/2025, da Fundação Saú… | R$ 1.955,98 | 11/03/2027 | 125 |
| 2026001614 | FUNESBOM | COMERCIAL CIRURGICA RIOCLARENSE LTDA | Aquisição de insumos por meio de ATA SRP nº0227/2025, da SECRETARIA D… | R$ 19.055,70 | 11/03/2027 | 125 |
| 2026001630 | FUNESBOM | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de insumos por meio de ATA SRP nº0015/2026-B, da Fundação S… | R$ 12.060,00 | 11/03/2027 | 125 |
| 2026001637 | FUNESBOM | FARMACE - INDÚSTRIA QUÍMICO FARMACÊUTICA CEA… | Aquisição de insumos por meio de ATA SRP nº0016/2026-C, da Fundação S… | R$ 1.008,00 | 11/03/2027 | 125 |
| 2026001651 | FUNESBOM | MARCK SERVIÇOS E DISTRIBUIÇÃO DE EQUIPAMENTO… | Aquisição de insumo por meio de ATA SRP nº0167/2025, da Secretaria de… | R$ 897,00 | 11/03/2027 | 125 |
| 2024002811 | FUNESBOM | CONFERENCIA SAO JOSE DO AVAI | Credenciamento de empresa para prestaçãocontinuada de serviços de APO… | R$ 170.792,79 | 12/03/2027 | 126 |
| 2026001582 | FUNESBOM | IMAGEMVIDA CURSO PREPARATORIO EM RADIOLOGIA … | CREDENCIAMENTO DE CLÍNICAS ONCOLÓGICAS ESPECIALIZADAS EM QUIMIOTERAPI… | R$ 6.250.000,00 | 12/03/2027 (PNCP) | 126 |
| 2022001735 | FUNESBOM | ESCAPE SOLUTIONS CONSULTORIA E REPRESENTAÇÃO… | serviço de manutenção preventiva e corretiva com fornecimento de peça… | R$ 2.149.462,78 | 14/03/2027 | 128 |
| 2023002224 | SEDEC | CLINICA DE MEDICINA NUCLEAR VILLELA PEDRAS L… | CONTRATAÇÃO DE EMPRESA PARA REALIZAÇÃODE TOMOGRAFIA COMPUTADORIZADA P… | R$ 331.319,33 | 14/03/2027 | 128 |
| 2026001649 | FUNESBOM | MULTIFARMA COMÉRCIO E REPRESENTAÇÕES LTDA | Aquisição de insumos por meio de ATA SRP nº0193/2025-E, da Fundação S… | R$ 144,00 | 16/03/2027 | 130 |
| 2026001084 | FUNESBOM | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de insumos por meio de ATA SRP nº0125/2025-A, da Fundação S… | R$ 2.016,50 | 17/03/2027 | 131 |
| 2026001288 | FUNESBOM | MED LAGOS CIRÚRGICA IMPORTAÇÃO E EXPORTAÇÃO … | Aquisição de insumos por meio de ATA SRP nº0189/2025, da SECRETARIA D… | R$ 3.306,00 | 17/03/2027 | 131 |
| 2026001289 | FUNESBOM | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de medicamentos por meio de ATA SRP nº0119/2025-B, da Funda… | R$ 2.100,00 | 17/03/2027 | 131 |
| 2026001290 | FUNESBOM | HUNTER CIENTIFICA COMERCIAL E SERVIÇOS LTDA | Aquisição de insumos por meio de ATA SRP nº0119/2025-H, da Fundação S… | R$ 155,20 | 17/03/2027 | 131 |
| 2026001291 | FUNESBOM | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de insumos por meio de ATA SRP nº0042/2025, da FUNESBOM. | R$ 349,92 | 17/03/2027 | 131 |
| 2026001292 | FUNESBOM | TOTAL SUPRI COMERCIO, IMPORTACAO E EXPORTACA… | Aquisição de insumos por meio de ATA SRP nº0119/2025-F, da Fundação S… | R$ 133,20 | 17/03/2027 | 131 |
| 2026001293 | FUNESBOM | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de insumos por meio de ATA SRP nº0116/2025-A, da Fundação S… | R$ 3.206,80 | 17/03/2027 | 131 |
| 2026001294 | FUNESBOM | COTAÇÃO COMÉRCIO REPRESENTAÇÃO IMPORTAÇÃO E … | Aquisição de insumos por meio de ATA SRP nº0125/2025-B, da Fundação S… | R$ 560,64 | 17/03/2027 | 131 |
| 2026001494 | FUNESBOM | BLAU FARMACEUTICA S.A. | Aquisição de medicamentos por meio de ATA SRP nº 0002/2026-B, da Fund… | R$ 14.001,60 | 17/03/2027 | 131 |
| 2026001556 | FUNESBOM | ESPECIFARMA COMERCIO DE MEDICAMENTOS E PRODU… | Aquisição de insumos por meio de ATA SRP nº 0070/2025, da SECRETARIA … | R$ 262,50 | 17/03/2027 | 131 |
| 2026001558 | FUNESBOM | ONCOVIT DISTRIBUIDORA DE MEDICAMENTOS LTDA M… | Aquisição de insumos por meio de ATA SRP nº0158/2025-D, da Fundação S… | R$ 90,42 | 17/03/2027 | 131 |
| 2026001617 | FUNESBOM | BLAU FARMACEUTICA S.A. | Aquisição de insumos por meio de ATA SRP nº0092/2026, da Fundação Saú… | R$ 4.190,00 | 17/03/2027 | 131 |
| 2026002290 | FUNESBOM | S.O.S SUL RESGATE - COMERCIO E SERVICOS DE S… | Aquisição de capacete de combate a incêndio | R$ 5.803.500,00 | 18/03/2027 | 132 |
| 2024003305 | FUNESBOM | SERVIÇO DE RADIOLOGIA E ULTRASSONOGRAFIA DE … | CREDENCIAMENTO DE EMPRESAS PARAPRESTAÇÃO CONTINUADA DE SERVIÇOS DE AP… | R$ 90.847,04 | 19/03/2027 | 133 |
| 2026001006 | FUNESBOM | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | AQUISIÇÃO DE MEDICAMENTO CLORIDRATO DE HIDRALAZINA POR MEIO DA ATA SR… | R$ 622,00 | 19/03/2027 | 133 |
| 2026001552 | FUNESBOM | RESGATECNICA COMERCIO DE EQUIPAMENTOS DE RES… | Aquisicao de Kit de Incendios Florestais para pick-ups | R$ 355.135,20 | 19/03/2027 | 133 |
| 2026001893 | SEDEC | INSTITUTO NEGOCIOS PUBLICOS ESTUDOS E PESQUI… | Aquisição de 70 (setenta) vagas para capacitação profissional, a sere… | R$ 375.232,49 | 19/03/2027 | 133 |
| 2025001828 | FUNESBOM | EXCLUSIVE HEALTH LABORATORIOS MEDICOS LTDA | Credenciamento de clínica oncológica especializada em quimioterapia p… | R$ 6.250.000,00 | 20/03/2027 (PNCP) | 134 |
| 2026001127 | FUNESBOM | RIO MEIER COMERCIO DE MATERIAIS ODONTO-HOSPI… | SUPRIMENTOS PARA ODONTOLOGIA DIGITAL | R$ 2.625,88 | 20/03/2027 | 134 |
| 2026001507 | FUNESBOM | DENTAL BONSUCESSO PRODUTOS ODONTOLÓGICOS LTDA | SUPRIMENTOS PARA ODONTOLOGIA DIGITAL | R$ 199.525,33 | 20/03/2027 | 134 |
| 2025004222 | FUNESBOM | AMPLA ENERGIA E SERVIÇOS S/A | PROCESSO DE PAGAMENTO REFERENTE AOS SERVIÇOS A SEREM PRESTADOS PELA E… | R$ 8.185.919,00 | 23/03/2027 (PNCP) | 137 |
| 2025002353 | FUNESBOM | FESO FUNDAÇÃO EDUCACIONAL SERRA DOS ÓRGÃOS | Credenciamento de empresa para prestação de serviços de APOIO DIAGNÓS… | R$ 197.661,93 | 24/03/2027 | 138 |
| 2026002223 | FUNESBOM | HPE AUTOMOTORES DO BRASIL LTDA | Aquisição de viaturas tipo pickup | R$ 6.235.443,00 | 25/03/2027 (PNCP) | 139 |
| 2025010436 | FUNESBOM | VISUAL INDUSTRIA E COMERCIO DE LONAS EIRELI | Aquisição de barracas tipo tenda pantográfica para atender a demanda … | R$ 132.000,00 | 26/03/2027 | 140 |
| 2026001049 | FUNESBOM | DENTAL BONSUCESSO PRODUTOS ODONTOLÓGICOS LTDA | INSUMOS DO LABORATÓRIO DE ODONTOLOGIA DIGITAL DO SISTEMA CAD/CAM | R$ 498.525,20 | 27/03/2027 | 141 |
| 2026001629 | FUNESBOM | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de insumos por meio de ATA SRP nº124/2025, da SECRETARIA DE… | R$ 34.376,00 | 27/03/2027 | 141 |
| 2026001495 | FUNESBOM | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de insumos por meio de ATA SRP nº0079/2025, da SECRETARIA D… | R$ 6.180,00 | 31/03/2027 | 145 |
| 2026001898 | FUNESBOM | NSA DISTRIBUIDORA DE MEDICAMENTOS EIRELLI | Aquisição de insumos por meio de ATA SRP nº0072/2025-B, da Fundação S… | R$ 14.610,00 | 31/03/2027 | 145 |
| 2026001933 | FUNESBOM | AVF COMERCIO DE PRODUTOS DE MEDICAMENTOS E F… | Aquisição de insumos por meio de ATA SRP nº0107/2025-A, da Fundação S… | R$ 1.103,77 | 31/03/2027 | 145 |
| 2026002221 | FUNESBOM | BEL MICRO TECNOLOGIA S/A | Aquisição de Aparelhos ar condicionados | R$ 113.815,96 | 31/03/2027 | 145 |
| 2026002222 | FUNESBOM | TAVELO COMÉRCIO E DISTRIBUIDORA LTDA | Aquisição de Aparelhos ar condicionados | R$ 11.334,00 | 31/03/2027 | 145 |
| 2024002405 | FUNESBOM | GRIDLAB SISTEMAS E SERVICOS LTDA | CONTRATAÇÃO DE EMPRESA PARA A PRESTAÇÃO DE SERVIÇO DE MÃO DE OBRA ESP… | R$ 5.171.709,07 | 02/04/2027 | 147 |
| 2024003063 | FUNESBOM | AVFARMA ASSISTENCIA E SERVIÇOS FARMACEUTICOS… | A contratação de empresa especialiada em manipulação e transporte de … | R$ 1.288.800,00 | 04/04/2027 | 149 |
| 2026001946 | FUNESBOM | SOCIEDADE FEDERAL DE PROCESSAMENTO DE DADOS … | Este Termo de Referência tem por finalidade apresentar os elementos e… | R$ 81.561,72 | 06/04/2027 | 151 |
| 2026002399 | FUNESBOM | BRUMO ESPORTES LTDA | Aquisição de Barra para supino | R$ 1.145,21 | 08/04/2027 | 153 |
| 2026001647 | FUNESBOM | BOTTI PHARMA LTDA | Aquisição de insumos por meio de ATA SRP nº0016/2026-D, da Fundação S… | R$ 228,00 | 09/04/2027 | 154 |
| 2026001496 | FUNESBOM | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de insumos por meio de ATA SRP nº0048/2025-B, da Fundação S… | R$ 410,00 | 09/04/2027 | 154 |
| 2026001499 | FUNESBOM | DROGAFONTE LTDA. | Aquisição de insumos por meio de ATA SRP nº0158/2025-B, da Fundação S… | R$ 2.539,50 | 09/04/2027 | 154 |
| 2026001557 | FUNESBOM | BRISTOL MYERS SQUIBB FARMACÊUTICA LTDA | Aquisição de insumos por meio de ATA SRP nº0027/2025, da FUNESBOM. | R$ 157.149,68 | 09/04/2027 | 154 |
| 2026001561 | FUNESBOM | HALEX ISTAR INDÚSTRIA FARMACÊUTICA S/A | Aquisição de insumos por meio de ATA SRP nº0068/2025, da SECRETARIA D… | R$ 5.756,40 | 09/04/2027 | 154 |
| 2026001590 | FUNESBOM | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de insumos por meio de ATA SRP nº0065/2025-G, da Fundação S… | R$ 39.959,40 | 09/04/2027 | 154 |
| 2026001604 | FUNESBOM | BLAU FARMACEUTICA S.A. | Aquisição de insumos por meio de ATA SRP nº0166/2025-D, da Fundação S… | R$ 150.110,10 | 09/04/2027 | 154 |
| 2026001609 | FUNESBOM | H. STRATTNER & CIA. LTDA. | Aquisição de insumo por meio de ATA SRP nº 171/2025, da Secretaria de… | R$ 155.720,00 | 09/04/2027 | 154 |
| 2026001618 | FUNESBOM | TRES PHARMA DISTRIBUIDORA E SERVIÇOS LTDA | Aquisição de insumo por meio de ATA SRP nº134/2025, da Secretaria de … | R$ 7.399,00 | 09/04/2027 | 154 |
| 2026001619 | FUNESBOM | NSA DISTRIBUIDORA DE MEDICAMENTOS EIRELLI | Aquisição de insumos por meio de ATA SRP nº0044/2025-B, da Fundação S… | R$ 860,40 | 09/04/2027 | 154 |
| 2026001621 | FUNESBOM | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de insumos por meio de ATA SRP nº0079/2025, da SECRETARIA D… | R$ 8.157,60 | 09/04/2027 | 154 |
| 2026001628 | FUNESBOM | COMERCIAL CIRURGICA RIOCLARENSE LTDA | Aquisição de insumos por meio de ATA SRP nº 0015/2026-A, da Fundação … | R$ 11.985,07 | 09/04/2027 | 154 |
| 2026001633 | FUNESBOM | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de insumos por meio de ATA SRP nº0015/2026-D, da Fundação S… | R$ 4.605,00 | 09/04/2027 | 154 |
| 2026001636 | FUNESBOM | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de insumos por meio de ATA SRP nº 0016/2026-A, da Fundação … | R$ 57,40 | 09/04/2027 | 154 |
| 2026001639 | FUNESBOM | RJD HOSPITALAR EIRELI | Aquisição de insumos por meio de ATA SRP nº0184/2025-D, da Fundação S… | R$ 55,32 | 09/04/2027 | 154 |
| 2026001641 | FUNESBOM | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de insumo por meio de ATA SRP nº0185/2025, da Secretaria de… | R$ 17.316,00 | 09/04/2027 | 154 |
| 2026001642 | FUNESBOM | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de insumo por meio de ATA SRP nº0187/2025, da Secretaria de… | R$ 7.113,58 | 09/04/2027 | 154 |
| 2026001643 | FUNESBOM | MULTIFARMA COMÉRCIO E REPRESENTAÇÕES LTDA | Aquisição de insumos por meio de ATA SRP nº0269/2025, da SECRETARIA D… | R$ 700,00 | 09/04/2027 | 154 |
| 2026001646 | FUNESBOM | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de insumos por meio de ATA SRP nº0166/2025-E, da Fundação S… | R$ 1.976,00 | 09/04/2027 | 154 |
| 2026001650 | FUNESBOM | UNIQUE DISTRIBUIDORA DE MEDICAMENTOS EIRELI | Aquisição de insumo por meio de ATA SRP nº0186/2025, da Secretaria de… | R$ 9.500,00 | 09/04/2027 | 154 |
| 2026001652 | FUNESBOM | FARMACE - INDÚSTRIA QUÍMICO FARMACÊUTICA CEA… | Aquisição de insumos por meio da ata 0065/2025-B da FSERJ | R$ 690,00 | 09/04/2027 | 154 |
| 2026001890 | FUNESBOM | MEDKA DISTRIBUIDORA HOSPITALAR LTDA | Aquisição de insumos por meio de ATA SRP nº0001/2026-D, da Fundação S… | R$ 1.525,28 | 09/04/2027 | 154 |
| 2026001921 | FUNESBOM | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de insumos por meio de ATA SRP nº0125/2025-E, da Fundação S… | R$ 788,66 | 09/04/2027 | 154 |
| 2026001923 | FUNESBOM | NSA DISTRIBUIDORA DE MEDICAMENTOS EIRELLI | Aquisição de insumo por meio de ATA SRP nº0090/2025, da Secretaria de… | R$ 19.678,48 | 09/04/2027 | 154 |
| 2026001925 | FUNESBOM | NSA DISTRIBUIDORA DE MEDICAMENTOS EIRELLI | Aquisição de insumos por meio da Ata 135/2025, da SEPM | R$ 42.382,20 | 09/04/2027 | 154 |
| 2026001926 | FUNESBOM | MAX PHARMA COMERCIO LTDA | Aquisição de insumos por meio de ATA SRP nº0037/2026, da SECRETARIA D… | R$ 66,60 | 09/04/2027 | 154 |
| 2026001927 | FUNESBOM | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de insumos por meio de ATA SRP nº0125/2025-C, da Fundação S… | R$ 18.075,96 | 09/04/2027 | 154 |
| 2026001932 | FUNESBOM | DLM HOSPITALAR EIRELI | Aquisição de insumos por meio de ATA SRP nº 0125/2025-D, da Fundação … | R$ 180,00 | 09/04/2027 | 154 |
| 2026001935 | FUNESBOM | BOTTI PHARMA LTDA | Aquisição de insumos conforme ATA 0015/2026-F da FSERJ | R$ 237,60 | 09/04/2027 | 154 |
| 2026001936 | FUNESBOM | ONCO PROD DISTR. DE PROD. HOSPITALARES E ONC… | Solicitação de compra conforme ATA SRP 0007/2025 da FUNESBOM | R$ 265.320,00 | 09/04/2027 | 154 |
| 2026002262 | FUNESBOM | CRISTÁLIA PRODUTOS QUÍMICOS FARMACÊUTICOS LT… | Aquisição de insumos por meio de ATA SRP nº0010/2026-F, da Fundação S… | R$ 725,00 | 09/04/2027 | 154 |
| 2026002628 | FUNESBOM | VARIEDADE COMERCIAL JGB LTDA | A aquisição de três (03) ESPIRÔMETROS para a Diretoria Geral de Saúde… | R$ 33.999,99 | 09/04/2027 | 154 |
| 2025002350 | FUNESBOM | UNIMED DE CAMPOS COOPERATIVA DE TRABALHO MED… | SERVICO MEDICO- HOSPITALAR,DESCRIÇÃO: CONTRATACAO DE CLINICA ONCOLOGI… | R$ 1.103.611,87 | 11/04/2027 (PNCP) | 156 |
| 2026001653 | FUNESBOM | DISTRIBUIÇÃO DE MEDICAMENTOS PAMED LTDA | Aquisição de insumos por meio de ATA SRP nº0007/2026-B, da Fundação S… | R$ 4.686,00 | 13/04/2027 | 158 |
| 2026001931 | FUNESBOM | NSA DISTRIBUIDORA DE MEDICAMENTOS EIRELLI | Aquisição de insumos por meio de ATA SRP nº0065/2025-H, da Fundação S… | R$ 1.843,50 | 13/04/2027 | 158 |
| 2026002725 | FUNESBOM | INSTITUTO ITER S/A | Aquisição de vagas para o evento Curso ``Planejamento e Gestão de Obr… | R$ 19.305,00 | 13/04/2027 | 158 |
| 2026001383 | FUNESBOM | MEDFUTURA DISTRIBUIDORA DE MEDICAMENTOS E PR… | Aquisição de insumos por meio de ATA SRP nº0276/2025, da SECRETARIA D… | R$ 358.768,86 | 14/04/2027 | 159 |
| 2026001577 | FUNESBOM | VISUAL INDUSTRIA E COMERCIO DE LONAS EIRELI | Aquisição de tendas pantograficas | R$ 208.000,00 | 14/04/2027 | 159 |
| 2026003011 | FUNESBOM | COELHO E MACHADO COMERCIAL E DISTRIBUIDORA E… | Aquisição de macacão de apicultor | R$ 51.480,00 | 14/04/2027 | 159 |
| 2026002675 | FUNESBOM | HOSPINOVA DISTRIBUIDORA DE PRODUTOS HOSPITAL… | Aquisição de insumo por meio de ATA SRP nº0049/2025, da Secretaria de… | R$ 346.750,00 | 17/04/2027 | 162 |
| 2026002981 | FUNESBOM | FLEET CARDS GESTÃO DE FROTAS LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM PRESTAÇÃO DE SERVIÇO DE GEREN… | R$ 17.865.594,18 | 17/04/2027 (PNCP) | 162 |
| 2026002718 | FUNESBOM | FARMACE - INDÚSTRIA QUÍMICO FARMACÊUTICA CEA… | Aquisição de medicamento - atropina 0,2mg/ml - ampola de 1ml. | R$ 207,00 | 20/04/2027 | 165 |
| 2026002740 | FUNESBOM | BIONEFRO COMÉRCIO DE MATERIAL HOSPITALAR LTD… | Aquisição de tubo endotraqueal n° 4.0mm. | R$ 169,40 | 20/04/2027 | 165 |
| 2026002744 | FUNESBOM | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição do medicamento Diazepam Solução Injetável por meio da Ata S… | R$ 360,00 | 20/04/2027 | 165 |
| 2026002805 | FUNESBOM | COMERCIAL CIRURGICA RIOCLARENSE LTDA | AQUISIÇÃO DE MEDICAMENTO ADENOSINA POR MEIO DA ATA SRP Nº 0173/2025/2… | R$ 1.731,68 | 20/04/2027 | 165 |
| 2023003030 | SEDEC | BMS SERVICE EIRELI - EPP | Serviço de teleatendimento para agendamento telefônico de consultas e… | R$ 2.555.136,00 | 27/04/2027 | 172 |
| 2026003468 | FUNESBOM | INJEX INDUSTRIAS CIRURGICAS LTDA | Aquisição de insumo por meio de ATA SRP nº023/2025, da Secretaria de … | R$ 26.847,00 | 27/04/2027 | 172 |
| 2026002257 | FUNESBOM | IS 8 INTERNATIONAL SUPPLIES IMP. E COM. PROD… | INSUMOS DA CENTRAL DE MATERIAL DE ESTERILIZAÇÃO - CBMERJ | R$ 28.784,00 | 28/04/2027 | 173 |
| 2026002296 | FUNESBOM | DENTAL BONSUCESSO PRODUTOS ODONTOLÓGICOS LTDA | AQUISIÇÃO DE MATERIAL DE CONSUMO ODONTOLÓGICO - ETAPA 7 - ATA 036/2025 | R$ 128,32 | 28/04/2027 | 173 |
| 2026002393 | FUNESBOM | RIO MEIER COMERCIO DE MATERIAIS ODONTO-HOSPI… | AQUISIÇÃO DE MATERIAL DE CONSUMO ODONTOLÓGICO - ETAPA 7 - ATA 035/2025 | R$ 660,04 | 28/04/2027 | 173 |
| 2026002678 | FUNESBOM | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | Aquisição de insumos por meio de ATA SRP nº0025/2025, da FUNESBOM. | R$ 8.386,56 | 28/04/2027 | 173 |
| 2026002766 | FUNESBOM | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação de serviço de hospedagem em Servidores Virtuais Privados … | R$ 57.485,76 | 28/04/2027 | 173 |
| 2026002777 | FUNESBOM | BAXTER HOSPITALAR LTDA | Aquisição de insumos por meio da Ata SRP N° 0091/2025/266500-03 da FU… | R$ 3.536,84 | 28/04/2027 | 173 |
| 2026000355 | FUNESBOM | DBV COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO DO BRAS… | Aquisição de medicamentos por meio de ATA SRP nº0018/2025-A, da Funda… | R$ 425,00 | 29/04/2027 | 174 |
| 2026000463 | FUNESBOM | FARMACE - INDÚSTRIA QUÍMICO FARMACÊUTICA CEA… | Aquisição de medicamentos por meio de ATA SRP nº54/2025-C, da Fundaçã… | R$ 2.154,00 | 29/04/2027 | 174 |
| 2026002803 | FUNESBOM | ESPECIFARMA COMERCIO DE MEDICAMENTOS E PRODU… | Aquisição de Insumos (TUBO EXTENSOR CATETER, COMPRIMENTO: 120 CM, CAL… | R$ 824,60 | 30/04/2027 | 175 |
| 2026002906 | FUNESBOM | TARGET MEDICAMENTOS E PRODUTOS HOSPITALARES … | AQUISIÇÃO DE MEDICAMENTO ÁCIDO ACETILSALICILICO POR MEIO DA ATA SRP N… | R$ 65,52 | 30/04/2027 | 175 |
| 2026002943 | FUNESBOM | LABORATÓRIOS B. BRAUN S.A | Aquisição de insumo - Ringer com lactato | R$ 66.880,00 | 30/04/2027 | 175 |
| 2026003196 | FUNESBOM | MULTIFARMA COMÉRCIO E REPRESENTAÇÕES LTDA | Aquisição de medicamento - cloridrato de tramadol. | R$ 350,00 | 30/04/2027 | 175 |
| 2025003238 | FUNESBOM | INSTITUTO DE DIAGNOSTICO POR IMAGEM LTDA | Credenciamento de empresa para prestação de serviços de APOIO DIAGNÓS… | R$ 209.473,00 | 05/05/2027 | 180 |
| 2026001917 | FUNESBOM | DISTRIBUIDORA DE MEDICAMENTOS SANTE LTDA | Aquisição de insumos por meio de ATA SRP nº0041/2025, da FUNESBOM. | R$ 165,60 | 05/05/2027 | 180 |
| 2026002680 | FUNESBOM | GREEN MED DISTRIBUIDORA E IMPORTADORA DE MED… | Aquisição de insumos por meio da ATA SRP Nº 0204/2026/266500-01, da F… | R$ 344,70 | 05/05/2027 | 180 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025004930 | FUNESBOM | ANGLOCO LIMITED | Aquisição de viaturas tipo ABSL | R$ 77.000.000,00 | 11/06/2026 | -148 |
| 2022004828 | FUNESBOM | ENGE PRAT ENGENHARIA E SERVIÇOS LTDA | Contratação de empresa qualificada para aprestação de serviços comuns… | R$ 29.901.202,67 | 23/06/2026 | -136 |
| 2025007278 | FUNESBOM | MARDISA VEÍCULOS LTDA | Aquisição de viaturas do tipo multimissões | R$ 28.380.000,00 | 12/09/2026 (PNCP) | -55 |
| 2025005015 | FUNESBOM | HERCULES EQUIPAMENTOS DE PROTECAO LTDA | Aquisicao de Conjuntos de Aproximacao de Incendios Urbanos | R$ 26.053.500,00 | 22/06/2026 | -137 |
| 2025000158 | FUNESBOM | WLM PARTICIPACOES E COMERCIO DE MAQUINAS E V… | Aquisição de viaturas tipo ATT | R$ 19.422.000,00 | 15/08/2025 | -448 |
| 2024003801 | FUNESBOM | LINK CARD ADMINISTRADORA DE BENEFICIOS EIREL… | GERENCIAMENTO DE FORNECIMENTO DE COMBUSTÍVEL | R$ 19.295.037,06 | 06/11/2025 (PNCP) | -365 |
| 2025003419 | FUNESBOM | LIGHT SERVICOS DE ELETRICIDADE SA | PROCESSO DE PAGAMENTO REFERENTE AOS SERVIÇOS A SEREM PRESTADOS PELA E… | R$ 19.293.504,06 | 12/06/2026 (PNCP) | -147 |
| 2025000244 | FUNESBOM | AGUAS DO RIO 4 SPE S.A | PROCESSO DE PAGAMENTO REFERENTE AOS SERVIÇOS A SEREM PRESTADOS PELA E… | R$ 17.416.573,53 | 18/02/2026 (PNCP) | -261 |
| 2021000109 | FUNESBOM | EMPRESA BRASILEIRA DE CORREIOS E TELÉGRAFOS | Consiste na contratação de empresa especializada para a execução dos … | R$ 13.664.889,13 | 10/12/2025 | -331 |
| 2024005539 | FUNESBOM | ITURRI S.A. | Auto Bomba Salvamento | R$ 12.950.000,00 | 09/07/2025 | -485 |
| 2024005542 | FUNESBOM | ITURRI S.A. | Aquisição de Viatura do tipo AUTO BOMBA E SALVAMENTO (ABS). | R$ 12.950.000,00 | 09/07/2025 | -485 |
| 2025005943 | FUNESBOM | JACINTO MARQUES DE OLIVEIRA SUCESSORES LDA | Aquisição de VTR ABTF | R$ 10.782.856,00 | 26/08/2026 (PNCP) | -72 |
| 2023003378 | FUNESBOM | LIGHT SERVICOS DE ELETRICIDADE SA | PROCESSO DE PAGAMENTO REFERENTE AOS SERVIÇOS A SEREM PRESTADOS PELA E… | R$ 9.055.563,70 | 02/04/2025 | -583 |
| 2025008550 | FUNESBOM | LECARD ADMNISTRADORA DE CARTÕES LTDA | CONTRATAÇÃO DE EMPRESA PARA FORNECIMENTO DE CARTÃO NATALINO. | R$ 8.592.454,00 | 21/10/2026 (PNCP) | -16 |
| 2025001635 | FUNESBOM | HERCULES EQUIPAMENTOS DE PROTECAO LTDA | CONJUNTO DE APROXIMAÇÃO DE COMBATE A INCÊNDIO | R$ 8.250.000,00 | 05/03/2026 | -246 |
| 2022005819 | FUNESBOM | GEOMETRIE PROJETOS E SERVIÇOS DE ARQUITETURA… | Contratação de pessoa jurídica para a prestação de serviços relativos… | R$ 7.967.511,76 | 13/06/2025 | -511 |
| 2024009689 | FUNESBOM | RC CARD SOLUCOES EM PAGAMENTOS LTDA | Contratação de empresa especializada na prestação de serviços de emis… | R$ 6.314.880,00 | 06/02/2026 (PNCP) | -273 |
| 2024010357 | FUNESBOM | CLÍNICA SÃO CARLOS S/A | Credenciamento de Clínica Oncológica Especializada em Quimioterapia p… | R$ 6.250.000,00 | 19/12/2025 (PNCP) | -322 |
| 2023010001 | SEDEC | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | aquisição de cartões alimentação a título de bonificação natalina | R$ 6.131.962,50 | 28/11/2024 | -708 |
| 2024003141 | FUNESBOM | TOVÁ COMÉRCIO DE PNEUS LTDA | Aquisição de pneus, câmara de ar, protetores e válvulas | R$ 6.037.714,57 | 24/04/2025 | -561 |
| 2025004678 | FUNESBOM | S.O.S SUL RESGATE - COMERCIO E SERVICOS DE S… | Aquisição de Capacetes para Combate a Incêndios | R$ 5.803.500,00 | 16/06/2026 | -143 |
| 2023010809 | SEDEC | RC FOREVER COMERCIO DE VEICULOS EIRELI | Solicito a Compra SC do quantitativo total de 24 unidades de Auto Mot… | R$ 5.799.994,83 | 19/12/2024 | -687 |
| 2025008150 | FUNESBOM | MANUPA COMERCIO EXPORTACAO IMPORTACAO DE EQU… | Consumo de VTR Posto Móvel | R$ 5.777.272,71 | 13/10/2026 (PNCP) | -24 |
| 2023010217 | FUNESBOM | NIVEL 1 SOLUÇÕES AUTOMOTIVAS LTDA | Aquisição de viaturas tipo V5 | R$ 5.215.248,50 | 03/12/2024 | -703 |
| 2024002085 | FUNESBOM | TOYOTA DO BRASIL LTDA | Viatura do tipo APC. | R$ 5.161.000,00 | 13/03/2025 | -603 |
| 2025005751 | FUNESBOM | S.O.S SUL RESGATE - COMERCIO E SERVICOS DE S… | Aquisicao de Capacetes para Incendios | R$ 5.029.700,00 | 24/07/2026 | -105 |
| 2024005418 | FUNESBOM | NIVEL 1 SOLUÇÕES AUTOMOTIVAS LTDA | Aquisição de viaturas tipo V5 | R$ 4.798.028,62 | 09/07/2025 | -485 |
| 2025000020 | FUNESBOM | INSTITUTO DE DESENVOLVIMENTO EDUCACIONAL, CU… | contratação de instituição especializada na prestação de serviços téc… | R$ 4.732.536,00 | 17/01/2026 (PNCP) | -293 |
| 2024005816 | FUNESBOM | JBS COMÉRCIO DE UNIFORMES E EQUIPAMENTOS EIR… | Fardamento BM | R$ 4.431.618,40 | 23/07/2025 | -471 |
| 2024002009 | FUNESBOM | BGS AMERICA LTDA | AQUISIÇÃO DE MULTIESTRUTURAS DE TREINAMENTO DECOMBATE A INCÊNDIO TIPO… | R$ 4.400.000,00 | 07/03/2025 | -609 |

_Registros mais antigos (provável falta de baixa no SIGA): 3017, R$ 1.633,5 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2022007886 | FUNESBOM | CONSTRUTORA METROPOLITANA S.A. | Contratação de empresa especializada na PRESTAÇÃO DE SERVIÇO DE REFOR… | R$ 53.865.258,34 | 15/09/2027 | 313 |
| 2024007141 | FUNESBOM | MGS CLEAN SOLUÇÕES E SERVIÇOS LTDA | CONTRATAÇÃO DE PESSOA JURÍDICA PARA PRESTAÇÃO DE SERVIÇOS CONTINUADOS… | R$ 35.015.569,68 | 31/07/2027 | 267 |
| 2022005491 | FUNESBOM | ARGAL CONSTRUTORA LTDA | Contratação de empresa qualificada para aprestação de serviços comuns… | R$ 30.234.550,17 | 23/06/2027 | 229 |
| 2025010297 | FUNESBOM | EMPRESA BRASILEIRA DE CORREIOS E TELEGRAFOS | contratação de empresa para a prestação do serviço e postagem, princi… | R$ 26.248.441,20 | 11/12/2030 | 1496 |
| 2026000179 | FUNESBOM | BEM ESTAR HOSPITALAR COMÉRCIO DE EQUIPAMENTO… | Aquisição de Ambulância de Resgate | R$ 21.991.600,00 | 04/03/2027 (PNCP) | 118 |
| 2026003836 | FUNESBOM | NEO CONSULTORIA E ADMINISTRACAO DE BENEFICIO… | CONTRATACAO DE EMPRESA ESPECIALIZADA EM SERVICO DE FORNECIMENTO DE CO… | R$ 20.871.799,96 | 25/05/2028 | 566 |
| 2026001170 | FUNESBOM | MARDISA VEÍCULOS LTDA | Aquisição de viaturas tipo Multimissoes | R$ 18.920.000,00 | 04/03/2027 (PNCP) | 118 |
| 2026002981 | FUNESBOM | FLEET CARDS GESTÃO DE FROTAS LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM PRESTAÇÃO DE SERVIÇO DE GEREN… | R$ 17.865.594,18 | 17/04/2027 (PNCP) | 162 |
| 2024001494 | FUNESBOM | ENGE PRAT ENGENHARIA E SERVIÇOS LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇO DE REFOR… | R$ 14.960.938,65 | 24/01/2027 | 79 |
| 2025004932 | SEDEC | CS BRASIL FROTAS S.A. | Contratação, por meio de Pregão Eletrônico para Registro de Preços, d… | R$ 12.432.728,16 | 16/07/2028 | 618 |
| 2026000252 | FUNESBOM | 7LAN COMERCIO E SERVICOS LTDA | Aquisição de aeronaves tipo drones e acessorios | R$ 12.430.945,70 | 06/02/2027 (PNCP) | 92 |
| 2025009401 | FUNESBOM | BEM ESTAR HOSPITALAR COMÉRCIO DE EQUIPAMENTO… | Aquisição de viaturas tipo ASE | R$ 11.494.440,00 | 24/11/2026 (PNCP) | 18 |
| 2024006939 | FUNESBOM | MGS CLEAN SOLUÇÕES E SERVIÇOS LTDA | Contratação de serviço continuado de apoio às atividades hospitalares… | R$ 11.069.355,36 | 01/09/2027 | 299 |
| 2023006093 | FUNESBOM | MAPFRE SEGUROS GERAIS S/A | SEGURO PARA A FROTA AÉREA DO CBMERJ HELICÓPTEROS | R$ 9.317.657,10 | 01/08/2027 | 268 |
| 2025004222 | FUNESBOM | AMPLA ENERGIA E SERVIÇOS S/A | PROCESSO DE PAGAMENTO REFERENTE AOS SERVIÇOS A SEREM PRESTADOS PELA E… | R$ 8.185.919,00 | 23/03/2027 (PNCP) | 137 |
| 2022000508 | FUNESBOM | BRAVO ASSESSORIA E SERVICOS EMPRESARIAIS LTDA | lIMPEZA DAS UNIDADES DE SAÚDE CO CBMERJ. | R$ 7.891.968,75 | 15/01/2027 | 70 |
| 2023005958 | FUNESBOM | INSTITUTO HERMES PARDINI S.A. | Contratação de Empresa especialiada na realiação de exames deRessonân… | R$ 7.334.269,11 | 31/07/2027 | 267 |
| 2022003476 | FUNESBOM | CONSTRUIR FACILITIES ARQUITETURA E SERVIÇOS … | Prestação de Serviços de Limpeza Predial comfornecimento de material … | R$ 7.213.041,37 | 12/05/2027 | 187 |
| 2024008293 | FUNESBOM | ONCOMED CLÍNICA ONCOLÓGICA LTDA. | Credenciamento de clínica oncológica. | R$ 6.250.000,00 | 10/10/2027 | 338 |
| 2025001828 | FUNESBOM | EXCLUSIVE HEALTH LABORATORIOS MEDICOS LTDA | Credenciamento de clínica oncológica especializada em quimioterapia p… | R$ 6.250.000,00 | 20/03/2027 (PNCP) | 134 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| MGS CLEAN SOLUÇÕES E SERVIÇOS LTDA | 4 | R$ 56.329.659,43 |
| CONSTRUTORA METROPOLITANA S.A. | 1 | R$ 53.865.258,34 |
| BEM ESTAR HOSPITALAR COMÉRCIO DE EQUIPAMENTOS MÉDICOS E MAT… | 2 | R$ 33.486.040,00 |
| ARGAL CONSTRUTORA LTDA | 1 | R$ 30.234.550,17 |
| EMPRESA BRASILEIRA DE CORREIOS E TELEGRAFOS | 1 | R$ 26.248.441,20 |
| NEO CONSULTORIA E ADMINISTRACAO DE BENEFICIOS LTDA | 1 | R$ 20.871.799,96 |
| MARDISA VEÍCULOS LTDA | 1 | R$ 18.920.000,00 |
| FLEET CARDS GESTÃO DE FROTAS LTDA | 1 | R$ 17.865.594,18 |
| ENGE PRAT ENGENHARIA E SERVIÇOS LTDA | 1 | R$ 14.960.938,65 |
| CS BRASIL FROTAS S.A. | 2 | R$ 14.682.825,00 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2023001856 | RESGATECNICA COMERCIO DE EQUIPAMENTOS DE RES… | R$ 8.240.966,30 | R$ 802.139,94 | R$ 7.438.826,36 |
| 2016001642 | HSI SERVIÇOS, IMPORTAÇÃO E EXPORTAÇÃO LTDA | R$ 12.682.655,99 | R$ 7.228.330,26 | R$ 5.454.325,73 |
| 2020002213 | LANG E FILHOS MATERIAL HOSPITALAR LTDA | R$ 8.159.500,00 | R$ 4.679.000,00 | R$ 3.480.500,00 |
| 2023005694 | JBS COMÉRCIO DE UNIFORMES E EQUIPAMENTOS EIR… | R$ 3.224.377,15 | R$ 642.980,50 | R$ 2.581.396,65 |
| 2020002415 | MV GONÇALVES COMERCIO DE MERCADORIAS EIRELI | R$ 2.795.858,64 | R$ 263.996,52 | R$ 2.531.862,12 |
| 2016000428 | VIBRA ENERGIA SA | R$ 10.541.276,08 | R$ 8.247.537,43 | R$ 2.293.738,65 |
| 2022003388 | LIGHT SERVICOS DE ELETRICIDADE SA | R$ 4.570.637,76 | R$ 2.369.669,51 | R$ 2.200.968,25 |
| 2019003104 | KIARGOS SERVIÇOS E FACILITY LTDA. | R$ 7.325.588,44 | R$ 5.200.446,51 | R$ 2.125.141,93 |
| 2020002017 | PMH - PRODUTOS MEDICOS HOSPITALARES LTDA | R$ 2.356.292,00 | R$ 515.600,00 | R$ 1.840.692,00 |
| 2019001959 | B7 EMPREENDIMENTOS LTDA | R$ 18.437.948,75 | R$ 16.822.328,75 | R$ 1.615.620,00 |
| 2016000403 | COMPANHIA ESTADUAL DE AGUAS E ESGOTOS-CEDAE | R$ 2.900.370,36 | R$ 1.338.260,19 | R$ 1.562.110,17 |
| 2016000405 | LIGHT SERVICOS DE ELETRICIDADE SA | R$ 5.709.433,22 | R$ 4.346.787,41 | R$ 1.362.645,81 |
| 2023001868 | INFINITY MULTISERVIÇOS LTDA | R$ 4.321.309,70 | R$ 3.198.412,74 | R$ 1.122.896,96 |
| 2021004521 | GRIDLAB SISTEMAS E SERVICOS LTDA | R$ 4.903.940,92 | R$ 3.913.059,85 | R$ 990.881,07 |
| 2020002328 | AMPLA ENERGIA E SERVIÇOS S/A | R$ 3.313.669,32 | R$ 2.402.195,25 | R$ 911.474,07 |
| 2018001009 | COMPANHIA ESTADUAL DE AGUAS E ESGOTOS-CEDAE | R$ 2.513.556,24 | R$ 1.603.921,20 | R$ 909.635,04 |
| 2022004828 | ENGE PRAT ENGENHARIA E SERVIÇOS LTDA | R$ 11.474.453,55 | R$ 10.614.417,94 | R$ 860.035,61 |
| 2018000994 | AMPLA ENERGIA E SERVIÇOS S/A | R$ 1.524.479,03 | R$ 687.322,62 | R$ 837.156,41 |
| 2019000096 | GRIDLAB SISTEMAS E SERVICOS LTDA | R$ 8.055.092,44 | R$ 7.269.802,96 | R$ 785.289,48 |
| 2019003063 | JR- ADAMVER INDÚSTRIA E COMÉRCIO DE PRODUTOS… | R$ 1.034.941,05 | R$ 344.980,35 | R$ 689.960,70 |

## 11. Unidades incluídas neste dossiê
- FUNESBOM - FUNDO ESPECIAL DO CORPO DE BOMBEIROS
- SEDEC - Sec Est Def Civil e Corpo Bomb Militar

## 12. Conjuntos de dados abertos da secretaria
- Planilha de Funcionários Ativos MGS Clean - JULHO 2026 (CBA IV) (atualizado 2026-11-05): [Planilha de Funcionários Ativos MGS Cle… XML](https://dadosabertos.rj.gov.br/dataset/ff46daec-ac0e-4a4f-a101-9ff5cc77c9e9/resource/6683f2b4-0720-4cfb-8f48-4d6d8dcfa537/download/julho_2026.xlsx)
- Planilha de Funcionários Ativos BRAVO SERV - MAIO 2026 (CBA IV) (atualizado 2026-11-05): [PLANILHA FUNCIONÁRIOS CONTRATO 61.2022 … XML](https://dadosabertos.rj.gov.br/dataset/232b86e3-f400-48ee-881f-260017ae2ec0/resource/3006a730-9c81-43c9-922f-d51818d2e74a/download/planilha-funcionarios-contrato-61.2022-maio-2026.xlsx)
- Planilha MGS Clean Contrato 117/2024 Maio 2026 (atualizado 2026-11-05): [Planilha de Funcionários Ativos MGS Cle… XML](https://dadosabertos.rj.gov.br/dataset/f7a47981-0c4e-467f-b099-fa7c38267597/resource/9bf2f3fb-921d-442a-a314-9d0a83cd66a7/download/ativos-maio-2026.xlsx)
- Planilha de Funcionários Ativos BRAVO SERV - JUNHO 2026 (CBA IV) (atualizado 2026-11-05): [JUNHO.xlsx XML](https://dadosabertos.rj.gov.br/dataset/548ff551-6b6e-4fc7-a818-e0c615bd6e6d/resource/b6a7f5df-4bea-43c0-a9dd-f75d6de7f121/download/junho.xlsx)
- Planilha de Funcionários Ativos BRAVO SERV -JULHO 2026 (CBA IV) (atualizado 2026-11-05): [Planilha de Funcionários Ativos BRAVO S… XML](https://dadosabertos.rj.gov.br/dataset/b546a5c1-d875-43f5-9648-81e8aa3e6ce0/resource/a9f9e0d3-8e4c-4aee-98fc-1d88620abb50/download/planilha-funcionarios-julho-cbmerj-lt06.xlsx)
- Planilha de Funcionários Ativos BRAVO  - Agosto 2026 (CBA IV) (atualizado 2026-11-05): [PLANILHA FUNCIONÁRIOS BRAVO - AGO- CBME… XLS](https://dadosabertos.rj.gov.br/dataset/11de7668-e58c-43ad-af6a-28252a310c44/resource/b5676d96-4737-4955-b35e-3501965caeea/download/planilha-funcionarios-bravo-ago-cbmerj-lt06.xlsx)
- PLANILHA DE FUNCIONÁRIO MGS CLEAN – SETEMBRO/2026 CBMERJ (atualizado 2026-11-05): [MGS_ SETEMBRO_2026.xlsx XLSX](https://dadosabertos.rj.gov.br/dataset/c74311ad-c83b-433a-b768-70f11630c9f7/resource/ee05b5e5-ee7c-4519-bb25-0f75093670fd/download/mgs_-setembro_2026.xlsx)
- Planilha de Funcionários Ativos MGS Clean - AGOSTO 2026 (CBA IV) (atualizado 2026-11-05): [PLANILHA_FUNCIONARIOS_MGS_ATIVOS_LOTE_3… XLS](https://dadosabertos.rj.gov.br/dataset/d52e2f9c-157a-4e1d-9d07-50b401113fc4/resource/f5b73f97-eda5-4ade-9c8a-a9dec4300e71/download/planilha_funcionarios_mgs_ativos_lote_3_ago_2026-1.xlsx)
- Terceirizados contrato 115/2024 (atualizado 2026-10-29): [Efetivo ATIVOS E DEMITIDOS - 6GBM - OUT… XLSX](https://dadosabertos.rj.gov.br/dataset/62406012-7ed4-4b20-a3b8-19f98fbc9f96/resource/dcab23a2-d5c4-4d2f-967e-84e95192a546/download/efetivo-ativos-e-demitidos-outubro-6gbm.xlsx)
- PLANO DE INTEGRIDADE SEDEC/CBMERJ (atualizado 2026-10-28): [Programa de Integridade SEDEC/CBMERJ .pdf](https://dadosabertos.rj.gov.br/dataset/ed08904d-0cdd-4387-be61-d59e0472b18c/resource/bb9df72f-97b1-4ac6-8c32-8e421dce6335/download/plano-de-integridade-3a-edicao-final.pdf)
- Dados da SEDEC (atualizado 2026-10-28): [Dados_Abertos_SEDEC_2026_Monitoramento … .pdf](https://dadosabertos.rj.gov.br/dataset/87b0f79c-4708-45c4-92e6-33985de16f85/resource/a0233c69-8e34-4f5f-9473-2af9ad0c4dcd/download/execucao-de-metas-2026.pdf), [Dados_Abertos_SEDEC_2025.csv CSV](https://dadosabertos.rj.gov.br/dataset/87b0f79c-4708-45c4-92e6-33985de16f85/resource/1095112d-16fc-4e28-b52a-5ce57af7f196/download/dados_abertos_sedec_metas_realizadas-ppa-2025.csv), [Dados_Abertos_SEDEC_2025_Monitoramento … PDF](https://dadosabertos.rj.gov.br/dataset/87b0f79c-4708-45c4-92e6-33985de16f85/resource/5f978051-f71b-4346-a258-26414740c862/download/dados_abertos_sedec_metas_realizadas-ppa-2025.pdf), [Dados_Abertos_SEDEC_2024.csv CSV](https://dadosabertos.rj.gov.br/dataset/87b0f79c-4708-45c4-92e6-33985de16f85/resource/7509f0e7-0eac-4710-bb3c-66615bfe6487/download/dados_abertos_sedec_2024.csv)
- Dados de TIC da SEDEC (atualizado 2026-10-28): [inventario_de_ativos.csv CSV](https://dadosabertos.rj.gov.br/dataset/9c5c6876-0660-4f8a-a585-4b097796e6e7/resource/d73ef6d8-a28a-413b-93e2-d90583c4fd27/download/inventario_de_ativos.csv), [inventario_de_sistemas.csv CSV](https://dadosabertos.rj.gov.br/dataset/9c5c6876-0660-4f8a-a585-4b097796e6e7/resource/e169abe6-35ab-476b-a769-b160239bf879/download/inventario_de_sistemas.csv), [Inventario de Sistemas 2026 CSV](https://dadosabertos.rj.gov.br/dataset/9c5c6876-0660-4f8a-a585-4b097796e6e7/resource/f1202996-592b-4553-99c9-567632862534/download/inventario_de_sistemas-2026.csv), [Inventario de Ativos 2026 CSV](https://dadosabertos.rj.gov.br/dataset/9c5c6876-0660-4f8a-a585-4b097796e6e7/resource/88667c0f-9bb2-47f3-ba65-b04302026c2a/download/inventario_de_ativos-2026.csv)
- TRABALHADORES MGS 125-2024 LOTE 12 - CRD (atualizado 2026-08-27): [COLABORADOES _MGS 125-2024 LOTE 12 CRD … XLSX](https://dadosabertos.rj.gov.br/dataset/d0199d61-9ee3-4323-bb0d-628b6ccfb232/resource/be3aff91-5239-400b-9591-2952022b11c0/download/colaboradores_mgs-2024.xlsx), [Colaboradores_MGS125/2024 - LOTE 12 - C… XLSX](https://dadosabertos.rj.gov.br/dataset/d0199d61-9ee3-4323-bb0d-628b6ccfb232/resource/87ac5867-53ef-40a0-8112-07c7331c396e/download/colaboradores_mgs-2025.xlsx), [Colaboradores_MGS 125-2024 LOTE 12 CRD … XLSX](https://dadosabertos.rj.gov.br/dataset/d0199d61-9ee3-4323-bb0d-628b6ccfb232/resource/b19dc13c-bd6a-4775-b26d-53449343ae80/download/colaboradores_mgs-2026-3.xlsx)
- Dados do CBMERJ (atualizado 2026-08-21): [Efetivo 2024 CSV](https://dadosabertos.rj.gov.br/dataset/d052174c-6ca7-4733-be8f-c80f13a94c4c/resource/8853cc41-08c5-4de1-b960-860d0f3d3c89/download/dados_abertos_assemg_efetivo_2024.csv), [Dados_Abertos_ASSEMG_frota_2024.csv CSV](https://dadosabertos.rj.gov.br/dataset/d052174c-6ca7-4733-be8f-c80f13a94c4c/resource/87a41598-f1fd-47cc-9662-1f86ef635bf7/download/dados_abertos_assemg_frota_2024.csv), [Dados_Abertos_ASSEMG_unidades_2024.csv CSV](https://dadosabertos.rj.gov.br/dataset/d052174c-6ca7-4733-be8f-c80f13a94c4c/resource/333b7cf8-e978-4c82-9260-d9896185fa43/download/dados_abertos_assemg_unidades_2024.csv), [Dados_Abertos_ASSEMG_eventos_2024.csv CSV](https://dadosabertos.rj.gov.br/dataset/d052174c-6ca7-4733-be8f-c80f13a94c4c/resource/cd9fbed6-8653-421c-8b2d-78625fc95b83/download/dados_abertos_assemg_eventos_2024.csv)
- Planilha MGS Clean Contrato 117 2024 - JUNHO 2026 (atualizado 2026-07-28): [Planilha de Funcionários Ativos MGS Cle… XML](https://dadosabertos.rj.gov.br/dataset/8d119940-3fce-46ad-9d64-c9b9efdf1b53/resource/1d9c7949-178f-4b1e-b569-0eec22e1a251/download/ativos_junho-2026.xlsx)
- Terceirizados contrato 154/2024 CBA III (atualizado 2026-07-27): [Terceirizados 22-26 .xlsx](https://dadosabertos.rj.gov.br/dataset/c90a4f71-0e66-463b-b2f3-6cce231e8ec3/resource/04c23a36-232e-462d-8411-da959f57eff1/download/d1gbm23_contrato_154_22_26_limpeza_interior_centro_sul_.xlsx)
- Assistência Social 2025 (atualizado 2026-07-01): [planilha-assistencia-social-2025-atual … XML](https://dadosabertos.rj.gov.br/dataset/189588bd-03e6-4478-87ff-78521e4aaacb/resource/467235c2-6333-46ea-a92e-061036192c6f/download/planilha-assistencia-social-2025-atual-3.xlsx)
- Terceirizados contrato 061/2022 (atualizado 2026-05-13): [Planilha_BravoSERV__Contrato_61.2022.xl… .xslx](https://dadosabertos.rj.gov.br/dataset/30da849d-1ba8-43ea-9925-462991965233/resource/ee641105-cd93-49dd-b42b-c2dd952a2d8a/download/planilha_bravoserv__contrato_61.2022.xlsx)
- Terceirizados Contrato 049/2022 (atualizado 2026-04-30): [CBA2_Colaboradores_Construir_2023.xlsx .xlsx](https://dadosabertos.rj.gov.br/dataset/e98af3ce-4f8d-4f59-aa9e-a4187c612313/resource/a66ba960-58e8-43a5-94dd-7390b9e02e88/download/cba2_colaboradores_construir_2023.xlsx), [CBA2_Colaboradores_Construir_2024.xlsx .xlsx](https://dadosabertos.rj.gov.br/dataset/e98af3ce-4f8d-4f59-aa9e-a4187c612313/resource/f245fd1f-e647-42e3-8cbd-d1d9e807d341/download/cba2_colaboradores_construir_2024.xlsx), [CBA2_Colaboradores_Construir_2025.xlsx .xlsx](https://dadosabertos.rj.gov.br/dataset/e98af3ce-4f8d-4f59-aa9e-a4187c612313/resource/c0c36941-dc41-4f03-a0da-a729e5a77d32/download/cba2_colaboradores_construir_2025.xlsx), [CBA2_Colaboradores_Construir_2026.xlsx .xlsx](https://dadosabertos.rj.gov.br/dataset/e98af3ce-4f8d-4f59-aa9e-a4187c612313/resource/51f28dc0-4197-4aec-ad2b-43b3fa9539d8/download/cba2_colaboradores_construir_2026.xlsx)
- Terceirizados contrato 050/2022 (atualizado 2026-04-30): [QCG__CBMERJ_LOTE_I___JAN2023_MAR2026__1… .xlsx](https://dadosabertos.rj.gov.br/dataset/141dec74-aadf-4645-9f0a-ff85da66bdbb/resource/b64bfee6-8cb8-4247-b037-5e315cfb47f6/download/qcg__cbmerj_lote_i___jan2023_mar2026__1_.xlsx)
- Terceirizados contrato 129/2025 (atualizado 2026-04-30): [Terceirizados .xlsx](https://dadosabertos.rj.gov.br/dataset/392bdb3a-905d-4367-aabb-a3c87202b492/resource/533942b8-4365-458c-a150-6c4c773672c4/download/hcaptec_colaboradores_mensais_2026.xlsx)
- Terceirizados contrato 107/2024 (atualizado 2026-04-30): [Terceirizados 2024-26 .xlsx](https://dadosabertos.rj.gov.br/dataset/597ba429-8922-4033-8cfd-449cb6e52865/resource/524c2626-a2a1-4904-9997-ea3a2f804783/download/supad_planilha_colaboradores_2024_a_2026.xlsx)
- Terceirizados contrato 080/2023 (atualizado 2026-04-30): [DGTI_funcionarios_2023_2026.xlsx .xlsx](https://dadosabertos.rj.gov.br/dataset/1e94c58a-88cd-4838-beaa-4a45b732d76f/resource/1e728b2c-1db6-4207-a7cc-7cb13b3c547d/download/dgti_funcionarios_2023_2026.xlsx)
- Terceirizados contrato 048/2022 Lote 03 (atualizado 2026-04-30): [Terceirizados 2023-26 .xlsx](https://dadosabertos.rj.gov.br/dataset/18ec20dc-74cc-4095-9396-3e4727f94b1d/resource/8fdb7c5d-96a7-4c68-a87e-27afe96ee0ec/download/contrato_48_lote_3.xlsx)
- Terceirizados Contrato 003/2022 (atualizado 2026-04-30): [Relacao_de_funcionarios_da_BRAVO_por_me… .xlsx](https://dadosabertos.rj.gov.br/dataset/f00218c1-d7f6-47f2-b839-0b87810d709a/resource/9197b7bd-c023-4f23-b184-682f553419d3/download/relacao_de_funcionarios_da_bravo_por_mes__2023_.xlsx), [Relacao_de_funcionarios_da_BRAVO_por_me… .xlsx](https://dadosabertos.rj.gov.br/dataset/f00218c1-d7f6-47f2-b839-0b87810d709a/resource/9f802227-1ee2-4307-97b5-078a71fca577/download/relacao_de_funcionarios_da_bravo_por_mes____2024_.xlsx), [Relacao_de_funcionarios_da_BRAVO_por_me… XLSX](https://dadosabertos.rj.gov.br/dataset/f00218c1-d7f6-47f2-b839-0b87810d709a/resource/0ace409d-5a3b-4b0c-a93f-a7a1fb54ca0a/download/relacao_de_funcionarios_da_bravo_por_mes____2025_.xlsx), [Relacao_de_funcionarios_da_BRAVO_por_me… .xlsx](https://dadosabertos.rj.gov.br/dataset/f00218c1-d7f6-47f2-b839-0b87810d709a/resource/6591c62b-6e46-4956-9607-4bddd448ec49/download/relacao_de_funcionarios_da_bravo_por_mes____2026_.xlsx)
- Terceirizados contrato 083/2023 (atualizado 2026-04-30): [HCAP_Planilha_Contrato_083_2023___FXX__… .xlsx](https://dadosabertos.rj.gov.br/dataset/bcd001e3-dfe8-4e63-afac-8a11030b20e6/resource/639e145d-fa79-470a-9261-c76f434a1b70/download/hcap_planilha_contrato_083_2023___fxx___vigilancia_armada.xlsx)
- Terceirizados do contrato 083/2023 ABMDPII (atualizado 2026-04-30): [Terceirizados 2023-26 .xlsx](https://dadosabertos.rj.gov.br/dataset/4ecbb16c-0b26-44b4-a57f-32142689ab99/resource/f85792a2-d169-4fc9-9044-f74f59123757/download/efetivo_conquista_2023_2026.xlsx)
- Terceirizados contrato 154/2024 HCAP (atualizado 2026-04-30): [Terceirizados 24-26 .xlsx](https://dadosabertos.rj.gov.br/dataset/5c771e13-ef2b-476f-a743-0f12e6750100/resource/027c405c-5d0f-4a46-a8ad-8ba93d25589d/download/hcap_colaboradores_mgs_clean_contrato_154_2024.xlsx)
- Área operacional do CBMERJ (atualizado 2025-08-28): [Áreas Operacionais do CBMERJ 2024.kml KML](https://dadosabertos.rj.gov.br/dataset/ae060da5-12fd-42aa-8c46-83ee49a3bb7c/resource/f2fe69bc-0677-428b-ae7b-1138decd3a8c/download/areas-operacionais-do-cbmerj-2024.kml)
- Regularização e Fiscalização (atualizado 2025-08-28): [Dados de Fiscalização e Regularização -… CSV](https://dadosabertos.rj.gov.br/dataset/5c81d45f-0d1a-463d-8b36-f76d531d4a90/resource/b7d97e5e-d7a0-457d-9313-da28a91f9867/download/planilha-dados-aberto-final-dgst-2025.csv)
- Dados de Assistência Social do CBMERJ (atualizado 2025-08-28): [Assistência Social CBMERJ 2024 ODS](https://dadosabertos.rj.gov.br/dataset/62e05344-8fbc-4989-9b7e-12f53b2fd963/resource/55fe6795-b514-418b-9765-dfc8e10b4abf/download/planilha-assistencia-social-2024-atual.ods)
- Ouvidoria geral (atualizado 2025-08-28): [Relatório da Ouvidoria-Geral 2024 DOCX](https://dadosabertos.rj.gov.br/dataset/1341883a-65e7-4851-9863-e5fbe8e1b06b/resource/65eb3697-8b78-4cd0-a007-36e3b3e7611a/download/relatorio-modificado-vf.docx)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 4 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

- A auditoria externa independente dos contratos da Defesa Civil foi exigida pelo governador interino Ricardo Couto como condição para manter Tarciso Salles como secretário e comandante-geral, mas as fontes não informam se a auditoria foi contratada, concluída ou quais foram seus resultados. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml)
- O relatório anual de atividades registra auditoria de contratos de combustíveis e manutenção de postos internos de abastecimento como concluída, e auditoria da gestão do RAS com relatório preliminar encaminhado, sem resultado conclusivo informado. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- Há recomendações do TCE-RJ com status “Implementado” e recomendações SIAUDI ainda “Respondido/em Análise (Pendente)”, conforme o relatório disponibilizado. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- As fontes também registram uma ação civil sobre obras no quartel do 2º GMar ainda submetida ao Judiciário e uma ação penal militar contra um coronel, sem que isso permita concluir por culpa definitiva. [Diário eletrônico do MPF](https://transparencia.mpf.mp.br/conteudo/diarios-e-boletins/diario-eletronico-dmpf-e/2026/DMPF-EXTRAJUDICIAL-2026-06-09.pdf/at_download/file) [G1 — coronel réu por coação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/05/coronel-dos-bombeiros-reu-por-coacao.ghtml)

##### Alertas vermelhos

- **Auditoria exigida, sem comprovação de execução nas fontes:** em 14/07/2026, Ricardo Couto convocou Tarciso Salles e exigiu auditoria externa independente nos contratos da Defesa Civil; o texto a apresenta como condição para sua permanência no cargo, mas não informa escopo, prazo, contratação ou resultados. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml)
- Pendências de controle interno: a tabela registra recomendações dos relatórios SIAUDI 0347 e 606e com o status “Respondido/em Análise (Pendente)”; são 13 recomendações do relatório 0347 e três do 606e. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- **Obras no 2º GMar:** a controvérsia sobre a legalidade das construções no quartel da Praia do Pepê permanece em ação civil pública; não foi concedida liminar para paralisar o empreendimento. [Diário eletrônico do MPF](https://transparencia.mpf.mp.br/conteudo/diarios-e-boletins/diario-eletronico-dmpf-e/2026/DMPF-EXTRAJUDICIAL-2026-06-09.pdf/at_download/file)
- **Ação penal militar contra coronel:** a Justiça Militar aceitou denúncia contra Lauro César Botto Maia por quatro supostos crimes de coação; a denúncia foi aceita para início da ação penal e não equivale a condenação. [G1 — coronel réu por coação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/05/coronel-dos-bombeiros-reu-por-coacao.ghtml)
- **Não confundir investigação do Instituto Rio Metrópole com contratos da SEDEC ou do CBMERJ:** o valor superior a R$ 86 milhões mencionado pelo Ministério Público diz respeito a contratos suspeitos atribuídos ao Instituto Rio Metrópole, não à Defesa Civil ou aos Bombeiros. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml)

##### Contratos e serviços críticos

- O RANAT 2025 informa que o PLANAT 2025 do FUNESBOM incluiu auditoria de contratos de aquisição de combustíveis e manutenção de postos internos de abastecimento, como continuidade de trabalho iniciado em 2024, com status “concluída”. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- O mesmo relatório registra auditoria da Gestão do Regime Adicional de Serviços (RAS) no âmbito da SEDEC e do CBMERJ, incluída em 2025 por determinação do secretário; o relatório preliminar havia sido encaminhado, sem resultado conclusivo informado. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- A notícia sobre a auditoria exigida em julho de 2026 não informa número, empresa, valor, vigência ou prazo dos contratos da Defesa Civil ou dos Bombeiros. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml)
- O RANAT também não informa números, empresas, valores ou vigências dos contratos de combustíveis e manutenção de postos. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- As fontes consultadas não relatam atrasos, risco de interrupção de serviços ou medidas para assegurar a continuidade operacional desses contratos. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml) [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- **TCE-RJ:** o RANAT registra três recomendações vinculadas ao Processo TCERJ 106703-3/2024, todas com status “Implementado”; tratam de adequação de valores pagos, eventual ajuste de pagamentos de GRET se confirmadas irregularidades e correção do envio de dados das folhas de pagamento. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- O relatório não apresenta o teor de acórdãos ou decisões do TCE-RJ, mas registra aquelas recomendações e seus status. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- **SIAUDI:** as recomendações visíveis do relatório 0347 incluem regularização de contas contábeis e de pendências relativas a convênios, consignações, passivos, atividades em andamento e ativos circulantes; todas aparecem como “Respondido/em Análise (Pendente)”. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- **MPRJ e Polícia Civil:** segundo a investigação citada pelo G1, uma organização criminosa teria fraudado licitações e direcionado contratos do Instituto Rio Metrópole; o Ministério Público afirmou que os contratos suspeitos somavam mais de R$ 86 milhões, e David Perini Vermelho, conhecido como Didê, foi preso em 09/07/2026. Essas alegações se referem ao Instituto Rio Metrópole, não a contratos da SEDEC ou do CBMERJ. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml)
- Didê é descrito como sargento bombeiro reformado e recebeu de Tarciso Salles, em 02/12/2024, a medalha Mérito Avante Bombeiro; a fonte não afirma que essa relação com a corporação comprove participação de agentes da SEDEC ou do CBMERJ nos fatos investigados. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml)
- **MPF e Judiciário — 2º GMar:** o MPF ajuizou a Ação Civil Pública nº 5082582-26.2025.4.02.5101 sobre a legalidade das construções no quartel da Praia do Pepê; não houve liminar para paralisar a obra, e a controvérsia continuava submetida ao Judiciário. [Diário eletrônico do MPF](https://transparencia.mpf.mp.br/conteudo/diarios-e-boletins/diario-eletronico-dmpf-e/2026/DMPF-EXTRAJUDICIAL-2026-06-09.pdf/at_download/file)
- No procedimento criminal relacionado às obras do 2º GMar, a investigação da Polícia Federal concluiu pela inexistência de indícios de crime e a 4ª Câmara de Coordenação e Revisão homologou por unanimidade o arquivamento da Notícia de Fato Criminal nº 1.30.001.002642/2026-96; isso não encerrou a ação civil sobre a legalidade das construções. [Diário eletrônico do MPF](https://transparencia.mpf.mp.br/conteudo/diarios-e-boletins/diario-eletronico-dmpf-e/2026/DMPF-EXTRAJUDICIAL-2026-06-09.pdf/at_download/file)
- **Justiça Militar:** o MPRJ denunciou Lauro César Botto Maia por supostamente coagir vítimas e testemunhas em investigação por assédio sexual, e a Justiça Militar aceitou a denúncia por quatro supostos crimes de coação; o coronel negou o crime. [G1 — coronel réu por coação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/05/coronel-dos-bombeiros-reu-por-coacao.ghtml)
- O MPRJ pediu a prisão preventiva de Botto Maia, mas o juiz não analisou o pedido imediatamente e determinou que se observasse o contraditório antes de decidir sobre eventual prisão; o mesmo magistrado restabeleceu punição disciplinar de 15 dias de prisão administrativa. [G1 — coronel réu por coação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/05/coronel-dos-bombeiros-reu-por-coacao.ghtml)

##### Riscos de apagão administrativo

- **Nada encontrado nas fontes consultadas** sobre atrasos de contratos, risco de interrupção de serviços ou medidas de continuidade operacional da SEDEC e do CBMERJ. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml) [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- O RANAT registra pendências contábeis e de regularização em recomendações SIAUDI, mas as fontes não quantificam eventual impacto sobre a operação dos serviços ou sobre a disponibilidade de recursos. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- **Nada encontrado nas fontes consultadas** sobre dívidas totais da SEDEC ou do CBMERJ, plano de transição de governo ou providências específicas para a posse de 01/01/2027. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf) [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml)

##### Fatos recentes

- Em 17/07/2026, o G1 noticiou que o governador interino Ricardo Couto exigiu auditoria externa independente nos contratos da Defesa Civil após a prisão de Didê, ocorrida em 09/07/2026; a reunião com Tarciso Salles havia sido convocada para 14/07/2026. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml)
- O documento do RANAT indica a data de 26/01/2026 e registra a auditoria de contratos de combustíveis e manutenção de postos como concluída, além da auditoria do RAS com relatório preliminar encaminhado. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- Em 09/06/2026, o Diário do MPF publicou a homologação do arquivamento da notícia de fato criminal sobre as obras no quartel do 2º GMar, enquanto a ação civil pública sobre a legalidade da construção permanecia em curso. [Diário eletrônico do MPF](https://transparencia.mpf.mp.br/conteudo/diarios-e-boletins/diario-eletronico-dmpf-e/2026/DMPF-EXTRAJUDICIAL-2026-06-09.pdf/at_download/file)
- Em 05/08/2026, o G1 noticiou que a Justiça Militar aceitou denúncia contra Lauro César Botto Maia por quatro supostos crimes de coação e que havia pedido de prisão preventiva ainda sem decisão. [G1 — coronel réu por coação](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/05/coronel-dos-bombeiros-reu-por-coacao.ghtml)

##### Lacunas da pesquisa

- Solicitar à secretaria o ato de contratação, escopo, cronograma, responsáveis e produtos da auditoria externa exigida em julho de 2026, além de qualquer relatório ou providência já adotada, pois a fonte não informa execução nem resultados. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml)
- Solicitar a relação atualizada dos contratos da SEDEC, do CBMERJ e do FUNESBOM, com objeto, fornecedor, valor, vigência, saldo, execução, pagamentos e riscos de continuidade; as fontes não fornecem esses dados para os contratos mencionados. [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml) [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- Solicitar o relatório final da auditoria do RAS e evidências de encerramento das recomendações SIAUDI 0347 e 606e, cujos status informados são preliminares ou pendentes. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- Solicitar a documentação atualizada do Processo TCERJ 106703-3/2024 e das recomendações registradas como implementadas, para verificar os documentos de comprovação e eventual acompanhamento posterior, pois o RANAT não apresenta o teor de acórdãos ou decisões do Tribunal. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf)
- Solicitar informações sobre o estágio, cronograma, contratos e impacto operacional das obras do 2º GMar, pois a fonte informa a existência da ação civil e a ausência de liminar para paralisar o empreendimento, mas não detalha esses elementos. [Diário eletrônico do MPF](https://transparencia.mpf.mp.br/conteudo/diarios-e-boletins/diario-eletronico-dmpf-e/2026/DMPF-EXTRAJUDICIAL-2026-06-09.pdf/at_download/file)
- Solicitar mapa de dívidas, passivos, atrasos de pagamentos e plano de continuidade dos serviços para a transição, pois nada disso foi encontrado nas fontes consultadas. [RANAT 2025 — SEDEC](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf) [G1 — auditoria na Defesa Civil](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml)

##### Fontes consultadas
1. [Auditoria na Defesa Civil RJ é condição para manter Tarciso ...](https://g1.globo.com/politica/blog/octavio-guedes/post/2026/07/17/governador-interino-exige-auditoria-em-todos-os-contratos-da-defesa-civil-para-manter-coronel-bombeiro-no-cargo-de-secretario-da-pasta.ghtml) — 2026-07-17
2. [ PDF  DIÁRIO DO MINISTÉRIO PÚBLICO FEDERAL ELETRÔNICO](https://transparencia.mpf.mp.br/conteudo/diarios-e-boletins/diario-eletronico-dmpf-e/2026/DMPF-EXTRAJUDICIAL-2026-06-09.pdf/at_download/file) — 2026-11-04
3. [Coronel dos bombeiros investigado por assédio vira réu por ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/05/coronel-dos-bombeiros-reu-por-coacao.ghtml) — 2026-08-05
4. [Relatório Anual de Atividades – RANAT 2025 DADOS GERAIS ...](https://defesacivil.rj.gov.br/images/Transparencia/RANAT_2025_assinado_assinado_1776339615.pdf) — 2026-10-21


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2022010214 (HOSPITAL DAS CLINICAS DA REGIAO DOS LAG…) vence em 06/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2025010754 (SILITEC PRODUTOS HOSPITALARES LTDA) vence em 06/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025008854 (COMITE NACIONAL DO CERIMONIAL E PROTOCO…) vence em 07/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2025009148 (VISUAL INDUSTRIA E COMERCIO DE LONAS EI…) vence em 07/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025009177 (KM2 COMERCIO E REPRESENTAÇÃO) vence em 07/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2025004930 (ANGLOCO LIMITED, R$ 77,0 mi) consta 'Ativo' no SIGA com fim em 11/06/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2022004828 (ENGE PRAT ENGENHARIA E SERVIÇOS LTDA, R$ 29,9 mi) consta 'Ativo' no SIGA com fim em 23/06/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2025007278 (MARDISA VEÍCULOS LTDA, R$ 28,4 mi) consta 'Ativo' no SIGA com fim em 12/09/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2025005015 (HERCULES EQUIPAMENTOS DE PROTECAO LTDA, R$ 26,1 mi) consta 'Ativo' no SIGA com fim em 22/06/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2025000158 (WLM PARTICIPACOES E COMERCIO DE MAQUINA…, R$ 19,4 mi) consta 'Ativo' no SIGA com fim em 15/08/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
