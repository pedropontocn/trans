# Dossiê de transição — Secretaria de Estado de Desenvolvimento Social e Direitos Humanos (SEDSODH)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/sedsodh)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 1025 | R$ 462.310.737,05 |
| Com vigência futura (válidos no SIGA) | 122 | R$ 227.332.422,01 |
| até 30 dias | 12 | R$ 19.344.727,50 |
| até 60 dias | 8 | R$ 8.749.989,54 |
| até 90 dias | 12 | R$ 7.142.566,36 |
| até 180 dias | 30 | R$ 30.577.785,56 |
| vencido no SIGA | 903 | R$ 234.978.315,04 |
| sem data | 1 | R$ 52.568,24 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 147,5 mi / R$ 124,0 mi / R$ 114,5 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2024009601 (LOCASEM SERVIÇOS DE LIMPEZA, MANUTENÇÃO E ALIMENT…) vence em 27/11/2026 — 21 dias — R$ 4.928.880,00. Objeto: Contratação de empresa especializada na prestação de serviço contínuo de prepar…
- Contrato 2024009602 (A.C.F. DA SILVA LTDA) vence em 27/11/2026 — 21 dias — R$ 6.828.287,50. Objeto: Contratação de empresa especializada na prestação de serviço contínuo de prepar…
- Contrato 2025008481 (NUTRIVITA ALIMENTAÇÃO E SERVIÇOS LTDA) vence em 01/12/2026 — 25 dias — R$ 2.679.600,00. Objeto: Contratação de empresa especializada na prestação do serviço contínuo de prepar…
- Contrato 2025009838 (A.C.F. DA SILVA LTDA) vence em 01/12/2026 — 25 dias — R$ 1.026.960,00. Objeto: Contratação de empresa especializada na prestação do serviço contínuo de prepar…
- Mais 8 contratos menores (R$ 3,9 mi) vencem em até 30 dias — ver seção 3.
- 54 contratos (R$ 65,1 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 81 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 42,4 mi); 1 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 822 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 192,5 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Concentração: RESTAURANTE NOVA RODOVIA 2007 LTDA detém 34% do valor vigente (7 contratos).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025009392 | FLXIII | NP TECNOLOGIA E GESTAO DE DADOS LTDA | Contratação de assinatura de ferramenta de pesquisas e comparação de … | R$ 29.900,00 | 12/11/2026 | 6 |
| 2025009423 | FIA | LECARD ADMNISTRADORA DE CARTÕES LTDA | A presente aquisição tem por objetivo viabilizar a concessão de cartõ… | R$ 264.810,00 | 12/11/2026 | 6 |
| 2024009601 | SEDSODH | LOCASEM SERVIÇOS DE LIMPEZA, MANUTENÇÃO E AL… | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 4.928.880,00 | 27/11/2026 (PNCP) | 21 |
| 2024009602 | SEDSODH | A.C.F. DA SILVA LTDA | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 6.828.287,50 | 27/11/2026 (PNCP) | 21 |
| 2025009771 | FLXIII | LECARD ADMNISTRADORA DE CARTÕES LTDA | O presente administrativo destina à contratação de empres para a conf… | R$ 267.150,00 | 29/11/2026 | 23 |
| 2025008481 | SEDSODH | NUTRIVITA ALIMENTAÇÃO E SERVIÇOS LTDA | Contratação de empresa especializada na prestação do serviço contínuo… | R$ 2.679.600,00 | 01/12/2026 (PNCP) | 25 |
| 2025008482 | SEDSODH | A.C.F. DA SILVA LTDA | Contratação de empresa especializada na prestação do serviço contínuo… | R$ 918.720,00 | 01/12/2026 (PNCP) | 25 |
| 2025009836 | SEDSODH | A.C.F. DA SILVA LTDA | Contratação de empresa especializada na prestação do serviço contínuo… | R$ 609.840,00 | 01/12/2026 (PNCP) | 25 |
| 2025009837 | SEDSODH | A.C.F. DA SILVA LTDA | Contratação de empresa especializada na prestação do serviço contínuo… | R$ 319.440,00 | 01/12/2026 | 25 |
| 2025009838 | SEDSODH | A.C.F. DA SILVA LTDA | Contratação de empresa especializada na prestação do serviço contínuo… | R$ 1.026.960,00 | 01/12/2026 (PNCP) | 25 |
| 2025009839 | SEDSODH | A.C.F. DA SILVA LTDA | Contratação de empresa especializada na prestação do serviço contínuo… | R$ 896.940,00 | 01/12/2026 (PNCP) | 25 |
| 2025009840 | SEDSODH | A.C.F. DA SILVA LTDA | Contratação de empresa especializada na prestação do serviço contínuo… | R$ 574.200,00 | 02/12/2026 (PNCP) | 26 |
| 2025010963 | SEDSODH | AMBIENTAL TEC 2006 TECNOLOGIA EM CONTROLE DE… | Contratação de empresa especializada na execução dos SERVIÇOS DE CONT… | R$ 9.000,00 | 11/12/2026 | 35 |
| 2023010267 | SEDSODH | CONTROL 361 TECNOLOGIA E SERVICOS LTDA | contratação de serviços terceiriados de instalação e operação da Cent… | R$ 7.555.200,00 | 15/12/2026 | 39 |
| 2025009788 | FIA | TOP MIX COMÉRCIO E SERVIÇOS LTDA | O presente instrumento tem por objetivo elencar diversos meios de pro… | R$ 203.706,90 | 18/12/2026 | 42 |
| 2025010048 | FIA | GRANA 298 DISTRIBUIDORA DE ALIMENTOS LTDA EPP | Contratação de empresa para aquisição e entrega de Kits Lanche nas un… | R$ 93.585,00 | 18/12/2026 | 42 |
| 2025010805 | SEDSODH | PORTO SEGURO CIA DE SEGUROS GERAIS | Contratação de empresa especializada em seguro contra fogo/incêndio, … | R$ 1.689,01 | 19/12/2026 | 43 |
| 2023010550 | FLXIII | ESPAR ESTACIONAMENTOS LTDA | Locação de 10 de vagas de estacionamento do tipo VAGA LIVRE no imóvel… | R$ 45.600,00 | 20/12/2026 | 44 |
| 2025010564 | SEDSODH | CELOGRAF GRAFICA, EDITORA E PAPEIS LTDA | A contratação de empresa especializada para prestação de serviços grá… | R$ 838.708,63 | 22/12/2026 (PNCP) | 46 |
| 2025010986 | SEDSODH | OLIVEIRA IMUNIZAÇÕES E CONSERVAÇÕES LTDA ME | Contratação de empresa especializada na execução dos serviços de Limp… | R$ 2.500,00 | 26/12/2026 | 50 |
| 2024008499 | SEDSODH | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação de serviço de hospedagem em Servidores Virtuais Privados … | R$ 23.756,52 | 08/01/2027 | 63 |
| 2025010960 | SEDSODH | GROW UP LTDA | A contratação, por meio de Adesão à Ata de Registro de Preços nº 2024… | R$ 1.499.900,00 | 09/01/2027 (PNCP) | 64 |
| 2025010964 | SEDSODH | TD DANTAS SOLUÇÕES LTDA | Tem por objeto a contratação, por meio de Adesão à Ata de Registro de… | R$ 2.146.640,00 | 09/01/2027 (PNCP) | 64 |
| 2025010965 | SEDSODH | INORD GRAFICA & EDITORA LTDA | Tem por objeto a contratação, por meio de Adesão à Ata de Registro de… | R$ 60.625,00 | 09/01/2027 | 64 |
| 2025010966 | SEDSODH | H2A COMERCIO E SERVIÇOS LTDA | Tem por objeto a contratação, por meio de Adesão à Ata de Registro de… | R$ 150.000,00 | 09/01/2027 | 64 |
| 2025010967 | SEDSODH | TD DANTAS SOLUÇÕES LTDA | Tem por objeto a contratação, por meio de Adesão à Ata de Registro de… | R$ 2.373.005,00 | 09/01/2027 (PNCP) | 64 |
| 2025010968 | SEDSODH | TEIXEIRA IMPRESSAO DIGITAL E SOLUCOES GRAFIC… | Tem por objeto a contratação, por meio de Adesão à Ata de Registro de… | R$ 40.029,00 | 13/01/2027 | 68 |
| 2025000771 | SEDSODH | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação de serviços de hospedagem demensageria eletrônica (e-mail) | R$ 40.476,96 | 15/01/2027 | 70 |
| 2026000253 | SEDSODH | PRECISA COMÉRCIO E SOLUÇÕES EM REFRIGERAÇÃO … | serviços de limpeza, manutenção preventiva e corretiva com troca de p… | R$ 23.000,00 | 21/01/2027 | 76 |
| 2026000254 | SEDSODH | FIMPRA SERVIÇOS DE DEDETIZAÇÃO LTDA | Contratação de empresa especializada na execução dos serviços de Limp… | R$ 16.300,00 | 21/01/2027 | 76 |
| 2026000477 | FLXIII | CBD BOLHETE DIGITAL S/A | A contratação da empresa CBD BILHETE DIGITAL S/A, CNPJ n.º 48.707.842… | R$ 660.000,00 | 02/02/2027 (PNCP) | 88 |
| 2025010375 | SEDSODH | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação de serviço de hospedagem em Servidores Virtuais Privados … | R$ 108.833,88 | 03/02/2027 | 89 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025000586 | SEDSODH | INDUSTRIA E COMERCIO DE COLCHOES POLAR LTDA | Aquisição via sistema de registro de preços objetivando o forneciment… | R$ 3.938.750,00 | 06/02/2027 (PNCP) | 92 |
| 2025000587 | SEDSODH | AGUA MINERAL OASIS DA SAUDE LTDA | Aquisição via sistema de registro de preços objetivando o forneciment… | R$ 215.000,00 | 06/02/2027 | 92 |
| 2025000588 | SEDSODH | LOCASEM SERVIÇOS DE LIMPEZA, MANUTENÇÃO E AL… | Aquisição via sistema de registro de preços objetivando o forneciment… | R$ 9.810.750,00 | 06/02/2027 (PNCP) | 92 |
| 2026000493 | FLXIII | AD RIO ASSESSORIA IMOBILIÁRIA LTDA-ME | Despesa com condomínio da Sede da Fundação Leão XIII situada na Rua S… | R$ 206.256,73 | 06/02/2027 | 92 |
| 2026000496 | FLXIII | GLOBALMOB SOLUCOES PARA MOBILIDADE SA | O presente administrativo tem por objeto a contratação da empresa GLO… | R$ 17.022,40 | 06/02/2027 | 92 |
| 2026000502 | FLXIII | RIO + SANEAMENTO BL3 S.A | Prestação de Serviço de abastecimento de água e tratamento de esgoto … | R$ 18.887,76 | 06/02/2027 | 92 |
| 2026000488 | FLXIII | COMPANHIA ESTADUAL DE AGUAS E ESGOTOS-CEDAE | Prestação de serviço de abastecimento de água e tratamento de esgoto … | R$ 1.304,68 | 11/02/2027 | 97 |
| 2026000536 | FLXIII | AMPLA ENERGIA E SERVIÇOS S/A | Despesas com a prestação de serviço de fornecimento de energia elétri… | R$ 40.747,74 | 11/02/2027 | 97 |
| 2026000666 | FLXIII | AGUAS DE NITEROI S/A | Prestação de serviços continuados de abastecimento de água e tratamen… | R$ 516.509,16 | 11/02/2027 (PNCP) | 97 |
| 2026000763 | FLXIII | AGUAS DO RIO 1 SPE S.A | Prestação de serviços de abastecimento de água e tratamento de esgoto… | R$ 164.724,91 | 11/02/2027 | 97 |
| 2026000757 | FLXIII | AMPLA ENERGIA E SERVIÇOS S/A | Prestação de serviço de serviços de fornecimento de energia elétrica … | R$ 126.165,48 | 23/02/2027 | 109 |
| 2026000769 | FLXIII | LIGHT SERVICOS DE ELETRICIDADE SA | O presente processo tem como objetivo a continuidade da prestação de … | R$ 335.970,84 | 23/02/2027 | 109 |
| 2026000823 | FLXIII | LIGHT SERVICOS DE ELETRICIDADE SA | Pagamento de despesas da prestação de serviço de fornecimento de ener… | R$ 149.656,68 | 23/02/2027 | 109 |
| 2026000765 | FIA | IBS FIRE SOLUÇÕES CONTRA INCÊNDIO LTDA | O objeto do presente instrumento consiste na Contratação de empresa e… | R$ 32.700,00 | 25/02/2027 | 111 |
| 2026000500 | FLXIII | SINDICATO DAS EMP DE TRANSP DE PASS DE B MAN… | Contratação da empresa SINDICATO DAS EMPRESAS DE TRANSPORTE DE PASSAG… | R$ 23.366,30 | 03/03/2027 | 117 |
| 2026000748 | FLXIII | LIGHT SERVICOS DE ELETRICIDADE SA | Prestação dos serviços de distribuição de energia elétrica para atend… | R$ 73.171,08 | 03/03/2027 | 117 |
| 2026000770 | FLXIII | F AB ZONA OESTE S A | Prestação de serviço de abastecimento de agua e tratamento de esgoto … | R$ 720.182,64 | 03/03/2027 (PNCP) | 117 |
| 2026001036 | FLXIII | AGUAS DO RIO 4 SPE S.A | Prestação de Serviço de Abastecimento de agua e coleta de esgoto para… | R$ 55.567,68 | 03/03/2027 | 117 |
| 2026001787 | FIA | RIOPAR PARTICIPAÇÕES S/A | Aquisição de vale-transporte para subsidiar as depesas com o transpor… | R$ 563.139,00 | 12/03/2027 (PNCP) | 126 |
| 2026001543 | FIA | SINDICATO DAS EMP DE TRANSP DE PASS DE B MAN… | Aquisição de vale-transporte para subsidiar as depesas com o transpor… | R$ 13.203,20 | 17/03/2027 | 131 |
| 2026001947 | SEDSODH | DEMAFE SOLUCOES INTEGRADAS E GOVERNAMENTAIS … | Aquisição de bens duráveis diversos, incluindo mesas de escritório, c… | R$ 170.999,92 | 01/04/2027 | 146 |
| 2025001501 | SEDSODH | RESTAURANTE NOVA RODOVIA 2007 LTDA | Contratação por menor preço global objetivando a Prestação de Serviço… | R$ 12.697.620,00 | 01/04/2027 (PNCP) | 146 |
| 2026002259 | FIA | COMPANHIA DISTRIBUIDORA DE GAS DO RIO DE JAN… | O presente processo administrativo refere-se à contratação de empresa… | R$ 12.000,00 | 07/04/2027 | 152 |
| 2026002261 | FIA | LIGHT SERVICOS DE ELETRICIDADE SA | O presente processo administrativo refere-se à contratação de empresa… | R$ 176.001,00 | 07/04/2027 | 152 |
| 2026002265 | FIA | AGUAS DE NITEROI S/A | O presente processo administrativo refere-se à contratação de empresa… | R$ 35.000,00 | 07/04/2027 | 152 |
| 2026002267 | FIA | AMPLA ENERGIA E SERVIÇOS S/A | O presente processo administrativo refere-se à contratação de empresa… | R$ 100.000,08 | 07/04/2027 | 152 |
| 2026002274 | FIA | AGUAS DO RIO 1 SPE S.A | O presente processo administrativo refere-se à contratação de empresa… | R$ 40.000,08 | 07/04/2027 | 152 |
| 2026002275 | FIA | AGUAS DO RIO 4 SPE S.A | O presente processo administrativo refere-se à contratação de empresa… | R$ 5.000,00 | 07/04/2027 | 152 |
| 2026002277 | FIA | F AB ZONA OESTE S A | O presente processo administrativo refere-se à contratação de empresa… | R$ 36.000,00 | 07/04/2027 | 152 |
| 2026002539 | FIA | CBD BOLHETE DIGITAL S/A | O objeto do presente termo é a aquisição de vale-transporte em favor … | R$ 282.088,20 | 13/04/2027 | 158 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025006907 | SEDSODH | SANTA COMBA SERVICOS LTDA | Contratação emergencial de empresa para prestação de serviço de acolh… | R$ 13.859.780,00 | 03/10/2026 (PNCP) | -34 |
| 2024006492 | FLXIII | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | A Contratação de Solução para adequação à Lei Geral de Proteção de Da… | R$ 2.646.822,00 | 18/08/2025 | -445 |
| 2023009107 | FIA | CONQUISTA VIGILANCIA E SEGURANCA PATRIMONIAL… | Empresa especialiada para VIGILÂNCIA PATRIMONIAL DESARMADA diurna e n… | R$ 2.584.435,20 | 30/10/2025 | -372 |
| 2021006946 | FIA | CLARO S/A (FILIAL) | Contratação de Serviços de Comunicação de Dados de Longa Distância (W… | R$ 2.289.217,68 | 02/12/2024 | -704 |
| 2025004507 | FLXIII | RESTAURANTE NOVA RODOVIA 2007 LTDA | Contratação de empresa especializada na prestação de serviços continu… | R$ 2.080.880,00 | 08/07/2026 (PNCP) | -121 |
| 2025008009 | SEDSODH | A.C.F. DA SILVA LTDA | Tem por objetivo a contratação de empresa especializada para fornecim… | R$ 2.079.998,35 | 06/10/2026 (PNCP) | -31 |
| 2023009125 | FIA | FXX SEGURANCA E TRANSPORTE DE VALORES LTDA | Consumo de Ata SRP referente a vigilância | R$ 1.973.609,28 | 30/10/2025 | -372 |
| 2025006387 | SEDSODH | DENTECK AR CONDICIONADO LTDA | Contratação de empresa especializada para o fornecimento e instalação… | R$ 1.886.150,00 | 04/09/2026 (PNCP) | -63 |
| 2024010635 | FIA | RIVIERA RIO - MULTISERVICOS EIRELI | Prestação de Serviço de Limpeza Predial e Asseio. | R$ 1.200.000,00 | 25/12/2025 | -316 |
| 2025008950 | SEDSODH | BORMANA COMERCIO DE AUTOPEÇAS LTDA | Contratação, por meio de Pregão Eletrônico, de empresa especializada … | R$ 999.689,21 | 02/05/2026 (PNCP) | -188 |
| 2025006863 | FIA | LOCASEM SERVIÇOS DE LIMPEZA, MANUTENÇÃO E AL… | Aquisição de Gêneros Alimentícios para o CICAPD  Professor Almir Rib… | R$ 951.687,14 | 03/09/2026 (PNCP) | -64 |
| 2025005650 | SEDSODH | BELABRU COMERCIO E REPRESENTACOES LTDA | A aquisição de (02) dois veículos do tipo VAN, para promoção da inclu… | R$ 936.000,00 | 13/08/2026 (PNCP) | -85 |
| 2023007364 | FIA | BRS SUPRIMENTOS CORPORATIVOS S/A | Almoxarifado Virtual | R$ 902.978,54 | 15/09/2026 | -52 |
| 2022008202 | FLXIII | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | Contratação de empresa especialiada para a prestação de serviços de O… | R$ 666.864,00 | 24/10/2026 | -13 |
| 2025005610 | FLXIII | CBD BOLHETE DIGITAL S/A | a contratação da empresa CBD BILHETE DIGITAL S/A, CNPJ n.º 48.707.842… | R$ 620.400,00 | 28/07/2026 (PNCP) | -101 |
| 2025002247 | SEDSODH | AMAZONIA BR SERVICOS ALIMENTACAO LTDA | O presente Termo de Referência tem como objetivo a licitação para a c… | R$ 584.011,50 | 24/04/2026 (PNCP) | -196 |
| 2023010348 | FLXIII | JUDKAL SERVIÇOS DE TRANSPORTE E ALIMENTAÇÃO … | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇOS DE TRAN… | R$ 565.200,00 | 18/12/2025 | -323 |
| 2023004436 | FLXIII | CS BRASIL FROTAS S.A. | Adesão à ata de registro de preço interna para locação de veículos | R$ 475.792,20 | 19/08/2026 | -79 |
| 2023010345 | FLXIII | B G CRESPO PRODUCOES LOGISTICAS EIRELI | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇOS DE TRAN… | R$ 467.260,92 | 18/03/2026 | -233 |
| 2023009327 | FLXIII | GLOBAL 233 COMERCIAL LTDA | Contratação de empresa especialiada para fornecimento montagem e inst… | R$ 431.471,00 | 07/11/2024 | -729 |
| 2023007281 | FLXIII | HADDAD RENT A CAR LOCADORA LTDA | Identificase a presente demanda como contratação do serviço de locaçã… | R$ 388.800,00 | 13/09/2026 | -54 |
| 2023003457 | FIA | CS BRASIL FROTAS S.A. | Locação de veículos | R$ 353.844,00 | 14/05/2026 | -176 |
| 2024009953 | SEDSODH | RC CARD SOLUCOES EM PAGAMENTOS LTDA | contratação de empresa especializada na prestação de serviços de impl… | R$ 314.400,00 | 07/12/2025 | -334 |
| 2024009999 | FIA | RC CARD SOLUCOES EM PAGAMENTOS LTDA | Contratação de prestação de serviços de emissão e entrega de cartões … | R$ 302.400,00 | 07/01/2026 | -303 |
| 2025001554 | SEDSODH | SOLIDEZ SEGURANÇA E VIGILÂNCIA LTDA | Contratação emergencial de empresa especializada na prestação de serv… | R$ 290.151,72 | 01/04/2026 | -219 |
| 2025002351 | FIA | FUNDAÇÃO SANTA CABRINI | Contratação de 07 (sete) profissionais para a prestação de serviços a… | R$ 211.688,40 | 21/10/2026 | -16 |
| 2024006258 | FIA | QUANTUM13 SOLUCOES EM TECNOLOGIA LTDA | Aquisição de Switch para Unidades FIA/RJ. | R$ 192.011,19 | 06/08/2025 | -457 |
| 2022009004 | FIA | CS BRASIL FROTAS S.A. | Serviço de locação de veículos HATCH | R$ 186.799,80 | 10/05/2025 | -545 |
| 2022001504 | FLXIII | CLARO S/A (FILIAL) | Trata o presente administrativo de contratação de 03 links Infovia 3.… | R$ 169.704,00 | 10/03/2025 | -606 |
| 2025009948 | FLXIII | MAIS MOBI SERVICOS LTDA | Inclusão no sistema. | R$ 156.000,00 | 08/02/2026 | -271 |

_Registros mais antigos (provável falta de baixa no SIGA): 822, R$ 192,5 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025003260 | SEDSODH | RESTAURANTE NOVA RODOVIA 2007 LTDA | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 17.995.607,52 | 10/02/2028 | 461 |
| 2025005222 | SEDSODH | A.C.F. DA SILVA LTDA | rata-se do serviço contínuo de distribuição diária de refeições (café… | R$ 14.997.850,00 | 23/09/2027 | 321 |
| 2024009641 | SEDSODH | A.C.F. DA SILVA LTDA | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 14.028.933,60 | 05/08/2027 | 272 |
| 2026000744 | SEDSODH | RESTAURANTE NOVA RODOVIA 2007 LTDA | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 13.099.850,00 | 20/02/2028 | 471 |
| 2025001501 | SEDSODH | RESTAURANTE NOVA RODOVIA 2007 LTDA | Contratação por menor preço global objetivando a Prestação de Serviço… | R$ 12.697.620,00 | 01/04/2027 (PNCP) | 146 |
| 2026000432 | SEDSODH | A.C.F. DA SILVA LTDA | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 11.493.850,00 | 05/02/2028 | 456 |
| 2026000430 | SEDSODH | RESTAURANTE NOVA RODOVIA 2007 LTDA | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 10.497.400,00 | 20/02/2028 | 471 |
| 2025000588 | SEDSODH | LOCASEM SERVIÇOS DE LIMPEZA, MANUTENÇÃO E AL… | Aquisição via sistema de registro de preços objetivando o forneciment… | R$ 9.810.750,00 | 06/02/2027 (PNCP) | 92 |
| 2025006795 | SEDSODH | LOCASEM SERVIÇOS DE LIMPEZA, MANUTENÇÃO E AL… | Prestação de serviços continuada de preparo, fornecimento e distribui… | R$ 8.928.480,00 | 01/09/2027 | 299 |
| 2025010727 | SEDSODH | RESTAURANTE NOVA RODOVIA 2007 LTDA | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 8.899.440,00 | 19/12/2027 | 408 |
| 2026000478 | SEDSODH | RESTAURANTE NOVA RODOVIA 2007 LTDA | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 7.891.300,00 | 09/02/2028 | 460 |
| 2026000485 | SEDSODH | A.C.F. DA SILVA LTDA | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 7.566.450,00 | 20/02/2028 | 471 |
| 2023010267 | SEDSODH | CONTROL 361 TECNOLOGIA E SERVICOS LTDA | contratação de serviços terceiriados de instalação e operação da Cent… | R$ 7.555.200,00 | 15/12/2026 | 39 |
| 2025002039 | SEDSODH | FUNDAÇÃO SANTA CABRINI | Contratação de mão de obra de 50 (cinquenta) apenados da Fundação San… | R$ 7.450.536,00 | 29/04/2030 | 1270 |
| 2024009602 | SEDSODH | A.C.F. DA SILVA LTDA | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 6.828.287,50 | 27/11/2026 (PNCP) | 21 |
| 2026005688 | FLXIII | RESTAURANTE NOVA RODOVIA 2007 LTDA | Contratação de empresa especializada na prestação de serviços continu… | R$ 6.622.367,52 | 17/07/2027 | 253 |
| 2025006033 | SEDSODH | MEAT NIT COMERCIO E SERVIÇOS LTDA (SMART SER… | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 5.049.775,00 | 17/08/2027 | 284 |
| 2024009601 | SEDSODH | LOCASEM SERVIÇOS DE LIMPEZA, MANUTENÇÃO E AL… | Contratação de empresa especializada na prestação de serviço contínuo… | R$ 4.928.880,00 | 27/11/2026 (PNCP) | 21 |
| 2026000973 | SEDSODH | GLOBAL - INCORPORAÇÃO E ADMINISTRAÇÃO DE IMÓ… | A locação do 4º (quarto) e 10º (décimo) pavimento do Edifício Viscond… | R$ 4.042.984,80 | 20/02/2031 | 1567 |
| 2023007967 | FLXIII | GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | Contratação de empresa especialiada na prestação de serviços de imple… | R$ 3.963.960,00 | 04/10/2027 | 332 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| RESTAURANTE NOVA RODOVIA 2007 LTDA | 7 | R$ 77.703.585,04 |
| A.C.F. DA SILVA LTDA | 11 | R$ 59.261.471,10 |
| LOCASEM SERVIÇOS DE LIMPEZA, MANUTENÇÃO E ALIMENTAÇÃO - EPP | 3 | R$ 23.668.110,00 |
| CONTROL 361 TECNOLOGIA E SERVICOS LTDA | 1 | R$ 7.555.200,00 |
| FUNDAÇÃO SANTA CABRINI | 1 | R$ 7.450.536,00 |
| MEAT NIT COMERCIO E SERVIÇOS LTDA (SMART SERVICE) | 1 | R$ 5.049.775,00 |
| AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA LTDA | 8 | R$ 5.036.958,36 |
| TD DANTAS SOLUÇÕES LTDA | 2 | R$ 4.519.645,00 |
| GLOBAL - INCORPORAÇÃO E ADMINISTRAÇÃO DE IMÓVEIS LTDA. | 1 | R$ 4.042.984,80 |
| GREEN CARD S/A REFEIÇÕES COMERCIO E SERVIÇOS | 1 | R$ 3.963.960,00 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2020002130 | CESTA DE ALIMENTOS BRASIL LTDA | R$ 27.079.488,00 | R$ 20.599.488,00 | R$ 6.480.000,00 |
| 2020002012 | INSTITUTO NACIONAL DE ASSISTÊNCIA, TRABALHO,… | R$ 21.932.640,45 | R$ 20.638.854,91 | R$ 1.293.785,54 |
| 2017004658 | UPPER CONSTRUÇÃO E SERVIÇOS EIRELI | R$ 11.195.374,67 | R$ 10.733.866,77 | R$ 461.507,90 |
| 2017002441 | FUNDAÇÃO SANTA CABRINI | R$ 390.901,36 | R$ 0,00 | R$ 390.901,36 |
| 2022000714 | RIOPAR PARTICIPAÇÕES S/A | R$ 396.108,18 | R$ 159.448,84 | R$ 236.659,34 |
| 2018000162 | SERVLOG RIO CONSULTORIA E ASSESSORIA EMPRESA… | R$ 19.341.245,49 | R$ 19.188.091,10 | R$ 153.154,39 |
| 2022006148 | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | R$ 241.132,00 | R$ 106.260,00 | R$ 134.872,00 |
| 2021002675 | EMPRESA BRASILEIRA DE ENGENHARIA E COMÉRCIO … | R$ 350.521,14 | R$ 256.531,01 | R$ 93.990,13 |
| 2021006988 | DADY ILHA SOLUCOES INTEGRADAS LTDA | R$ 257.917,48 | R$ 192.877,48 | R$ 65.040,00 |
| 2022002561 | LIGHT SERVICOS DE ELETRICIDADE SA | R$ 102.716,47 | R$ 37.724,97 | R$ 64.991,50 |
| 2017004771 | GRANA 298 DISTRIBUIDORA DE ALIMENTOS LTDA EPP | R$ 327.860,21 | R$ 263.780,71 | R$ 64.079,50 |
| 2018000846 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 66.070,20 | R$ 5.388,24 | R$ 60.681,96 |
| 2019006154 | B7 EMPREENDIMENTOS LTDA | R$ 1.029.920,04 | R$ 972.702,26 | R$ 57.217,78 |
| 2016004379 | MADRIMED PRODUTOS MEDICOS LTDA | R$ 54.557,00 | R$ 0,00 | R$ 54.557,00 |
| 2016005002 | FERNANDO UNIFORMES EIRELI-EPP | R$ 50.755,00 | R$ 0,00 | R$ 50.755,00 |
| 2022002688 | AMPLA ENERGIA E SERVIÇOS S/A | R$ 50.657,27 | R$ 0,00 | R$ 50.657,27 |
| 2016000587 | COMERCIAL MILANO BRASIL LTDA | R$ 90.671,86 | R$ 40.823,22 | R$ 49.848,64 |
| 2017003788 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 45.870,86 | R$ 0,00 | R$ 45.870,86 |
| 2023004319 | NUTRIPLAN COMERCIAL LTDA | R$ 54.700,00 | R$ 10.750,00 | R$ 43.950,00 |
| 2018005995 | ELIAS ALVES DE OLIVEIRA LICITAÇÕES EPP | R$ 41.146,56 | R$ 0,00 | R$ 41.146,56 |

## 11. Unidades incluídas neste dossiê
- FIA - FUNDAÇÃO PARA A INFÂNCIA E ADOLESCÊNCIA
- FLXIII - FUNDAÇÃO LEÃO XIII
- SEASDH - SECRETARIA DE ESTAD ASSIST SOC E DIR HUMANOS
- SEDHMI - SEC EST DIR HUM E POL PARA MUL E IDOSOS
- SEDSODH - SEC ESTADO DESEN SOCIAL E DE DIR HUM
- SEPREDEQ - SEC EST DE PREVENÇÃO A DEP QUÍMICA

## 12. Conjuntos de dados abertos da secretaria
- Nenhum conjunto encontrado no portal.

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 5 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

- As fontes apontam dois temas prioritários para a SEDSODH: falhas em contratações emergenciais de alimentação para o Abrigo Cristo Redentor e instabilidade financeira e operacional do Programa Rio Sem LGBTIfobia. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/) [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao)
- O TCE-RJ multou três ex-gestores por irregularidades ligadas à contratação de alimentação, que incluíram sucessivas dispensas emergenciais por mais de 15 meses. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- No Rio Sem LGBTIfobia, trabalhadores denunciaram atrasos salariais e risco de interrupção dos serviços; o governo anunciou a regularização dos pagamentos e houve publicação de uma liberação orçamentária, mas as fontes não confirmam que os valores tenham sido efetivamente pagos. [Trabalhadores protestam por salários](https://oglobo.globo.com/rio/noticia/2026/07/02/sem-salarios-trabalhadores-do-rio-sem-lgbtfobia-protestam-no-centro.ghtml) [Governo promete pagar atrasados](https://www.poder360.com.br/poder-gente/governo-do-rj-promete-pagar-atrasados-do-programa-rio-sem-lgbtifobia/) [Assembleia e liberação de recursos](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html)
- A Secretaria informou que o modelo de contratação e gestão do programa está em revisão com a PGE, enquanto trabalhadores cobravam definições sobre sua continuidade e forma de execução. [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao) [Assembleia e liberação de recursos](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html)

##### Alertas vermelhos

- **Alimentação do Abrigo Cristo Redentor:** o TCE-RJ apontou demora injustificada na licitação, dispensas sucessivas, ausência de orçamento detalhado e falta de justificativa de preços; o processo classificou o cenário como “emergência fabricada”. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- **Continuidade do Rio Sem LGBTIfobia:** trabalhadores relataram atrasos de salários referentes a abril, maio e junho de 2026, estado de greve e risco de paralisação; em julho, informaram que a manutenção dos atendimentos estava se tornando insustentável. [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao) [Governo promete pagar atrasados](https://www.poder360.com.br/poder-gente/governo-do-rj-promete-pagar-atrasados-do-programa-rio-sem-lgbtifobia/)
- **Pagamentos sem confirmação de conclusão:** em 11 de julho, o governo disse que regularizaria os salários “em breve”; em 3 de julho, foi publicada descentralização orçamentária de R$ 3,35 milhões, com previsão de pagamento até 08/07/2026, mas as fontes consultadas não confirmam a quitação. [Governo promete pagar atrasados](https://www.poder360.com.br/poder-gente/governo-do-rj-promete-pagar-atrasados-do-programa-rio-sem-lgbtifobia/) [Assembleia e liberação de recursos](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html)
- **Incerteza sobre a gestão do programa:** a SEDSODH informou que revia o modelo de contratação e gestão com a PGE, enquanto trabalhadores questionavam se a execução permaneceria na UERJ, passaria a uma organização social ou seria internalizada na Secretaria. [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao) [Assembleia e liberação de recursos](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html)

##### Contratos e serviços críticos

- O Contrato nº 18/2023 teve origem em dispensa de licitação formalizada pelo então subsecretário de Governança e Gestão, José Carlos Costa Simonin, para serviços de alimentação do Centro de Promoção Social Abrigo Cristo Redentor, destinado ao atendimento de até 300 idosos. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- Segundo a decisão do TCE-RJ, as contratações emergenciais de alimentação se repetiram por mais de 15 meses sem conclusão do processo licitatório iniciado anteriormente. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- As fontes não informam a empresa contratada, o valor ou a vigência do Contrato nº 18/2023. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- O Rio Sem LGBTIfobia é executado pela SEDSODH em parceria com a UERJ; segundo as fontes, mantém 24 equipamentos ou centros de atendimento no estado, com serviços de acolhimento, orientação jurídica, atendimento psicossocial e encaminhamentos. [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao) [Trabalhadores protestam por salários](https://oglobo.globo.com/rio/noticia/2026/07/02/sem-salarios-trabalhadores-do-rio-sem-lgbtfobia-protestam-no-centro.ghtml)
- Trabalhadores relataram que mais de 400 colaboradores estavam sem receber salários e que os repasses do convênio estavam atrasados havia três meses; essas informações foram atribuídas aos trabalhadores, não apresentadas como auditoria independente. [Trabalhadores protestam por salários](https://oglobo.globo.com/rio/noticia/2026/07/02/sem-salarios-trabalhadores-do-rio-sem-lgbtfobia-protestam-no-centro.ghtml)
- Em 03/07/2026, resolução conjunta publicada no Diário Oficial descentralizou R$ 3,35 milhões para a UERJ; a notícia apresentou o valor como destinado aos salários atrasados e registrou previsão de pagamento até 08/07/2026, sem confirmação posterior de quitação nas fontes consultadas. [Assembleia e liberação de recursos](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html)
- As fontes não apresentam números, empresas, valores ou vigências dos contratos do Rio Sem LGBTIfobia; uma delas menciona convênio, sem detalhar esses dados. [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao) [Trabalhadores protestam por salários](https://oglobo.globo.com/rio/noticia/2026/07/02/sem-salarios-trabalhadores-do-rio-sem-lgbtfobia-protestam-no-centro.ghtml)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- O TCE-RJ aplicou multa de 2.500 UFIR-RJ a José Carlos Costa Simonin, equivalentes a cerca de R$ 12,4 mil, por falhas na formalização da dispensa que originou o Contrato nº 18/2023; o relator apontou erro grosseiro. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- Júlio Cesar Saraiva e Matheus Quintal de Sousa Ribeiro receberam multas de 2.000 UFIR-RJ cada, cerca de R$ 9,9 mil, por morosidade na condução dos processos licitatórios; segundo a fonte, ambos não apresentaram defesa e foram julgados à revelia. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- Os três ex-gestores tinham 15 dias para recolher as multas ao FEM/TCE-RJ; a decisão previu protesto extrajudicial antes do encaminhamento do débito para inscrição em dívida ativa, mas as fontes não informam se houve pagamento ou protesto. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- O TCE-RJ acolheu as defesas de Rosangela de Souza Gomes, Bruno Felgueira Dauaire e Fernanda Titonel de Souza e afastou a responsabilidade de Cristiane Lobo Lamarão Silva por sua atuação ter ocorrido antes do período dos fatos sancionados. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- Nada encontrado nas fontes consultadas sobre ações do MPRJ relacionadas aos casos ou sobre ações judiciais; a menção ao Ministério Público em uma fonte é apenas como parte da rede que recebe suporte técnico do programa. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/) [Governo promete pagar atrasados](https://www.poder360.com.br/poder-gente/governo-do-rj-promete-pagar-atrasados-do-programa-rio-sem-lgbtifobia/)

##### Riscos de apagão administrativo

- A repetição de dispensas emergenciais por mais de 15 meses, sem conclusão da licitação, foi apontada como falha de planejamento no serviço de alimentação do Abrigo; a fonte não menciona risco de descontinuidade contratual nem ameaça concreta de interrupção do serviço. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- No Rio Sem LGBTIfobia, trabalhadores denunciaram risco de interrupção dos serviços e relataram que mantiveram plantões e pagaram despesas do próprio bolso para evitar que o atendimento fosse interrompido. [Governo promete pagar atrasados](https://www.poder360.com.br/poder-gente/governo-do-rj-promete-pagar-atrasados-do-programa-rio-sem-lgbtifobia/) [Trabalhadores protestam por salários](https://oglobo.globo.com/rio/noticia/2026/07/02/sem-salarios-trabalhadores-do-rio-sem-lgbtfobia-protestam-no-centro.ghtml)
- A suspensão das admissões de candidatos aprovados em processo seletivo de 2025 foi relatada pelos trabalhadores; a UERJ informou que a efetivação dependia de disponibilidade orçamentária e de repasses do governo estadual. [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao)
- A revisão do modelo de gestão, sem definição divulgada sobre permanência na UERJ, transferência a uma organização social ou internalização na Secretaria, cria uma pendência de governança para a continuidade do programa. [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao) [Assembleia e liberação de recursos](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html)

##### Fatos recentes

- Em 02/07/2026, a SEDSODH informou que o modelo de contratação e gestão do Rio Sem LGBTIfobia estava em revisão e que trabalhava com a PGE para definir medidas de continuidade e regularização de pendências. [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao)
- Em 03/07/2026, foi publicada resolução conjunta com descentralização de R$ 3,35 milhões à UERJ, e trabalhadores marcaram assembleia para 06/07/2026 para avaliar a manutenção do estado de greve e possível entrada em greve; a fonte não afirma que os serviços tenham sido interrompidos. [Assembleia e liberação de recursos](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html)
- Em 07/07/2026, durante audiência pública na Alerj, o governo reiterou que regularizaria “em breve” os salários atrasados, sem informar data específica ou valor total devido. [Governo promete pagar atrasados](https://www.poder360.com.br/poder-gente/governo-do-rj-promete-pagar-atrasados-do-programa-rio-sem-lgbtifobia/)
- Em 15/08/2026, foi publicada a notícia sobre as multas do TCE-RJ relacionadas à contratação emergencial de alimentação do Abrigo Cristo Redentor. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- A fonte sobre o processo do Abrigo informa que Simonin foi exonerado pelo governo estadual em março de 2026, após repercussão de caso de estupro coletivo investigado em Copacabana; a fonte associa a investigação ao filho dele entre os investigados, sem atribuir a Simonin participação no crime. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)

- Solicitar cópia integral do processo do Contrato nº 18/2023, identificação da contratada, valor, vigência, pagamentos, aditivos, licitação subsequente e situação atual do serviço, pois esses dados não constam da fonte consultada. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- Solicitar comprovantes de recolhimento das multas do TCE-RJ, informação sobre eventual protesto ou inscrição em dívida ativa e atualização do cumprimento da decisão, pois a fonte não informa o desfecho após o prazo de 15 dias. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/)
- Solicitar posição atualizada sobre salários atrasados, pagamentos realizados com os R$ 3,35 milhões, obrigações ainda pendentes e repasses à UERJ, pois as fontes registram promessas e previsão de pagamento, mas não confirmam quitação. [Governo promete pagar atrasados](https://www.poder360.com.br/poder-gente/governo-do-rj-promete-pagar-atrasados-do-programa-rio-sem-lgbtifobia/) [Assembleia e liberação de recursos](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html)
- Solicitar contratos, convênios, valores, prazos, prestações de contas e plano de continuidade do Rio Sem LGBTIfobia, além da decisão final sobre o modelo de execução, pois as fontes não detalham esses instrumentos nem informam a conclusão da revisão anunciada. [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao) [Trabalhadores protestam por salários](https://oglobo.globo.com/rio/noticia/2026/07/02/sem-salarios-trabalhadores-do-rio-sem-lgbtfobia-protestam-no-centro.ghtml)
- Solicitar atualização sobre a retomada das admissões suspensas do processo seletivo de 2025 e sobre o quadro de equipes e os atendimentos em cada um dos 24 equipamentos. As fontes apresentam dados agregados de profissionais e atendimentos, mas não informam se as contratações foram retomadas nem trazem atualização posterior ou detalhamento por equipamento. [Rio Sem LGBTIfobia: modelo em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao) [Assembleia e liberação de recursos](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html)
- Nada encontrado nas fontes consultadas sobre procedimentos do MPRJ ou ações judiciais relacionadas aos temas; solicitar à Secretaria informação sobre eventuais procedimentos, recomendações, processos e prazos em curso. [Emergência fabricada no Abrigo Cristo Redentor](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/) [Governo promete pagar atrasados](https://www.poder360.com.br/poder-gente/governo-do-rj-promete-pagar-atrasados-do-programa-rio-sem-lgbtifobia/)

##### Fontes consultadas
1. [‘Emergência fabricada’: ex-gestores da Assistência Social são multados pelo TCE-RJ por falhas em contrato de a](https://temporealrj.com/multa-tce-ex-gestores-assistencia-social/) — 2026-08-15
2. [Rio Sem LGBTIfobia: modelo de contrato e gestão está em revisão](https://agenciabrasil.ebc.com.br/direitos-humanos/noticia/2026-07/rio-sem-lgbtifobia-modelo-de-contrato-e-gestao-esta-em-revisao) — 2026-07-02
3. [Governo do RJ promete pagar atrasados do programa Rio Sem LGBTIfobia](https://www.poder360.com.br/poder-gente/governo-do-rj-promete-pagar-atrasados-do-programa-rio-sem-lgbtifobia/) — 2026-07-11
4. [Sem salários, trabalhadores do Rio Sem LGBTfobia ...](https://oglobo.globo.com/rio/noticia/2026/07/02/sem-salarios-trabalhadores-do-rio-sem-lgbtfobia-protestam-no-centro.ghtml) — 2026-07-02
5. [Rio Sem LGBTIfobia: Trabalhadores marcam assembleia para avaliar greve  Rio de Janeiro](https://odia.ig.com.br/rio-de-janeiro/2026/07/7273020-rio-sem-lgbtifobia-trabalhadores-marcam-assembleia-para-avaliar-greve.html) — 2026-07-03


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2025009392 (NP TECNOLOGIA E GESTAO DE DADOS LTDA) vence em 12/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2025009423 (LECARD ADMNISTRADORA DE CARTÕES LTDA) vence em 12/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2024009601 (LOCASEM SERVIÇOS DE LIMPEZA, MANUTENÇÃO…) vence em 27/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2024009602 (A.C.F. DA SILVA LTDA) vence em 27/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025009771 (LECARD ADMNISTRADORA DE CARTÕES LTDA) vence em 29/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2025006907 (SANTA COMBA SERVICOS LTDA, R$ 13,9 mi) consta 'Ativo' no SIGA com fim em 03/10/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2024006492 (EVERY TI TECNOLOGIA & INOVAÇÃO LTDA, R$ 2,6 mi) consta 'Ativo' no SIGA com fim em 18/08/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2023009107 (CONQUISTA VIGILANCIA E SEGURANCA PATRIM…, R$ 2,6 mi) consta 'Ativo' no SIGA com fim em 30/10/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2021006946 (CLARO S/A (FILIAL), R$ 2,3 mi) consta 'Ativo' no SIGA com fim em 02/12/2024: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2025004507 (RESTAURANTE NOVA RODOVIA 2007 LTDA, R$ 2,1 mi) consta 'Ativo' no SIGA com fim em 08/07/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
