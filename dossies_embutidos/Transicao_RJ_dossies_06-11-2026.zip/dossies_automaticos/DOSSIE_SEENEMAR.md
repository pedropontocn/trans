# Dossiê de transição — Secretaria de Estado de Energia e Economia do Mar (SEENEMAR)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/seenemar)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 418 | R$ 97.351.300,38 |
| Com vigência futura (válidos no SIGA) | 26 | R$ 12.998.795,79 |
| até 30 dias | 2 | R$ 4.691.395,60 |
| até 60 dias | 7 | R$ 1.436.463,19 |
| até 90 dias | 0 | R$ 0,00 |
| até 180 dias | 2 | R$ 2.252.714,56 |
| vencido no SIGA | 392 | R$ 84.352.504,58 |
| sem data | 2 | R$ 26.440,00 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 4,0 mi / R$ 2,1 mi / R$ 1,8 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2026004063 (METTA INDUSTRIA EM SOLUÇÕES AMBIENTAIS LTDA) vence em 27/11/2026 — 21 dias — R$ 4.449.000,00. Objeto: Contratação de empresa especializada, para o serviço de desmantelamento e desco…
- Mais 1 contratos menores (R$ 0,2 mi) vencem em até 30 dias — ver seção 3.
- 11 contratos (R$ 8,4 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 51 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 68,6 mi); 2 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 341 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 15,8 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Concentração: METTA INDUSTRIA EM SOLUÇÕES AMBIENTAIS LTDA detém 34% do valor vigente (1 contratos).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025008388 | SEENEMAR | AMAZONIA BR SERVICOS ALIMENTACAO LTDA | Contratação de empresa especializada em serviços de alimentação, sob … | R$ 242.395,60 | 26/11/2026 | 20 |
| 2026004063 | SEENEMAR | METTA INDUSTRIA EM SOLUÇÕES AMBIENTAIS LTDA | Contratação de empresa especializada, para o serviço de desmantelamen… | R$ 4.449.000,00 | 27/11/2026 (PNCP) | 21 |
| 2025009297 | SEENEMAR | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada para a prestação de serviços de … | R$ 76.050,00 | 10/12/2026 | 34 |
| 2023010644 | DRM | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Contratação de serviços de fornecimento e aquisição de certificado di… | R$ 2.350,00 | 18/12/2026 | 42 |
| 2025005638 | DRM | AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA L… | A presente contratação centralizada tem como objeto a prestação dos s… | R$ 33.259,18 | 22/12/2026 | 46 |
| 2025005639 | DRM | AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA L… | A presente contratação centralizada tem como objeto a prestação dos s… | R$ 14.583,28 | 22/12/2026 | 46 |
| 2025005640 | DRM | AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA L… | A presente contratação centralizada tem como objeto a prestação dos s… | R$ 19.933,55 | 22/12/2026 | 46 |
| 2025010823 | DRM | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | empresa especializada na prestação de serviços de emissão e entrega d… | R$ 1.279.803,20 | 22/12/2026 (PNCP) | 46 |
| 2023010478 | DRM | CS BRASIL FROTAS S.A. | Tratase de contratação de empresa especialiada na prestação de serviç… | R$ 10.483,98 | 31/12/2026 | 55 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024003564 | SEENEMAR | ASSOCIAÇÃO NITEROIENSE DOS DEFICIENTES FISIC… | Contratação de empresa especializada, com dedicação exclusiva de mãod… | R$ 2.161.834,56 | 10/02/2027 (PNCP) | 96 |
| 2026001058 | SEENEMAR | ASTA MOBILI MOVEIS LTDA | Aquisição de mobiliário administrativo, compreendendo 60 (sessenta) a… | R$ 90.880,00 | 04/03/2027 | 118 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024002560 | DRM | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | Contratação de serviços continuados de gestão do abastecimento, com u… | R$ 25.398.000,00 | 12/12/2025 | -329 |
| 2026000892 | DRM | AMBIENTECH SOLUÇÕES EM TECNOLOGIA AMBIENTAL … | A referida cartografia deverá atender aos critérios e metodologia def… | R$ 15.193.813,23 | 07/06/2026 (PNCP) | -152 |
| 2024010644 | DRM | AMBIENTECH SOLUÇÕES EM TECNOLOGIA AMBIENTAL … | Contratação de serviços especializado em apoio técnico para análise d… | R$ 6.992.804,72 | 12/06/2026 (PNCP) | -147 |
| 2026000893 | DRM | THALWEG TECNOLOGIA E SERVICOS DE GEOTECNIA E… | 2.1 - Os serviços compreendem a execução de apoio técnico especializa… | R$ 4.685.862,16 | 07/06/2026 (PNCP) | -152 |
| 2025003554 | SEENEMAR | SPARK EXPERIENCES LTDA. | Contratação mediante cota de patrocínio, da empresa Spark Experiences… | R$ 3.000.000,00 | 23/11/2025 (PNCP) | -348 |
| 2024009737 | DRM | INSTITUTO MAAYAN | Contratação de serviço especializado para elaboração de plano de exec… | R$ 2.490.000,00 | 23/06/2025 (PNCP) | -501 |
| 2026002190 | SEENEMAR | BRASVIP SEGURANCA PRIVADA LTDA | O objeto da pretensa é a contratação de empresa especializada para a … | R$ 2.407.875,12 | 24/09/2026 (PNCP) | -43 |
| 2025006971 | SEENEMAR | INSTITUTO BRASILEIRO DE PETROLEO, GAS E BIOC… | Contratação mediante cota de patrocínio do Governo do Estado do Rio d… | R$ 1.850.000,00 | 04/03/2026 (PNCP) | -247 |
| 2023008944 | SEENEMAR | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | O presente certame tem por objetivo a contratação de agente de integr… | R$ 1.425.720,00 | 01/11/2025 | -370 |
| 2025007765 | SEENEMAR | FUNDACAO SOCIAL, CULTURAL E EDUCATIVA REDE C… | Contratação, por inexigibilidade de licitação, da Fundação Social, Cu… | R$ 790.000,00 | 14/11/2025 (PNCP) | -357 |
| 2024005726 | SEENEMAR | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Contratação de empresa para prestação de serviços de agência de viage… | R$ 732.000,00 | 07/08/2025 | -456 |
| 2024008007 | DRM | EVERY TI TECNOLOGIA & INOVAÇÃO LTDA | Contratação de empresa para o fornecimento de solução tecnológica de … | R$ 702.896,00 | 27/09/2025 | -405 |
| 2025007330 | SEENEMAR | EDITORA GLOBO S/A | Contratação mediante cota de patrocínio institucional junto à Editora… | R$ 675.000,00 | 24/10/2025 (PNCP) | -378 |
| 2024003263 | DRM | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | O objetivo deste Termo de Referência é estabelecer as condições que i… | R$ 420.000,00 | 13/05/2025 | -542 |
| 2025009669 | SEENEMAR | FUNDACAO SOCIAL, CULTURAL E EDUCATIVA REDE C… | Contratação de cota de patrocínio institucional para viabilizar a par… | R$ 300.000,00 | 24/05/2026 | -166 |
| 2023009135 | DRM | ANGELS SEGURANÇA E VIGILANCIA EIRELI | serviços continuados de vigilância patrimonial desarmada | R$ 281.647,92 | 30/11/2025 | -341 |
| 2025002029 | DRM | ANGELS SEGURANÇA E VIGILANCIA EIRELI | O objetivo deste Termo de Referência é estabelecer as condições para … | R$ 256.962,48 | 02/05/2026 | -188 |
| 2025008338 | SEENEMAR | INSTITUTO DOS MAGISTRADOS DO BRASIL | Contratação, por inexigibilidade, do Instituto dos Magistrados do Bra… | R$ 150.000,00 | 28/01/2026 | -282 |
| 2025002372 | SEENEMAR | BRAZILIAN - NORWEGIAN CHAMBER OF COMMERCE | Contratação mediante cota de patrocínio do Governo do Estado do Rio d… | R$ 107.114,25 | 10/06/2025 | -514 |
| 2025006367 | DRM | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | contratação de serviço de hospedagem em Servidores Virtuais Privados … | R$ 81.109,56 | 15/10/2026 | -22 |
| 2024009489 | SEENEMAR | MARCENARIA SULAR LTDA. | Contratação de empresa para fornecimento de divisórias (painéis de di… | R$ 78.600,00 | 17/02/2026 | -262 |
| 2024010599 | DRM | 49.054.909 LEONARDO PIMENTEL DOS SANTOS COSTA | Contratação de empresa especializada na prestação de serviços de manu… | R$ 58.900,00 | 17/02/2026 | -262 |
| 2024010435 | DRM | DYEGO OLIVEIRA SEVERO SILVA 09044873776 | Contratação de empresa especializada para prestação de serviços de Bu… | R$ 58.300,00 | 17/02/2026 | -262 |
| 2024010419 | DRM | BRUNO DE SOUZA SOARES - 09324971794 | Contratação de fornecimento de cesta executiva de natal, conforme esp… | R$ 58.024,35 | 22/02/2025 | -622 |
| 2025004982 | DRM | MASTER DE ITABORAÍ -COMÉRCIO E SERVIÇOS EIRE… | O presente Termo de Referência tem por objeto a contratação de empres… | R$ 54.000,00 | 23/12/2025 | -318 |
| 2024009995 | SEENEMAR | RC CARD SOLUCOES EM PAGAMENTOS LTDA | Contratação de empresa especializada na prestação de serviços de emis… | R$ 49.920,00 | 31/01/2026 | -279 |
| 2025008037 | SEENEMAR | MARCENARIA SULAR LTDA. | Contratação de serviço de compra e instalação de divisórias corporati… | R$ 47.862,00 | 09/10/2026 | -28 |
| 2024008371 | DRM | CHADA COMERCIO E SERVIÇOS LTDA | tem por objeto contratação de empresa especializada no fornecimento d… | R$ 29.454,24 | 29/10/2025 | -373 |
| 2025001434 | SEENEMAR | CACTUS COMUNICAÇÃO VISUAL E CENOGRAFIA LTDA | Contratação do serviço de instalação com fornecimento de material par… | R$ 26.330,00 | 30/06/2025 | -494 |
| 2023009715 | DRM | CS BRASIL FROTAS S.A. | Tratase de contratação de empresa especialiada na prestação de serviç… | R$ 23.002,96 | 20/10/2026 | -17 |

_Registros mais antigos (provável falta de baixa no SIGA): 341, R$ 15,8 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026004063 | SEENEMAR | METTA INDUSTRIA EM SOLUÇÕES AMBIENTAIS LTDA | Contratação de empresa especializada, para o serviço de desmantelamen… | R$ 4.449.000,00 | 27/11/2026 (PNCP) | 21 |
| 2025008407 | SEENEMAR | CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTAD… | Contratação de empresa especializada na prestação de serviços de Admi… | R$ 2.394.840,00 | 03/11/2028 | 728 |
| 2024003564 | SEENEMAR | ASSOCIAÇÃO NITEROIENSE DOS DEFICIENTES FISIC… | Contratação de empresa especializada, com dedicação exclusiva de mãod… | R$ 2.161.834,56 | 10/02/2027 (PNCP) | 96 |
| 2025010823 | DRM | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | empresa especializada na prestação de serviços de emissão e entrega d… | R$ 1.279.803,20 | 22/12/2026 (PNCP) | 46 |
| 2025006431 | SEENEMAR | CS BRASIL FROTAS S.A. | Contratação de empresa especializada para o fornecimento de veículos … | R$ 587.519,16 | 26/08/2028 | 659 |
| 2026004989 | SEENEMAR | REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | Contratação de prestação de serviços de locação de veículos de repres… | R$ 324.000,00 | 25/06/2029 | 962 |
| 2025008388 | SEENEMAR | AMAZONIA BR SERVICOS ALIMENTACAO LTDA | Contratação de empresa especializada em serviços de alimentação, sob … | R$ 242.395,60 | 26/11/2026 | 20 |
| 2024009052 | DRM | LOCADORA GRILLO E RIBEIRO LTDA | O objeto do presente procedimento é a contratação de serviços de loca… | R$ 225.139,08 | 22/04/2029 | 898 |
| 2024009053 | DRM | AVANTE MARKETING E LOGÍSTICA LTDA | O objeto do presente procedimento é a contratação de serviços de loca… | R$ 189.343,08 | 31/03/2028 | 511 |
| 2024009054 | DRM | NTSEC SOLUÇÕES EM TELEINFORMÁTICA LTDA | contratação de empresa de Tecnologia da Informação para o forneciment… | R$ 180.518,57 | 31/10/2027 | 359 |
| 2026005401 | SEENEMAR | 3CORP TECHNOLOGY S/A INFRA ESTRUTURA TELECOM | Contratação de solução de Telefonia IP em nuvem, contemplando o forne… | R$ 168.336,00 | 23/07/2028 | 625 |
| 2026000972 | SEENEMAR | ASSOCIACAO BRASILEIRA DE CORROSAO | Contratação de empresa na prestação de serviços para treinamento e ce… | R$ 150.000,00 | 16/07/2027 | 252 |
| 2024008396 | SEENEMAR | NTSEC SOLUÇÕES EM TELEINFORMÁTICA LTDA | A presente demanda visa a disponibilização de solução de segurança qu… | R$ 117.378,32 | 30/10/2027 | 358 |
| 2026004222 | DRM | IMAGEM GEOSISTEMAS E COMÉRCIO LTDA | ontratação de licenciamento anual de solução de tecnologia da informa… | R$ 94.183,52 | 13/07/2027 | 249 |
| 2026001058 | SEENEMAR | ASTA MOBILI MOVEIS LTDA | Aquisição de mobiliário administrativo, compreendendo 60 (sessenta) a… | R$ 90.880,00 | 04/03/2027 | 118 |
| 2024004038 | SEENEMAR | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação de concessionária para a disponibilização de energia elét… | R$ 90.000,00 | 10/08/2027 | 277 |
| 2025009297 | SEENEMAR | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de empresa especializada para a prestação de serviços de … | R$ 76.050,00 | 10/12/2026 | 34 |
| 2026000962 | DRM | 3CORP TECHNOLOGY S/A INFRA ESTRUTURA TELECOM | Contratação de Solução Integrada de VoIP com PABX Virtual utilizando … | R$ 40.884,00 | 24/02/2028 | 475 |
| 2025005638 | DRM | AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA L… | A presente contratação centralizada tem como objeto a prestação dos s… | R$ 33.259,18 | 22/12/2026 | 46 |
| 2025003811 | SEENEMAR | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação de serviço de hospedagem de correio eletrônico coorporati… | R$ 29.640,72 | 17/06/2027 | 223 |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| METTA INDUSTRIA EM SOLUÇÕES AMBIENTAIS LTDA | 1 | R$ 4.449.000,00 |
| CENTRO DE INTEGRAÇÃO EMPRESA ESCOLA DO ESTADO DO RIO DE JAN… | 2 | R$ 2.400.720,00 |
| ASSOCIAÇÃO NITEROIENSE DOS DEFICIENTES FISICOS | 1 | R$ 2.161.834,56 |
| TRIVALE INSTITUICAO DE PAGAMENTO LTDA | 1 | R$ 1.279.803,20 |
| CS BRASIL FROTAS S.A. | 2 | R$ 598.003,14 |
| REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | 1 | R$ 324.000,00 |
| NTSEC SOLUÇÕES EM TELEINFORMÁTICA LTDA | 2 | R$ 297.896,89 |
| AMAZONIA BR SERVICOS ALIMENTACAO LTDA | 1 | R$ 242.395,60 |
| LOCADORA GRILLO E RIBEIRO LTDA | 1 | R$ 225.139,08 |
| 3CORP TECHNOLOGY S/A INFRA ESTRUTURA TELECOM | 2 | R$ 209.220,00 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2022008825 | DELL COMPUTADORES DO BRASIL LTDA | R$ 313.200,00 | R$ 0,00 | R$ 313.200,00 |
| 2017005118 | AMPLA ENERGIA E SERVIÇOS S/A | R$ 233.358,39 | R$ 178.179,10 | R$ 55.179,29 |
| 2016001677 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 12.843,07 | R$ 0,00 | R$ 12.843,07 |
| 2021000653 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 13.364,97 | R$ 3.635,00 | R$ 9.729,97 |
| 2017004498 | FORÇA TATICA VIGILANCIA E SEGURANÇA EIRELI | R$ 574.291,69 | R$ 564.946,70 | R$ 9.344,99 |
| 2019003358 | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | R$ 71.143,41 | R$ 63.462,23 | R$ 7.681,18 |
| 2022002866 | CLARO S/A (FILIAL) | R$ 5.217,40 | R$ 1.203,98 | R$ 4.013,42 |
| 2021005401 | AGUAS DE NITEROI S/A | R$ 13.910,00 | R$ 11.168,66 | R$ 2.741,34 |
| 2016001456 | CREACTEVE EVENTOS E TURISMO LTDA | R$ 2.600,00 | R$ 0,00 | R$ 2.600,00 |
| 2016003071 | SOCIEDADE BRASILEIRA DE GEOLOGIA | R$ 2.342,80 | R$ 0,00 | R$ 2.342,80 |
| 2022006357 | A C S DE OLIVEIRA MATERIAL DE INFORMATICA E … | R$ 1.561,80 | R$ 0,00 | R$ 1.561,80 |
| 2016001441 | WP SISTEMAS REPROGRAFICOS E IMPRESSAO LTDA E… | R$ 15.031,09 | R$ 13.500,09 | R$ 1.531,00 |
| 2019000728 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 23.425,23 | R$ 22.251,22 | R$ 1.174,01 |
| 2016001831 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 796,00 | R$ 0,00 | R$ 796,00 |
| 2022006347 | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | R$ 2.455,20 | R$ 2.046,00 | R$ 409,20 |
| 2016004949 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 300,00 | R$ 0,00 | R$ 300,00 |
| 2018000488 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 6.860,83 | R$ 6.799,85 | R$ 60,98 |

## 11. Unidades incluídas neste dossiê
- DRM - DEPART RECURSOS MINERAIS ESTADO RJ
- SEENEMAR - SECRETARIA DE ESTADO DE ENERGIA E ECONOMIA DO MAR

## 12. Conjuntos de dados abertos da secretaria
- Projeto Empregos Azuis (atualizado 2025-05-23): [Empregos Azuis PDF](https://dadosabertos.rj.gov.br/dataset/c5879331-7a87-476f-9e1a-6657004f6c96/resource/16c32c3c-ec8d-4ebb-9ba4-040daeae0202/download/empregos_azuis_compressed.pdf)
- Ranat - 2024 (atualizado 2025-05-21): [Ranat 2024.pdf PDF](https://dadosabertos.rj.gov.br/dataset/239c8c2f-843e-458f-9697-975b79bccaf6/resource/031c2c40-339c-4563-9468-b7cf2d7c1248/download/ranat-2024.pdf)
- Plano Anual de Atividades - 2025 (atualizado 2025-05-21): [Planat 2025.pdf PDF](https://dadosabertos.rj.gov.br/dataset/8275237c-f05d-4767-8b46-57e5ac77d987/resource/2d379d69-3c90-4757-9520-f124f67c1ffe/download/planat-2025.pdf)
- Prestação de Contas (atualizado 2025-05-20): [Prestação de Contas PDF](https://dadosabertos.rj.gov.br/dataset/43cf4e39-cfc0-4193-8d87-f2df3cd23fbd/resource/f3de374a-f25d-4703-abec-78d533971671/download/relatorio-de-auditoria-pca-2023-seenemar.pdf)
- Plano Anual de Atividades (atualizado 2025-05-20): [Planat 2024.pdf PDF](https://dadosabertos.rj.gov.br/dataset/0bb44052-2ab9-4e09-a3f9-3de12bc84555/resource/46d521fb-eb5f-402c-810f-d5cb6637a364/download/planat-2024.pdf)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 5 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

- A Seenemar deixou de existir como secretaria independente e foi incorporada à Secretaria de Estado de Desenvolvimento Econômico, Indústria, Comércio e Serviços, conforme incorporação formalizada pelo Decreto nº 50.391, de 21 de julho de 2026. [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62)
- A área de Energia e Economia do Mar permaneceu na estrutura como subsecretaria, com atribuições relativas a petróleo e gás, energia elétrica, transição energética, portos, indústria naval e economia do mar. [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/)
- As fontes não apresentam dados suficientes para avaliar contratos específicos, continuidade de serviços, passivos, processos ou apontamentos de órgãos de controle; esses itens devem ser solicitados à Secretaria antes da posse. [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/)

##### Alertas vermelhos

- **Nada encontrado nas fontes consultadas** sobre interrupção iminente de serviços, crise operacional, dívida, irregularidade comprovada ou risco de apagão administrativo. [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/)
- A publicação do Governo do Estado de 27 de agosto informa revisão de contratos e economia prevista, mas não identifica contratos, empresas, valores individuais ou prazos; é um ponto de verificação, não evidência de irregularidade. [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940)
- Há uma divergência de redação a esclarecer: a publicação do Governo diz que a Secretaria de Desenvolvimento Econômico foi “integrada à Secretaria de Energia e Economia do Mar”, enquanto o decreto e a notícia sobre a extinção descrevem a incorporação da Seenemar pela estrutura de Desenvolvimento Econômico. [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940) [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml)

##### Contratos e serviços críticos

- A publicação do Governo informa que os contratos da secretaria foram revisados e prevê economia de R$ 715 mil por mês; não fornece números de contratos, empresas, valores individuais ou vigências. [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940)
- A mesma publicação informa redução de 30,4% no número de áreas, redução de 35,5% no quadro de pessoal e queda da folha mensal de R$ 2,08 milhões para R$ 1,43 milhão; as fontes não detalham os cargos, unidades ou efeitos sobre a prestação de serviços. [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940)
- O decreto atribui à subsecretaria competências em cadeias de petróleo, gás e biocombustíveis, energia elétrica, eficiência e transição energética, portos, indústria naval e economia do mar, mas não identifica serviços contratados, operadores ou dependências críticas. [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62)
- **Nada encontrado nas fontes consultadas** sobre contratos específicos, fornecedores, valores individualizados, vigências, indicadores de continuidade ou planos de contingência de serviços. [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/) [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- **Nada encontrado nas fontes consultadas** sobre decisões do TCE-RJ, ações ou procedimentos do MPRJ, ações judiciais, irregularidades ou sanções relacionados à Seenemar ou à subsecretaria. [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/) [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940)
- A ausência de menções nessas fontes não confirma que não existam processos ou apurações; é necessário solicitar à Secretaria a relação de processos, auditorias, recomendações e respostas pendentes. [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/)

##### Riscos de apagão administrativo

- Em 22 de julho, foi informado que o secretário de Fazenda, Guilherme Mercês, acumularia as funções até a nomeação de titular para a pasta unificada; as fontes posteriores fornecidas não informam quem passou a ocupar o cargo ou como ficou a distribuição efetiva de responsabilidades. [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/)
- O decreto lista uma estrutura para a Subsecretaria de Energia e Economia do Mar com assessoria, superintendências e coordenadorias, e a matéria de outubro informa que o Regimento Interno definiu competências e atribuições; as fontes não detalham quadro nominal, vacâncias, delegações, sistemas ou procedimentos de transição administrativa. [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/)
- **Nada encontrado nas fontes consultadas** que comprove risco concreto de interrupção de serviços ou perda de capacidade operacional; a situação de pessoal e a transferência de processos e responsabilidades precisam ser verificadas. [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/)

##### Fatos recentes

- Em 21 de julho de 2026, o Decreto nº 50.391 formalizou a incorporação da Seenemar à Secretaria de Desenvolvimento Econômico; o decreto entrou em vigor na data de publicação, conforme o texto publicado no DOERJ de 27 de agosto. [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62)
- Em 22 de julho, foi noticiada a extinção da secretaria independente e a incorporação de suas funções à Secretaria de Desenvolvimento Econômico, com acúmulo temporário das funções por Guilherme Mercês até a nomeação de titular. [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml)
- Em 27 de agosto, o Governo informou redução de 30,4% no número de áreas, redução de 35,5% no quadro de pessoal, queda da folha mensal de R$ 2,08 milhões para R$ 1,43 milhão e economia anual estimada de R$ 16,3 milhões com as medidas anunciadas. [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940)
- Em 27 de outubro, foi noticiada a publicação do Regimento Interno da Secretaria, que organiza a estrutura e define competências e atribuições, incluindo as da Subsecretaria de Energia e Economia do Mar. [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/)
- Em 12 de março de 2026, foi noticiada a saída de Cássio Coelho do comando da Seenemar e sua nomeação para outra subsecretaria, não identificada no texto. [Arquivo de destaque do Tempo Real](https://temporealrj.com/tag/destaque/page/253/)

##### Lacunas da pesquisa (o que não foi encontrado e deve ser pedido à secretaria)

- Solicitar inventário integral de contratos, aditivos, fornecedores, valores, vigências, objeto, fiscalizações, pagamentos pendentes e resultados da revisão contratual anunciada, pois a publicação do Governo informa economia prevista, mas não discrimina contratos. [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940)
- Solicitar mapa dos serviços essenciais e dos riscos de descontinuidade, incluindo planos de contingência e responsabilidades dos gestores, pois as fontes não descrevem contratos ou riscos de interrupção. [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/)
- Solicitar relação atualizada de processos no TCE-RJ, procedimentos no MPRJ, ações judiciais, auditorias, recomendações, prazos e providências pendentes, pois nada sobre esses itens foi encontrado nas fontes consultadas. [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/)
- Solicitar quadro atual de pessoal, vacâncias, nomeações, distribuição de funções, organograma efetivamente implantado e situação do titular da pasta, considerando o acúmulo temporário anunciado em julho e as reduções de pessoal informadas em agosto. [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940) [Regimento Interno da Secretaria](https://temporealrj.com/desenvolvimento-economico-regimento-interno/)
- Solicitar confirmação formal da estrutura institucional vigente, para esclarecer a diferença entre a direção de incorporação descrita no decreto e na notícia de julho e a redação da publicação governamental de agosto. [DOERJ de 27/08/2026](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) [G1: extinção da Seenemar](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) [Publicação do Governo do RJ](https://x.com/GovRJ/status/2092968770272669940)

##### Fontes consultadas
1. [Couto extingue Secretaria de Energia e Economia do Mar   G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/22/couto-extingue-secretaria-de-energia-e-economia-do-mar-e-incorpora-pasta-ao-desenvolvimento-economico.ghtml) — 2026-07-22
2. [DOERJ 27/08/2026 - Diario Oficial do Estado do RJ - Dia Oficial](https://diaoficial.com/documento/2457235/DOERJ-20260827-p1-75DB3C62) — 2026-08-27
3. [Secretaria Estadual de Desenvolvimento Econômico publica Regimento Interno e estabelece modelo de governança](https://temporealrj.com/desenvolvimento-economico-regimento-interno/) — 2026-10-27
4. [Post](https://x.com/GovRJ/status/2092968770272669940) — 2026-08-27
5. [Arquivo de destaque - Página 253 de 834 - Tempo Real](https://temporealrj.com/tag/destaque/page/253/) — 2026-11-03


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2025008388 (AMAZONIA BR SERVICOS ALIMENTACAO LTDA) vence em 26/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2026004063 (METTA INDUSTRIA EM SOLUÇÕES AMBIENTAIS …) vence em 27/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025009297 (LECARD ADMNISTRADORA DE CARTÕES LTDA) vence em 10/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2023010644 (IMPRENSA OFICIAL DO ESTADO DO RIO DE JA…) vence em 18/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025005638 (AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMAT…) vence em 22/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2024002560 (PRIME CONSULTORIA E ASSESSORIA EMPRESAR…, R$ 25,4 mi) consta 'Ativo' no SIGA com fim em 12/12/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2026000892 (AMBIENTECH SOLUÇÕES EM TECNOLOGIA AMBIE…, R$ 15,2 mi) consta 'Ativo' no SIGA com fim em 07/06/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2024010644 (AMBIENTECH SOLUÇÕES EM TECNOLOGIA AMBIE…, R$ 7,0 mi) consta 'Ativo' no SIGA com fim em 12/06/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2026000893 (THALWEG TECNOLOGIA E SERVICOS DE GEOTEC…, R$ 4,7 mi) consta 'Ativo' no SIGA com fim em 07/06/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2025003554 (SPARK EXPERIENCES LTDA., R$ 3,0 mi) consta 'Ativo' no SIGA com fim em 23/11/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
