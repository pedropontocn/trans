# Dossiê de transição — Secretaria de Estado do Gabinete do Governador (SEGG)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/segg)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 444 | R$ 305.974.289,66 |
| Com vigência futura (válidos no SIGA) | 63 | R$ 58.059.110,47 |
| até 30 dias | 6 | R$ 65.424,27 |
| até 60 dias | 5 | R$ 2.833.490,00 |
| até 90 dias | 5 | R$ 1.661.208,59 |
| até 180 dias | 8 | R$ 20.284.774,20 |
| vencido no SIGA | 381 | R$ 247.915.179,19 |
| sem data | 2 | R$ 245.889,66 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 117,1 mi / R$ 81,1 mi / R$ 75,8 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Mais 6 contratos menores (R$ 0,1 mi) vencem em até 30 dias — ver seção 3.
- 24 contratos (R$ 24,8 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 81 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 72,3 mi); 0 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 300 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 175,7 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Concentração: HELICÓPTEROS DO BRASIL S/A detém 34% do valor vigente (1 contratos).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026008151 | SERGB | MD POWER INSTALACAO E MANUTENCAO LTDA | SERVICOS DE MANUTENCAO DE NOBREAK 160KVA, COM FORNECIMENTO DE PECAS E… | R$ 11.106,00 | 08/11/2026 | 2 |
| 2026007676 | GSI | ALTHVA TECNOLOGIA VENDAS E SERVIÇOS LTDA | 10 unidades de Controlador Facial05 unidades de Fonte de Alimentação1… | R$ 20.099,00 | 09/11/2026 | 3 |
| 2025009328 | SMGSI | IBS FIRE SOLUÇÕES CONTRA INCÊNDIO LTDA | Contratação prestação de serviços de manutenção, recarga, teste hidro… | R$ 8.190,00 | 18/11/2026 | 12 |
| 2026006706 | GSI | STARMEDICAL IMPORTACAO E EXPORTACAO DE PRODU… | Aquisição de eletrocardiógrafo portátil digital de 12 derivações, com… | R$ 9.342,00 | 19/11/2026 | 13 |
| 2024003926 | SERGB | EMBRATEL TVSAT TELECOMUNICAÇÕES S/A | prestação de serviços de adesão, captação, instalação e distribuição … | R$ 5.496,00 | 23/11/2026 | 17 |
| 2025009864 | GSI | MAPFRE SEGUROS GERAIS S/A | Contratação de serviço de Seguro na modalidade R.E.T.A. (Responsabili… | R$ 11.191,27 | 03/12/2026 | 27 |
| 2025008996 | GSI | ELOAR SERVIÇOS DE COMUNICAÇÃO E MARKETING LT… | Aquisição de uniformes personalizados para atendimento das necessidad… | R$ 7.010,00 | 08/12/2026 | 32 |
| 2026006934 | GSI | INSTITUTO BRASILEIRO DE DIREITO ADMINISTRATI… | Trata-se de contratação de 10 (dez) vagas para participação no 40º Co… | R$ 22.500,00 | 24/12/2026 | 48 |
| 2026007459 | GSI | IBS FIRE SOLUÇÕES CONTRA INCÊNDIO LTDA | Contratação prestação de serviços de manutenção, recarga, teste hidro… | R$ 1.000,00 | 24/12/2026 | 48 |
| 2026007460 | GSI | JSRC GNV SEGURANÇA CONTRA INCÊNDIO LTDA | Contratação prestação de serviços de manutenção, recarga, teste hidro… | R$ 6.080,00 | 24/12/2026 | 48 |
| 2022010107 | GSI | RENTCON LOCAÇÃO E COMERCIO DE EQUIPAMENTOS L… | O presente procedimento administrativo tem como objeto o pregão eletr… | R$ 2.796.900,00 | 01/01/2027 | 56 |
| 2026004301 | GSI | MINISTERIO DA FAZENDA | Pagamento de eventuais juros e multas em favor do Instituto Nacional … | R$ 5.000,00 | 08/01/2027 | 63 |
| 2026004302 | GSI | MINISTERIO DA FAZENDA | Pagamento de eventuais juros e multas em favor do Instituto Nacional … | R$ 5.000,00 | 08/01/2027 | 63 |
| 2025005024 | GSI | FUNDAÇÃO GETULIO VARGAS | Inscrição de servidor no Curso de Pós-Graduação LLM Direito / Licitaç… | R$ 38.035,00 | 10/01/2027 | 65 |
| 2024000039 | GSI | CS BRASIL FROTAS S.A. | Contratação de serviço para a locação de veículos automotores novos d… | R$ 1.611.720,00 | 16/01/2027 | 71 |
| 2026000401 | SMGSI | SECRETARIA MUNICIPAL DE FAZENDA | Custear a despesa com o pagamento da Taxa de Coleta de Lixo (TCL) ref… | R$ 1.453,59 | 30/01/2027 | 85 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000736 | GSI | MAPFRE SEGUROS GERAIS S/A | Contratação de empresa especializada na prestação de serviço de segur… | R$ 7.750,00 | 11/02/2027 | 97 |
| 2025000684 | GSI | HELICÓPTEROS DO BRASIL S/A | Contratação de empresa especializada e autorizada na prestação de ser… | R$ 19.521.196,12 | 17/02/2027 (PNCP) | 103 |
| 2026000978 | GSI | AIRWAY COMÉRCIO IMPORTAÇÃO & EXPORTAÇÃO LTDA | Assinatura Anual de atualização do banco de dados de navegação aérea,… | R$ 43.460,00 | 20/02/2027 | 106 |
| 2023007723 | SMGSI | TAGG SERVICES LTDA | PRESTAÇÃO DE SERVIÇOS DE LOCAÇÃO DE VEÍCULOS ESPECIAIS DE REPRESENTAÇ… | R$ 628.128,00 | 01/03/2027 | 115 |
| 2026001431 | GSI | MINISTERIO DA FAZENDA | Pagamento de eventuais juros e multas em favor do Instituto Nacional … | R$ 5.000,00 | 06/03/2027 | 120 |
| 2026002071 | GSI | TAVELO COMÉRCIO E DISTRIBUIDORA LTDA | Aquisição de 03(três) aparelhos de ar condicionado tipo split, capaci… | R$ 34.002,00 | 20/03/2027 | 134 |
| 2025003064 | SMGSI | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Assinatura de prestação de serviços de hospedagem de mensagem eletrôn… | R$ 34.050,72 | 23/03/2027 | 137 |
| 2026001965 | GSI | BEL MICRO TECNOLOGIA S/A | Aquisição de Ar Condicionado | R$ 11.187,36 | 23/03/2027 | 137 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024007579 | SERGB | INSTITUTO NTC DO BRASIL LTDA | contratação de empresa especializada na prestação de serviços de quat… | R$ 8.061.300,00 | 17/03/2025 (PNCP) | -599 |
| 2025006257 | SERGB | INSTITUTO NTC DO BRASIL LTDA | ``inscrições, na modalidade por vaga, em quatro seminários temáticos … | R$ 7.660.800,00 | 15/11/2025 (PNCP) | -356 |
| 2025003697 | SERGB | INSTITUTO NTC DO BRASIL LTDA | ``inscrições, na modalidade por vaga, em quatro seminários técnicos o… | R$ 7.552.768,00 | 28/07/2025 (PNCP) | -466 |
| 2024006295 | SERGB | INSTITUTO NTC DO BRASIL LTDA | ontratação de empresa especializada na prestação de serviços de capac… | R$ 6.120.000,00 | 08/08/2025 (PNCP) | -455 |
| 2025004505 | SERGB | O & G BRASIL LTDA | empresa especializada na prestação de serviços de capacitação de prof… | R$ 6.120.000,00 | 23/08/2025 (PNCP) | -440 |
| 2022009290 | GSI | LÍDER TÁXI AÉREO S/A - AIR BRASIL | Contratação de empresa especialiada naprestação de serviços de manute… | R$ 5.115.415,13 | 30/11/2024 | -706 |
| 2024000318 | GSI | SAFRAN HELICOPTER ENGINES INDÚSTRIA E COMÉRC… | Fornecimento de peças e componentes aeronáuticos homologados pelo fab… | R$ 4.780.783,53 | 28/12/2024 | -678 |
| 2025004558 | GSI | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Prestação de serviços de implementação, gerenciamento e administração… | R$ 4.647.500,00 | 30/07/2026 (PNCP) | -99 |
| 2022009180 | SMGSI | CS BRASIL FROTAS S.A. | VEÍCULOS ESPECIAIS DE REPRESENTAÇÃO DE ESCOLTA E DE SERVIÇO conforme … | R$ 3.855.168,00 | 27/03/2026 | -224 |
| 2024009387 | SERGB | INSTITUTO NTC DO BRASIL LTDA | 5.1. Introdução5.1.1. O objeto da presente contratação consiste na pr… | R$ 3.746.695,50 | 13/01/2025 (PNCP) | -662 |
| 2023001335 | SMGSI | AMAZON SERVIÇOS E CONSTRUÇÕES LTDA | Prestação de serviços de locação de veículos especiais SUV | R$ 3.186.000,00 | 14/07/2026 | -115 |
| 2022009220 | SMGSI | REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | PRESTAÇÃO DE SERVIÇOS DE LOCAÇÃO DEVEÍCULOS ESPECIAIS DE REPRESENTAÇÃ… | R$ 1.854.000,00 | 29/03/2026 | -222 |
| 2022009177 | SMGSI | HADDAD RENT A CAR LOCADORA LTDA | SEI390004000320 | R$ 1.555.200,00 | 29/03/2026 | -222 |
| 2024003382 | SERGB | INSTITUTO NTC DO BRASIL LTDA | Prestação de serviços de capacitação de gestores e técnicos estaduais… | R$ 1.272.512,00 | 08/11/2024 (PNCP) | -728 |
| 2023006760 | SMGSI | CS BRASIL FROTAS S.A. | PRESTAÇÃO DE SERVIÇOS DE LOCAÇÃODEVEÍCULOS ESPECIAIS DE REPRESENTAÇÃO… | R$ 838.080,00 | 31/08/2026 | -67 |
| 2023008949 | GSI | CS BRASIL FROTAS S.A. | Prestação de serviços comuns e contínuos de locação de veículos autom… | R$ 825.600,00 | 09/09/2026 | -58 |
| 2022008159 | SMGSI | LIBEX SERVIÇOS E LOCAÇÕES DE VEÍCULOS LTDA E… | contratação de 08 veículos AUTOMOVEL DE PORTE COMPACTO OU SUBCOMPACTO | R$ 744.480,00 | 28/02/2026 | -251 |
| 2023006746 | SMGSI | REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | PRESTAÇÃO DE SERVIÇOS DE LOCAÇÃO DEVEÍCULOS ESPECIAIS DE REPRESENTAÇÃ… | R$ 741.600,00 | 29/08/2026 | -69 |
| 2024008404 | SERGB | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Prestação de serviços de agenciamento de viagens | R$ 719.997,95 | 14/10/2025 | -388 |
| 2022000221 | GSI | CLARO S/A (FILIAL) | Contratação de rede Governo e Internet simétrica. | R$ 693.138,24 | 24/02/2025 | -620 |
| 2023003025 | GSI | 2LIVE STREAMING TELECOMUNICAÇÕES DIGITAIS LT… | Contratação de Serviços de Locação de Equipamentos de Transmissão de … | R$ 492.480,00 | 25/05/2025 | -530 |
| 2022009181 | SMGSI | TAGG SERVICES LTDA | PRESTAÇÃO DE SERVIÇOS DE LOCAÇÃO DE VEÍCULOS ESPECIAIS DE REPRESENTAÇ… | R$ 314.064,00 | 01/04/2026 | -219 |
| 2020000448 | SERGB | CONDOMINIO VIA OFFICE | taxa do Condomínio Via Office - ANUAL | R$ 204.000,00 | 31/12/2024 | -675 |
| 2023001720 | GSI | BRS SUPRIMENTOS CORPORATIVOS S/A | Contratação entre o Gabinete de Segurança Institucional do Governo CN… | R$ 176.413,53 | 31/03/2026 | -220 |
| 2022004476 | GSI | NTSEC SOLUÇÕES EM TELEINFORMÁTICA LTDA | Contratação de Licenças de Softwares de Solução Antivírus | R$ 107.109,95 | 29/06/2025 | -495 |
| 2022009389 | SERGB | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | Prestação de serviços de gestão do abastecimento com utiliação de sol… | R$ 90.300,60 | 24/04/2025 | -561 |
| 2026004611 | SERGB | REK PRODUCOES AUDIOVISUAIS LTDA | Contratação de empresa especializada para realização de apresentação … | R$ 63.500,00 | 12/08/2026 | -86 |
| 2026004607 | SERGB | REK PRODUCOES AUDIOVISUAIS LTDA | Estruturação do stand institucional do Governo do Estado do Rio de Ja… | R$ 60.500,00 | 12/08/2026 | -86 |
| 2024009880 | GSI | RC CARD SOLUCOES EM PAGAMENTOS LTDA | Contratação de empresa especializada em emissão, entrega e administra… | R$ 48.000,00 | 11/12/2025 | -330 |
| 2024004033 | GSI | BRAINSTORMING ASSESSESSORIA DE PLANEJAMENTO … | Contratação de serviço técnico de capacitação altamente especializada… | R$ 40.000,00 | 30/11/2024 | -706 |

_Registros mais antigos (provável falta de baixa no SIGA): 300, R$ 175,7 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025000684 | GSI | HELICÓPTEROS DO BRASIL S/A | Contratação de empresa especializada e autorizada na prestação de ser… | R$ 19.521.196,12 | 17/02/2027 (PNCP) | 103 |
| 2026006921 | GSI | VR BENEFICIOS E SERVICOS DE PROCESSAMENTO IN… | Prestação dos serviços de emissão, entrega e gerenciamento de cartões… | R$ 13.585.000,00 | 28/08/2027 | 295 |
| 2026005131 | SMGSI | REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | Contratação de prestação de serviços de locação de veículos automotor… | R$ 6.080.400,00 | 01/01/2030 | 1152 |
| 2026003949 | SMGSI | REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | Contratação de Serviços de Locação de Veículos de Representação comBl… | R$ 3.888.000,00 | 26/11/2029 (PNCP) | 1116 |
| 2022010107 | GSI | RENTCON LOCAÇÃO E COMERCIO DE EQUIPAMENTOS L… | O presente procedimento administrativo tem como objeto o pregão eletr… | R$ 2.796.900,00 | 01/01/2027 | 56 |
| 2025005617 | SMGSI | HADDAD RENT A CAR LOCADORA LTDA | Prestação de serviços de locação de veículos especiais(SUV) com blind… | R$ 2.249.262,00 | 28/11/2028 | 753 |
| 2024010430 | SMGSI | CS BRASIL FROTAS S.A. | Contratação de empresa especializada no fornecimento dos serviços de … | R$ 1.690.819,55 | 30/12/2027 | 419 |
| 2024000039 | GSI | CS BRASIL FROTAS S.A. | Contratação de serviço para a locação de veículos automotores novos d… | R$ 1.611.720,00 | 16/01/2027 | 71 |
| 2024002648 | GSI | ANDROMEDA PARTICIPACOES SOCIETARIAS LTDA | Locação do imóvel situado na Rodovia Mário Covas (Antiga Rio-Santos -… | R$ 1.320.000,00 | 17/04/2029 (PNCP) | 893 |
| 2025005901 | SERGB | TRIVALE INSTITUICAO DE PAGAMENTO LTDA | FORNECIMENTO DE VALE REFEICAO / ALIMENTACAO, DESCRIÇÃO: CONTRATACAO D… | R$ 1.098.500,00 | 06/08/2027 | 273 |
| 2026008694 | SMGSI | HADDAD RENT A CAR LOCADORA LTDA | solicita a contratação do saldo remanescente de 02 (dois) veículos es… | R$ 899.704,80 | 20/02/2030 | 1202 |
| 2023007723 | SMGSI | TAGG SERVICES LTDA | PRESTAÇÃO DE SERVIÇOS DE LOCAÇÃO DE VEÍCULOS ESPECIAIS DE REPRESENTAÇ… | R$ 628.128,00 | 01/03/2027 | 115 |
| 2026002807 | SMGSI | LIGHT SERVICOS DE ELETRICIDADE SA | Contratação do serviço de fornecimento de energia elétrica pelo perío… | R$ 285.255,33 | 26/05/2036 | 3489 |
| 2024009200 | GSI | NTSEC SOLUÇÕES EM TELEINFORMÁTICA LTDA | Consumo da Ata de Registro de Preços 0002/2024/403200-01 (PE SRP 014/… | R$ 261.761,05 | 13/02/2028 | 464 |
| 2025006957 | GSI | AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA L… | Contratação centralizada por meio de Registro de Preços, para prestaç… | R$ 235.003,09 | 25/09/2027 | 323 |
| 2026008316 | GSI | HIGH LEVEL COMERCIAL LTDA | Aquisição de Nobreaks (Fonte Ininterrupta de Energia) de pequeno e mé… | R$ 221.575,80 | 09/10/2027 | 337 |
| 2026003751 | GSI | AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA L… | Contratação centralizada por meio de Registro de Preços, paraprestaçã… | R$ 218.398,98 | 22/05/2028 | 563 |
| 2024010429 | SMGSI | AVANTE MARKETING E LOGÍSTICA LTDA | Contratação de empresa especializada no fornecimento dos serviços de … | R$ 201.481,92 | 30/12/2027 | 419 |
| 2026001547 | SMGSI | AGUAS DO RIO 1 SPE S.A | Contratação do serviço de fornecimento de água e coleta de esgoto pel… | R$ 178.680,00 | 13/03/2036 | 3415 |
| 2025008998 | GSI | UNIWORK UNIFORMES E EQUIPAMENTOS DE SEGURANÇ… | Aquisição de uniformes personalizados para atendimento das necessidad… | R$ 165.897,74 | — |  |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| HELICÓPTEROS DO BRASIL S/A | 1 | R$ 19.521.196,12 |
| VR BENEFICIOS E SERVICOS DE PROCESSAMENTO INSTITUICAO DE PA… | 1 | R$ 13.585.000,00 |
| REI DOS BLINDADOS LOCAÇÃO DE VEÍCULOS LTDA | 2 | R$ 9.968.400,00 |
| CS BRASIL FROTAS S.A. | 3 | R$ 3.308.465,26 |
| HADDAD RENT A CAR LOCADORA LTDA | 2 | R$ 3.148.966,80 |
| RENTCON LOCAÇÃO E COMERCIO DE EQUIPAMENTOS LTDA EPP | 1 | R$ 2.796.900,00 |
| ANDROMEDA PARTICIPACOES SOCIETARIAS LTDA | 1 | R$ 1.320.000,00 |
| TRIVALE INSTITUICAO DE PAGAMENTO LTDA | 1 | R$ 1.098.500,00 |
| TAGG SERVICES LTDA | 1 | R$ 628.128,00 |
| AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA LTDA | 2 | R$ 453.402,07 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2018002709 | LÍDER SIGNATURE S/A | R$ 9.669.707,45 | R$ 8.341.573,68 | R$ 1.328.133,77 |
| 2016000908 | LÍDER SIGNATURE S/A | R$ 1.578.715,89 | R$ 637.369,11 | R$ 941.346,78 |
| 2016000095 | COMPANHIA DE LOCAÇÃO DAS AMERICAS | R$ 2.121.193,97 | R$ 1.556.464,75 | R$ 564.729,22 |
| 2016000092 | LIDER TAXI AEREO S/A AIR BRASIL | R$ 1.236.950,40 | R$ 846.322,26 | R$ 390.628,14 |
| 2018002695 | LÍDER SIGNATURE S/A | R$ 2.493.237,93 | R$ 2.170.898,38 | R$ 322.339,55 |
| 2016003382 | LÍDER SIGNATURE S/A | R$ 289.802,05 | R$ 0,00 | R$ 289.802,05 |
| 2016000949 | LÍDER SIGNATURE S/A | R$ 378.819,22 | R$ 125.620,55 | R$ 253.198,67 |
| 2018004675 | LÍDER SIGNATURE S/A | R$ 1.562.340,47 | R$ 1.329.502,51 | R$ 232.837,96 |
| 2019006381 | HELICÓPTEROS DO BRASIL S/A | R$ 3.929.710,34 | R$ 3.724.543,33 | R$ 205.167,01 |
| 2016002302 | RURAL RENTAL SERVICE LTDA - EPP (MATRIZ) | R$ 185.700,00 | R$ 0,00 | R$ 185.700,00 |
| 2022002899 | VIBRA ENERGIA SA | R$ 127.462,94 | R$ 0,00 | R$ 127.462,94 |
| 2016004500 | JETFLY REVENDEDORA DE COMBUSTIVEIS LTDA | R$ 528.727,89 | R$ 409.881,63 | R$ 118.846,26 |
| 2022009290 | LÍDER TÁXI AÉREO S/A - AIR BRASIL | R$ 752.003,57 | R$ 661.763,14 | R$ 90.240,43 |
| 2019001109 | HADDAD RENT A CAR LOCADORA LTDA | R$ 4.713.119,32 | R$ 4.637.097,82 | R$ 76.021,50 |
| 2018006618 | JETFLY REVENDEDORA DE COMBUSTÍVEIS LTDA | R$ 1.189.658,40 | R$ 1.129.453,50 | R$ 60.204,90 |
| 2019001110 | EMPRESA BRASILEIRA DE ENGENHARIA E COMÉRCIO … | R$ 2.209.631,81 | R$ 2.151.389,71 | R$ 58.242,10 |
| 2016000090 | PEÇA OIL DISTRIBUIDORA LTDA | R$ 44.821,69 | R$ 9.395,39 | R$ 35.426,30 |
| 2021007026 | GLOBAL DISTRIBUIÇÃO DE BENS DE CONSUMO LTDA | R$ 32.460,00 | R$ 0,00 | R$ 32.460,00 |
| 2022005028 | LEONARDO DO BRASIL LTDA | R$ 19.819,19 | R$ 0,00 | R$ 19.819,19 |
| 2022000221 | CLARO S/A (FILIAL) | R$ 34.278,85 | R$ 22.410,63 | R$ 11.868,22 |

## 11. Unidades incluídas neste dossiê
- GSI - Gabinete de Segurança Institucional do Governo do Estado do Rio de Janeiro
- SERGB - SECRET EXTR DE REPRES DO GOV EM BSB
- SMGSI - Subsecretaria Militar do Gab de Seg Inst
- VICE-GOV - VICE-GOVERNADORIA

## 12. Conjuntos de dados abertos da secretaria
- Nenhum conjunto encontrado no portal.

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 7 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

- As fontes consultadas não identificam contratos, valores, vigências ou serviços críticos atribuídos especificamente à SEGG, nem relatam riscos de interrupção de serviços do Gabinete. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) [G1 — análise de contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)
- Há uma auditoria geral estadual anunciada em abril de 2026, com revisão de despesas, contratos e estrutura administrativa; as fontes não atribuem irregularidades à SEGG. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml)
- Um decreto de transição previu informações das secretarias até 30 de outubro sobre programas, contas públicas e prioridades, mas a fonte não informa o ano dessa data nem se a SEGG entregou os dados. [Governo do RJ — regras da transição](http://www.rj.gov.br/radioroquettepinto/node/21550)
- A principal prioridade documental para os primeiros 90 dias é obter da SEGG inventário de contratos, situação da auditoria e da transição, quadro de pessoal e eventuais pendências legais ou de controle, não detalhados nas fontes. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) [Governo do RJ — regras da transição](http://www.rj.gov.br/radioroquettepinto/node/21550)

##### Alertas vermelhos

- **Indício de risco de governança, não denúncia de irregularidade:** em abril de 2026, foi determinada auditoria geral estadual, com entrega de informações por órgãos e análise pela Controladoria Geral do Estado de contratações diretas com indícios de irregularidade; a notícia não atribui esses indícios à SEGG. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml)
- A fonte sobre a transição prevê prazo até 30 de outubro para as secretarias informarem programas, contas e prioridades, mas não confirma entrega, atraso ou consequência para a SEGG; o ano do prazo não é indicado. [Governo do RJ — regras da transição](http://www.rj.gov.br/radioroquettepinto/node/21550)

##### Contratos e serviços críticos

- Nada encontrado nas fontes consultadas sobre contratos da SEGG com número, empresa, valor ou vigência, ou sobre fornecedores e serviços essenciais contratados pelo Gabinete. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) [G1 — análise de contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)
- A reportagem do G1 menciona um contrato de agenciamento de viagens aéreas estimado em R$ 825 milhões, mas o situa entre acordos concentrados na Casa Civil, não o atribui à SEGG. [G1 — análise de contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)
- A auditoria geral estadual determinou a apresentação, em 15 dias úteis, de relatórios sobre gastos, projetos, contratos, cargos comissionados, terceirizados e licitações; a notícia não esclarece se a SEGG foi incluída especificamente nesse rol. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml)
- Nada encontrado nas fontes consultadas sobre atrasos de pagamentos, dívidas da SEGG ou risco de interrupção de serviços sob responsabilidade da Secretaria. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) [G1 — análise de contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- Nada encontrado nas fontes consultadas sobre decisões ou determinações do TCE-RJ relativas à SEGG. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) [G1 — análise de contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)
- Nada encontrado nas fontes consultadas sobre ações ou procedimentos do Ministério Público relativos à SEGG. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) [G1 — análise de contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)
- Nada encontrado nas fontes consultadas sobre ações judiciais, condenações ou outras pendências no Judiciário envolvendo a SEGG. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) [G1 — análise de contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)
- A auditoria geral prevê apuração de contratações diretas e prazo de 45 dias para a Controladoria Geral do Estado analisar casos com indícios de irregularidade; não há indicação de que algum caso envolva a SEGG. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml)

##### Riscos de apagão administrativo

- Nada encontrado nas fontes consultadas que indique risco concreto de paralisação de serviços da SEGG ou insuficiência de pessoal que ameace sua operação. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) [G1 — análise de contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)
- O decreto de transição tem como objetivo declarado transferir dados estratégicos e assegurar a continuidade de serviços públicos essenciais, mas não descreve riscos ou medidas específicas da SEGG. [Governo do RJ — regras da transição](http://www.rj.gov.br/radioroquettepinto/node/21550)
- Um decreto publicado em 27 de fevereiro de 2026 alterou, sem aumento de despesa, a estrutura da SEGG, mas a fonte consultada não detalha as mudanças nem seus efeitos sobre equipes, atribuições ou continuidade operacional. [Boletim GESPERJ — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Boletim%20GESPERJ%20-%20FEVEREIRO%2026.pdf)

##### Fatos recentes

- Em 13 de abril de 2026, o governador em exercício Ricardo Couto exonerou, “a pedido”, o secretário-chefe de Gabinete Rodrigo Abel; a reportagem descreve a saída como encerramento da presença de um grupo que concentrava decisões no Palácio Guanabara desde 2020, sem apontar irregularidade específica da SEGG. [G1 — análise de contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)
- Em 14 de abril de 2026, foi publicado decreto de auditoria geral estadual para revisar despesas, contratos e estrutura administrativa; a notícia não individualiza achados da SEGG. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml)
- O Decreto nº 50.162, de 26 de fevereiro de 2026, alterou a estrutura da SEGG sem aumento de despesa e foi publicado em 27 de fevereiro de 2026; os detalhes da reorganização não constam no material fornecido. [Boletim GESPERJ — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Boletim%20GESPERJ%20-%20FEVEREIRO%2026.pdf)
- A relação de órgãos publicada em junho de 2026 identifica Marco Antônio Rodrigues Simões como titular da Secretaria de Estado do Gabinete do Governador e Ricardo Couto de Castro como governador em exercício; essa fonte não confirma a permanência desses titulares em 6 de novembro de 2026. [Decreto nº 50.332 — publicação de junho de 2026](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/22-Decreto-Estadual-no-50.332-de-15.06.2026-CGE.pdf)
- O decreto de transição prevê comissão presidida pelo secretário da Casa Civil e permite ao governador eleito indicar até cinco integrantes para sua equipe; a fonte não informa a composição da equipe indicada nem a situação dos documentos da SEGG. [Governo do RJ — regras da transição](http://www.rj.gov.br/radioroquettepinto/node/21550)

##### Lacunas da pesquisa

- Solicitar à SEGG inventário atualizado de contratos, aditivos, fornecedores, valores, vigências, responsáveis e serviços associados, incluindo a identificação dos contratos considerados essenciais. As fontes não trazem esses dados para a Secretaria. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) [G1 — análise de contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)
- Solicitar o relatório entregue pela SEGG no âmbito da auditoria geral, se aplicável, e a situação de eventuais análises da Controladoria, pois as fontes não confirmam inclusão da Secretaria no rol de órgãos obrigados nem apresentam resultados específicos. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml)
- Solicitar comprovação da entrega das informações de transição relativas à SEGG, incluindo programas, situação de contas e decisões prioritárias; a fonte fixa prazo até 30 de outubro, mas não informa o ano nem registra o cumprimento. [Governo do RJ — regras da transição](http://www.rj.gov.br/radioroquettepinto/node/21550)
- Solicitar organograma vigente, atos de implementação do Decreto nº 50.162/2026, quadro de cargos e terceirizados, funções críticas e plano de continuidade, pois o material registra a alteração estrutural, mas não descreve seu conteúdo ou efeitos. [Boletim GESPERJ — fevereiro de 2026](https://www.rj.gov.br/gesperj/sites/default/files/Boletim%20GESPERJ%20-%20FEVEREIRO%2026.pdf) [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml)
- Solicitar certidões e relação atualizada de processos, recomendações e determinações do TCE-RJ, MPRJ e Judiciário, pois nada sobre esses temas relacionado à SEGG foi encontrado nas fontes consultadas. [CBN — auditoria geral](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) [G1 — análise de contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml)


##### Fontes consultadas
1. [Governador em exercício do RJ impõe auditoria geral nas ...](https://cbn.globo.com/rio-de-janeiro/noticia/2026/04/15/governador-em-exercicio-do-rj-impoe-auditoria-geral-nas-contas-do-estado.ghtml) — 2026-04-15
2. [Choque de transparência no RJ prevê análise de 6,7 mil contratos](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/04/16/choque-de-transparencia-no-rj-preve-analise-de-67-mil-contratos-que-somam-r-81-bilhoes.ghtml) — 2026-04-16
3. [Governo do Estado publica decreto com as regras para a transição governamental](http://www.rj.gov.br/radioroquettepinto/node/21550) — 2026-10-14
4. [ PDF  FEVEREIRO/2026 - Governo do Estado do Rio de Janeiro](https://www.rj.gov.br/gesperj/sites/default/files/Boletim%20GESPERJ%20-%20FEVEREIRO%2026.pdf) — 2026-05-16
5. [parte i poder executivo](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/05/Decreto-Estadual-no-49.736-Membos-Comite-LGPD.pdf) — 2026-07-19
6. [16/06/2026 PI160626-S-01___1](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/08/22-Decreto-Estadual-no-50.332-de-15.06.2026-CGE.pdf) — 2026-08-29
7. [ESTA PARTE É EDITADA](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/05/16-Decreto-de-49989-de-17-de-Novembro-de-2025-SEAPA.pdf) — 2026-07-05


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2026008151 (MD POWER INSTALACAO E MANUTENCAO LTDA) vence em 08/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2026007676 (ALTHVA TECNOLOGIA VENDAS E SERVIÇOS LTDA) vence em 09/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025009328 (IBS FIRE SOLUÇÕES CONTRA INCÊNDIO LTDA) vence em 18/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2026006706 (STARMEDICAL IMPORTACAO E EXPORTACAO DE …) vence em 19/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2024003926 (EMBRATEL TVSAT TELECOMUNICAÇÕES S/A) vence em 23/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2024007579 (INSTITUTO NTC DO BRASIL LTDA, R$ 8,1 mi) consta 'Ativo' no SIGA com fim em 17/03/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2025006257 (INSTITUTO NTC DO BRASIL LTDA, R$ 7,7 mi) consta 'Ativo' no SIGA com fim em 15/11/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2025003697 (INSTITUTO NTC DO BRASIL LTDA, R$ 7,6 mi) consta 'Ativo' no SIGA com fim em 28/07/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2024006295 (INSTITUTO NTC DO BRASIL LTDA, R$ 6,1 mi) consta 'Ativo' no SIGA com fim em 08/08/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2025004505 (O & G BRASIL LTDA, R$ 6,1 mi) consta 'Ativo' no SIGA com fim em 23/08/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
13. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
14. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
15. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
16. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
