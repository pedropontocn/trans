# Dossiê de transição — Secretaria de Estado do Ambiente e Sustentabilidade (SEAS)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/seas)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 354 | R$ 1.354.747.253,35 |
| Com vigência futura (válidos no SIGA) | 50 | R$ 694.262.339,15 |
| até 30 dias | 3 | R$ 8.803.550,00 |
| até 60 dias | 4 | R$ 27.664.484,68 |
| até 90 dias | 10 | R$ 111.359.568,93 |
| até 180 dias | 7 | R$ 7.933.308,83 |
| vencido no SIGA | 304 | R$ 660.484.914,21 |
| sem data | 3 | R$ 1.141.335,29 |
| Fornecedores em recuperação judicial | 1 | R$ 18.111.139,08 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 521,5 mi / R$ 213,7 mi / R$ 184,5 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2025009272 (VCS IMPLEMENTOS E VEÍCULOS LTDA) vence em 19/11/2026 — 13 dias — R$ 5.660.000,00. Objeto: Aquisição de veículos do tipo pick-up 4x4 (caminhonete).
- Contrato 2024008855 (BETA-I BRASIL CONSULTORIA EM INOVAÇÃO EMPRESARIAL…) vence em 21/11/2026 — 15 dias — R$ 2.450.000,00. Objeto: Contratação de serviços de consultoria para o desenvolvimento da segunda etapa …
- Contrato 2025010336 (2R DATATEL TELEINFORMÁTICA LTDA) vence em 10/12/2026 — 34 dias — R$ 12.624.000,00. Objeto: Aquisição de dois Appliance Firewall Tipo 1, dois Console de Gerenciamento Cent…
- Contrato 2022010302 (FUNDACAO PARQUES E JARDINS) vence em 31/12/2026 — 55 dias — R$ 15.000.000,00. Objeto: Tratase de convênio celebrado entre o Estado do Rio de Janeiro por intermédio d…
- Contrato 2026000229 (FXS ENGENHARIA LTDA) vence em 26/01/2027 — 81 dias — R$ 14.445.955,41. Objeto: Licitação na modalidade Pregão Eletrônico para a contratação da prestaçãodos se…
- Contrato 2026000230 (MSL PRESTACAO DE SERVICOS LTDA) vence em 26/01/2027 — 81 dias — R$ 13.872.193,08. Objeto: Licitação na modalidade Pregão Eletrônico para a contratação da prestaçãodos se…
- Contrato 2026000232 (CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO JUDIC…) vence em 26/01/2027 — 81 dias — R$ 18.111.139,08. Objeto: Licitação na modalidade Pregão Eletrônico para a contratação da prestaçãodos se…
- Contrato 2026000233 (ENGEBIO ENGENHARIA DO MEIO AMBIENTE LTDA) vence em 26/01/2027 — 81 dias — R$ 13.871.068,56. Objeto: Licitação na modalidade Pregão Eletrônico para a contratação da prestaçãodos se…
- Contrato 2026000234 (NEVADADISTRIBUIDORA E TRANSPORTADORA LTDA) vence em 26/01/2027 — 81 dias — R$ 18.040.736,16. Objeto: Licitação na modalidade Pregão Eletrônico para a contratação da prestaçãodos se…
- Contrato 2025000357 (MOBILIZA FOR RENT LTDA) vence em 27/01/2027 — 82 dias — R$ 13.692.840,00. Objeto: Locação de 60 (sessenta) veículos automotores (sendo 40 - tipo: pick-up, 15 - t…
- Contrato 2026000231 (JH SERVICOS E MANUTENCAO LTDA) vence em 27/01/2027 — 82 dias — R$ 18.008.516,64. Objeto: Licitação na modalidade Pregão Eletrônico para a contratação da prestaçãodos se…
- Mais 1 contratos menores (R$ 0,7 mi) vencem em até 30 dias — ver seção 3.
- 20 contratos (R$ 152,1 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 63 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 184,8 mi); 4 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 241 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 475,7 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Fornecedor em recuperação judicial: CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO JUDICIAL — 1 contrato(s), R$ 18,1 mi, último fim 26/01/2027.
- Concentração: HYDRA ENGENHARIA E SANEAMENTO LTDA detém 55% do valor vigente (2 contratos).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025009558 | INEA | LECARD ADMNISTRADORA DE CARTÕES LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇOS DE EMIS… | R$ 693.550,00 | 18/11/2026 (PNCP) | 12 |
| 2025009272 | SEAS | VCS IMPLEMENTOS E VEÍCULOS LTDA | Aquisição de veículos do tipo pick-up 4x4 (caminhonete). | R$ 5.660.000,00 | 19/11/2026 (PNCP) | 13 |
| 2024008855 | SEAS | BETA-I BRASIL CONSULTORIA EM INOVAÇÃO EMPRES… | Contratação de serviços de consultoria para o desenvolvimento da segu… | R$ 2.450.000,00 | 21/11/2026 (PNCP) | 15 |
| 2025010336 | INEA | 2R DATATEL TELEINFORMÁTICA LTDA | Aquisição de dois Appliance Firewall Tipo 1, dois Console de Gerencia… | R$ 12.624.000,00 | 10/12/2026 (PNCP) | 34 |
| 2014006702 | INEA | IMPERIAL ADMINISTRAÇÃO E CONTABILIDADE LTDA … | Aluguel | R$ 38.904,68 | 19/12/2026 | 43 |
| 2026002738 | SEAS | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | Aquisição de certificados digitais para os servidores da Secretaria d… | R$ 1.580,00 | 25/12/2026 | 49 |
| 2022010302 | SEAS | FUNDACAO PARQUES E JARDINS | Tratase de convênio celebrado entre o Estado do Rio de Janeiro por in… | R$ 15.000.000,00 | 31/12/2026 | 55 |
| 2024010227 | INEA | LABORPEC RIO COMERCIAL LTDA | Aquisição de RAÇÃO utilizada pelo CENPRI - CENTRO DE PRIMATOLOGIA na … | R$ 717.120,00 | 13/01/2027 (PNCP) | 68 |
| 2026000003 | SEAS | COOPERATIVA DA AGRICULTURA FAMILIAR DA REGIÃ… | O projeto visa à formação de 30 jovens estudantes da rede pública est… | R$ 150.000,00 | 16/01/2027 | 71 |
| 2026000229 | SEAS | FXS ENGENHARIA LTDA | Licitação na modalidade Pregão Eletrônico para a contratação da prest… | R$ 14.445.955,41 | 26/01/2027 (PNCP) | 81 |
| 2026000230 | SEAS | MSL PRESTACAO DE SERVICOS LTDA | Licitação na modalidade Pregão Eletrônico para a contratação da prest… | R$ 13.872.193,08 | 26/01/2027 (PNCP) | 81 |
| 2026000232 | SEAS | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | Licitação na modalidade Pregão Eletrônico para a contratação da prest… | R$ 18.111.139,08 | 26/01/2027 (PNCP) | 81 |
| 2026000233 | SEAS | ENGEBIO ENGENHARIA DO MEIO AMBIENTE LTDA | Licitação na modalidade Pregão Eletrônico para a contratação da prest… | R$ 13.871.068,56 | 26/01/2027 (PNCP) | 81 |
| 2026000234 | SEAS | NEVADADISTRIBUIDORA E TRANSPORTADORA LTDA | Licitação na modalidade Pregão Eletrônico para a contratação da prest… | R$ 18.040.736,16 | 26/01/2027 (PNCP) | 81 |
| 2025000357 | INEA | MOBILIZA FOR RENT LTDA | Locação de 60 (sessenta) veículos automotores (sendo 40 - tipo: pick-… | R$ 13.692.840,00 | 27/01/2027 (PNCP) | 82 |
| 2026000231 | SEAS | JH SERVICOS E MANUTENCAO LTDA | Licitação na modalidade Pregão Eletrônico para a contratação da prest… | R$ 18.008.516,64 | 27/01/2027 (PNCP) | 82 |
| 2026009074 | SEAS | GREEN RIO TEC LTDA | Patrocínio concedido pelo PATROCINADOR em favor do PATROCINADO para r… | R$ 450.000,00 | 01/02/2027 | 87 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026001733 | INEA | SABERES POPULARES LTDA ME | Contratação da empresa Saberes  Projetos Socioambientais e Educacion… | R$ 678.600,00 | 12/03/2027 (PNCP) | 126 |
| 2024010481 | SEAS | FUNDAÇÃO DE APOIO A PESQUISA CIENTIFICA E TE… | Contratação para prestação dos serviços de consultoria técnica especi… | R$ 1.600.000,00 | 21/03/2027 (PNCP) | 135 |
| 2024010698 | INEA | IMAGEM GEOSISTEMAS E COMÉRCIO LTDA | serviços de manutenção de licenças de software em sua última versão, … | R$ 1.996.346,46 | 31/03/2027 (PNCP) | 145 |
| 2025002216 | INEA | COMÉRCIO IMPORTAÇÃO E EXPORTAÇÃO 3 IRMÃOS LT… | Tem por finalidade apresentar critérios norteadores para viabilizar a… | R$ 474.776,15 | 04/04/2027 | 149 |
| 2026002433 | SEAS | CONSORCIO CENTRO SUL 1 | Definição das regras e dos critérios de participação do CONTRATANTE j… | R$ 1.401.595,74 | 15/04/2027 (PNCP) | 160 |
| 2026002877 | SEAS | CONSORCIO INT.DE GES. DE RES. SOL. DO VALE C… | O presente CONTRATO DE RATEIO tem por objeto a definição das regras e… | R$ 1.766.445,48 | 15/04/2027 (PNCP) | 160 |
| 2026008780 | SEAS | GPS REPRESENTAÇOES COMERCIO E SERVIÇOS LTDA | Aquisição de aparelhos de ar-condicionado, com tecnologia Inverter e … | R$ 15.545,00 | 19/04/2027 | 164 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2023004812 | UEPSAM | CONSTRUVERDE CONSTRUCOES E SERVICOS EIRELI | Execução das Obras e Serviços de Engenharia, objetivando, complementa… | R$ 55.285.113,16 | 30/12/2024 | -676 |
| 2023002225 | SEAS | VOLUME PARTICIPACOES, PRODUCOES E EVENTOS LT… | O objeto da presente licitação é a escolha da proposta mais vantajosa… | R$ 37.008.423,50 | 16/03/2026 | -235 |
| 2024002818 | INEA | SERPEN SERVIÇOS E PROJETOS DE ENGENHARIA LTDA | Gerenciamento de Riscos com Implantação de Sistemas Tecnológicos de M… | R$ 26.445.000,00 | 20/09/2026 | -47 |
| 2024008375 | INEA | ERWIL CONSTRUÇÃO LTDA | OBRAS DE DESOBSTRUÇÃO DO CANAL DA BARRA FRANCA DE SAQUAREMA | R$ 10.984.901,28 | 20/08/2026 (PNCP) | -78 |
| 2025005346 | SEAS | MMAR MONTAGENS EVENTOS E PROGRAMACAO VISUAL … | Contratação de prestação de serviço para disponibilização de 3.370 m²… | R$ 7.009.600,00 | 18/11/2025 (PNCP) | -353 |
| 2024007574 | INEA | FLYONE SERVIÇO AÉREO ESPECIALIZADO COMÉRCIO … | LOCAÇÃO DE AERONAVES DE ASA ROTATIVA, SOB DEMANDA, INCLUÍDA LOGÍSTICA… | R$ 6.500.000,00 | 16/09/2025 (PNCP) | -416 |
| 2023003718 | SEAS | TRIAL (RIO) TECNOLOGIA AMBIENTAL LTDA | Contratação de empresa especializada pararealização de auditoria inde… | R$ 6.278.400,00 | 01/03/2025 | -615 |
| 2025007656 | SEAS | EMPRESAS PADILHA LTDA | Aquisição de veículos do tipo pick-up 4x4 (caminhonete), Drone e kit … | R$ 5.750.000,00 | 16/10/2026 (PNCP) | -21 |
| 2023011079 | SEAS | PREFEITURA MUNICIPAL DE TERESÓPOLIS | formaliação de Convênio entre a SEAS e o Município de Teresópolis no … | R$ 2.700.000,00 | 29/12/2024 | -677 |
| 2024007933 | INEA | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | Contratação de serviço de hospedagem em Servidores Virtuais Privados … | R$ 2.167.419,72 | 01/10/2026 (PNCP) | -36 |
| 2025006580 | SEAS | ESFERA BRASIL LTDA | Patrocínio do evento Brasil Hoje 2025 - Sustentabilidade como estraté… | R$ 2.100.000,00 | 06/01/2026 (PNCP) | -304 |
| 2025005458 | SEAS | CONSORCIO CENTRO SUL 1 | Contrato de rateio celebrado entre Seas e o Consórcio Centro Sul i, q… | R$ 1.773.144,21 | 20/08/2026 (PNCP) | -78 |
| 2024008834 | SEAS | CONSORCIO CENTRO SUL 1 | Definição das regras e dos critérios de participação do CONTRATANTE j… | R$ 1.707.178,10 | 06/08/2025 (PNCP) | -457 |
| 2016001856 | INEA | EDSON APARECIDO DOS SANTOS | Locação do Imóvel | R$ 1.591.476,85 | 01/12/2025 | -340 |
| 2025005720 | SEAS | CONSORCIO INT.DE GES. DE RES. SOL. DO VALE C… | Contrato de Rateio entre a SEAS e o CONVALE que tem por objeto a defi… | R$ 1.438.792,34 | 20/08/2026 (PNCP) | -78 |
| 2024009360 | SEAS | CONSORCIO INT.DE GES. DE RES. SOL. DO VALE C… | Definição das regras e dos critérios de participação do CONTRATANTE j… | R$ 1.430.424,89 | 07/08/2025 (PNCP) | -456 |
| 2024010420 | SEAS | ASSOCIAÇÃO BRASILEIRA DE NORMAS TÉCNICAS-ABNT | Contratação de empresa especializada em normalização e certificação p… | R$ 1.093.250,00 | 21/03/2026 (PNCP) | -230 |
| 2025005275 | SEAS | EDITORA A NOTICIA LTDA | Contratação de quota de patrocínio para viabilizar a participação ins… | R$ 1.000.000,00 | 18/11/2025 (PNCP) | -353 |
| 2025009602 | SEAS | CEMAFER PRODUÇÕES LTDA | Patrocínio do evento Seminário Integra RJ, que tem como tema a despol… | R$ 1.000.000,00 | 16/04/2026 (PNCP) | -204 |
| 2026001907 | SEAS | CEMAFER PRODUÇÕES LTDA | Patrocínio do Seminário Integra RJ - Meio Ambiente e Sustentabilidade… | R$ 1.000.000,00 | 14/06/2026 (PNCP) | -145 |
| 2024005007 | INEA | LEDATH COMERCIO E REPRESENTAÇÃO EIRELI | Aquisição de frutas, legumes, verduras e outros alimentos utilizadas … | R$ 999.997,60 | 08/07/2025 (PNCP) | -486 |
| 2025007655 | SEAS | B&A COMERCIO DE EPIS EIRELI | Aquisição de veículos do tipo pick-up 4x4 (caminhonete), Drone e kit … | R$ 847.000,00 | 16/10/2026 (PNCP) | -21 |
| 2024005008 | SEAS | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | SERVICO DE AQUISICAO DE PASSAGENS AEREAS,DESCRIÇÃO: PRESTAÇÃO DE SERV… | R$ 843.750,00 | 03/07/2025 | -491 |
| 2025009330 | SEAS | GREEN RIO TEC LTDA | contratação de cota de patrocínio para realização dos eventos Green R… | R$ 800.000,00 | 25/08/2026 (PNCP) | -73 |
| 2025007657 | SEAS | A CASA LICITA LTDA | Aquisição de veículos do tipo pick-up 4x4 (caminhonete), Drone e kit … | R$ 747.000,00 | 16/10/2026 (PNCP) | -21 |
| 2025001117 | SEAS | LEDATH COMERCIO E REPRESENTAÇÃO EIRELI | Contratação de empresas para aquisição de placas de sinalização, equi… | R$ 743.981,70 | 21/05/2025 (PNCP) | -534 |
| 2025006798 | SEAS | DORIA ADMINISTRAÇÃO E EVENTOS LTDA | Contratação de cota de patrocínio para a participação da Secretaria d… | R$ 669.000,00 | 07/12/2025 (PNCP) | -334 |
| 2025003233 | SEAS | DORIA ADMINISTRAÇÃO E EVENTOS LTDA | Contratação de cota de patrocínio institucional para participação da … | R$ 636.000,00 | 26/08/2025 (PNCP) | -437 |
| 2025007658 | SEAS | MARCOPOLO S.A. | Aquisição de veículos do tipo pick-up 4x4 (caminhonete), Drone e kit … | R$ 559.990,00 | 16/10/2026 (PNCP) | -21 |
| 2024009770 | INEA | RC CARD SOLUCOES EM PAGAMENTOS LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇOS DE EMIS… | R$ 528.000,00 | 02/12/2025 (PNCP) | -339 |

_Registros mais antigos (provável falta de baixa no SIGA): 241, R$ 475,7 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 20)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026002405 | SEAS | HYDRA ENGENHARIA E SANEAMENTO LTDA | Complementação das Obras de Implantação do Sistema de Esgotamento San… | R$ 193.333.333,33 | 15/10/2028 | 709 |
| 2026002404 | SEAS | HYDRA ENGENHARIA E SANEAMENTO LTDA | Complementação das Obras de Implantação do Sistema de Esgotamento San… | R$ 190.301.178,17 | 15/10/2028 | 709 |
| 2024007130 | INEA | PRESTAR SERVICOS DE LIMPEZA E CONSERVACAO LT… | Contratação de pessoa jurídica para gerenciamento e execução de servi… | R$ 80.908.294,56 | 04/10/2027 (PNCP) | 332 |
| 2024010060 | SEAS | ESCRITORIO REGIONAL DO HABITAT PARA A AMERIC… | Celebração do Acordo de Coooperação Técnica internacional a ser celeb… | R$ 34.362.000,70 | 12/11/2028 | 737 |
| 2026000232 | SEAS | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | Licitação na modalidade Pregão Eletrônico para a contratação da prest… | R$ 18.111.139,08 | 26/01/2027 (PNCP) | 81 |
| 2026000234 | SEAS | NEVADADISTRIBUIDORA E TRANSPORTADORA LTDA | Licitação na modalidade Pregão Eletrônico para a contratação da prest… | R$ 18.040.736,16 | 26/01/2027 (PNCP) | 81 |
| 2026000231 | SEAS | JH SERVICOS E MANUTENCAO LTDA | Licitação na modalidade Pregão Eletrônico para a contratação da prest… | R$ 18.008.516,64 | 27/01/2027 (PNCP) | 82 |
| 2022010302 | SEAS | FUNDACAO PARQUES E JARDINS | Tratase de convênio celebrado entre o Estado do Rio de Janeiro por in… | R$ 15.000.000,00 | 31/12/2026 | 55 |
| 2026000229 | SEAS | FXS ENGENHARIA LTDA | Licitação na modalidade Pregão Eletrônico para a contratação da prest… | R$ 14.445.955,41 | 26/01/2027 (PNCP) | 81 |
| 2026000230 | SEAS | MSL PRESTACAO DE SERVICOS LTDA | Licitação na modalidade Pregão Eletrônico para a contratação da prest… | R$ 13.872.193,08 | 26/01/2027 (PNCP) | 81 |
| 2026000233 | SEAS | ENGEBIO ENGENHARIA DO MEIO AMBIENTE LTDA | Licitação na modalidade Pregão Eletrônico para a contratação da prest… | R$ 13.871.068,56 | 26/01/2027 (PNCP) | 81 |
| 2025000357 | INEA | MOBILIZA FOR RENT LTDA | Locação de 60 (sessenta) veículos automotores (sendo 40 - tipo: pick-… | R$ 13.692.840,00 | 27/01/2027 (PNCP) | 82 |
| 2025010336 | INEA | 2R DATATEL TELEINFORMÁTICA LTDA | Aquisição de dois Appliance Firewall Tipo 1, dois Console de Gerencia… | R$ 12.624.000,00 | 10/12/2026 (PNCP) | 34 |
| 2025000013 | SEAS | FUNDAÇÃO COORDENAÇÃO DE PROJETOS, PESQUISAS … | Contratação direta para desenvolver e operar a Plataforma Digital Ope… | R$ 6.868.213,14 | 21/07/2028 | 623 |
| 2025003400 | INEA | MGS CLEAN SOLUÇÕES E SERVIÇOS LTDA | Contratação de empresa para a prestação de serviço de limpeza, asseio… | R$ 6.506.972,72 | 19/05/2027 | 194 |
| 2025009272 | SEAS | VCS IMPLEMENTOS E VEÍCULOS LTDA | Aquisição de veículos do tipo pick-up 4x4 (caminhonete). | R$ 5.660.000,00 | 19/11/2026 (PNCP) | 13 |
| 2024010546 | INEA | SIMTECH REPRESENTAÇÕES LTDA. | Contratação de empresa especializada para Manutenção e Suporte Técnic… | R$ 4.537.380,00 | 23/12/2029 (PNCP) | 1143 |
| 2024004298 | SEAS | FUNDAÇÃO COORDENAÇÃO DE PROJETOS, PESQUISAS … | CONTRATAÇÃO DE CONSULTORIA TÉCNICA ESPECIALIZADA PARA ELABORAÇÃO DAS … | R$ 4.000.000,00 | 16/11/2027 | 375 |
| 2024007892 | SEAS | FUNDAÇÃO UNIVERSITÁRIA JOSE BONIFACIO | CONTRATAÇÃO DE CONSULTORIA TÉCNICA ESPECIALIZADA PARA ELABORAÇÃO DAS … | R$ 4.000.000,00 | 19/05/2027 | 194 |
| 2026009283 | SEAS | LECARD ADMNISTRADORA DE CARTÕES LTDA | Contratação de serviços de confecção, fornecimento e administração de… | R$ 2.856.568,00 | 04/11/2027 | 363 |

## 7. Fornecedores em recuperação judicial
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000232 | SEAS | CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO … | Licitação na modalidade Pregão Eletrônico para a contratação da prest… | R$ 18.111.139,08 | 26/01/2027 (PNCP) | 81 |

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| HYDRA ENGENHARIA E SANEAMENTO LTDA | 2 | R$ 383.634.511,50 |
| PRESTAR SERVICOS DE LIMPEZA E CONSERVACAO LTDA | 1 | R$ 80.908.294,56 |
| ESCRITORIO REGIONAL DO HABITAT PARA A AMERICA LATINA E O CA… | 1 | R$ 34.362.000,70 |
| CONSTRUTORA LYTORANEA LTDA - EM RECUPERACAO JUDICIAL | 1 | R$ 18.111.139,08 |
| NEVADADISTRIBUIDORA E TRANSPORTADORA LTDA | 1 | R$ 18.040.736,16 |
| JH SERVICOS E MANUTENCAO LTDA | 1 | R$ 18.008.516,64 |
| FUNDACAO PARQUES E JARDINS | 1 | R$ 15.000.000,00 |
| FXS ENGENHARIA LTDA | 1 | R$ 14.445.955,41 |
| MSL PRESTACAO DE SERVICOS LTDA | 1 | R$ 13.872.193,08 |
| ENGEBIO ENGENHARIA DO MEIO AMBIENTE LTDA | 1 | R$ 13.871.068,56 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2020000995 | CONSTRUTORA PASSARELLI LTDA. | R$ 91.344.944,50 | R$ 80.122.147,57 | R$ 11.222.796,93 |
| 2021000325 | CONSTRUTORA PASSARELLI LTDA. | R$ 44.587.106,26 | R$ 33.367.597,23 | R$ 11.219.509,03 |
| 2021003679 | PREFEITURA MUNICIPAL DE PARATY | R$ 15.194.100,54 | R$ 12.001.277,16 | R$ 3.192.823,38 |
| 2018007127 | CONSORCIO SONDOTECNICA-COBRAPE-CH2M | R$ 31.627.927,90 | R$ 30.470.088,49 | R$ 1.157.839,41 |
| 2022001975 | CONSORCIO CENTRO SUL 1 | R$ 567.315,26 | R$ 0,00 | R$ 567.315,26 |
| 2016002573 | CONSORCIO INT.DE GES. DE RES. SOL. DO VALE C… | R$ 911.921,40 | R$ 395.958,24 | R$ 515.963,16 |
| 2016005533 | CONSORCIO PASSARINHO | R$ 431.826,04 | R$ 0,00 | R$ 431.826,04 |
| 2023003782 | CONSTRUTORA BRASFORM LTDA | R$ 368.811,68 | R$ 0,00 | R$ 368.811,68 |
| 2016006173 | CONSORCIO CENTRO SUL 1 | R$ 300.000,00 | R$ 0,00 | R$ 300.000,00 |
| 2016001856 | EDSON APARECIDO DOS SANTOS | R$ 1.337.438,71 | R$ 1.145.126,61 | R$ 192.312,10 |
| 2016003937 | ASSOCIAÇÃO PRÓ-GESTÃO DE ÁGUAS DA BACIA HIDR… | R$ 170.000,00 | R$ 0,00 | R$ 170.000,00 |
| 2022001974 | CONSORCIO INT.DE GES. DE RES. SOL. DO VALE C… | R$ 252.890,07 | R$ 168.593,38 | R$ 84.296,69 |
| 2023003572 | NP COMÉRCIO E REPRESENTAÇÕES LTDA | R$ 233.691,90 | R$ 153.373,90 | R$ 80.318,00 |
| 2022007910 | CAMARA DE COMERCIO E INDUSTRIA DO ESTADO DO … | R$ 17.600,00 | R$ 0,00 | R$ 17.600,00 |
| 2023006503 | HADDAD RENT A CAR LOCADORA LTDA | R$ 30.096,00 | R$ 18.369,79 | R$ 11.726,21 |
| 2020000810 | SUDESTE BRASIL COOPERATIVA DE TRANSPORTES | R$ 1.079.755,26 | R$ 1.072.165,78 | R$ 7.589,48 |
| 2022010333 | BETA-I BRASIL CONSULTORIA EM INOVAÇÃO EMPRES… | R$ 469.000,00 | R$ 463.555,00 | R$ 5.445,00 |
| 2023003780 | HYDRA ENGENHARIA E SANEAMENTO LTDA | R$ 547.933,92 | R$ 544.535,05 | R$ 3.398,87 |
| 2019004120 | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | R$ 2.100,00 | R$ 0,00 | R$ 2.100,00 |
| 2018006938 | DSCON SOLUÇÕES TECNOLOGICAS LTDA | R$ 198.343,21 | R$ 196.541,39 | R$ 1.801,82 |

## 11. Unidades incluídas neste dossiê
- FUNDRHI - FUNDO ESTADUAL DE RECURSOS HÍDRICOS
- INEA - INSTITUTO ESTADUAL DO AMBIENTE
- SEAS - SEC DE EST DO AMBIENT E SUSTENTABILIDADE
- UEPSAM - Unidade Executora do PSAM

## 12. Conjuntos de dados abertos da secretaria
- Plano de Dados Abertos (PDA) da Secretaria de Estado do Ambiente e Sustentabilidade (SEAS) 2025-2027 (atualizado 2025-10-27): [Plano de Dados Abertos da SEAS 2025-2027 PDF](https://dadosabertos.rj.gov.br/dataset/9f023074-d936-4ef6-9fec-e3302d0574c5/resource/8a0e8cb4-3773-4ef0-b180-7822c03c1e83/download/plano-de-dados-abertos-da-seas-2025-2027.pdf)
- ICMS Ecológico e Gestão da Mata Atlântica no Estado do RJ (atualizado 2025-09-21): [1. Manual de uso do observatório do ICM… PDF](https://dadosabertos.rj.gov.br/dataset/57909e30-ed10-4aa6-a140-25fb36d72a27/resource/94d61f03-310a-44c3-b400-4d43e357ecb8/download/manual-de-uso-do-observatorio-do-icms-ecologico-do-estado-do-rio-de-janeiro.pdf), [2. Projeto Conexão Mata Atlântica PDF](https://dadosabertos.rj.gov.br/dataset/57909e30-ed10-4aa6-a140-25fb36d72a27/resource/23fa42e2-d56f-4475-b219-757c48c7e3fb/download/projeto-conexao-mata-atlantica.pdf), [3. Planos municipais da Mata Atlântica: PDF](https://dadosabertos.rj.gov.br/dataset/57909e30-ed10-4aa6-a140-25fb36d72a27/resource/5cbe9966-a3c1-43ea-8770-5c559fa0ac8a/download/plano-municipal-da-mata-atlantica-estado-do-rio-de-janeiro.pdf)
- Gestão de Resíduos Sólidos, Reciclagem e Inclusão Socioambiental (atualizado 2025-09-21): [Progride: Documento-base e Plano de Açã… PDF](https://dadosabertos.rj.gov.br/dataset/4eb42e5a-718d-498d-8bbb-f235be2e06e7/resource/8c219682-c673-4473-85c7-9cb139c17d5e/download/documento-base-e-plano-de-acao-do-programa.pdf), [Estratégia Estadual de Enfrentamento ao… PDF](https://dadosabertos.rj.gov.br/dataset/4eb42e5a-718d-498d-8bbb-f235be2e06e7/resource/0478751e-40b6-4f61-856c-310dda4929f4/download/estrategia-estadual-de-enfrentamento-ao-lixo-no-mar.pdf), [MANUAL-DE ORIENTAÇÕES SOBRE RECICLAGEM … PDF](https://dadosabertos.rj.gov.br/dataset/4eb42e5a-718d-498d-8bbb-f235be2e06e7/resource/e4601448-3fcb-4b32-923d-023cb2a5b6e7/download/manual-de-orientacoes-sobre-reciclagem-de-lixo.pdf), [Cadastro Estadual de Organizações de Ca… XLSX](https://dadosabertos.rj.gov.br/dataset/4eb42e5a-718d-498d-8bbb-f235be2e06e7/resource/349ee4b3-56f0-4114-8914-b6dd45940fd0/download/acordos-de-cooperacao-tecnica.xlsx)
- Editais de Licitações (atualizado 2025-09-21): [Editais de Licitações - 1º quadrimestre… XLSX](https://dadosabertos.rj.gov.br/dataset/d7400860-3a04-4978-81b8-71e8c323428b/resource/f2f7909d-f31a-49a9-ab58-d3786a8ef2a6/download/editaislicitacoes-1-quadrimestre-dse-2025.xls)
- Composição do Conselho Superior do FECAM (atualizado 2025-09-21): [1. Composição do Conselho Superior do F… PDF](https://dadosabertos.rj.gov.br/dataset/afda3265-1e6a-444f-b115-4097eb060f5c/resource/dd4a5177-9ef9-4872-a43b-f9ae84099299/download/composicao-conselho-superior-do-fecam.pdf)
- Obras e Projetos do Programa de Saneamento Ambiental – PSAM (atualizado 2025-09-21): [Obras e Projetos – PSAM PDF](https://dadosabertos.rj.gov.br/dataset/41a38828-8f84-4137-b410-92e1bd376eca/resource/9c0de84b-3030-484e-b3b0-0eff5d25ec54/download/obras-e-projetos-psam.pdf)
- Plano de Integridade da Secretaria de Estado do Ambiente e Sustentabilidade – SEAS (atualizado 2025-09-21): [PLANO DE INTEGRIDADE DA SEAS PDF](https://dadosabertos.rj.gov.br/dataset/4280b438-8825-4d24-be2b-eaeefd854e04/resource/c9f465f4-e3f8-430a-897a-29a5200f36de/download/plano-de-integridade-da-seas.pdf)
- Acordos de Cooperação Técnica firmados entre a SEAS e Entidades Públicas e Privadas (atualizado 2025-09-21): [Acordos de Cooperação Técnica firmados … XLSX](https://dadosabertos.rj.gov.br/dataset/f511e9bb-c108-4b9b-ae84-81ce6797bd77/resource/9b0ea0c0-d78f-42f6-b05f-0f0a182943cb/download/relacao-dos-acordos-e-convenios.xlsx)
- Painel de Recursos Humanos (atualizado 2025-09-21): [Painel RH RJ-junho2025.pdf PDF](https://dadosabertos.rj.gov.br/dataset/a0a03f09-28a4-48d1-abad-4020775f146c/resource/0c2e9b79-b9b9-4aee-b5b6-38c05b2d2b86/download/painel-rh-rj-jun2025.pdf)
- Contratos de Aquisições e Serviços SEAS - 2025 (atualizado 2025-09-21): [Contratos aquisições e serviços - SEAS … PDF](https://dadosabertos.rj.gov.br/dataset/e36d01be-386c-4914-9a40-830ea4e76191/resource/3e52a120-8192-4cab-884b-8cffe243cf76/download/contratos-seas.pdf)
- Lei Orçamentária - SEAS 2025 (atualizado 2025-09-21): [Lei Orçamentária SEAS -2025 PDF](https://dadosabertos.rj.gov.br/dataset/8b570930-957d-4be8-92a5-29b65096b4bf/resource/24906d4a-8db0-447c-aa08-9c50e14a47d9/download/livro_loa_2025_-_volume_ii-264-281.pdf)
- Plano Plurianual – SEAS 2025 (Revisão PPA 2024-2027) (atualizado 2025-09-21): [PPA 2024-2025 revisão 2025-SEAS.pdf PDF](https://dadosabertos.rj.gov.br/dataset/cad8c34d-efac-4702-b0be-5aa531bd38f6/resource/6e8b1f2f-b3de-483b-8426-2941ec19fa39/download/ppa-2024-2025-revisao-2025-seas.pdf)
- Relatórios de Auditoria (atualizado 2025-09-21): [PLANAT 2023.pdf PDF](https://dadosabertos.rj.gov.br/dataset/d3c88c51-3521-4a3e-9c50-b99c9e68f040/resource/9ec86809-f6fe-4bde-afbf-35094a8d7e4f/download/planat-2023.pdf), [RANAT-2023 SEAS.pdf PDF](https://dadosabertos.rj.gov.br/dataset/d3c88c51-3521-4a3e-9c50-b99c9e68f040/resource/3d2ba879-8459-4721-a0a2-d088be2abc10/download/ranat-2023-seas.pdf), [RELATORIO DE AUDITORIA PCA 2023 PDF](https://dadosabertos.rj.gov.br/dataset/d3c88c51-3521-4a3e-9c50-b99c9e68f040/resource/32998e7f-55b7-403b-a377-42118b5a1f88/download/seas_relatorio_de_auditoria_pca_2023___com_parecer_assinado.pdf)
- Relatórios de atividades da Ouvidoria da SEAS - 2024 e 2025 (atualizado 2025-09-21): [2025 - 1º Trimestre PDF](https://dadosabertos.rj.gov.br/dataset/542a5ce2-8653-43d8-8485-6fff029cbe66/resource/f0697ea4-c5ff-4819-baa4-a0e0fbd53cc1/download/relatorio-1-trimestre-de-2025.pdf), [2024 - 4º trimestre PDF](https://dadosabertos.rj.gov.br/dataset/542a5ce2-8653-43d8-8485-6fff029cbe66/resource/8e88c6fd-d045-48e5-a3b8-8e4dd9911e75/download/relatorio-4-trimestre-de-2024.pdf), [2024 - 3º trimestre PDF](https://dadosabertos.rj.gov.br/dataset/542a5ce2-8653-43d8-8485-6fff029cbe66/resource/9bf97684-fa1f-4620-ae07-0d3c282cd7b0/download/relatorio-3-trimestre-de-2024.pdf), [2024 - 2º trimestre PDF](https://dadosabertos.rj.gov.br/dataset/542a5ce2-8653-43d8-8485-6fff029cbe66/resource/a1e365d5-90b1-4b89-a2e7-0351514b46de/download/relatorio-2-trimestre-de-2024.pdf)

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 8 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo

- O TCE-RJ determinou a retenção de R$ 3.693.431,29 em parcelas do contrato nº 024/2024 do INEA, após auditoria apontar indícios de sobrepreço e divergência entre trabalhadores pagos e efetivamente disponibilizados; o estado atual do cumprimento da decisão não consta nas fontes. [TCE-RJ bloqueia R$ 3,6 milhões](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/)
- A parceria de R$ 23 milhões do projeto Conexão Ambiental foi alvo de suspensão pelo TCE-RJ por indícios de irregularidades; o G1 informa que a contratação não foi concluída e o convênio não foi firmado. [TCE-RJ suspende parceria](https://temporealrj.com/tce-rj-mira-parceria-de-r-23-milhoes/) [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml)
- A obra de macrodrenagem dos rios Registro e Viegas seguia em execução em novembro de 2026, embora a previsão original de conclusão fosse janeiro de 2024; o INEA aplicou multa de R$ 4.989.669,69 à contratada. [Inea pune a Construtora Metropolitana](https://clickpetroleoegas.com.br/quase-r-5-milhoes-de-multa-20-do-que-faltava-pagar-inea-pune-a-construtora-metropolitana-responsavel-por-obra-contra-enchentes-na-zona-oeste-do-rio-que-tinha-previsao-de-btl96-mhbb01/)
- A gestão recente inclui substituição de dirigentes do INEA por servidores de carreira e reestruturação da SEAS; as fontes não confirmam como essas mudanças afetaram a continuidade dos serviços. [O Dia: mudanças no Inea](https://odia.ig.com.br/rio-de-janeiro/2026/05/7245885-governador-interino-do-rio-substitui-toda-a-direcao-do-inea-por-servidores-de-carreira.html) [Decreto nº 50.330](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/06/9-DECRETO-No-50.329-DE-12-DE-JUNHO-DE-2026-SEPPEN.pdf)

##### Alertas vermelhos

- **Contrato do INEA sob cautelar:** o TCE-RJ determinou bloqueio de R$ 3.693.431,29 nas próximas parcelas do contrato nº 024/2024, de valor estimado em R$ 80.908.294,56 e vigência de 36 meses; a decisão apontou risco de continuidade de dano aos cofres públicos enquanto prosseguissem os pagamentos mensais. [TCE-RJ bloqueia R$ 3,6 milhões](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/)
- **Conexão Ambiental suspenso:** o TCE-RJ determinou a suspensão das relações formais entre a SEAS e o Instituto Chaya e apontou indícios como falta de chamamento público, ausência de publicação no Portal da Transparência e possível uso irregular de termo de convênio; a contratação não foi concluída, segundo o G1. [TCE-RJ suspende parceria](https://temporealrj.com/tce-rj-mira-parceria-de-r-23-milhoes/) [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml)
- **Obra de drenagem atrasada e ainda em execução:** a macrodrenagem tinha previsão de conclusão total em janeiro de 2024 e continuava em execução em novembro de 2026; em 2025, ainda faltava o reservatório de amortecimento de cheias, descrito como essencial ao funcionamento completo do sistema. [Inea pune a Construtora Metropolitana](https://clickpetroleoegas.com.br/quase-r-5-milhoes-de-multa-20-do-que-faltava-pagar-inea-pune-a-construtora-metropolitana-responsavel-por-obra-contra-enchentes-na-zona-oeste-do-rio-que-tinha-previsao-de-btl96-mhbb01/)
- **Investigação criminal envolvendo ex-dirigentes do INEA:** o Ministério Público do Rio realizou operação que teve como alvos ex-dirigentes do Instituto e integrantes da CECA; 11 pessoas são investigadas por suspeitas de corrupção em processos de licenciamento ambiental, sem que a fonte informe desfecho ou denúncias oferecidas. [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml)

##### Contratos e serviços críticos

- O contrato nº 024/2024 do INEA com a Prestar Serviços de Limpeza e Conservação Ltda. foi assinado em setembro de 2024, tem valor estimado de R$ 80.908.294,56 e vigência de 36 meses, para serviços de apoio à conservação da biodiversidade, gestão ambiental e monitoramento de unidades de conservação estaduais. [TCE-RJ bloqueia R$ 3,6 milhões](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/)
- A auditoria do TCE-RJ apontou, como irregularidades ou indícios a apurar, BDI supostamente acima dos parâmetros indicados pelo Tribunal, cálculo tributário sem exigência da média efetivamente recolhida nos 12 meses anteriores, pagamento por quantidade de trabalhadores superior à disponibilizada e possível não repasse integral de reajuste salarial de 7,50% aos Agentes de Defesa Ambiental. [TCE-RJ bloqueia R$ 3,6 milhões](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/)
- O Tribunal determinou que o INEA use salários de referência corrigidos nas futuras medições e confira a quantidade de trabalhadores em campo antes de liberar parcelas; a presidente do INEA recebeu prazo de 15 dias para esclarecimentos e para, voluntariamente, promover termo aditivo de reequilíbrio econômico-financeiro. [TCE-RJ bloqueia R$ 3,6 milhões](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/)
- A obra de macrodrenagem dos rios Registro e Viegas, em Bangu e Senador Camará, está a cargo da Construtora Metropolitana S.A., no contrato nº 41/2021-INEA; o saldo contratual informado é R$ 24.948.348,43 e o valor atualizado do contrato é R$ 120.071.124,96. [Inea pune a Construtora Metropolitana](https://clickpetroleoegas.com.br/quase-r-5-milhoes-de-multa-20-do-que-faltava-pagar-inea-pune-a-construtora-metropolitana-responsavel-por-obra-contra-enchentes-na-zona-oeste-do-rio-que-tinha-previsao-de-btl96-mhbb01/)
- Em 26/10/2026, o INEA determinou multa de R$ 4.989.669,69 à Construtora Metropolitana, equivalente a 20% do saldo contratual; o ato não especificou as obrigações descumpridas nem estabeleceu relação direta com os indícios investigados pelo TCE-RJ. [Inea pune a Construtora Metropolitana](https://clickpetroleoegas.com.br/quase-r-5-milhoes-de-multa-20-do-que-faltava-pagar-inea-pune-a-construtora-metropolitana-responsavel-por-obra-contra-enchentes-na-zona-oeste-do-rio-que-tinha-previsao-de-btl96-mhbb01/)
- O projeto Conexão Ambiental previa R$ 23 milhões e cerca de R$ 17 milhões em repasses ainda naquele ano para contratar aproximadamente 360 profissionais em 60 núcleos; o G1 informa que a contratação não foi concluída e o convênio não foi firmado, enquanto o TCE-RJ determinou a suspensão das relações formais com o Instituto Chaya. [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml) [TCE-RJ suspende parceria](https://temporealrj.com/tce-rj-mira-parceria-de-r-23-milhoes/)
- **Risco de interrupção de serviços:** A fonte sobre a obra informa que ela seguia em execução, mas registra que a construtora pediu a suspensão dos serviços até uma decisão definitiva do tribunal, enquanto a fiscalização do Inea se posicionou contra a paralisação. Já a fonte sobre o contrato do INEA com a Prestar trata de risco de dano ao erário, sem informar risco de interrupção dos serviços ambientais. [Inea pune a Construtora Metropolitana](https://clickpetroleoegas.com.br/quase-r-5-milhoes-de-multa-20-do-que-faltava-pagar-inea-pune-a-construtora-metropolitana-responsavel-por-obra-contra-enchentes-na-zona-oeste-do-rio-que-tinha-previsao-de-btl96-mhbb01/) [TCE-RJ bloqueia R$ 3,6 milhões](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)

- **TCE-RJ — contrato nº 024/2024:** a decisão cautelar foi monocrática, do conselheiro José Gomes Graciosa, baseada em auditoria da CAD-SANEAMENTO; a empresa foi notificada e poderá apresentar defesa, mas as fontes não informam se houve manifestação, decisão posterior ou situação atual do bloqueio. [TCE-RJ bloqueia R$ 3,6 milhões](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/)
- **TCE-RJ — Conexão Ambiental:** o secretário da SEAS foi notificado para prestar esclarecimentos em 15 dias, e o Instituto Chaya também poderia se manifestar; o projeto permaneceria suspenso até o Tribunal decidir seu destino. As fontes não informam o resultado dessas manifestações nem decisão final. [TCE-RJ suspende parceria](https://temporealrj.com/tce-rj-mira-parceria-de-r-23-milhoes/)
- O G1 informa que o ex-secretário Bernardo Rossi foi intimado pelo TCE-RJ em março a prestar esclarecimentos sobre o convênio e, segundo o Tribunal, não respondeu; o atual secretário Rodrigo Mascarenhas e o Instituto Chaya receberam prazo de 15 dias para se manifestar. [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml)
- **MPRJ/Ministério Público:** há notícia de operação do Ministério Público do Rio e investigação de 11 pessoas por suspeitas de corrupção em licenciamentos ambientais envolvendo ex-dirigentes do INEA e integrantes da CECA; Nada encontrado nas fontes consultadas sobre denúncia criminal oferecida, ação judicial ou decisão judicial nesse caso. [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml)
- **Judiciário:** Nada encontrado nas fontes consultadas sobre ações judiciais relacionadas aos contratos, à parceria ou à gestão da SEAS e do INEA. [O Dia: mudanças no Inea](https://odia.ig.com.br/rio-de-janeiro/2026/05/7245885-governador-interino-do-rio-substitui-toda-a-direcao-do-inea-por-servidores-de-carreira.html) [Rio busca virar página na área ambiental](https://valor.globo.com/brasil/noticia/2026/10/08/rio-busca-virar-pagina-na-area-ambiental-com-gestao-tecnica-e-novos-regramentos.ghtml)

##### Riscos de apagão administrativo

- Em maio de 2026, foram abrangidos 12 cargos de liderança do INEA, incluindo vice-presidência, chefia de gabinete e toda a direção, com previsão de ocupação por servidores de carreira e perfil técnico; as fontes não informam se houve vacâncias, perda de capacidade operacional ou interrupção de atividades. [O Dia: mudanças no Inea](https://odia.ig.com.br/rio-de-janeiro/2026/05/7245885-governador-interino-do-rio-substitui-toda-a-direcao-do-inea-por-servidores-de-carreira.html)
- Desde março, a gestão atual da SEAS informou ter exonerado 250 servidores apontados como funcionários fantasmas; segundo o secretário, parte ocupava cargos e recebia salários sem exercer as funções, mas as fontes não detalham efeitos sobre equipes, processos ou serviços. [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml)
- O Decreto nº 50.330, de 12/06/2026, alterou e consolidou a estrutura organizacional da SEAS sem aumento de despesa e previu mudanças em unidades administrativas; as fontes consultadas não descrevem o cronograma de implantação, as funções ainda não preenchidas ou os impactos na operação. [Decreto nº 50.330](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/06/9-DECRETO-No-50.329-DE-12-DE-JUNHO-DE-2026-SEPPEN.pdf)
- A gestão da SEAS declarou estar reformulando o sistema de licenciamento e apostando em servidores de carreira para fortalecer decisões técnicas; as fontes não especificam prazos, etapas, quadro de pessoal ou indicadores de continuidade dos processos. [Rio busca virar página na área ambiental](https://valor.globo.com/brasil/noticia/2026/10/08/rio-busca-virar-pagina-na-area-ambiental-com-gestao-tecnica-e-novos-regramentos.ghtml)
- Nada encontrado nas fontes consultadas que confirme apagão administrativo ou interrupção efetiva de serviços da SEAS ou do INEA. [O Dia: mudanças no Inea](https://odia.ig.com.br/rio-de-janeiro/2026/05/7245885-governador-interino-do-rio-substitui-toda-a-direcao-do-inea-por-servidores-de-carreira.html) [Rio busca virar página na área ambiental](https://valor.globo.com/brasil/noticia/2026/10/08/rio-busca-virar-pagina-na-area-ambiental-com-gestao-tecnica-e-novos-regramentos.ghtml)

##### Fatos recentes

- **05/05/2026:** o governador em exercício Ricardo Couto determinou mudanças em 12 cargos de liderança do INEA, que passariam a ser ocupados exclusivamente por profissionais de carreira e perfil técnico. [O Dia: mudanças no Inea](https://odia.ig.com.br/rio-de-janeiro/2026/05/7245885-governador-interino-do-rio-substitui-toda-a-direcao-do-inea-por-servidores-de-carreira.html)
- **12/06/2026, com publicação em 15/06/2026:** o Decreto nº 50.330 alterou e consolidou a estrutura da SEAS sem aumento de despesa e estabeleceu atribuições para a Secretaria, incluindo a supervisão da harmonização entre a SEAS e o INEA. [Decreto nº 50.330](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/06/9-DECRETO-No-50.329-DE-12-DE-JUNHO-DE-2026-SEPPEN.pdf)
- **02/07/2026:** o TCE-RJ determinou a retenção de R$ 3.693.431,29 do contrato nº 024/2024 do INEA e exigiu correção das referências salariais e conferência da quantidade de trabalhadores nas medições. [TCE-RJ bloqueia R$ 3,6 milhões](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/)
- **10/07/2026 e 13/07/2026:** o TCE-RJ suspendeu as relações formais entre a SEAS e o Instituto Chaya por indícios de irregularidades na parceria de R$ 23 milhões; o G1 informou que a contratação não foi concluída e o convênio não foi firmado. [TCE-RJ suspende parceria](https://temporealrj.com/tce-rj-mira-parceria-de-r-23-milhoes/) [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml)
- **08/10/2026:** a SEAS informou estar reformulando o sistema de licenciamento e priorizando servidores de carreira e decisões técnicas. [Rio busca virar página na área ambiental](https://valor.globo.com/brasil/noticia/2026/10/08/rio-busca-virar-pagina-na-area-ambiental-com-gestao-tecnica-e-novos-regramentos.ghtml)
- **26/10/2026:** ato publicado no Diário Oficial determinou multa de R$ 4.989.669,69 à Construtora Metropolitana por descumprimento de obrigações do contrato de macrodrenagem; a obra seguia em execução em novembro de 2026. [Inea pune a Construtora Metropolitana](https://clickpetroleoegas.com.br/quase-r-5-milhoes-de-multa-20-do-que-faltava-pagar-inea-pune-a-construtora-metropolitana-responsavel-por-obra-contra-enchentes-na-zona-oeste-do-rio-que-tinha-previsao-de-btl96-mhbb01/)

##### Lacunas da pesquisa

- Solicitar ao INEA o andamento e a situação financeira do contrato nº 024/2024, o valor já pago e retido, as medições revisadas, a conferência do efetivo em campo, as providências sobre o BDI e a carga tributária e o status das defesas e manifestações perante o TCE-RJ, pois as fontes não informam esses desdobramentos. [TCE-RJ bloqueia R$ 3,6 milhões](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/)
- Solicitar à SEAS e ao INEA o cronograma atualizado, o avanço físico-financeiro e os riscos operacionais da obra dos rios Registro e Viegas, além da situação da multa e de eventuais recursos, pois as fontes registram atraso, execução em curso e multa, mas não apresentam esses dados. [Inea pune a Construtora Metropolitana](https://clickpetroleoegas.com.br/quase-r-5-milhoes-de-multa-20-do-que-faltava-pagar-inea-pune-a-construtora-metropolitana-responsavel-por-obra-contra-enchentes-na-zona-oeste-do-rio-que-tinha-previsao-de-btl96-mhbb01/)
- Solicitar à SEAS a situação processual atual do projeto Conexão Ambiental, as manifestações apresentadas ao TCE-RJ e a confirmação de que não houve assinatura, repasse ou execução, pois as fontes informam suspensão e ausência de conclusão do convênio, mas não trazem atualização posterior. [TCE-RJ suspende parceria](https://temporealrj.com/tce-rj-mira-parceria-de-r-23-milhoes/) [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml)
- Solicitar ao MPRJ informação pública atualizada sobre a investigação de suspeitas de corrupção em licenciamentos, inclusive eventual oferecimento de denúncia ou ação judicial, pois as fontes apenas informam a realização de operação e a investigação de 11 pessoas. [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml)
- Solicitar à SEAS o quadro atualizado de pessoal, vacâncias, distribuição de servidores, estágio de implantação da nova estrutura e indicadores de continuidade de serviços, pois as fontes relatam exonerações e mudanças organizacionais, mas não seus efeitos operacionais. [G1: TCE suspende convênio de R$ 23 milhões](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml) [Decreto nº 50.330](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/06/9-DECRETO-No-50.329-DE-12-DE-JUNHO-DE-2026-SEPPEN.pdf)
- Nada encontrado nas fontes consultadas sobre passivos ou dívidas consolidados da SEAS e do INEA, ações judiciais em curso contra os órgãos, ou um levantamento geral de contratos e serviços essenciais além dos casos descritos acima. [Rio busca virar página na área ambiental](https://valor.globo.com/brasil/noticia/2026/10/08/rio-busca-virar-pagina-na-area-ambiental-com-gestao-tecnica-e-novos-regramentos.ghtml) [O Dia: mudanças no Inea](https://odia.ig.com.br/rio-de-janeiro/2026/05/7245885-governador-interino-do-rio-substitui-toda-a-direcao-do-inea-por-servidores-de-carreira.html)

##### Fontes consultadas
1. [TCE-RJ bloqueia R$ 3,6 milhões em contrato do INEA por encontrar indícios de superfaturamento](https://temporealrj.com/tce-rj-bloqueia-3-milhoes-inea-processos/) — 2026-07-02
2. [TCE aponta falhas e suspende convênio de R$ 23 milhões - G1](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/07/13/tce-suspende-convenio-de-r-23-milhoes-da-secretaria-do-ambiente-do-rj-por-indicios-de-irregularidades.ghtml) — 2026-07-13
3. [Quase R$ 5 milhões de multa, 20% do que faltava pagar: Inea pune a Construtora Metropolitana, responsável por ](https://clickpetroleoegas.com.br/quase-r-5-milhoes-de-multa-20-do-que-faltava-pagar-inea-pune-a-construtora-metropolitana-responsavel-por-obra-contra-enchentes-na-zona-oeste-do-rio-que-tinha-previsao-de-btl96-mhbb01/) — 2026-11-03
4. [PARTE I PODER EXECUTIVO www.rj.gov.br S U M Á R I O ...](https://www.transparencia.rj.gov.br/wp-content/uploads/2026/06/9-DECRETO-No-50.329-DE-12-DE-JUNHO-DE-2026-SEPPEN.pdf) — 2026-07-28
5. [ PDF  ANEXO II - Governo do Estado do Rio de Janeiro](https://www.rj.gov.br/seas/sites/default/files/arquivos_paginas/SEI_124137298_Anexo_2.pdf) — 2026-03-06
6. [Governador em exercício do Rio substitui toda a direção do Inea por ...](https://odia.ig.com.br/rio-de-janeiro/2026/05/7245885-governador-interino-do-rio-substitui-toda-a-direcao-do-inea-por-servidores-de-carreira.html) — 2026-05-05
7. [Rio busca virar página na área ambiental com gestão técnica ...](https://valor.globo.com/brasil/noticia/2026/10/08/rio-busca-virar-pagina-na-area-ambiental-com-gestao-tecnica-e-novos-regramentos.ghtml) — 2026-10-08
8. [TCE-RJ suspende parceria de R$ 23 milhões entre governo do estado e instituto para projeto ambiental](https://temporealrj.com/tce-rj-mira-parceria-de-r-23-milhoes/) — 2026-07-10


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2025009558 (LECARD ADMNISTRADORA DE CARTÕES LTDA) vence em 18/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2025009272 (VCS IMPLEMENTOS E VEÍCULOS LTDA) vence em 19/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2024008855 (BETA-I BRASIL CONSULTORIA EM INOVAÇÃO E…) vence em 21/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2025010336 (2R DATATEL TELEINFORMÁTICA LTDA) vence em 10/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2014006702 (IMPERIAL ADMINISTRAÇÃO E CONTABILIDADE …) vence em 19/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
7. Contrato 2023004812 (CONSTRUVERDE CONSTRUCOES E SERVICOS EIR…, R$ 55,3 mi) consta 'Ativo' no SIGA com fim em 30/12/2024: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2023002225 (VOLUME PARTICIPACOES, PRODUCOES E EVENT…, R$ 37,0 mi) consta 'Ativo' no SIGA com fim em 16/03/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2024002818 (SERPEN SERVIÇOS E PROJETOS DE ENGENHARI…, R$ 26,4 mi) consta 'Ativo' no SIGA com fim em 20/09/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2024008375 (ERWIL CONSTRUÇÃO LTDA, R$ 11,0 mi) consta 'Ativo' no SIGA com fim em 20/08/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Contrato 2025005346 (MMAR MONTAGENS EVENTOS E PROGRAMACAO VI…, R$ 7,0 mi) consta 'Ativo' no SIGA com fim em 18/11/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
12. Qual é o plano de contingência para o contrato 2026000232 com CONSTRUTORA LYTORANEA LTDA - EM RECUPER… (em recuperação judicial)? Garantia contratual está válida?
13. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
14. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
15. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
16. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
17. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
