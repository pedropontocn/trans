# Dossiê de transição — Secretaria de Estado da Mulher (SEM)

**Gerado em:** 06/11/2026 17:38 · **Base SIGA extraída em:** 06/11/2026 · **Pesquisa aprofundada:** incluída (gerada em 06/11/2026)
**Fontes automáticas:** [SIGA — base de contratos do Estado](https://www.compras.rj.gov.br/siga/imagens/CONTRATOS.CSV) · [Portal de Dados Abertos RJ](https://dadosabertos.rj.gov.br/organization/sem)

> Atenção: o SIGA registra a vigência informada pelo órgão e frequentemente NÃO reflete termos aditivos de prazo. Contratos marcados como 'vencido no SIGA' precisam ser confirmados no DOERJ antes de qualquer conclusão.

## 1. Painel de urgência
| Indicador | Qtde | Valor |
|---|---|---|
| Contratos 'Ativo' no SIGA | 52 | R$ 25.331.821,12 |
| Com vigência futura (válidos no SIGA) | 15 | R$ 12.454.329,23 |
| até 30 dias | 2 | R$ 3.412.597,33 |
| até 60 dias | 1 | R$ 600.000,00 |
| até 90 dias | 1 | R$ 388.800,00 |
| até 180 dias | 1 | R$ 83.526,30 |
| vencido no SIGA | 37 | R$ 12.877.491,89 |
| sem data | 5 | R$ 633.430,60 |
| Fornecedores em recuperação judicial | 0 | R$ 0,00 |
| Emergenciais vigentes | 0 | R$ 0,00 |
| Empenhado / liquidado / pago (acumulado SIGA) | — | R$ 0,3 mi / R$ 0,0 mi / R$ 0,0 mi |

## 2. ALERTAS VERMELHOS (automáticos)
- Contrato 2024009216 (FUNDAÇÃO UNIVERSITÁRIA JOSE BONIFACIO) vence em 24/11/2026 — 18 dias — R$ 2.470.517,33. Objeto: CONTRATAÇÃO DE CONSULTORIA TÉCNICAESPECIALIZADA PARA ELABORAÇÃO, DESENVOLVIMENT…
- Mais 1 contratos menores (R$ 0,9 mi) vencem em até 30 dias — ver seção 3.
- 5 contratos (R$ 4,5 mi) vencem entre hoje e 90 dias após a posse (01/01/2027): renovação ou nova licitação precisa ser decidida agora.
- 34 contratos 'Ativo' no SIGA venceram nos últimos 24 meses (R$ 12,7 mi); 0 acima de R$ 10,0 mi. Confirmar termos aditivos no DOERJ ou se há execução sem cobertura contratual.
- 3 registros 'Ativo' com vigência encerrada há mais de 2 anos (R$ 0,2 mi): provável falta de baixa no SIGA (risco de controle, não de execução).
- Concentração: PLUXEE BENEFICIOS BRASIL S.A. detém 36% do valor vigente (1 contratos).

## 3. Vencimentos nos próximos 90 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2024009216 | SEMPI | FUNDAÇÃO UNIVERSITÁRIA JOSE BONIFACIO | CONTRATAÇÃO DE CONSULTORIA TÉCNICAESPECIALIZADA PARA ELABORAÇÃO, DESE… | R$ 2.470.517,33 | 24/11/2026 (PNCP) | 18 |
| 2024009538 | SEMPI | INSTITUTO MAPEAR (MASCULINIDADES, PATERNIDAD… | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA, COM NOTÓRIO SABER EM CAPACITAÇÃ… | R$ 942.080,00 | 29/11/2026 (PNCP) | 23 |
| 2025010866 | SEMPI | LIVRE DE ASSÉDIO LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM CAPACITAÇÃO E TREINAMENTO PAR… | R$ 600.000,00 | 26/12/2026 (PNCP) | 50 |
| 2023007991 | SEMPI | HADDAD RENT A CAR LOCADORA LTDA | Serviços de Locação Veículo Automotor Categoria Representação RP02 Ca… | R$ 388.800,00 | 04/02/2027 | 90 |

## 4. Vencimentos entre 91 e 180 dias
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026000476 | SEMPI | HOLZ CONFECÇÕES LTDA. | Aquisição de Uniformes Personalizados, de forma a atender às necessid… | R$ 83.526,30 | 10/03/2027 | 124 |

## 5. 'Ativo' no SIGA com vigência encerrada nos últimos 24 meses (confirmar aditivos no DOERJ)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2025002241 | SEMPI | IMPRENSA OFICIAL DO ESTADO DO RIO DE JANEIRO | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM CONFECÇÃO E IMPRESSÃO DE MATE… | R$ 2.065.690,00 | 10/06/2026 (PNCP) | -149 |
| 2025005730 | SEMPI | INSTITUTO AQUILA DE GESTÃO LTDA. | CONSULTORIA PARA CAPACITAÇÃO DE SERVIDORES | R$ 1.385.000,00 | 18/08/2026 (PNCP) | -80 |
| 2025005118 | SEMPI | FUNDAÇÃO SANTA CABRINI | CONTRATAÇÃO DE PRESTAÇÃO DE SERVIÇO DE FORNECIMENTO DE COFFE BREAK | R$ 1.240.040,00 | 23/07/2026 (PNCP) | -106 |
| 2024008775 | SEMPI | LIVRE DE ASSÉDIO LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM CAPACITAÇÃO E TREINAMENTO PAR… | R$ 1.068.639,05 | 04/11/2025 (PNCP) | -367 |
| 2025005635 | SEMPI | CEMAFER PRODUÇÕES LTDA | PARTICIPAÇÃO DA SEM NO SEMINÁRIO INTEGRA/RJ | R$ 1.000.000,00 | 29/09/2025 (PNCP) | -403 |
| 2024007444 | SEMPI | SOCIEDADE DE ENSINO SUPERIOR ESTACIO DE SA L… | Contratação de empresa especializada em solução educacional para pres… | R$ 821.197,56 | 01/10/2026 (PNCP) | -36 |
| 2026000856 | SEMPI | 43812093 THAMYRIS MACHARETH ELPIDIO | SERVIÇOS DE CONSULTORIA ESTRATÉGICA E CURADORIA INSTITUCIONAL | R$ 800.000,00 | 26/08/2026 (PNCP) | -72 |
| 2026001418 | SEMPI | FALA ENTRETENIMENTO E EVENTOS | CONTRATAÇÃO DE EMPRESA PARA PARTICIPAÇÃO DA SEM NO EVENTO DENOMINADO … | R$ 760.000,00 | 04/06/2026 (PNCP) | -155 |
| 2025009552 | SEMPI | FALA ENTRETENIMENTO E EVENTOS | Contratação de empresa para participação da SEM no evento denominado … | R$ 450.000,00 | 17/02/2026 | -262 |
| 2024008294 | SEMPI | FALA ENTRETENIMENTO E EVENTOS | Contratação de empresa para participação da SEM no evento denominado … | R$ 380.000,00 | 09/01/2025 | -666 |
| 2025003268 | SEMPI | FALA ENTRETENIMENTO E EVENTOS | Contratação de empresa para participação da SEM no evento denominado … | R$ 380.000,00 | 27/08/2025 | -436 |
| 2025007982 | SEMPI | FALA ENTRETENIMENTO E EVENTOS | Contratação de empresa para participação da SEM no evento denominado … | R$ 380.000,00 | 03/01/2026 | -307 |
| 2024008412 | SEMPI | WEBTRIP AGÊNCIA DE VIAGENS E TURISMO EIRELI | Solicitação para consumo da Ata de Registro de Preços nº 001/2024 , p… | R$ 355.200,00 | 24/10/2025 | -378 |
| 2025002018 | SEMPI | ARCHOTE VIGILANCIA E SEGURANÇA PATRIMONIAL L… | CONTRATAÇÃO EMERGENCIAL DE PRESTAÇÃO DE SERVIÇOS DE VIGILÂNCIA ARMADA… | R$ 336.272,88 | 03/04/2026 | -217 |
| 2025008643 | SEMPI | NEW QUALITY EVENTOS E MARKETING PROMOCIONAL … | PARTICIPAÇÃO INSTITUCIONAL DA SECRETARIA DE ESTADO DA MULHER (SEM) NA… | R$ 300.000,00 | 22/10/2026 | -15 |
| 2025005597 | SEMPI | CIDADE INOVADORA LTDA | CONTRATAÇÃO DE CONSULTORIA TÉCNICA ESPECIALIZADA DE NATUREZA EMINENTE… | R$ 273.616,20 | 05/09/2026 | -62 |
| 2023005875 | SEMPI | PRIME CONSULTORIA E ASSESSORIA EMPRESARIAL L… | Contratação de serviços continuados de gestão do abastecimento com ut… | R$ 224.386,50 | 08/02/2025 | -636 |
| 2023001985 | SEMPI | INTELIGÊNCIA ARTIFICIAL TECNOLOGIA E REFRIGE… | Registro de preços visando a contratação de empresa especialiada na p… | R$ 101.946,58 | 16/04/2025 | -569 |
| 2024010077 | SEMPI | RC CARD SOLUCOES EM PAGAMENTOS LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇOS DE EMIS… | R$ 63.360,00 | 06/12/2025 | -335 |
| 2025003647 | SEMPI | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | CAPACITAÇÃO/CURSO PARA SERVIDORESDASECRETARIA DE ESTADO DA MULHER DO … | R$ 54.000,00 | 30/09/2025 | -402 |
| 2024006516 | SEMPI | FUNDAÇÃO SANTA CABRINI | CONTRATAÇÃO DE PRESTAÇÃO DE SERVIÇO DE FORNECIMENTO DE COFFE BREAK | R$ 48.000,00 | 07/01/2026 | -303 |
| 2025001338 | SEMPI | FUNDAÇÃO SANTA CABRINI | Contratação de prestação de serviços de buffet para coffee break, vis… | R$ 46.080,00 | 21/09/2026 | -46 |
| 2024009375 | SEMPI | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | CONTRATAÇÃO DE SERVIÇO DE HOSPEDAGEM EM SERVIDORES VIRTUAIS PRIVADOS … | R$ 29.079,36 | 24/11/2025 | -347 |
| 2024008784 | SEMPI | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | PLANO DE HOSPEDAGEM WEB E GERENCIAMENTO DE SERVIDOR | R$ 25.916,00 | 12/12/2025 | -329 |
| 2025003651 | SEMPI | INSTITUTO NEGOCIOS PUBLICOS DO BRASIL - ESTU… | CAPACITAÇÃO/CURSO MASTERCLASS DE ENCONTRO DOS GESTORES DE CONVÊNIOS | R$ 22.140,00 | 27/08/2025 | -436 |
| 2026006754 | SEMPI | INSPER INSTITUTO DE ENSINO E PESQUISA | CAPACITAÇÃO PARA SERVIDORES PÚBLICOS | R$ 21.420,00 | 19/09/2026 | -48 |
| 2025001410 | SEMPI | GUARAILHA DISTRIBUIDORA DE ALIMENTOS LTDA EPP | AQUISIÇÃO DE GÊNEROS ALIMENTÍCIOS - CAFÉ | R$ 13.850,00 | 04/09/2026 | -63 |
| 2025000439 | SEMPI | INOVE CAPACITACAO E EVENTOS LTDA | CAPACITAÇÃO DE SERVIDORES | R$ 7.470,00 | 12/03/2025 | -604 |
| 2025008252 | SEMPI | CONTAGOV LTDA | CAPACITAÇÃO/CURSO MASTERCLASS DE IMERSÃO ESTRATÉGICA NAS FINANÇAS PÚB… | R$ 7.002,00 | 13/01/2026 | -297 |
| 2024010104 | SEMPI | PRODERJ - CENTRO DE TECNOLOGIA DE INFORMACAO… | PLANO DE HOSPEDAGEM WEB E GERENCIAMENTO DE SERVIDOR | R$ 6.853,56 | 12/12/2025 | -329 |

_Registros mais antigos (provável falta de baixa no SIGA): 3, R$ 0,2 mi. Lista completa em `dados/vencidos_no_siga.csv`._

## 6. Maiores contratos com vigência futura (top 15)
| Contrato | Unidade | Fornecedor | Objeto | Valor | Fim | Dias |
|---|---|---|---|---|---|---|
| 2026007692 | SEMPI | PLUXEE BENEFICIOS BRASIL S.A. | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA NA PRESTAÇÃO DE SERVIÇOS DE IMPL… | R$ 4.430.400,00 | 25/09/2027 | 323 |
| 2024009216 | SEMPI | FUNDAÇÃO UNIVERSITÁRIA JOSE BONIFACIO | CONTRATAÇÃO DE CONSULTORIA TÉCNICAESPECIALIZADA PARA ELABORAÇÃO, DESE… | R$ 2.470.517,33 | 24/11/2026 (PNCP) | 18 |
| 2025005123 | SEMPI | INSTITUTO MAPEAR (MASCULINIDADES, PATERNIDAD… | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA, COM NOTÓRIO SABER EM CAPACITAÇÃ… | R$ 1.476.920,00 | 29/07/2027 | 265 |
| 2024009538 | SEMPI | INSTITUTO MAPEAR (MASCULINIDADES, PATERNIDAD… | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA, COM NOTÓRIO SABER EM CAPACITAÇÃ… | R$ 942.080,00 | 29/11/2026 (PNCP) | 23 |
| 2026006661 | SEMPI | OTONI SEGURANÇA E SERVIÇOS LTDA | CONTRATAÇÃO DE PRESTAÇÃO DE SERVIÇOS DE VIGILÂNCIA ARMADA E/OU DESARM… | R$ 758.655,00 | 04/03/2029 | 849 |
| 2025010866 | SEMPI | LIVRE DE ASSÉDIO LTDA | CONTRATAÇÃO DE EMPRESA ESPECIALIZADA EM CAPACITAÇÃO E TREINAMENTO PAR… | R$ 600.000,00 | 26/12/2026 (PNCP) | 50 |
| 2026000802 | SEMPI | A & G SERVICOS MEDICOS LTDA | Contratação de empresa especializada em locação de veículo tipo van a… | R$ 504.000,00 | 13/07/2029 (PNCP) | 980 |
| 2023007991 | SEMPI | HADDAD RENT A CAR LOCADORA LTDA | Serviços de Locação Veículo Automotor Categoria Representação RP02 Ca… | R$ 388.800,00 | 04/02/2027 | 90 |
| 2025003011 | SEMPI | LIGHT SERVICOS DE ELETRICIDADE SA | TRATA-SE DA NECESSIDADE DE FORNECIMENTO DE ENERGIA ELÉTRICA, ASSEGURA… | R$ 180.000,00 | — |  |
| 2026006189 | SEMPI | LIGHT SERVICOS DE ELETRICIDADE SA | CONTRATAÇÃO DE EMPRESA PARA PRESTAÇÃO DE SERVIÇO DE FORNECIMENTO DE E… | R$ 180.000,00 | — |  |
| 2026001969 | SEMPI | COMUNIQUE ACESSIBILIDADE LTDA | O objeto da pretensa contratação é a prestação de serviço de tradução… | R$ 165.999,99 | 17/09/2027 | 315 |
| 2025002798 | SEMPI | AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA L… | CONTRATAÇÃO DO SERVIÇO CONTINUADODE DE OUTSOURCING PARA OPERAÇÃO DE A… | R$ 160.393,80 | — |  |
| 2025006109 | SEMPI | OFICINA VENTURA GARAGE CLUB LTDA | CONTRATAÇÃO DE EMPRESA PRESTADORA DE SERVIÇOS DE MANUTENÇÃO VEICULAR. | R$ 89.996,80 | — |  |
| 2026000476 | SEMPI | HOLZ CONFECÇÕES LTDA. | Aquisição de Uniformes Personalizados, de forma a atender às necessid… | R$ 83.526,30 | 10/03/2027 | 124 |
| 2026000561 | SEMPI | REFORCO DE GENEROS ALIMENTICIOS LTDA ME | AQUISIÇÃO DE GÊNEROS ALIMENTÍCIOS / KIT LANCHE | R$ 23.040,00 | — |  |

## 7. Fornecedores em recuperação judicial
_Nenhum registro._

## 8. Contratações emergenciais vigentes
_Nenhum registro._

## 9. Concentração por fornecedor (vigência futura)
| Fornecedor | Contratos | Valor |
|---|---|---|
| PLUXEE BENEFICIOS BRASIL S.A. | 1 | R$ 4.430.400,00 |
| FUNDAÇÃO UNIVERSITÁRIA JOSE BONIFACIO | 1 | R$ 2.470.517,33 |
| INSTITUTO MAPEAR (MASCULINIDADES, PATERNIDADES E ANTIRRACIS… | 2 | R$ 2.419.000,00 |
| OTONI SEGURANÇA E SERVIÇOS LTDA | 1 | R$ 758.655,00 |
| LIVRE DE ASSÉDIO LTDA | 1 | R$ 600.000,00 |
| A & G SERVICOS MEDICOS LTDA | 1 | R$ 504.000,00 |
| HADDAD RENT A CAR LOCADORA LTDA | 1 | R$ 388.800,00 |
| LIGHT SERVICOS DE ELETRICIDADE SA | 2 | R$ 360.000,00 |
| COMUNIQUE ACESSIBILIDADE LTDA | 1 | R$ 165.999,99 |
| AUTOPEL AUTOMAÇAO COEMERCIAL E INFORMATICA LTDA | 1 | R$ 160.393,80 |

## 10. Liquidado e ainda não pago (maiores saldos)
| Contrato | Fornecedor | Liquidado | Pago | Saldo |
|---|---|---|---|---|
| 2022006533 | DADY ILHA SOLUCOES INTEGRADAS LTDA | R$ 16.099,20 | R$ 13.416,00 | R$ 2.683,20 |

## 11. Unidades incluídas neste dossiê
- SEMPI - SECRETARIA DE ESTADO DA MULHER E POLITICAS INCLUSIVAS

## 12. Conjuntos de dados abertos da secretaria
- Nenhum conjunto encontrado no portal.

## 13. Pesquisa aprofundada (web, com citações)

Gerada em 06/11/2026 pela equipe (Perplexity Computer), com busca web e leitura de 6 fontes. Os fatos foram extraídos das fontes listadas abaixo; confirme os pontos críticos no documento original.

##### Resumo executivo
- Como proposta de prioridades para os primeiros 90 dias, podem ser considerados dois temas: a parceria para implantação das Salas Lilases e CEAMs, suspensa cautelarmente para apuração de possíveis irregularidades, e a formalização dos recursos de 2026 do Programa Empoderadas, enquanto mais de 200 profissionais relatam atraso nos salários. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/) [Empoderadas: recursos e salários](https://temporealrj.com/empoderadas-mulheres-sem-salario/)
- A auditoria citada sobre o Empoderadas apontou indícios de pagamentos indevidos e desvio de finalidade em 2025, mas a reportagem atribui os achados à auditoria do programa, não a irregularidades praticadas pela SEM. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml)
- As fontes não relatam decisão do TCE-RJ nem ação do MPRJ contra a SEM ou sobre os instrumentos aqui descritos; a auditoria do Empoderadas seria encaminhada a órgãos de controle, segundo informação do governo reproduzida pela reportagem. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml) [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- Para a futura estrutura, foi anunciado que a vice-governadora eleita Fernanda Louback comandará a Secretaria de Políticas Inclusivas e da Mulher, acumulando a função com a vice-governadoria. [Primeiros nomes do secretariado](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml)

##### Alertas vermelhos
- **Suspensão cautelar:** foi suspenso o Termo de Fomento nº 005/2026 com a AFIURJ, de valor informado pela reportagem como R$ 43 milhões, até a conclusão de apurações administrativas; estão vedados novos repasses, emissão de Ordem de Serviço, contratação de equipes e obras. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- **Valor divergente para a parceria:** reportagem anterior informa repasse de R$ 44.500.830,00 no Termo de Fomento nº 05/2026 à mesma entidade, enquanto a notícia da suspensão informa R$ 43 milhões e Termo nº 005/2026; as fontes não esclarecem a diferença entre os valores e a numeração. [Repasse de R$ 44,5 milhões](https://temporealrj.com/secretaria-mulher-garante-44-milhoes/) [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- **Risco de atendimento e renda no Empoderadas:** mais de 200 profissionais relataram estar sem salário desde janeiro de 2026, enquanto a formalização para liberar R$ 21,3 milhões previstos no orçamento de 2026 ainda não estava concluída; em julho, profissionais afirmaram que continuavam atendendo mulheres sem remuneração. [Empoderadas: recursos e salários](https://temporealrj.com/empoderadas-mulheres-sem-salario/) [Protesto de profissionais do Empoderadas](https://odia.ig.com.br/rio-de-janeiro/2026/07/7282807-sem-salario-ha-sete-meses-profissionais-do-empoderadas-fazem-protesto.html)
- **Achados de auditoria, não decisão definitiva:** auditoria da Casa Civil sobre a execução do Empoderadas em 2025 apontou indícios que somariam aproximadamente R$ 4,45 milhões, incluindo pagamentos adicionais a servidores e possível desvio de finalidade; a reportagem não apresenta decisão final de órgão de controle ou conclusão judicial. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml)

##### Contratos e serviços críticos
- **Salas Lilases e CEAMs:** o Termo de Fomento nº 005/2026 com a AFIURJ previa implantação e modernização de 20 Salas Lilases e três Centros Especializados de Atendimento à Mulher, por dois anos; a reportagem da suspensão informa valor de R$ 43 milhões e que R$ 15 milhões foram destinados inicialmente do orçamento do programa “Antes que Aconteça”. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- Outra reportagem informa R$ 44.500.830,00 para a parceria com a Afiur, com vigência de 24 meses e a mesma finalidade de implantação de 20 Salas Lilases e modernização de três CEAMs; a divergência com o valor e a identificação do termo na notícia de suspensão precisa ser esclarecida. [Repasse de R$ 44,5 milhões](https://temporealrj.com/secretaria-mulher-garante-44-milhoes/) [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- A suspensão impede, até a conclusão das apurações administrativas, novos repasses, a emissão de Ordem de Serviço, a contratação de equipes e a realização de obras. A reportagem informa que a medida interrompe um projeto destinado à implantação e modernização de unidades voltadas ao atendimento, mas não diz que unidades já estivessem em funcionamento nem que serviços existentes tenham sido interrompidos. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- **Programa Empoderadas:** R$ 21,3 milhões estavam previstos no orçamento estadual de 2026, mas dependiam da conclusão da formalização entre a SEM e a UERJ para liberação; as fontes não informam número, data, vigência ou empresa contratada para o instrumento. [Empoderadas: recursos e salários](https://temporealrj.com/empoderadas-mulheres-sem-salario/)
- Em reportagem publicada em 22/07, mais de 200 profissionais disseram estar sem receber desde janeiro; a matéria registra que elas continuavam os atendimentos e que relatórios, fotos, vídeos e outros registros foram anexados ao processo. Outra reportagem relata sete meses sem salário e uma manifestação, em uma segunda-feira (27), de representantes de quase 70 polos. [Empoderadas: recursos e salários](https://temporealrj.com/empoderadas-mulheres-sem-salario/) [Protesto de profissionais do Empoderadas](https://odia.ig.com.br/rio-de-janeiro/2026/07/7282807-sem-salario-ha-sete-meses-profissionais-do-empoderadas-fazem-protesto.html)
- A UERJ informou que a Resolução Conjunta não havia sido assinada e que não houve efetiva descentralização dos créditos orçamentários e financeiros pelo Governo do Estado; diante disso, a reitoria suspendeu novas atividades vinculadas ao programa. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml)

##### Pendências legais e de controle (TCE-RJ, MPRJ, Judiciário)
- Na contratação da AFIURJ, uma tentativa anterior por chamamento público foi anulada após a SUPEV apontar ausência de pesquisa de preços adequada na fase de planejamento, considerada vício insanável; após revisão do projeto, houve novo processo e a parceria foi firmada. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- Concorrentes questionaram a habilitação da AFIURJ, alegando que o perfil institucional e o estatuto priorizavam educação superior, e não o atendimento social e pericial de urgência previsto; a fonte relata o questionamento, não uma decisão que o confirme. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- A auditoria da Casa Civil sobre o Empoderadas em 2025 apontou indícios de aproximadamente R$ 4,45 milhões em pagamentos indevidos e desvio de finalidade; entre os achados, registrou R$ 2.920.264,16 em pagamentos adicionais brutos a 49 servidores da UERJ e da Secretaria de Desenvolvimento Social e Direitos Humanos. A reportagem não atribui esses achados à SEM como autora das irregularidades. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml)
- O governo informou que enviaria o resultado da auditoria do Empoderadas ao MPRJ, ao MPT e ao TCE-RJ; a fonte não confirma que o envio tenha ocorrido nem relata decisão desses órgãos sobre o caso. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml)
- Nada encontrado nas fontes consultadas sobre decisão do TCE-RJ relativa ao termo da AFIURJ, ação do MPRJ ou processo judicial relacionado à suspensão, à parceria ou aos impasses do Empoderadas. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/) [Empoderadas: recursos e salários](https://temporealrj.com/empoderadas-mulheres-sem-salario/) [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml)

##### Riscos de apagão administrativo
- A parceria das Salas Lilases e CEAMs não pode avançar em repasses, ordens de serviço, contratação de equipes ou obras enquanto durar a suspensão cautelar; não há prazo informado para conclusão das apurações. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- No Empoderadas, a falta de formalização e descentralização dos recursos de 2026 impedia o processamento financeiro, enquanto profissionais relataram salários em atraso; as fontes não informam data para regularização. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml) [Protesto de profissionais do Empoderadas](https://odia.ig.com.br/rio-de-janeiro/2026/07/7282807-sem-salario-ha-sete-meses-profissionais-do-empoderadas-fazem-protesto.html)
- O planejamento do projeto das Salas Lilases e CEAMs foi questionado por não constar originalmente no Plano de Contratações Anuais e por a contratação da gestão externa ter avançado enquanto ainda se elaborava o decreto estadual do programa “Antes que Aconteça”. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- A transferência do Empoderadas da Casa Civil para a recém-criada SEM exigiu revisão da documentação da parceria e reinício de parte dos procedimentos administrativos, segundo a reportagem. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml)
- As reportagens identificam a secretária como “Bia Pacheco” e “Bianca Pacheco”, sem esclarecer nominalmente a diferença. [Repasse de R$ 44,5 milhões](https://temporealrj.com/secretaria-mulher-garante-44-milhoes/) [Protesto de profissionais do Empoderadas](https://odia.ig.com.br/rio-de-janeiro/2026/07/7282807-sem-salario-ha-sete-meses-profissionais-do-empoderadas-fazem-protesto.html)

##### Fatos recentes
- Em 21/09/2026, a SEM determinou a suspensão cautelar da parceria com a AFIURJ para apurar possíveis irregularidades; a publicação da suspensão não informa prazo de conclusão das apurações. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- Em 03/11/2026, foi informado que Fernanda Louback, vice-governadora eleita, comandará a futura Secretaria de Políticas Inclusivas e da Mulher, acumulando o posto com a vice-governadoria, conforme já havia sido anunciado. [Primeiros nomes do secretariado](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml)
- A reportagem de 03/11 não apresenta informações sobre contratos, valores, decisões de controle, irregularidades ou riscos de interrupção de serviços relacionados à futura secretaria. [Primeiros nomes do secretariado](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml)

##### Lacunas da pesquisa
- Solicitar à SEM o instrumento integral e seus anexos da parceria com a AFIURJ, o valor oficial, a identificação correta do termo, os pagamentos já realizados, o saldo, o cronograma físico-financeiro e o estado das apurações, pois as fontes apresentam valores e numeração divergentes e não informam prazo para conclusão. [Repasse de R$ 44,5 milhões](https://temporealrj.com/secretaria-mulher-garante-44-milhoes/) [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- Solicitar o processo administrativo completo da contratação das Salas Lilases e CEAMs, incluindo pesquisa de preços, justificativa de habilitação da AFIURJ, inclusão no Plano de Contratações Anuais e situação do decreto do “Antes que Aconteça”, pontos questionados nas reportagens. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/)
- Solicitar a situação atual da formalização SEM–UERJ do Empoderadas, a Resolução Conjunta, a descentralização dos R$ 21,3 milhões, os valores de salários pendentes e a situação operacional dos polos, pois as fontes não informam previsão de regularização. [Empoderadas: recursos e salários](https://temporealrj.com/empoderadas-mulheres-sem-salario/) [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml) [Protesto de profissionais do Empoderadas](https://odia.ig.com.br/rio-de-janeiro/2026/07/7282807-sem-salario-ha-sete-meses-profissionais-do-empoderadas-fazem-protesto.html)
- Solicitar o relatório integral da auditoria do Empoderadas, as providências administrativas adotadas e comprovantes de eventual encaminhamento ao MPRJ, MPT e TCE-RJ, já que a fonte relata a intenção de envio, mas não confirma sua realização nem informa desfechos. [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml)
- Nada encontrado nas fontes consultadas sobre ações judiciais, decisões do TCE-RJ relativas à parceria da AFIURJ, dívida consolidada da SEM, execução orçamentária global, quadro de pessoal, inventário de contratos ou plano de continuidade dos serviços; esses itens devem ser solicitados à Secretaria. [Suspensão do contrato de R$ 43 milhões](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/) [Repasse de R$ 44,5 milhões](https://temporealrj.com/secretaria-mulher-garante-44-milhoes/) [Auditoria do Empoderadas](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml) [Primeiros nomes do secretariado](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml)


##### Fontes consultadas
1. [Secretaria da Mulher suspende contrato de R$ 43 milhões para ...](https://temporealrj.com/secretaria-mulher-suspende-contrato-irregularidade/) — 2026-09-21
2. [Nem só de tesourada vive o Guanabara: Secretaria Estadual da Mulher garante R$ 44,5 milhões para megaprojeto d](https://temporealrj.com/secretaria-mulher-garante-44-milhoes/) — 2026-08-05
3. [Programa Empoderadas: Auditoria do RJ aponta desvio de R$ 4,5 ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/08/13/auditoria-do-governo-do-rj-programa-empoderadas.ghtml) — 2026-08-13
4. [Empoderadas: irregularidades no contrato R$ 21,3 milhões do programa estadual deixam mais de 200 mulheres sem ](https://temporealrj.com/empoderadas-mulheres-sem-salario/) — 2026-07-22
5. [Sem salário há sete meses, profissionais do Empoderadas ...](https://odia.ig.com.br/rio-de-janeiro/2026/07/7282807-sem-salario-ha-sete-meses-profissionais-do-empoderadas-fazem-protesto.html) — 2026-07-27
6. [Douglas Ruas apresenta primeiros nomes do secretariado no ...](https://g1.globo.com/rj/rio-de-janeiro/noticia/2026/11/03/douglas-ruas-anuncia-parte-do-secretariado.ghtml) — 2026-11-03


## 14. Notas manuais e dados recebidos da secretaria
_Sem notas._

Arquivos em `recebidos_da_secretaria/`: nenhum.

## 15. Perguntas-chave para a secretaria / IA externa
1. Confirme a lista completa de contratos vigentes, com número, contratada, valor atualizado, vigência após o último termo aditivo e gestor/fiscal designado.
2. Contrato 2024009216 (FUNDAÇÃO UNIVERSITÁRIA JOSE BONIFACIO) vence em 24/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
3. Contrato 2024009538 (INSTITUTO MAPEAR (MASCULINIDADES, PATER…) vence em 29/11/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
4. Contrato 2025010866 (LIVRE DE ASSÉDIO LTDA) vence em 26/12/2026: há prorrogação em curso, nova licitação ou risco de interrupção?
5. Contrato 2023007991 (HADDAD RENT A CAR LOCADORA LTDA) vence em 04/02/2027: há prorrogação em curso, nova licitação ou risco de interrupção?
6. Contrato 2025002241 (IMPRENSA OFICIAL DO ESTADO DO RIO DE JA…, R$ 2,1 mi) consta 'Ativo' no SIGA com fim em 10/06/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
7. Contrato 2025005730 (INSTITUTO AQUILA DE GESTÃO LTDA., R$ 1,4 mi) consta 'Ativo' no SIGA com fim em 18/08/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
8. Contrato 2025005118 (FUNDAÇÃO SANTA CABRINI, R$ 1,2 mi) consta 'Ativo' no SIGA com fim em 23/07/2026: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
9. Contrato 2024008775 (LIVRE DE ASSÉDIO LTDA, R$ 1,1 mi) consta 'Ativo' no SIGA com fim em 04/11/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
10. Contrato 2025005635 (CEMAFER PRODUÇÕES LTDA, R$ 1,0 mi) consta 'Ativo' no SIGA com fim em 29/09/2025: qual termo aditivo vigente (nº, data DOERJ)? Há execução sem cobertura?
11. Quais serviços contínuos (limpeza, vigilância, TI, alimentação, transporte, saúde) dependem de contrato emergencial ou vencem até 31/03/2027?
12. Quais processos no TCE-RJ, ações civis públicas do MPRJ e ações judiciais com risco de bloqueio ou multa estão abertos?
13. Qual o volume de restos a pagar e de faturas liquidadas e não pagas por fornecedor?
14. Quais cargos-chave (ordenador de despesa, gestores e fiscais de contrato) ficarão vagos na transição e quais delegações vencem?
15. Quais convênios/transferências federais têm prazo de execução ou prestação de contas até 30/06/2027?

## 16. Arquivos de dados desta pasta
- `dados/contratos_ativos.csv` — todos os contratos 'Ativo' da secretaria e vinculadas, com faixa de vencimento.
- `dados/vencimentos_180d.csv` — somente os que vencem em até 180 dias.
- `dados/vencidos_no_siga.csv` — 'Ativo' com vigência encerrada (checar aditivos).
- `dados/historico_alteracoes.md` — o que mudou desde a última execução.

## 17. Limitações
- O SIGA cobre contratações registradas no sistema de compras; convênios, contratos de gestão (OS), concessões e parte das obras podem não constar.
- Valores são os do registro original; reajustes e aditivos de valor podem não estar lançados.
- Datas marcadas (PNCP) vêm do último termo publicado no Portal Nacional de Contratações Públicas, consultado automaticamente para contratos críticos (Lei 14.133).
- (PNCP: rescindido) indica Termo de Rescisão publicado no PNCP; (SIGA, diverge do PNCP) indica que o PNCP mostra fim anterior ao SIGA sem rescisão - confirmar no processo SEI.
- Datas marcadas (DOERJ) foram corrigidas manualmente em `config/correcoes_vigencia.csv`; acrescente ali cada aditivo confirmado.
- O vínculo unidade → secretaria está em `config/mapa_unidades.csv`; itens com 'confirmado=nao' devem ser checados.
