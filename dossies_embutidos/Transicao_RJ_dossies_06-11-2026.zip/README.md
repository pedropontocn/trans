# Transição RJ — Dossiês das Secretarias

- `dossies/`: 31 dossiês reduzidos (.md) + `00_CONSOLIDACAO_ESTADUAL.md`, todos preenchidos em 06/11/2026 com SIGA, vigências do PNCP, alertas e pesquisa web com citações.
- `scripts/gerar_dossies.py`: gera os modelos.
- `referencia/historico_conversa.jsonl`: histórico da sessão original (inclui dossiê completo da SECID).

Próximos passos: confirmar no DOERJ os contratos da Lei 8.666 sem confirmação (prioridade: contratos de gestão da SES) e incorporar os dados recebidos das secretarias.

## Dossiês automáticos (pipeline)
- `dossies_automaticos/`: um `DOSSIE_<SIGLA>.md` por secretaria, mais o `PAINEL_URGENCIAS.md` e as listas de vencimento em até 180 dias (`vencimentos_180d_estado.csv` e `dados_vencimentos/`).
- Gerados por `pipeline/transicao_rj.py` a partir da base SIGA de contratos e do portal de dados abertos do RJ.
- A seção 13 (pesquisa aprofundada, com citações) foi preenchida para as 31 secretarias em 06/11/2026. Os textos isolados estão em `dossies_automaticos/pesquisas/`. Em novas rodadas, o pipeline reaproveita `pesquisa/pesquisa_aprofundada.md` de cada pasta ou gera uma nova se houver chave da API da Perplexity.
- As vigências dos contratos críticos da Lei 14.133 são conferidas automaticamente no PNCP. Isso inclui prorrogações e rescisões. Só são aceitas rescisões críveis: publicadas até 120 dias antes do fim, ou depois dele, e sem aditivo posterior. Veja `referencia/VALIDACAO_PNCP_DOERJ_06-11-2026.md`.
- Revisão de qualidade de 06/11/2026: `referencia/REVISAO_QUALIDADE_06-11-2026.md`. Ela trouxe o recálculo independente, a conferência ao vivo no PNCP e a verificação de 380 afirmações dos alertas, além de corrigir a contagem de rescisões: são 4 (R$ 27,0 mi), e não 29.
- `dossies/`: versão reduzida de cada secretaria, derivada da rodada automática e da pesquisa.
Última atualização automática: 06/11/2026 17:03 (base SIGA extraída em 06/11/2026; PNCP consultado na mesma data; revisão de qualidade aplicada)
